IF ((SELECT	COUNT(*) 
	FROM	RunOnceIdentifiers
	WHERE	ID='78642D70-7BBD-48E8-980F-AF5258EB3950') = 0)
BEGIN

	DELETE usgf
	FROM SystemGrid sg
	INNER JOIN SystemGridGroup sgg ON sgg.SystemGridID = sg.ID
	INNER JOIN SystemGridField sgf ON sgf.SystemGridGroupID = sgg.ID
	INNER JOIN UserSystemGridField usgf ON usgf.SystemGridFieldID = sgf.ID
	WHERE sg.Name In('Natcat','RecommendationSummary','RiskQualityRatings')

	DELETE usgg
	FROM SystemGrid sg
	INNER JOIN SystemGridGroup sgg ON sgg.SystemGridID = sg.ID
	INNER JOIN UserSystemGridGroup usgg ON usgg.SystemGridGroupID = sgg.ID
	WHERE sg.Name In('Natcat','RecommendationSummary','RiskQualityRatings')


		   
-- make sure this script only runs once

PRINT('Applied Update: Release13_Sprint61_308607_Update Default_ColumnSettings_RecommendationsDetailsReport.sql')
INSERT INTO RunOnceIdentifiers
(ID) VALUES ('78642D70-7BBD-48E8-980F-AF5258EB3950')

END
GO

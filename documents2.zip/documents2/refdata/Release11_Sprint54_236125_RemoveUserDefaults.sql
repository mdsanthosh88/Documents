﻿IF ((SELECT	COUNT(*) 
	FROM	RunOnceIdentifiers
	WHERE	ID='BD5D42EF-2DA4-4824-AC95-39212086A414') = 0)
BEGIN

	DELETE usgf
	FROM SystemGrid sg
	INNER JOIN SystemGridGroup sgg ON sgg.SystemGridID = sg.ID
	INNER JOIN SystemGridField sgf ON sgf.SystemGridGroupID = sgg.ID
	INNER JOIN UserSystemGridField usgf ON usgf.SystemGridFieldID = sgf.ID
	WHERE sg.Name = 'RiskQualityRatings'

	DELETE usgg
	FROM SystemGrid sg
	INNER JOIN SystemGridGroup sgg ON sgg.SystemGridID = sg.ID
	INNER JOIN UserSystemGridGroup usgg ON usgg.SystemGridGroupID = sgg.ID
	WHERE sg.Name = 'RiskQualityRatings'

		   
-- make sure this script only runs once

PRINT('Applied Update: Release9_Sprint38_147877_RemoveUserDefaults.sql')
INSERT INTO RunOnceIdentifiers
(ID) VALUES ('BD5D42EF-2DA4-4824-AC95-39212086A414')

END
GO
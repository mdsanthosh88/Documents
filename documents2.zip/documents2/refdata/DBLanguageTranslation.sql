SET IDENTITY_INSERT [DBLanguageTables] ON
MERGE INTO [dbo].[DBLanguageTables] as t
    USING (
        VALUES
		 (1,'DataFilterField','DataFilterField_i18n','ID','DataFilterFieldID','DisplayName','Name','DataFilterFieldI18N'),
 (2,'DataFilterGroup','DataFilterGroup_i18n','ID','DataFilterGroupID','Name','Name','DataFilterGroupI18N'),
 (3,'DocumentType','DocumentType_i18n','ID','DocumentTypeID','Name','Name','DocumentTypeI18N'),
 (4,'FireDepartmentType','FireDepartmentType_i18n','LpFireDeptKey','LpFireDeptKey','Name','Name','FireDepartmentTypeI18N'),
 (5,'Frequency','Frequencyi18n','ID','FrequencyID','FrequencyString','FrequencyString','Frequencyi18N'),
 (6,'GroupType','GroupType_i18n','ID','LpDivGroupTypeKey','Name','Name','GroupTypeI18N'),
 (7,'ImpairmentRestorationMethod','ImpairmentRestorationMethod_i18n','ID','ImpairmentRestorationMethodID','Name','Name','ImpairmentRestorationMethodI18N'),
 (8,'ImpairmentSeverity','ImpairmentSeverity_i18n','ID','ImpairmentSeverityID','Name','Name','ImpairmentSeverityI18N'),
 (9,'ImpairmentStatus','ImpairmentStatus_i18n','ID','ImpairmentStatusID','Name','Name','ImpairmentStatusI18N'),
 (10,'ImpairmentSystemType','ImpairmentSystemType_i18n','ID','ImpairmentSystemTypeID','Name','Name','ImpairmentSystemTypeI18N'),
 (11,'ImpairmentTicketOriginType','ImpairmentTicketOriginType_i18n','ID','ImpairmentTicketOriginTypeID','Name','Name','ImpairmentTicketOriginTypeI18N'),
 (12,'ImpairmentType','ImpairmentType_i18n','ID','ImpairmentTypeID','Name','Name','ImpairmentTypeI18N'),
 (13,'IndustryClassification','IndustryClassification_i18n','LpOccupancyDetailedDescrKey','LpOccupancyDetailedDescrKey','Name','Name','IndustryClassificationI18N'),
 (14,'LossType','LossType_i18n','LpLossTypKey','LpLossTypKey','Name','Name','LossTypeI18N'),
 (15,'ManagementProgram','ManagementProgram_i18n','LpMgtSubPgmTypKey','LpMgtSubPgmTypKey','Name','Name','ManagementProgramI18N'),
 (16,'NotificationOption','NotificationOption_i18n','ID','NotificationOptionID','Description','Name','NotificationOptionI18N'),
 (17,'NotificationType','NotificationType_i18n','ID','NotificationTypeID','Description','Description','NotificationTypeI18N'),
 (18,'OverallRecommendationStatus','OverallRecommendationStatus_i18n','ID','OverallRecommendationStatusID','Name','Name','OverallRecommendationStatusI18N'),
 (19,'PredominantConstructionType','PredominantConstructionType_i18n1','LpPredomConsTypKey','LpPredomConsTypKey','Name','Name','PredominantConstructionTypeI18N1'),
 (20,'RatingType','RatingType_i18n','ID','RatingTypeID','Name','Name','RatingTypeI18N'),
 (21,'RecommendationCategory','RecommendationCategory_i18n','ID','RecommendationCategoryID','Name','Name','RecommendationCategoryI18N'),
 (22,'RecommendationClientIntent','RecommendationClientIntent_i18n','LpRecCustIntentKey','LpRecCustIntentKey','Name','Name','RecommendationClientIntentI18N'),
 (23,'RecommendationImpact','RecommendationImpact_i18n','LpEstEffRiskQualRtngKey','LpEstEffRiskQualRtngKey','Name','Name','RecommendationImpactI18N'),
 (24,'RecommendationProbability','RecommendationProbability_i18n','LpProbabilityKey','LpProbabilityKey','Name','Name','RecommendationProbabilityI18N'),
 (25,'RecommendationResponseStatus','RecommendationResponseStatus_i18n','ID','RecommendationResponseStatusID','Name','Name','RecommendationResponseStatusI18N'),
 (26,'RecommendationSource','RecommendationSource_i18n','ID','RecommendationSourceID','Name','Name','RecommendationSourceI18N'),
 (27,'RecommendationStatus','RecommendationStatus_i18n','LpRecStatusKey','LpRecStatusKey','Name','Name','RecommendationStatusI18N'),
 (28,'RecommendationType','RecommendationType_i18n','LprecSubRecTypKey','LpRecSubRecTypeKey','SubRecName','SubRecName','RecommendationTypeI18N'),
 (29,'ReportType','ReportType_i18n','ID','ReportTypeID','Name','Name','ReportTypeI18N'),
 (30,'RiskQualityCategory','RiskQualityCategory_i18n','ID','LpRiskQualRtngKey','Name','Name','RiskQualityCategoryI18N'),
 (31,'RiskQualityRatingType','RiskQualityRatingType_i18n','LpRatingCategoryKey','LpRatingCategoryKey','Description','Name','RiskQualityRatingTypeI18N'),
 (32,'RiskQualityRatingTypeDetail','RiskQualityRatingTypeDetail_i18n','LpRatingCategoryDtlKey','LpRatingCategoryDtlKey','Description','Name','RiskQualityRatingTypeDetailI18N'),
 (33,'SummaryReportType','SummaryReportType_i18n','ID','SummaryReportTypeID','Name','Name','SummaryReportTypeI18N'),
 (34,'SystemGridField','SystemGridField_i18n','ID','SystemGridFieldID','Name','Name','SystemGridFieldI18N'),
 (35,'SystemGridGroup','SystemGridGroup_i18n','ID','SystemGridGroupID','Name','Name','SystemGridGroupI18N'),
 (36,'ValueSourceType','ValueSourceType_i18n','LpSourceTypKey','LpSourceTypKey','Name','Name','ValueSourceTypeI18N'),
 (37,'WhatIfOptimisationType','WhatIfOptimisationType_i18n','ID','WhatIfOptimisationTypeID','Name','Name','WhatIfOptimisationTypeI18N'),
 (38,'DocumentTypeGroup','DocumentTypeGroup_i18n','ID','DocumentTypeGroupID','Name','Name','DocumentTypeGroupI18N')


    ) s ([ID],[SrcTableName],[DstTableName],[SourceKey],[DestKey],[SrcColumnName],[DstColumnName],[EntityColumnName])
        ON t.[ID] = s.[ID]
WHEN MATCHED AND (
        s.[SrcTableName] <> t.[SrcTableName]
		OR s.[DstTableName] <> t.[DstTableName]
        OR s.[SourceKey] <> t.[SourceKey]
        OR s.[DestKey] <> t.[DestKey]
		  OR s.[SrcColumnName] <> t.[SrcColumnName]
		    OR s.[DstColumnName] <> t.[DstColumnName]
			  OR s.[EntityColumnName] <> t.[EntityColumnName]
    )
    THEN 
        UPDATE
            SET [SrcTableName] = s.[SrcTableName]
			  ,[DstTableName] = s.[DstTableName]
			,[SourceKey] = s.[SourceKey]
            ,[DestKey] = s.[DestKey]
            ,[SrcColumnName] = s.[SrcColumnName]
			,[DstColumnName] = s.[DstColumnName]
			,[EntityColumnName] = s.[EntityColumnName]
			
WHEN NOT MATCHED BY TARGET
    THEN
        INSERT 
        (
            [ID]
            ,[SrcTableName]
			,[DstTableName]
            ,[SourceKey]
            ,[DestKey]
			,[SrcColumnName]
			,[DstColumnName]
			,[EntityColumnName]
        )
        VALUES 
        (
            [ID]
            ,[SrcTableName]
			,[DstTableName]
            ,[SourceKey]
            ,[DestKey]
			,[SrcColumnName]
			,[DstColumnName]
			,[EntityColumnName]
        )
WHEN NOT MATCHED BY SOURCE 
   THEN 
       DELETE;

GO
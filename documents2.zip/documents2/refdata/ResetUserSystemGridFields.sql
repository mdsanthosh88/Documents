﻿IF ((SELECT	COUNT(*) 
			FROM	RunOnceIdentifiers
			WHERE	ID='D6CF82B2-086B-432D-B891-51B0C4BE32A2') = 0)
		BEGIN

			DELETE UserSystemGridField
			DELETE UserSystemGridGroup

			-- make sure this script only runs once

			PRINT('Applied Update: ResetUserSystemGridFields.sql')
			INSERT INTO RunOnceIdentifiers
			(ID) VALUES ('D6CF82B2-086B-432D-B891-51B0C4BE32A2')

		END
﻿PRINT 'Populating Lookup Table [dbo].[DataFilterGroup]'

MERGE INTO [dbo].[DataFilterGroup] as t
    USING (
        VALUES
		(1,'Location',10,1,0)
        ,(2,'Survey',20,1,0)
        ,(3,'Recommendation',30,1,0)
        ,(4,'Loss Estimates',40,1,0)
        ,(5,'Natural Catastrophe',50,1,0)
        ,(6,'Mgmt Programs',60,1,0)
        ,(7,'Risk Quality Ratings',70,1,0)
        ,(8,'Construction',80,1,0)
        ,(9,'Protection',90,1,0)
		,(10,'LocationsPickerGroup',100,1,1)
    ) s ([ID],[Name],[Rank],[Active],[IsLocationsPickerGroup])
        ON t.[ID] = s.[ID]
WHEN MATCHED AND (
        s.[Name] <> t.[Name]
        OR s.[Rank] <> t.[Rank]
        OR s.[Active] <> t.[Active]
		OR s.[IsLocationsPickerGroup] <> t.[IsLocationsPickerGroup]
    )
    THEN 
        UPDATE
            SET [Name] = s.[Name]
              , [Rank] = s.[Rank]
              , [Active] = s.[Active]
			  , [IsLocationsPickerGroup] = s.[IsLocationsPickerGroup]
WHEN NOT MATCHED BY TARGET
    THEN
        INSERT 
        (
            [ID]
            ,[Name]
            ,[Rank]
            ,[Active]
			,[IsLocationsPickerGroup]
        )
        VALUES 
        (
            [ID]
            ,[Name]
            ,[Rank]
            ,[Active]
			,[IsLocationsPickerGroup]
        )
WHEN NOT MATCHED BY SOURCE 
   THEN 
       DELETE;

GO
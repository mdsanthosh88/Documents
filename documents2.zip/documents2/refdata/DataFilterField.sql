﻿PRINT 'Populating Lookup Table [dbo].[DataFilterField]'

MERGE INTO [dbo].[DataFilterField] as t
    USING (
        VALUES
		 
		(1,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'Location ID','LocationNo',10,1,   1,0,0,0,0,1,'nvarchar', 0),
		(2,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'Adr1','FullAddress',20,1,      0,0,0,0,1,0,'nvarchar', 0),
		(3,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'Adr2','FullAddress',30,1,      0,0,0,0,1,0,'nvarchar', 0),
		(4,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'City','City',40,1,      1,0,0,0,1,0,'nvarchar', 0),
		(5,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'State/Province','State',50,1,     1,0,0,0,1,0,'nvarchar', 0),
		(6,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'Country','CountryID',60,1,      1,0,0,0,1,0,'fklookup', 0),
		(7,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'Latitude','Latitude',70,1,      1,0,0,0,0,0,'decimal', 0),
		(8,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'SIC Code','SicCode',80,1,      1,1,1,1,0,0,'nvarchar', 0),
		(9,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'SIC Code (4 digit)','SicCode',90,0,      1,1,1,1,0,0,'fklookup', 0),
		(10,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'SIC Code Description','SicCodeDescription',100,1,  1,0,0,0,1,0,'nvarchar', 0),
		(11,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'Division','LpAcctWebDivKey',110,1,      1,0,0,0,0,0,'fklookup', 0),
		(12,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'Sub Division','LPsubDivKey',120,1,      1,0,0,0,0,0,'fklookup', 0),
		(13,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'ClientLocationNo','ClientLocationNo',130,1,      1,0,0,0,1,0,'nvarchar', 0),
		(14,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'Name','Name',140,1,      1,0,0,0,1,0 ,'nvarchar', 0),
		(15,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'Total Value','LocTotalValue',150,1,      1,1,1,1,0,0,'bigint', 0),
		(16,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'PD Value','LocPdValue',160,1,         1,1,1,1,0,0,'bigint', 0),
		(17,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'TE Value','LocTeValue',170,1,         1,1,1,1,0,0,'bigint', 0),
		(18,(SELECT ID FROM DataFilterGroup WHERE Name = 'Survey'),N'Last Survey Date','LastSurveyDate',180,1,   1,1,1,1,0,0,'datetime', 0),
		(19,(SELECT ID FROM DataFilterGroup WHERE Name = 'Survey'),N'Frequency','SurveyFrequencyInMonths',190,1,      1,0,0,0,0,0,'fklookup', 0),
		(20,(SELECT ID FROM DataFilterGroup WHERE Name = 'Survey'),N'Next Survey Due Date','NextSurveyDate',200,1,    1,1,1,1,0,0,'datetime', 0),
		(21,(SELECT ID FROM DataFilterGroup WHERE Name = 'Survey'),N'Survey Tentative Date','SurveyTentativeDate',210,1,   1,1,1,1,0,0,'datetime', 0),
		(22,(SELECT ID FROM DataFilterGroup WHERE Name = 'Survey'),N'Surveyed By','LastSurveyBy',220,1,      1,0,0,0,0,0,'fklookup', 0),
		(23,(SELECT ID FROM DataFilterGroup WHERE Name = 'Survey'),N'Published Date','SurveyPublishedDate',230,1,     1,1,1,1,0,0,'datetime', 0),
		(24,(SELECT ID FROM DataFilterGroup WHERE Name = 'Survey'),N'Turn Around Time (Days)','SurveyTurnaroundTimeInDays',240,1, 1,1,1,1,0,0,'nvarchar', 0),
		(25,(SELECT ID FROM DataFilterGroup WHERE Name = 'Survey'),N'Assigned To','NextSurveyAssignedTo',250,1,      1,1,1,1,0,0,'fklookup', 0),
		(26,(SELECT ID FROM DataFilterGroup WHERE Name = 'Survey'),N'Document Type','SurveyDocumentTypeID',260,1,      1,0,0,0,1,0,'fklookup', 0),
		(27,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Rec ID','RecID',270,1,      1,0,0,0,0,0,'nvarchar', 0),
		(28,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Type','LpRecSubRecTypKey',280,1,      1,0,0,0,1,0,'fklookup', 0),
		(29,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Category','RecommendationCategoryID',290,1,      1,0,0,0,0,0,'fklookup', 0),
		(30,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Priority','Priority',300,1,      1,0,0,0,0,0,'nvarchar', 0),
		(31,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Summary','Summary',310,1,      0,0,0,0,1,0,'nvarchar', 0),
		(32,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Issue Date','IssuedDate',320,1,     1,1,1,1,0,0,'datetime', 0),
		(33,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Complete Date','CompletedDate',330,1,   1,1,1,1,0,0,'datetime', 0),
		(34,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Recommendation Status','LpRecStatusKey',340,1,      1,0,0,0,0,0,'fklookup', 0),
		(35,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Probability','LpProbabilityKey',350,1,     1,0,0,0,0,0,'fklookup', 0),
		(36,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Customer Intent','LpRecCustIntentKey',360,1, 1,0,0,0,0,0,'fklookup', 0),
		(37,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Description','Description',370,1,     0,0,0,0,1,0,'nvarchar', 0),
		(38,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Before Completion Total','BeforeCompletionTotal',380,1,1,1,1,1,0,0,'bigint', 0),
		(39,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'After Completion Total','AfterCompletionTotal',390,1,1,1,1,1,0,0,'bigint', 0),
		(40,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Estimated Risk Reduction','EstRiskReduction',400,1,1,1,1,1,0,0,'bigint', 0),
		(41,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Est Cost Benefit Ratio','EstCostBenefitRatio',410,1,1,1,1,1,0,0,'bigint', 0),
		(42,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Estimated Effect Score','EstimatedEffectScore',420,1,1,1,1,1,0,0,'decimal', 0),
		(43,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Source Type','SourceType',430,1,     1,0,0,0,0,0,'fklookup', 0),
		(44,(SELECT ID FROM DataFilterGroup WHERE Name = 'Loss Estimates'),N'Loss Type','LpLossTypKey',440,1,      1,0,0,0,0,0,'fklookup', 0),
		(45,(SELECT ID FROM DataFilterGroup WHERE Name = 'Loss Estimates'),N'NLE Scenario','NLEScenario',450,1,      1,0,0,0,1,1,'nvarchar', 0),
		(46,(SELECT ID FROM DataFilterGroup WHERE Name = 'Loss Estimates'),N'PD Total','PdTotal',460,1,      1,1,1,1,0,0,'decimal', 0),
		(47,(SELECT ID FROM DataFilterGroup WHERE Name = 'Loss Estimates'),N'BI Total','BiTotal',470,1,      1,1,1,1,0,0,'decimal', 0),
		(48,(SELECT ID FROM DataFilterGroup WHERE Name = 'Loss Estimates'),N'PD Percent','PdPercent',480,1,    1,1,1,1,0,0,'decimal', 0),
		(49,(SELECT ID FROM DataFilterGroup WHERE Name = 'Loss Estimates'),N'BI Percent','BiPercent',490,1,    1,1,1,1,0,0,'decimal', 0),
		(50,(SELECT ID FROM DataFilterGroup WHERE Name = 'Loss Estimates'),N'Total Value','TotalValue',500,1,   1,1,1,1,0,0,'decimal', 0),
		(51,(SELECT ID FROM DataFilterGroup WHERE Name = 'Loss Estimates'),N'Total Percent','TotalPercent',510,1, 1,1,1,1,0,0,'decimal', 0),
		(52,(SELECT ID FROM DataFilterGroup WHERE Name = 'Natural Catastrophe'),N'Peril','NatCatTypeID',520,1,1,0,0,0,0,0,'fklookup', 0),
		(53,(SELECT ID FROM DataFilterGroup WHERE Name = 'Natural Catastrophe'),N'Hazard Rating','ExpectationLevel',530,1,1,0,0,0,0,0,'fklookup', 0),
		(54,(SELECT ID FROM DataFilterGroup WHERE Name = 'Mgmt Programs'),N'Category','LpMgtSubPgmTypKey',540,1,      1,0,0,0,0,0,'fklookup', 0),
		(55,(SELECT ID FROM DataFilterGroup WHERE Name = 'Mgmt Programs'),N'Rating','MgmtProgramsRating',550,1,      1,0,0,0,0,0,'fklookup', 0),
		(56,(SELECT ID FROM DataFilterGroup WHERE Name = 'Risk Quality Ratings'),N'Category','LpRiskQualRtngKey',560,1,  1,0,0,0,0,0,'fklookup', 0),
		(57,(SELECT ID FROM DataFilterGroup WHERE Name = 'Risk Quality Ratings'),N'Rating','RiskQualityRating',570,1,    1,0,0,0,0,0,'fklookup', 0),
		(58,(SELECT ID FROM DataFilterGroup WHERE Name = 'Construction'),N'Construction Category','LpPredomConsTypKey',580,1,1,0,0,0,0,0,'fklookup', 0),
		(59,(SELECT ID FROM DataFilterGroup WHERE Name = 'Construction'),N'Area','Area',590,1,      1,1,1,1,0,0,'decimal', 1),
		(60,(SELECT ID FROM DataFilterGroup WHERE Name = 'Construction'),N'Bldg Const Type','LpPredomConsTypKey',600,0,   1,0,0,0,0,0,'fklookup', 0),
		(61,(SELECT ID FROM DataFilterGroup WHERE Name = 'Construction'),N'Predom Year Built','PredominantYearBuilt',610,1, 1,1,1,1,0,0,'nvarchar', 0),
		(62,(SELECT ID FROM DataFilterGroup WHERE Name = 'Construction'),N'Predom Number of  Stories','PredominantNumOfStoreys',620,1,1,1,1,1,0,0,'int', 0),
		(63,(SELECT ID FROM DataFilterGroup WHERE Name = 'Protection'),N'Area Sprinklered','AreaSprinklered',630,1,    1,1,1,1,0,0,'decimal', 1),
		(64,(SELECT ID FROM DataFilterGroup WHERE Name = 'Protection'),N'Area Sprinklers Needed','AreaSprinklersNeeded',640,1,1,1,1,1,0,0,'decimal', 1),
		(65,(SELECT ID FROM DataFilterGroup WHERE Name = 'Protection'),N'Fire Dept Type','LpFireDeptKey',650,1,      1,0,0,0,0,0,'fklookup', 0),
		(66,(SELECT ID FROM DataFilterGroup WHERE Name = 'Protection'),N'Predom Water Supply','LpFireProtWaterSuplTypKey',660,1, 1,0,0,0,0,0,'fklookup', 0),
		(67,(SELECT ID FROM DataFilterGroup WHERE Name = 'Protection'),N'Predom Surveillance Type','LpPrdmSrvlTypKeyKey',670,1,1,0,0,0,0,0,'fklookup', 0),			
		(68,(SELECT ID FROM DataFilterGroup WHERE Name = 'Location'),N'Longitude','Longitude',71,1, 1,0,0,0,0,0,'decimal', 0),
		(69,(SELECT ID FROM DataFilterGroup WHERE Name = 'LocationsPickerGroup'),N'LP Database Location ID','LpAllPiKey',0,1, 1,0,0,0,0,0,'fklookup', 0),
		(70,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'LP Database Recommendation ID','LpRecKey',680,1,1,0,0,0,0,0,'fklookup', 0),		
		(71,(SELECT ID FROM DataFilterGroup WHERE Name = 'Risk Quality Ratings'),N'Current Site Rating','CurrentSiteRating',580,1, 1,1,1,1,0,0,'zerotoonehundred', 0),
		(72,(SELECT ID FROM DataFilterGroup WHERE Name = 'Risk Quality Ratings'),N'Rating Type','RatingType',590,1,    1,0,0,0,0,0,'fklookup', 0),
		(73,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Implementation Status','LpStatusCode',440,1,1,0,0,0,0,0,'fklookup', 0),
		(74,(SELECT ID FROM DataFilterGroup WHERE Name = 'Recommendation'),N'Response Status','RecommendationResponseStatusID',450,1,1,0,0,0,0,0,'fklookup', 0),
		(75,(SELECT ID FROM DataFilterGroup WHERE Name = 'Construction'),N'Predominant Construction Category','LPPredomConsTypKey',450,1,1,0,0,0,0,0,'fklookup', 0),
		(76,(SELECT ID FROM DataFilterGroup WHERE Name = 'Natural Catastrophe'),N'Earthquake Zones','NatCatRating',600,1,1,0,0,0,0,0,'fklookup', 0),
		(77,(SELECT ID FROM DataFilterGroup WHERE Name = 'Natural Catastrophe'),N'Flood Zones','NatCatRating',601,1,1,0,0,0,0,0,'fklookup', 0),
		(78,(SELECT ID FROM DataFilterGroup WHERE Name = 'Natural Catastrophe'),N'Windstorm  Zones','ExpectationLevel',602,1,1,0,0,0,0,0,'fklookup', 0),
		(79,(SELECT ID FROM DataFilterGroup WHERE Name = 'Loss Estimates'),N'PML Scenario','PMLScenario',451,1,      1,0,0,0,1,1,'nvarchar', 0),
		(80,(SELECT ID FROM DataFilterGroup WHERE Name = 'Loss Estimates'),N'MPL Scenario','MPLScenario',452,1,      1,0,0,0,1,1,'nvarchar', 0)

    ) s ([ID],[DataFilterGroupID],[DisplayName],[ExpressionName],[Rank],[Active],[CanApplyEquals],[CanApplyBetween],[CanApplyGreaterThan],[CanApplyLessThan],[CanApplyContains],[CanApplyDoesNotEqual],[DataType],[IsArea])
        ON t.[ID] = s.[ID]
WHEN MATCHED AND (
        s.[DisplayName] <> t.[DisplayName]
		OR s.[ExpressionName] <> t.[ExpressionName]
        OR s.[Rank] <> t.[Rank]
        OR s.[Active] <> t.[Active]  
		OR s.[CanApplyEquals]			<>  t.[CanApplyEquals]
		OR s.[CanApplyBetween]			<>	t.[CanApplyBetween]
		OR s.[CanApplyGreaterThan]		<>	t.[CanApplyGreaterThan]
		OR s.[CanApplyLessThan]			<>	t.[CanApplyLessThan]
		OR s.[CanApplyContains]			<>	t.[CanApplyContains]
		OR s.[CanApplyDoesNotEqual]		<>	t.[CanApplyDoesNotEqual]
		OR s.[DataType]					<>  t.[DataType]
		OR s.[IsArea]					<>  t.[IsArea]
    )
    THEN 
        UPDATE
            SET [DataFilterGroupID]			= s.[DataFilterGroupID]
			  , [DisplayName]				= s.[DisplayName]
			  , [ExpressionName]		    = s.[ExpressionName]
              , [Rank]						= s.[Rank]
              , [Active]					= s.[Active]  
			  , [CanApplyEquals]		    = s.[CanApplyEquals]
		   	  , [CanApplyBetween]	        = s.[CanApplyBetween]
		   	  , [CanApplyGreaterThan]       = s.[CanApplyGreaterThan]
		   	  , [CanApplyLessThan]	        = s.[CanApplyLessThan]
		   	  , [CanApplyContains]	        = s.[CanApplyContains]
		   	  , [CanApplyDoesNotEqual]      = s.[CanApplyDoesNotEqual]
			  , [DataType]			        = s.[DataType]
			  , [IsArea]			        = s.[IsArea]


WHEN NOT MATCHED BY TARGET
    THEN
        INSERT 
        (
            [ID]
			,[DataFilterGroupID]
            ,[DisplayName]
			,[ExpressionName]
            ,[Rank]
            ,[Active]
            ,[CanApplyEquals]
            ,[CanApplyBetween]
            ,[CanApplyGreaterThan]
            ,[CanApplyLessThan]
            ,[CanApplyContains]
            ,[CanApplyDoesNotEqual]
            ,[DataType]
			,[IsArea]
        )
        VALUES 
        (
            [ID]
			,[DataFilterGroupID]
            ,[DisplayName]
			,[ExpressionName]
            ,[Rank]
            ,[Active]
            ,[CanApplyEquals]
            ,[CanApplyBetween]
            ,[CanApplyGreaterThan]
            ,[CanApplyLessThan]
            ,[CanApplyContains]
            ,[CanApplyDoesNotEqual]
            ,[DataType]
			,[IsArea]
        )
WHEN NOT MATCHED BY SOURCE 
   THEN 
       DELETE;

GO
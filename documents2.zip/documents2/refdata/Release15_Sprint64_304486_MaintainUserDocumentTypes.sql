﻿IF ((SELECT	COUNT(*) 
	FROM	RunOnceIdentifiers
	WHERE	ID='289A1137-DAE4-4022-ACC0-2475B277D9BC') = 0)
BEGIN

	-- 304486 for the new document types, give each user access so long as the document type is part of the 'Basic Package'
	INSERT INTO UserDocumentAccess
	SELECT		CreatedDate = GETUTCDATE(),
				CreatedBy = 1,
				UpdatedDate = GETUTCDATE(),
				UpdatedBy = 1,
				UserID = u.ID,
				DocumentTypeID = dt.ID 
	FROM		DocumentType dt
	CROSS JOIN	[User] u
	INNER JOIN	UserRole ur ON ur.UserID = u.ID
	WHERE		dt.Active = 1							-- Active document type
	AND			dt.IsMemberOfBasicPackage = 1			-- Part of Basic Package
	AND			(	(dbo.func_IsInternalUserRole(ur.RoleID) = 1 AND dt.InternalOnly = 1)		-- Internal user role and Interal only document type
				OR	
					dt.InternalOnly = 0															-- or document for Internal and External
				)
	AND	NOT EXISTS (	SELECT		uda.ID
						FROM		UserDocumentAccess uda
						WHERE		uda.UserID = u.ID
						AND			uda.DocumentTypeID = dt.ID)									-- not already present
   
-- make sure this script only runs once

PRINT('Release15_Sprint64_304486_MaintainUserDocumentTypes.sql')
INSERT INTO RunOnceIdentifiers
(ID) VALUES ('289A1137-DAE4-4022-ACC0-2475B277D9BC')

END
GO
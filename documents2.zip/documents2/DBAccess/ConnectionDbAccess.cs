﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using XLC.MyAnalysis2.DbModels;

namespace XLC.MyAnalysis2.DbAccess
{
    public class ConnectionDbAccess : BaseDataAccess
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<UserConnection> GetConnectionsForUser(int userId)
        {
            using (var db = new MA2DbContext())
            {
                return db.UserConnections.Where(item => item.UserID == userId).ToList();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<UserConnection> GetActiveConnectionsForUser(int userId)
        {
            using (var db = new MA2DbContext())
            {
                return db.UserConnections.Where(item => item.UserID == userId && item.Connected).ToList();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public List<UserConnection> GetActiveConnectionsForUsers(List<int> userIds)
        {
            using (var db = new MA2DbContext())
            {
                return db.UserConnections.Where(item => userIds.Contains(item.UserID) && item.Connected).ToList();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userIds"></param>
        /// <param name="connection"></param>
        /// <returns></returns>
        public List<UserConnection> GetActiveConnectionsForUsersExcludeConn(List<int> userIds, Guid connection)
        {
            using (var db = new MA2DbContext())
            {
                return db.UserConnections.Where(item => userIds.Contains(item.UserID) && item.Connected && item.ConnectionID != connection).ToList();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lPAcctKey"></param>
        /// <returns></returns>
        public List<UserConnection> GetActiveConnectionsForLpAcctKey(int lPAcctKey)
        {
            using (var db = new MA2DbContext())
            {
                return db.UserConnections.Where(item => item.LpAcctKey == lPAcctKey && item.Connected).ToList();
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<UserConnection> GetActiveUsers()
        {
            using (var db = new MA2DbContext())
            {
                return db.UserConnections.Where(item => item.Connected).ToList();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="connectionId"></param>
        /// <param name="userAgent"></param>
        /// <param name="lPAcctKey"></param>
        /// <returns></returns>
        public bool AddConnection(int userId, Guid connectionId, string userAgent, int? lPAcctKey)
        {
            using (var db = new MA2DbContext())
            {
                var connection = new UserConnection
                {
                    UserID = userId,
                    ConnectionID = connectionId,
                    UserAgent = userAgent.Length > 512 ? userAgent.Substring(0, 512) : userAgent,
                    Connected = true,
                    LpAcctKey = lPAcctKey
                };

                UpsertUserConnection(connection, userId);
            };

            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public UserConnection UpsertUserConnection(UserConnection entity, int userId)
        {
            UserConnection result = null;

            try
            {
                using (var db = new MA2DbContext())
                {
                    var existing = db.UserConnections.FirstOrDefault(e => e.ID == entity.ID);

                    if (existing != null)
                    {
                        existing.UserID = entity.UserID;
                        existing.ConnectionID = entity.ConnectionID;
                        existing.UserAgent = entity.UserAgent;
                        existing.Connected = entity.Connected;
                        existing.LpAcctKey = entity.LpAcctKey;
                        existing.UpdatedDate = DateTime.UtcNow;
                        existing.UpdatedBy = userId;
                        result = existing;
                    }
                    else
                    {
                        entity.CreatedDate = DateTime.UtcNow; // this would be done by interceptor
                        entity.UpdatedDate = DateTime.UtcNow;
                        entity.CreatedBy = userId;
                        entity.UpdatedBy = userId;

                        result = db.UserConnections.Add(entity);
                    }

                    db.SaveChanges();
                }
            }
            catch (DbEntityValidationException e)
            {
                throw new Exception(Helpers.FormatValidationErrors(e));
                throw e;
            }


            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionId"></param>
        /// <returns></returns>
        public bool RemoveConnection(Guid connectionId)
        {
            using (var db = new MA2DbContext())
            {
                var connection = db.UserConnections.Where(item => item.ConnectionID == connectionId).SingleOrDefault();

                if (connection != null)
                {
                    db.UserConnections.Remove(connection);
                    db.SaveChanges();
                }
            };

            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="now"></param>
        /// <returns></returns>
        public bool CleanupConnections(DateTime now)
        {
            var connectionPurgeThreshold = now.AddDays(-1);

            using (var db = new MA2DbContext())
            {
                var oldConnections = (from item in db.UserConnections
                                      where (!item.Connected || (item.Connected && item.CreatedDate < connectionPurgeThreshold))
                                      select item).ToList();

                foreach (var connection in oldConnections)
                    db.UserConnections.Remove(connection);

                db.SaveChanges();
            };

            return true;
        }
    }
}

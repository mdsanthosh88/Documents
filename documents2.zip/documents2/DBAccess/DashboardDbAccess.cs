﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbAccess.ExtensionMethods;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.DbModels.DbEnums;
using XLC.MyAnalysis2.Resources;
using XLC.MyAnalysis2.Shared;
using static XLC.MyAnalysis2.DbModels.DbConstants.Constants;

namespace XLC.MyAnalysis2.DbAccess
{
    /// <summary>
    /// 
    /// </summary>
    public class DashboardDbAccess : BaseDataAccess
    {
        #region Load

        public IQueryable<ViewDataFilter> LoadLocationDataForCurrentFiltersBaseQuery(MA2DbContext db, DataFilter locationsSelectorDataFilter, DataFilter dataFilter)
        {
            IQueryable<ViewDataFilter> qry = null;
            qry = db.ViewDataFilters;
            qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

            return qry;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <returns></returns>
        public List<DashboardRecommendationByStatusData> LoadTileRecommendationByStatusData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, int lpAcctkey)
        {
            ReferenceDbAccess reference = new ReferenceDbAccess();
            var statuses = reference.GetRecommendationStatuses().Where(item => item.ID != RecommendationStatus.Unknown).OrderBy(x => x.Rank);
            var results = new List<ProcGetRecommendationsByImplementationStatusReturnModel>();
            var series = new List<DashboardRecommendationByStatusData>();

            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                List<int> locationIds = null;
                List<int?> lpRecKeys = (from exposure in qry select exposure.LpRecKey).Distinct().ToList();

                // lpRecKeys should only ever be used as a filter from the drill through. If we have a large list then set the value to All
                // otherwise there is a detrimental impact on performance


                locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecommendationsByImplementationStatus]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", lpAcctkey));


                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };


                    DataTable dataTableLpRecKeys = ConvertNullableIntListToDataTable(lpRecKeys);
                    var lpRecKeysParam = new SqlParameter("@LpRecKeyList", dataTableLpRecKeys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(lpRecKeysParam);


                    command.Parameters.Add(new SqlParameter("@AsAtDate", DateTime.Now));

                    command.Parameters.Add(locationIdsParam);

                    command.Parameters.Add(new SqlParameter("@NoPlansOrDisagreeGrouping", RecommendationStatus.NoPlansOrDisagreeValidated));
                    command.Parameters.Add(new SqlParameter("@VerifiedCompleteGrouping", RecommendationStatus.VerifiedComplete));
                    command.CommandTimeout = 500;

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            results = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ProcGetRecommendationsByImplementationStatusReturnModel>(reader)
                                .ToList();
                        }

                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }

                var listResults = new List<DashboardRecommendationByStatusData>();
                if (results != null)
                {
                    listResults.AddRange(results.Select(x => new DashboardRecommendationByStatusData
                    {
                        RecommendationStatusId = x.RecommendationStatusID ?? 0,
                        Total = x.Count ?? 0,
                    }));

                    var reswithNoplans = listResults
                            .Where(i => i.RecommendationStatusId == -1

                                   && i.RecommendationStatusId == 3)
                            .ToList();

                    var reswithNoplansValidated = listResults.Where(x => x.RecommendationStatusId == -1).ToList();
                    var reswithNoplansClient = listResults.Where(x => x.RecommendationStatusId == 3).ToList();

                    if (reswithNoplansClient != null && reswithNoplansValidated != null)
                    {
                        if (reswithNoplansValidated.Count > 0 || reswithNoplansClient.Count > 0)
                        {
                            var totalcount = 0;

                            if (reswithNoplansValidated.Count > 0)
                                totalcount += reswithNoplansValidated[0].Total;

                            if (reswithNoplansClient.Count > 0)
                                totalcount += reswithNoplansClient[0].Total;

                            var reswithNoplansValidateandClient = new List<DashboardRecommendationByStatusData>();
                            if (reswithNoplansClient.Count > 0)
                            {
                                reswithNoplansValidateandClient = reswithNoplansClient.Select(x => new DashboardRecommendationByStatusData
                                {
                                    RecommendationStatusId = x.RecommendationStatusId,
                                    Total = totalcount,
                                }).ToList();
                            }
                            else if (reswithNoplansValidated.Count > 0)
                            {

                                reswithNoplansValidateandClient = reswithNoplansValidated.Select(x => new DashboardRecommendationByStatusData
                                {
                                    RecommendationStatusId = 3,
                                    Total = totalcount,
                                }).ToList();

                            }


                            var resWoNoplans = listResults.Where(x => x.RecommendationStatusId != -1).Where(x => x.RecommendationStatusId != 3).ToList();

                            var res = resWoNoplans.Union(reswithNoplansValidateandClient).ToList();

                            // foreach status in our list, add a new series to the output
                            foreach (var status in statuses)
                            {
                                var total = (from item in res
                                             where item.RecommendationStatusId == status.ID
                                             select item.Total).SingleOrDefault();

                                series.Add(new DashboardRecommendationByStatusData
                                {
                                    RecommendationStatusId = status.ID,
                                    RecommendationStatusName = status.Name,
                                    Total = total
                                });
                            }
                        }
                        else
                        {

                            // foreach status in our list, add a new series to the output
                            foreach (var status in statuses)
                            {
                                var total = (from item in listResults
                                             where item.RecommendationStatusId == status.ID
                                             select item.Total).SingleOrDefault();

                                series.Add(new DashboardRecommendationByStatusData
                                {
                                    RecommendationStatusId = status.ID,
                                    RecommendationStatusName = status.Name,
                                    Total = total
                                });
                            }

                        }
                    }


                }

            }

            return series;
        }

        /// <summary>
        /// USER STORY 109973
        /// Gather main data for Dashboard NATCAT tile
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <returns></returns>
        public List<DashboardNatCatData> LoadTileNaturalCatastropheData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter)
        {
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            List<DashboardNatCatData> result = null;

            var reference = new ReferenceDbAccess();
            var natCatTypesList = reference.GetNatCatTypes(localeSpecific: true);       //Localised Nat Cat Types

            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                var locationIds =
                (from exposure in qry
                 select exposure.LpAllPiKey).Distinct().ToList();

                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetDashboardNatCatData]";
                    command.CommandType = CommandType.StoredProcedure;

                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };
                    command.Parameters.Add(locationIdsParam);

                    command.Parameters.Add(new SqlParameter("@NatCatTypeIDToExclude", (int)Constants.NatCatType.Other));

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<DashboardNatCatData>(reader)
                                .ToList();
                        }
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error("Error occured while reading the data in LoadTileNaturalCatastropheData method.", ex);
                        throw ex;
                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }

                    result.ForEach(r =>
                    {
                        r.ExpectationLevelNameLocalised = GetExpectationNameLocalised(r.ExpectationLevel);
                        r.NatCatTypeNameLocalised = natCatTypesList.Single(nct => nct.ID == r.NatCatTypeID).Name;
                    });
                }
            }

            return result;
        }

        private string GetExpectationNameLocalised(int expectationLevel)
        {
            switch (expectationLevel)
            {
                case 1:
                    return WebPageResources.Dashboard_RiskRating_Negligible;
                case 2:
                    return WebPageResources.Dashboard_RiskRating_Low;
                case 3:
                    return WebPageResources.Dashboard_RiskRating_Moderate;
                case 4:
                    return WebPageResources.Dashboard_RiskRating_High;
                case 5:
                    return WebPageResources.Dashboard_RiskRating_NE;
                default:
                    throw new NotImplementedException("Invalid expectationLevel");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <returns></returns>
        public List<DashboardLoadHighestFireLossEstimatesData> LoadHighestFireLossEstimatesData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter)
        {
            using (var db = new MA2DbContext())
            {
                // Always start with this block
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                // Then either filter further or join with another query
                var results =
                (from rec in qry
                 join loc in db.LocationLossEstimates on rec.LocationLossEstimateID equals loc.ID into set
                 from locationlossestimate in set.DefaultIfEmpty()
                 where rec.LocationLossEstimateID != null &&
                 locationlossestimate.LossTypeID == Constants.LossType.Fire
                 select new
                 {
                     locationlossestimate.ID,
                     locationlossestimate.NleTotal,
                     locationlossestimate.PmlTotal,
                     locationlossestimate.MflTotal,
                     locationlossestimate.AalTotal,
                     locationlossestimate.ArcTotal
                 }).Distinct().ToList();

                var nle = results.OrderByDescending(x => x.NleTotal).FirstOrDefault();
                var pml = results.OrderByDescending(x => x.PmlTotal).FirstOrDefault();
                var mpl = results.OrderByDescending(x => x.MflTotal).FirstOrDefault();

                DashboardLoadHighestFireLossEstimatesData nleJson = null;
                if (nle != null) nleJson = GetHighestFireLossEstimatesScenarioData(nle.ID, ScenarioType.Nle);

                DashboardLoadHighestFireLossEstimatesData pmlJson = null;
                if (pml != null) pmlJson = GetHighestFireLossEstimatesScenarioData(pml.ID, ScenarioType.Pml);

                DashboardLoadHighestFireLossEstimatesData mflJson = null;
                if (mpl != null) mflJson = GetHighestFireLossEstimatesScenarioData(mpl.ID, ScenarioType.Mpl);


                var series = new List<DashboardLoadHighestFireLossEstimatesData>()
                {
                    nleJson,
                    pmlJson,
                    mflJson,
                };

                return series.OrderBy(x => x.Order).ToList();
            }
        }

        public List<DashboardCitran> LoadCitranData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, int resultsToDisplay)
        {
            using (var db = new MA2DbContext())
            {
                // Always start with this block
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                // Then either filter further or join with another query


                var results =
                     (from rec in qry
                      where rec.LpRecStatusKey == OverallRecommendationStatus.Active
                      join x in db.Recommendations on
                             new { p1 = rec.RecommendationID.Value }
                             equals
                             new { p1 = x.ID }

                      select x)

                     .OrderByDescending(x => x.LossEstimateBefore)
                     .Include("Location")
                     .Distinct()
                     .Where(x => x.RecommendationCategoryID == Constants.RecommendationCategory.PhysicalProtection)
                     .Select(x => new DashboardCitran
                     {
                         LocationNo = x.Location.LocationNo,
                         LocationCode = x.Location.LocationCode,
                         CustomerLocationID = x.Location.ClientLocationNo,
                         LocationName = x.Location.Name,
                         LocationAddress = x.Location.AddressLine1 + ", " + x.Location.City + ", " + x.Location.State + ", " + x.Location.Country,
                         LpRecKey = x.LpRecKey,
                         LpAllPiKey = x.LpAllPiKey,
                         RecID = x.RecID,
                         RecommendationSummary = x.Summary,
                         LEBefore = x.LossEstimateBefore,
                         LEAfter = x.LossEstimateAfter,
                         RiskReduction = x.RiskReduction,
                         EstimatedCost = x.EstCostToComplete,
                         RCBAScenario = "",
                         PdBefore = x.PdBefore,
                         PdAfter = x.PdAfter,
                         BiBefore = x.BiBefore,
                         BiAfter = x.BiAfter,
                         EeBefore = x.EeBefore,
                         EeAfter = x.EeAfter
                     }).OrderByDescending(x => x.LEBefore).Take(resultsToDisplay).Where(x => x.LEBefore != null && !(x.LEBefore == 0)).ToList();


                return results;
            }
        }

        public IQueryable<Impairment> LoadDashboardImpairmentByStatusData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, MA2DbContext db, int lpAcctKey)
        {
            IQueryable<Impairment> results = null;

            if (locationsSelectorDataFilter != null)
            {
                // Always start with this block
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                // Then either filter further or join with another query
                results =
                    (from rec in qry
                     join imp in db.Impairments on rec.ImpairmentID equals imp.ID
                     select imp).Distinct();
            }
            else
            {
                results = db.Impairments.Where(x => x.LpAllPiKey == null);
            }

            results = results.Where(x => x.LpAcctKey == lpAcctKey);

            return results;
        }

        public IQueryable<Impairment> LoadDashboardImpairmentByStatusTableData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, MA2DbContext db, int lpAcctKey)
        {
            IQueryable<Impairment> results = null;

            if (locationsSelectorDataFilter != null)
            {
                // Always start with this block
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                // Then either filter further or join with another query
                results =
                    (from rec in qry
                     join imp in db.Impairments on rec.ImpairmentID equals imp.ID
                     select imp).Include("ImpairmentSeverity").Include("Location").Include("ImpairmentSystemType").Distinct();
            }
            else
            {
                results = db.Impairments.Where(x => x.LpAllPiKey == null);
            }

            results = results.Where(x => x.LpAcctKey == lpAcctKey);

            return results;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="tileId"></param>
        /// <returns></returns>
        public UserSystemTile LoadUserSystemTile(int userId, int tileId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<UserSystemTile> qry = null;
                qry = db.UserSystemTiles;
                qry = qry.Where(item => item.UserID == userId);
                qry = qry.Where(item => item.SystemTileID == tileId);

                return qry.SingleOrDefault();
            }
        }


        /// <summary>
        /// Retrieves a grouping and count based on account id and languageCode
        /// </summary>
        /// <returns></returns>
        public IList<CopeByConstructionType> LoadCopeTile(DataFilter locationsSelectorDataFilter, DataFilter dataFilter)
        {
            IList<CopeByConstructionType> copeByConstructionType = null;

            // Always start with this block
            IQueryable<ViewDataFilter> qry = null;

            using (MA2DbContext mA2DbContext = new MA2DbContext())
            {
                qry = mA2DbContext.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);
                IQueryable<int> lpAllPiKeys = qry.Select(q => q.LpAllPiKey);

                copeByConstructionType = mA2DbContext.ViewCopeTiles
                    .Where(vct => lpAllPiKeys.Contains(vct.LpAllPiKey))
                    .GroupBy(vct => new { vct.LpPredomConsTypKey })

                    .Select(ct =>
                    new CopeByConstructionType
                    {
                        LPPredomConsTypKey = ct.Key.LpPredomConsTypKey,
                        Count = ct.Count()
                    }).ToList();
            }

            return copeByConstructionType;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tileId"></param>
        /// <returns></returns>
        public SystemScreen LoadSystemScreenBySystemTileId(int tileId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<SystemTile> qry = null;
                qry = db.SystemTiles;
                qry = qry.Include(item => item.SystemScreen);
                qry = qry.Where(item => item.ID == tileId);

                var tile = qry.SingleOrDefault();

                return tile != null ? tile.SystemScreen : null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="systemScreenId"></param>
        /// <returns></returns>
        public List<UserSystemTile> LoadUserSystemTilesForUser(int userId, int systemScreenId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<UserSystemTile> qry = null;
                qry = db.UserSystemTiles;
                qry = qry.Include(item => item.SystemTile);
                qry = qry.Where(item => item.UserID == userId);
                qry = qry.Where(item => item.SystemTile.SystemScreenID == systemScreenId);


                return qry.ToList();
            }
        }

        public List<AccountProfileDashboardAccessConfiguration> LoadUserSystemTiles(int lpAcctkey, int systemScreenId, int userId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<AccountProfileDashboardAccessConfiguration> qry = null;
                qry = db.AccountProfileDashboardAccessConfigurations;
                qry = qry.Include(item => item.SystemTile);
                qry = qry.Where(item => item.LpAcctKey == lpAcctkey);
                qry = qry.Where(item => item.SystemTile.SystemScreenID == systemScreenId);
                qry = qry.Where(item => item.IsSelected == true);

                return qry.ToList();

            }
        }

        public List<SystemTile> LoadSystemTilesForAdmin(int systemScreenId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<SystemTile> qry = null;
                qry = db.SystemTiles;
                qry = qry.Where(item => item.SystemScreenID == systemScreenId);

                return qry.ToList();
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="systemScreenId"></param>
        /// <returns></returns>
        public List<SystemTile> LoadSystemTilesForScreen(int systemScreenId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<SystemTile> qry = null;
                qry = db.SystemTiles;
                qry = qry.Where(item => item.SystemScreenID == systemScreenId);

                return qry.ToList();
            }
        }

        #endregion

        #region Save

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userSystemTile"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public UserSystemTile UpsertUserSystemTile(UserSystemTile userSystemTile, int userId)
        {
            UserSystemTile result = null;

            try
            {
                using (var db = new MA2DbContext())
                {
                    var existing = db.UserSystemTiles.FirstOrDefault(e => e.ID == userSystemTile.ID);

                    if (existing != null)
                    {
                        existing.UserID = userSystemTile.UserID;
                        existing.SystemTileID = userSystemTile.SystemTileID;
                        existing.GridX = userSystemTile.GridX;
                        existing.GridY = userSystemTile.GridY;
                        existing.GridWidth = userSystemTile.GridWidth;
                        existing.GridHeight = userSystemTile.GridHeight;
                        existing.Visible = userSystemTile.Visible;

                        existing.UpdatedDate = DateTime.UtcNow;
                        existing.UpdatedBy = userId;

                        result = existing;
                    }
                    else
                    {
                        userSystemTile.UserID = userId;
                        userSystemTile.CreatedDate = DateTime.UtcNow; // this would be done by interceptor
                        userSystemTile.UpdatedDate = DateTime.UtcNow;
                        userSystemTile.CreatedBy = userId;

                        result = db.UserSystemTiles.Add(userSystemTile);
                    }

                    db.SaveChanges();
                }
            }
            catch (DbEntityValidationException e)
            {
                throw new Exception(Helpers.FormatValidationErrors(e));
                throw e;
            }


            return result;
        }


        #endregion

        #region Helpers

        /// <summary>
        /// 
        /// </summary>
        /// <param name="LocationLossEstimateId"></param>
        /// <param name="scenarioType"></param>
        /// <returns></returns>
        private DashboardLoadHighestFireLossEstimatesData GetHighestFireLossEstimatesScenarioData(int LocationLossEstimateId, ScenarioType scenarioType)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<DbModels.LocationLossEstimate> qry = null;
                qry = db.LocationLossEstimates;
                qry = qry.Where(item => item.ID == LocationLossEstimateId);
                qry = qry.Include(item => item.Location);
                qry = qry.Include(item => item.Location.Division);
                qry = qry.Include(item => item.Location.IndustryClassification);
                var estimate = qry.SingleOrDefault();
                int? order = null;
                decimal? value = null;
                decimal? pdPercent = null;
                decimal? biPercent = null;
                int? tlPercent = null;
                decimal? pdAmount = null;
                decimal? biAmount = null;
                decimal? tlAmount = null;
                string scenario = string.Empty;
                string name = string.Empty;
                string locationaddress = $"{estimate.Location.AddressLine1}, {estimate.Location.City}, {estimate.Location.Country}";
                string locationno = estimate.Location.LocationNo;
                string locationcode = estimate.Location.LocationCode;

                switch (scenarioType)
                {
                    case ScenarioType.Nle:
                        value = estimate.NleTotal;
                        pdPercent = estimate.NlePdPercentage;
                        biPercent = estimate.NleBiPercentage;
                        tlPercent = GetLossEstimatePercentOfTiv(estimate.NleTotal, estimate.Location);
                        pdAmount = estimate.NlePdValue;
                        biAmount = estimate.NleBiValue;
                        tlAmount = estimate.NleTotal;
                        scenario = "NLE"; // NOTE: in line with changes to User Story 109986 - Normal Maximum Loss (NML) has been changed to NLE 
                        name = WebPageResources.Dashboard_HflEstimates_Nle;
                        order = 3;
                        break;
                    case ScenarioType.Arc:
                        value = estimate.ArcTotal;
                        pdPercent = estimate.ArcPdPercentage;
                        biPercent = estimate.ArcBiPercentage;
                        tlPercent = 0;
                        pdAmount = estimate.ArcPdValue;
                        biAmount = estimate.ArcBiValue;
                        tlAmount = estimate.ArcTotal;
                        scenario = "ARC";
                        name = WebPageResources.Dashboard_HflEstimates_Arc;
                        break;
                    case ScenarioType.Pml:
                        value = estimate.PmlTotal;
                        pdPercent = estimate.PmlPdPercentage;
                        biPercent = estimate.PmlBiPercentage;
                        tlPercent = GetLossEstimatePercentOfTiv(estimate.PmlTotal, estimate.Location);
                        pdAmount = estimate.PmlPdValue;
                        biAmount = estimate.PmlBiValue;
                        tlAmount = estimate.PmlTotal;
                        scenario = "PML";
                        name = WebPageResources.Dashboard_HflEstimates_Pml;
                        order = 2;
                        break;
                    case ScenarioType.Mpl:
                        value = estimate.MflTotal;
                        pdPercent = estimate.MflPdPercentage;
                        biPercent = estimate.MflBiPercentage;
                        tlPercent = GetLossEstimatePercentOfTiv(estimate.MflTotal, estimate.Location);
                        pdAmount = estimate.MflPdValue;
                        biAmount = estimate.MflBiValue;
                        tlAmount = estimate.MflTotal;
                        scenario = "MPL"; // NOTE: in line with changes to User Story 109986 - MFL (Maximum Foreseable Loss) has since been renamed to Maximum Probable Loss
                        name = WebPageResources.Dashboard_HflEstimates_Mfl;
                        order = 1;
                        break;
                    case ScenarioType.Aal:
                        value = estimate.AalTotal;
                        pdPercent = estimate.AalPdPercentage;
                        biPercent = estimate.AalBiPercentage;
                        tlPercent = 0;
                        pdAmount = estimate.AalPdValue;
                        biAmount = estimate.AalBiValue;
                        tlAmount = estimate.AalTotal;
                        scenario = "AAL";
                        name = WebPageResources.Dashboard_HflEstimates_Aal;
                        break;
                }

                // build results including data used in tooltip
                return new DashboardLoadHighestFireLossEstimatesData
                {
                    Total = value,
                    DivisionName = estimate.Location.Division?.Name,
                    LocatioName = estimate.Location.Name,
                    ClientLocatioNo = estimate.Location.ClientLocationNo,
                    SicCode = estimate.Location.IndustryClassification.SicCode,
                    Address = estimate.Location.FullAddress,
                    PdAmount = FormatHelper.FormatCurrency(pdAmount),
                    PdPercent = pdPercent,
                    BiAmount = FormatHelper.FormatCurrency(biAmount),
                    BiPercent = biPercent,
                    TlAmount = FormatHelper.FormatCurrency(tlAmount),
                    TlPercent = tlPercent,
                    Scenario = scenario,
                    Name = name,
                    Order = order,
                    LocationAddress = locationaddress,
                    LocationCode = locationcode,
                    LocationNo = locationno
                };
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="scenarioTotal"></param>
        /// <param name="location"></param>
        /// <returns></returns>
        private int GetLossEstimatePercentOfTiv(decimal? scenarioTotal, Location location)
        {
            var result = 0;

            if ((location.PdValue == null && location.BiValue == null) || (location.PdValue == 0 && location.BiValue == 0))
                return result;

            result = (int)Math.Round(scenarioTotal.GetValueOrDefault(0) /
                (location.PdValue.GetValueOrDefault(0) + location.BiValue.GetValueOrDefault(0)) *
                100, 0, MidpointRounding.AwayFromZero);

            return result;
        }

        #endregion

        #region Test

        /// <summary>
        /// 
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <returns></returns>
        public List<ViewDataFilter> GetFilterResults(DataFilter locationsSelectorDataFilter, DataFilter dataFilter)
        {
            using (var db = new MA2DbContext())
            {
                // Always start with this block
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                // Then either filter further or join with another query
                return (from rec in qry select rec).ToList();
            }
        }

        #endregion
    }
}
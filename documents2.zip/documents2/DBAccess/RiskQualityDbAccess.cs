﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Linq;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbAccess.ExtensionMethods;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.DbModels.DbEnums;
using XLC.MyAnalysis2.Shared;

namespace XLC.MyAnalysis2.DbAccess
{
    public class RiskQualityDbAccess : BaseDataAccess
    {
        #region Load

        public IQueryable<LocationRiskQualityRating> LoadRiskQualityRatingDataForCurrentFilters(
            DataFilter locationsSelectorDataFilter, DataFilter dataFilter, MA2DbContext db)
        {
            IQueryable<LocationRiskQualityRating> results = null;

            db.Configuration.LazyLoadingEnabled = true;
            // Always start with this block
            IQueryable<ViewDataFilter> qry = null;
            qry = db.ViewDataFilters;
            qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

            var locationIds =
            (
                from rec in qry
                where rec.LocationRiskQualityRatingID != null
                join l in db.Locations on
                    new { p1 = rec.LpAllPiKey }
                    equals
                    new { p1 = l.LpAllPiKey }

                select l.ID).Distinct().ToList();

            var res =
            (
                from r in db.LocationRiskQualityRatings
                where locationIds.Contains(r.LocationID)
                select r
            );

            return res.Include("Location").Include("Location.FireDepartmentType")
                .Include("Location.PredominantConstructionType").Include("Location.Account.Currency").AsQueryable();


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <param name="lPAcctKey"></param>
        /// <param name="userId"></param>
        /// <param name="weightedAverage"></param>
        /// <returns></returns>
        public List<RiskQualityRatingBoxPlotQuartileData> LoadTileRiskQualityRatingData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, int lPAcctKey, int userId)
        {
            using (var db = new MA2DbContext())
            {
                var series = new List<RiskQualityRatingBoxPlotQuartileData>()
                {
                    GetLocationQuartileData(locationsSelectorDataFilter, dataFilter, lPAcctKey, db),
                    GetDivisionQuartileData(locationsSelectorDataFilter, dataFilter, lPAcctKey, userId, db),
                    GetAccountQuartileData(dataFilter, lPAcctKey, db)
                };

                return series.ToList();

            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="lPAcctKey"></param>
        /// <param name="dbContext"></param>
        /// <param name="allImprovementsInAccount"></param>
        /// <returns></returns>
        private RiskQualityRatingBoxPlotQuartileData GetAccountQuartileData(DataFilter dataFilter, int lPAcctKey, MA2DbContext dbContext)
        {
            var account = new RiskQualityRatingBoxPlotQuartileData
            {
                AccountLevel = AccountLevelEnum.Account,
                Type = GetAccountType(AccountLevelEnum.Account),
                CurrentTotal = GetAccountAverageRqr(lPAcctKey) * 10,
                Maximum = GetAccountMaximumRqr(lPAcctKey) * 10,
                UpperQuartile = GetAccountUpperQuartileRqr(lPAcctKey) * 10,
                Median = GetAccountMedianRqr(lPAcctKey) * 10,
                LowerQuartile = GetAccountLowerQuartileRqr(lPAcctKey) * 10,
                Minimum = GetAccountMinimumRqr(lPAcctKey) * 10
            };

            return account;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <param name="lPAcctKey"></param>
        /// <param name="dbContext"></param>
        /// <param name="allImprovementsInAccount"></param>
        /// <returns></returns>
        private RiskQualityRatingBoxPlotQuartileData GetLocationQuartileData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, int lPAcctKey, MA2DbContext dbContext)
        {
            IQueryable<ViewDataFilter> qry = dbContext.ViewDataFilters;
            qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);
            var locationIdsInCurrentFilter = (from result in qry select result.LpAllPiKey).Distinct().ToList();

            var location = new RiskQualityRatingBoxPlotQuartileData
            {
                AccountLevel = AccountLevelEnum.Location,
                Type = GetAccountType(AccountLevelEnum.Location),
                CurrentTotal = GetLocationAverageRqr(lPAcctKey, locationIdsInCurrentFilter, dbContext) * 10,
                Maximum = GetLocationMaximumRqr(lPAcctKey, locationIdsInCurrentFilter, dbContext) * 10,
                UpperQuartile =
                    GetLocationUpperQuartileRqr(lPAcctKey, locationIdsInCurrentFilter, dbContext) * 10,
                Median = GetLocationMedianRqr(lPAcctKey, locationIdsInCurrentFilter, dbContext) * 10,
                LowerQuartile =
                    GetLocationLowerQuartileRqr(lPAcctKey, locationIdsInCurrentFilter, dbContext) * 10,
                Minimum = GetLocationMinimumRqr(lPAcctKey, locationIdsInCurrentFilter, dbContext) * 10
            };

            return location;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="lPAcctKey"></param>
        /// <param name="userId"></param>
        /// <param name="dbContext"></param>
        /// <param name="allImprovementsInAccount"></param>
        /// <returns></returns>
        private RiskQualityRatingBoxPlotQuartileData GetDivisionQuartileData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, int lPAcctKey, int userId, MA2DbContext dbContext)
        {
            IQueryable<ViewDataFilter> qry = dbContext.ViewDataFilters;
            qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);
            var lpAcctWebDivKeyInCurrentFilter = qry.Where(loc => loc.LpAcctWebDivKey != null)
                .Select(loc => (int)loc.LpAcctWebDivKey)
                .Distinct()
                .ToList();

            var division = new RiskQualityRatingBoxPlotQuartileData
            {
                AccountLevel = AccountLevelEnum.Division,
                Type = GetAccountType(AccountLevelEnum.Division),
                CurrentTotal = GetDivisionAverageRqr(lpAcctWebDivKeyInCurrentFilter, lPAcctKey, userId) * 10,
                Maximum = GetDivisionMaximumRqr(lpAcctWebDivKeyInCurrentFilter, lPAcctKey, userId) * 10,
                UpperQuartile = GetDivisionUpperQuartileRqr(lpAcctWebDivKeyInCurrentFilter, lPAcctKey, userId) * 10,
                Median = GetDivisionMedianRqr(lpAcctWebDivKeyInCurrentFilter, lPAcctKey, userId) * 10,
                LowerQuartile = GetDivisionLowerQuartileRqr(lpAcctWebDivKeyInCurrentFilter, lPAcctKey, userId) * 10,
                Minimum = GetDivisionMinimumRqr(lpAcctWebDivKeyInCurrentFilter, lPAcctKey, userId) * 10
            };

            return division;
        }

        public List<RqrLevel4Data> LoadRqrLevel4Data(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, RatingTypesEnum ratingType, List<int> currentLocationCategoryRating, List<int> tivQuartilesFilter, List<int> showFilter, int? sinceFilter, DateTime asOfDate, int accountId, int lpAcctKey, string sortExpression, int pageSize, bool useLocationNo, int recordOffset, out int totalRows, DateTime surveyedDate, int userId, List<int> lpAllPiKeys = null)
        {
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            List<RqrLevel4Data> result = null;

            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                List<int> locationIds = null;

                if (lpAllPiKeys == null)
                {
                    locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                }
                else
                {
                    locationIds = lpAllPiKeys;
                }

                if (surveyedDate != DateTime.MinValue)
                {
                    locationIds = (qry.Where(x => x.LastSurveyDate >= surveyedDate).Select(y => y.LpAllPiKey)).Distinct().ToList();
                    asOfDate = DateTime.UtcNow;
                }


                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetLQRRQRLevelFourData]";
                    command.CommandType = CommandType.StoredProcedure;

                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(locationIdsParam);

                    var currentLocationCategoryRatingIds = ConvertIntListToDataTable(currentLocationCategoryRating);
                    var currentLocationCategoryRatingParam = new SqlParameter("@CurrentLocationCategoryRating", currentLocationCategoryRatingIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(currentLocationCategoryRatingParam);

                    var tivQuartileIds = ConvertIntListToDataTable(tivQuartilesFilter);
                    var tivQuartilesParam = new SqlParameter("@TIVQuartilesFilter", tivQuartileIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(tivQuartilesParam);

                    var showFilterIds = ConvertIntListToDataTable(showFilter);
                    var showFilterParam = new SqlParameter("@ShowFilter", showFilterIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(showFilterParam);

                    command.Parameters.Add(new SqlParameter("@SinceFilter", sinceFilter ?? Constants.RiskQualityRatingFilters.FilterSince.All));


                    command.Parameters.Add(new SqlParameter("@RatingPreference", (int)ratingType));
                    command.Parameters.Add(new SqlParameter("@AsOfDate", asOfDate));
                    command.Parameters.Add(new SqlParameter("@AccountID", accountId));
                    command.Parameters.Add(new SqlParameter("@lpAcctKey", lpAcctKey));
                    command.Parameters.Add(new SqlParameter("@UserID", userId));
                    command.Parameters.Add(new SqlParameter("@SortExpression", sortExpression.Split(' ')[0]));
                    command.Parameters.Add(new SqlParameter("@SortDirection", sortExpression.Contains("DESC") ? "DESC" : "ASC"));
                    command.Parameters.Add(new SqlParameter("@PageSize", pageSize));
                    command.Parameters.Add(new SqlParameter("@UseLocationNo", useLocationNo ? 1 : 0));
                    command.Parameters.Add(new SqlParameter("@TotalRows", SqlDbType.Int) { Direction = ParameterDirection.Output });
                    command.Parameters.Add(new SqlParameter("@StartRowIndex", recordOffset));
                    command.CommandTimeout = 800;

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<RqrLevel4Data>(reader)
                                .ToList();
                        }

                        var param = command.Parameters["@TotalRows"] as IDbDataParameter;
                        totalRows = param == null ? 0 : Convert.ToInt32(param.Value);
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error("Error occured while reading the data in LoadRqrLevel4Data method.", ex);
                        throw ex;
                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Calls stored procedure GetLQRRQRLevelThreeData
        ///
        /// Returns three Result Set Models as a RqrLevel3Data object -
        /// 1 Locations
        /// 2 SubDivisions
        /// 3 Divisions
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <param name="lpAcctKey"></param>
        /// <param name="userId"></param>
        /// <param name="asOfDate"></param>
        /// <param name="ratingType"></param>
        /// <param name="currentLocationCategoryRating"></param>
        /// <param name="tivQuartiles"></param>
        /// <param name="useLocationNo"></param>
        /// <returns></returns>
        public RqrLevel3Data LoadRqrLevel3Data(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, int lpAcctKey, int userId, DateTime asOfDate, int ratingType, List<int> currentLocationCategoryRating, List<int> tivQuartiles, bool useLocationNo)
        {
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            RqrLevel3Data result = null;

            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                List<int> locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();
                    command.CommandTimeout = 1000;
                    command.CommandText = "[dbo].[proc_GetLQRRQRLevelThreeData]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", lpAcctKey));

                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(locationIdsParam);

                    command.Parameters.Add(new SqlParameter("@CurrentUserID", userId));
                    command.Parameters.Add(new SqlParameter("@AsOfDate", asOfDate));
                    command.Parameters.Add(new SqlParameter("@AccountProfileRatingTypeID", ratingType));

                    var tivQuartilesFilter = ConvertIntListToDataTable(tivQuartiles);
                    var tivQuartilesParam = new SqlParameter("@TIVQuartilesFilter", tivQuartilesFilter)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(tivQuartilesParam);

                    var currentLocationCategoryRatingIds = ConvertIntListToDataTable(currentLocationCategoryRating);
                    var currentLocationCategoryRatingParam = new SqlParameter("@CurrentLocationCategoryRating", currentLocationCategoryRatingIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(currentLocationCategoryRatingParam);


                    command.Parameters.Add(new SqlParameter("@UseLocationNo", useLocationNo));

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            var locationResultSet = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ProcGetLqrrqrLevelThreeDataReturnModel.ResultSetModel1>(reader)
                                .ToList();

                            reader.NextResult();

                            var subDivisionResultSet = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ProcGetLqrrqrLevelThreeDataReturnModel.ResultSetModel2>(reader)
                                .ToList();

                            reader.NextResult();

                            var divisionResultSet = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ProcGetLqrrqrLevelThreeDataReturnModel.ResultSetModel3>(reader)
                                .ToList();


                            result = new RqrLevel3Data
                            {
                                LocationResultSet = locationResultSet,
                                SubDivisionResultSet = subDivisionResultSet,
                                DivisionResultSet = divisionResultSet
                            };
                            return result;
                        }

                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error("Error occured while reading the data in LoadRqrLevel3Data method.", ex);
                        throw ex;
                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }

                }
            }

            return result;
        }

        /// <summary>
        /// USER STORY 80519
        /// Gather main data for Dashboard RQR Overtime tile
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <param name="ratingType"></param>
        /// <param name="toDate"></param>
        /// <param name="currentRqrRatingsFilter"></param>
        /// <param name="currentRqrTivFilter"></param>
        /// <returns></returns>
        public List<RQROverTimeData> LoadRQROverTimeData(DataFilter locationsSelectorDataFilter,
            DataFilter dataFilter,
            RatingTypesEnum ratingType,
            DateTime toDate,
            int lpAcctKey,
            List<int> currentRqrRatingsFilter,
            List<int> currentRqrTivFilter
        )
        {
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            List<RQROverTimeData> result = null;

            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                var locationIds =
                    (from exposure in qry
                     select exposure.LpAllPiKey).Distinct().ToList();

                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRQROverTimeData]";
                    command.CommandType = CommandType.StoredProcedure;

                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };
                    command.Parameters.Add(locationIdsParam);

                    command.Parameters.Add(new SqlParameter("@SelectedRatingTypeID", (int)ratingType));

                    //command.Parameters.Add(new SqlParameter("@ToDate", toDate));
                    command.Parameters.Add(new SqlParameter("@ToDate", DateTime.Parse(toDate.ToUniversalTime().ToShortDateString().Trim() + " 23:59:59")));


                    command.Parameters.Add(new SqlParameter("@LpAcctKey", lpAcctKey));

                    DataTable dataTableRqrRating = ConvertIntListToDataTable(currentRqrRatingsFilter);
                    var rqrRatingsParam = new SqlParameter("@CurrentLocationCategoryRating", dataTableRqrRating)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };
                    command.Parameters.Add(rqrRatingsParam);

                    DataTable dataTableTivQuartiles = ConvertIntListToDataTable(currentRqrTivFilter);
                    var tivQuartilesParam = new SqlParameter("@TIVQuartilesFilter", dataTableTivQuartiles)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };
                    command.Parameters.Add(tivQuartilesParam);

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<RQROverTimeData>(reader)
                                .ToList();
                        }
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error("Error occured while reading the data in LoadRQROverTimeData method.", ex);
                        throw ex;
                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// USER STORY 134579
        /// Gather main data for Dashboard LQR / RQR Over Time Tile Two
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <param name="ratingType"></param>
        /// <param name="selectedAsAtDate"></param>
        /// <param name="userLastLoginDate"></param>
        /// <param name="selectedLocationCategoryRatingsList"></param>
        /// <returns></returns>
        public List<RQROverTimeTileTwoData> LoadRQROverTimeTileTwoData(DataFilter locationsSelectorDataFilter,
            DataFilter dataFilter,
            RatingTypesEnum ratingType,
            DateTime selectedAsAtDate,
            DateTime userLastLoginDate,
            int lpAcctKey,
            List<int> selectedLocationCategoryRatingsList,
            List<int> selectedTivOptionsFilter)
        {
            List<RQROverTimeTileTwoData> rQROverTimeTileTwoDataList = null;

            try
            {
                if (locationsSelectorDataFilter == null)
                    throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

                List<int> locationIdsSortedByTiv = new List<int> { };
                List<int> locationsSurveyedSinceLastLoginIds = new List<int> { };
                List<int> locationsSurveyedSinceStartDate = new List<int> { };

                using (var db = new MA2DbContext())
                {
                    IQueryable<ViewDataFilter> qry = null;
                    qry = db.ViewDataFilters;
                    qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                    locationIdsSortedByTiv = qry.OrderByDescending(item => item.LocTotalValue)
                       .Select(item => item.LpAllPiKey)
                       .Distinct()
                       .ToList();

                    locationsSurveyedSinceLastLoginIds = qry.Where(x => x.LastSurveyDate >= userLastLoginDate).Select(y => y.LpAllPiKey).Distinct().ToList();

                    DateTime startDate = (selectedAsAtDate == DateTime.Today.ToUniversalTime()
                        ? new DateTime(DateTime.Today.ToUniversalTime().Year, 1, 1)
                        : selectedAsAtDate);
                    locationsSurveyedSinceStartDate = (from item in qry
                                                       where item.LastSurveyDate >= startDate
                                                       select item.LpAllPiKey).Distinct().ToList();

                    rQROverTimeTileTwoDataList = new List<RQROverTimeTileTwoData>()
                    {
                        new RQROverTimeTileTwoData
                        {
                            /*
                             ‘Surveyed Since Last Login’: the breakdown of surveys completed since the user last logged in.
                            */
                            AsAtDate = DateTime.UtcNow.ToUniversalTime(),
                            RQROverTimeDataList = null,
                            CategoryType = RQROverTimeTileTwoCategoryTypes.SurveyedSinceLastLogin,
                            StartDate = userLastLoginDate
                        },
                        new RQROverTimeTileTwoData
                        {
                            /*
                             ‘Surveyed YTD (Since “As of Date”)’: 
                                o	Where Today’s Date, display the breakdown of surveys completed since 01-Jan of the current year.
                                o	Where Custom Date, display the breakdown of surveys completed since the Custom Date.
                             */
                            AsAtDate = DateTime.UtcNow.ToUniversalTime(),
                            RQROverTimeDataList = null,
                            CategoryType = RQROverTimeTileTwoCategoryTypes.SurveyedYTD,
                            StartDate = startDate
                        },
                        new RQROverTimeTileTwoData
                        {
                            AsAtDate = selectedAsAtDate.AddYears(-5),
                            RQROverTimeDataList = null,
                            CategoryType = RQROverTimeTileTwoCategoryTypes.AsOfDate
                        },
                        new RQROverTimeTileTwoData
                        {
                            AsAtDate = selectedAsAtDate.AddYears(-4),
                            RQROverTimeDataList = null,
                            CategoryType = RQROverTimeTileTwoCategoryTypes.AsOfDate
                        },
                        new RQROverTimeTileTwoData
                        {
                            AsAtDate = selectedAsAtDate.AddYears(-3),
                            RQROverTimeDataList = null,
                            CategoryType = RQROverTimeTileTwoCategoryTypes.AsOfDate
                        },
                        new RQROverTimeTileTwoData // etc
                        {
                            AsAtDate = selectedAsAtDate.AddYears(-2),
                            RQROverTimeDataList = null,
                            CategoryType = RQROverTimeTileTwoCategoryTypes.AsOfDate
                        },

                        new RQROverTimeTileTwoData // As of Date minus 1 year
                        {
                            AsAtDate = selectedAsAtDate.AddYears(-1),
                            RQROverTimeDataList = null,
                            CategoryType = RQROverTimeTileTwoCategoryTypes.AsOfDate
                        },
                        new RQROverTimeTileTwoData // As of Date
                        {
                            AsAtDate = selectedAsAtDate,
                            RQROverTimeDataList = null,
                            CategoryType = RQROverTimeTileTwoCategoryTypes.AsOfDate
                        },
                        new RQROverTimeTileTwoData // Current Ratings
                        {
                            AsAtDate = DateTime.UtcNow,
                            RQROverTimeDataList = null,
                            CategoryType = RQROverTimeTileTwoCategoryTypes.CurrentRatings
                        }
                    };
                }

                rQROverTimeTileTwoDataList.ForEach(item =>
                {
                    using (var db2 = new MA2DbContext())
                    {
                        using (var connection = db2.Database.Connection)
                        {
                            connection.Open();
                            var command = connection.CreateCommand();

                            command.CommandText = "[dbo].[proc_GetRQROverTimeData]";
                            command.CommandType = CommandType.StoredProcedure;

                            command.Parameters.Add(new SqlParameter("@SelectedRatingTypeID", (int)ratingType));

                            command.Parameters.Add(new SqlParameter("@ToDate", null));


                            command.Parameters.Add(new SqlParameter("@LpAcctKey", lpAcctKey));

                            DataTable dataTableRqrRating = ConvertIntListToDataTable(selectedLocationCategoryRatingsList);
                            var rqrRatingsParam = new SqlParameter("@CurrentLocationCategoryRating", dataTableRqrRating)
                            {
                                SqlDbType = SqlDbType.Structured,
                                TypeName = "dbo.IDsList"
                            };
                            command.Parameters.Add(rqrRatingsParam);

                            DataTable dataTableTivQuartiles = ConvertIntListToDataTable(selectedTivOptionsFilter);
                            var tivQuartilesParam = new SqlParameter("@TIVQuartilesFilter", dataTableTivQuartiles)
                            {
                                SqlDbType = SqlDbType.Structured,
                                TypeName = "dbo.IDsList"
                            };
                            command.Parameters.Add(tivQuartilesParam);

                            command.Parameters["@ToDate"].Value = item.AsAtDate;

                            switch (item.CategoryType)
                            {
                                case RQROverTimeTileTwoCategoryTypes.SurveyedSinceLastLogin:
                                    SetLocationIdsListParameter(command, locationsSurveyedSinceLastLoginIds);
                                    break;
                                case RQROverTimeTileTwoCategoryTypes.SurveyedYTD:
                                    SetLocationIdsListParameter(command, locationsSurveyedSinceStartDate);
                                    break;
                                default:
                                    SetLocationIdsListParameter(command, locationIdsSortedByTiv);
                                    break;
                            }

                            using (var reader = command.ExecuteReader())
                            {
                                item.RQROverTimeDataList = ((IObjectContextAdapter)db2)
                                    .ObjectContext
                                    .Translate<RQROverTimeData>(reader)
                                    .ToList();
                            }
                        }


                    }
                });
            }

            catch (Exception exception)
            {
                LogHelper.Error("Exception occurred calling proc_GetRQROverTimeData to get RQR Tile Two data", exception);
            }


            return rQROverTimeTileTwoDataList;
        }

        /// <summary>
        /// Filter the supplied list of Location Ids (that are sorted by TIV) by the specified
        /// TIV Quartile filters.
        /// </summary>
        /// <param name="selectedTivOptionsFilter"></param>
        /// <param name="locationIdsSortedByTiv"></param>
        /// <returns></returns>
        private List<int> ApplyTivQuartilesFilters(List<int> selectedTivOptionsFilter, List<int> locationIdsSortedByTiv)
        {
            var outputLocationIds = new List<int>();

            int quarter = locationIdsSortedByTiv.Count / 4;

            bool exactlyDivisibleByFour = (locationIdsSortedByTiv.Count % 4 == 0);

            if (selectedTivOptionsFilter.Contains(Constants.RiskQualityRatingFilters.TivQuartile.Top0to25))
            {
                outputLocationIds.AddRange(locationIdsSortedByTiv.Take(quarter));
            }

            if (selectedTivOptionsFilter.Contains(Constants.RiskQualityRatingFilters.TivQuartile.Top26to50))
            {
                outputLocationIds.AddRange(locationIdsSortedByTiv.Skip(quarter).Take(quarter));
            }

            if (selectedTivOptionsFilter.Contains(Constants.RiskQualityRatingFilters.TivQuartile.Top51to75))
            {
                outputLocationIds.AddRange(locationIdsSortedByTiv.Skip(2 * quarter).Take(quarter));
            }

            if (selectedTivOptionsFilter.Contains(Constants.RiskQualityRatingFilters.TivQuartile.Top76to100))
            {
                outputLocationIds.AddRange(locationIdsSortedByTiv.Skip(3 * quarter).Take(quarter + (exactlyDivisibleByFour
                                                                                                    ? 0
                                                                                                    : 1)));
            }

            return outputLocationIds;
        }

        /// <summary>
        /// Add a parameter to the specified DbCommand object to allow the locations to be filtered to the specified set of Ids
        /// </summary>
        /// <param name="command"></param>
        /// <param name="locationIdsList"></param>
        private void SetLocationIdsListParameter(DbCommand command, List<int> locationIdsList)
        {
            const string parameterName = "@LocationIDsList";

            DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIdsList);

            if (!command.Parameters.Contains(parameterName))
            {
                var locationIdsParam = new SqlParameter(parameterName, dataTableLocationIds)
                {
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "dbo.IDsList"
                };
                command.Parameters.Add(locationIdsParam);
            }
            else
            {
                command.Parameters[parameterName].Value = dataTableLocationIds;
            }
        }

        #region Account Quartile Data

        /// <summary>
        /// Given an account LPAcctKey return the average of all Location RQRs under that account
        /// </summary>
        /// <param name="lPAcctKey"></param>
        /// <returns></returns>
        public decimal? GetAccountAverageRqr(int lPAcctKey)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Location> qryAcct = null;
                qryAcct = db.Locations;
                qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
                return qryAcct.Average(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);
            }
        }

        private decimal? GetAccountMaximumRqr(int lPAcctKey)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Location> qryAcct = null;
                qryAcct = db.Locations;
                qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);

                return qryAcct.Max(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);
            }
        }

        private decimal? GetAccountMinimumRqr(int lPAcctKey)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Location> qryAcct = null;
                qryAcct = db.Locations;
                qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
                return qryAcct.Min(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);
            }
        }

        private decimal? GetAccountUpperQuartileRqr(int lPAcctKey)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Location> qryAcct = null;
                qryAcct = db.Locations;
                qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey).OrderBy(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);

                if (qryAcct.Count() > 1)
                {
                    var skipVal = qryAcct.Count() * 3 / 4;
                    var q3 = qryAcct.Skip(skipVal).Take(1).FirstOrDefault();

                    if (q3 != null)
                    {
                        return q3.IsValidated != null && q3.IsValidated.Value ? q3.RqrScoreWeighted : q3.RqrScore;
                    }
                    else
                    {
                        return null;
                    }
                }

                return null;

            }
        }
        private decimal? GetAccountMedianRqr(int lPAcctKey)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Location> qryAcct = null;
                qryAcct = db.Locations;
                qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey).OrderBy(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);

                var skipVal = (int)Math.Round(qryAcct.Count() * 0.5);
                var q2 = qryAcct.Skip(skipVal).Take(1).FirstOrDefault();
                if (qryAcct.Count() > 1)
                {
                    if (q2 != null)
                    {
                        return q2.IsValidated != null && q2.IsValidated.Value ? q2.RqrScoreWeighted : q2.RqrScore;
                    }
                    else
                    {
                        return null;
                    }
                }

                return null;
            }
        }


        private decimal? GetAccountLowerQuartileRqr(int lPAcctKey)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Location> qryAcct = null;
                qryAcct = db.Locations;
                qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey).OrderBy(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);

                var skipVal = qryAcct.Count() * 1 / 4;
                var q1 = qryAcct.Skip(skipVal).Take(1).FirstOrDefault();

                if (qryAcct.Count() > 1)
                {
                    if (q1 != null)
                    {
                        return q1.IsValidated != null && q1.IsValidated.Value ? q1.RqrScoreWeighted : q1.RqrScore;
                    }
                    else
                    {
                        return null;
                    }
                }
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountLevel"></param>
        /// <returns></returns>
        private string GetAccountType(AccountLevelEnum accountLevel)
        {
            var result = string.Empty;

            switch (accountLevel)
            {
                case AccountLevelEnum.Account:
                    result = Resources.WebPageResources.RiskQualityRatings_Benchmarking_AccountName;
                    break;
                case AccountLevelEnum.Division:
                    result = Resources.WebPageResources.RiskQualityRatings_Benchmarking_DivisionName;
                    break;
                case AccountLevelEnum.Location:
                    result = Resources.WebPageResources.RiskQualityRatings_Benchmarking_LocationName;
                    break;
            }

            return result;
        }


        #endregion

        #region Location Quartile Data 

        private decimal? GetLocationAverageRqr(int lPAcctKey, IEnumerable<int> locationIds, MA2DbContext dbContext)
        {
            IQueryable<Location> qryAcct = dbContext.Locations;
            qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
            qryAcct = qryAcct.Where(item => locationIds.Contains(item.LpAllPiKey));
            return qryAcct.Average(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);

        }

        private decimal? GetLocationMaximumRqr(int lPAcctKey, IEnumerable<int> locationIds, MA2DbContext dbContext)
        {
            IQueryable<Location> qryAcct = dbContext.Locations;
            qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
            qryAcct = qryAcct.Where(item => locationIds.Contains(item.LpAllPiKey));
            return qryAcct.Max(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);

        }


        private decimal? GetLocationMinimumRqr(int lPAcctKey, IEnumerable<int> locationIds, MA2DbContext dbContext)
        {
            IQueryable<Location> qryAcct = dbContext.Locations;
            qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
            qryAcct = qryAcct.Where(item => locationIds.Contains(item.LpAllPiKey));
            return qryAcct.Min(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);

        }


        private decimal? GetLocationUpperQuartileRqr(int lPAcctKey, IEnumerable<int> locationIds, MA2DbContext dbContext)
        {
            IQueryable<Location> qryAcct = dbContext.Locations;
            qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
            qryAcct = qryAcct.Where(item => locationIds.Contains(item.LpAllPiKey)).OrderBy(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);

            var skipVal = qryAcct.Count() * 3 / 4;
            var q3 = qryAcct.Skip(skipVal).Take(1).FirstOrDefault();

            return q3.IsValidated != null && q3.IsValidated.Value ? q3?.RqrScoreWeighted : q3?.RqrScore;

        }

        private decimal? GetLocationLowerQuartileRqr(int lPAcctKey, IEnumerable<int> locationIds, MA2DbContext dbContext)
        {

            IQueryable<Location> qryAcct = dbContext.Locations;
            qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
            qryAcct = qryAcct.Where(item => locationIds.Contains(item.LpAllPiKey)).OrderBy(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);

            var skipVal = qryAcct.Count() * 1 / 4;
            var q3 = qryAcct.Skip(skipVal).Take(1).FirstOrDefault();

            return q3.IsValidated != null && q3.IsValidated.Value ? q3?.RqrScoreWeighted : q3?.RqrScore;

        }

        private decimal? GetLocationMedianRqr(int lPAcctKey, IEnumerable<int> locationIds, MA2DbContext dbContext)
        {

            IQueryable<Location> qryAcct = dbContext.Locations;
            qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
            qryAcct = qryAcct.Where(item => locationIds.Contains(item.LpAllPiKey)).OrderBy(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);

            var skipVal = (int)Math.Round(qryAcct.Count() * 0.5);
            var q2 = qryAcct.Skip(skipVal).Take(1).FirstOrDefault();

            return q2.IsValidated != null && q2.IsValidated.Value ? q2?.RqrScoreWeighted : q2?.RqrScore;

        }

        #endregion

        #region Division Quartile Data

        /// <summary>
        /// Given an account LPAcctKey and User ID return the average of all Location RQRs for the selected Divisions
        /// </summary>
        /// <param name="lpAcctWebDivKeyInCurrentFilter"></param>
        /// <param name="lPAcctKey"></param>
        /// <param name="divisionIds"></param>
        /// <returns></returns>
        private decimal? GetDivisionAverageRqr(List<int> lpAcctWebDivKeyInCurrentFilter, int lPAcctKey, int userId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Location> qryAcct = null;
                qryAcct = db.Locations;
                qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
                qryAcct = qryAcct.Where(item => item.LpAcctWebDivKey.HasValue);
                qryAcct = qryAcct.Where(item => lpAcctWebDivKeyInCurrentFilter.Contains(item.LpAcctWebDivKey.Value));
                return qryAcct.Average(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lpAcctWebDivKeyInCurrentFilter"></param>
        /// <param name="lPAcctKey"></param>
        /// <param name="userId"></param>
        /// <param name="weightedAverage"></param>
        /// <returns></returns>
        private decimal? GetDivisionMaximumRqr(List<int> lpAcctWebDivKeyInCurrentFilter, int lPAcctKey, int userId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Location> qryAcct = null;
                qryAcct = db.Locations;
                qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
                qryAcct = qryAcct.Where(item => item.LpAcctWebDivKey.HasValue);
                qryAcct = qryAcct.Where(item => lpAcctWebDivKeyInCurrentFilter.Contains(item.LpAcctWebDivKey.Value));
                return qryAcct.Max(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lpAcctWebDivKeyInCurrentFilter"></param>
        /// <param name="lPAcctKey"></param>
        /// <param name="userId"></param>
        /// <param name="weightedAverage"></param>
        /// <returns></returns>
        private decimal? GetDivisionMinimumRqr(List<int> lpAcctWebDivKeyInCurrentFilter, int lPAcctKey, int userId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Location> qryAcct = null;
                qryAcct = db.Locations;
                qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
                qryAcct = qryAcct.Where(item => item.LpAcctWebDivKey.HasValue);
                qryAcct = qryAcct.Where(item => lpAcctWebDivKeyInCurrentFilter.Contains(item.LpAcctWebDivKey.Value));
                return qryAcct.Min(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lpAcctWebDivKeyInCurrentFilter"></param>
        /// <param name="lPAcctKey"></param>
        /// <param name="userId"></param>
        /// <param name="weightedAverage"></param>
        /// <returns></returns>
        private decimal? GetDivisionUpperQuartileRqr(List<int> lpAcctWebDivKeyInCurrentFilter, int lPAcctKey, int userId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Location> qryAcct = null;
                qryAcct = db.Locations;
                qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
                qryAcct = qryAcct.Where(item => item.LpAcctWebDivKey.HasValue);
                qryAcct = qryAcct.Where(item => lpAcctWebDivKeyInCurrentFilter.Contains(item.LpAcctWebDivKey.Value)).OrderBy(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);


                var skipVal = qryAcct.Count() * 3 / 4;
                var q3 = qryAcct.Skip(skipVal).Take(1).FirstOrDefault();

                return q3.IsValidated != null && q3.IsValidated.Value ? q3?.RqrScoreWeighted : q3?.RqrScore;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lpAcctWebDivKeyInCurrentFilter"></param>
        /// <param name="lPAcctKey"></param>
        /// <param name="userId"></param>
        /// <param name="weightedAverage"></param>
        /// <returns></returns>
        private decimal? GetDivisionLowerQuartileRqr(List<int> lpAcctWebDivKeyInCurrentFilter, int lPAcctKey, int userId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Location> qryAcct = null;
                qryAcct = db.Locations;
                qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
                qryAcct = qryAcct.Where(item => item.LpAcctWebDivKey.HasValue);
                qryAcct = qryAcct.Where(item => lpAcctWebDivKeyInCurrentFilter.Contains(item.LpAcctWebDivKey.Value)).OrderBy(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);


                var skipVal = qryAcct.Count() * 1 / 4;
                var q3 = qryAcct.Skip(skipVal).Take(1).FirstOrDefault();

                return q3.IsValidated != null && q3.IsValidated.Value ? q3?.RqrScoreWeighted : q3?.RqrScore;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lpAcctWebDivKeyInCurrentFilter"></param>
        /// <param name="lPAcctKey"></param>
        /// <param name="userId"></param>
        /// <param name="weightedAverage"></param>
        /// <returns></returns>
        private decimal? GetDivisionMedianRqr(List<int> lpAcctWebDivKeyInCurrentFilter, int lPAcctKey, int userId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Location> qryAcct = null;
                qryAcct = db.Locations;
                qryAcct = qryAcct.Where(item => item.LpAcctKey == lPAcctKey);
                qryAcct = qryAcct.Where(item => item.LpAcctWebDivKey.HasValue);
                qryAcct = qryAcct.Where(item => lpAcctWebDivKeyInCurrentFilter.Contains(item.LpAcctWebDivKey.Value)).OrderBy(item => item.IsValidated != null && item.IsValidated.Value ? item.RqrScoreWeighted : item.RqrScore);


                var skipVal = (int)Math.Round(qryAcct.Count() * 0.5);
                var q2 = qryAcct.Skip(skipVal).Take(1).FirstOrDefault();

                return q2.IsValidated != null && q2.IsValidated.Value ? q2?.RqrScoreWeighted : q2?.RqrScore;
            }
        }



        #endregion

        public List<RiskQualityCategory> GetRiskQualityCategories()
        {
            ReferenceDbAccess reference = new ReferenceDbAccess();
            return reference.GetRiskQualityCategories();
        }


        public bool InsertAndUpdateSharedComment(SharedComment entity)
        {

            try
            {
                bool isSaved = false;
                using (var db = new MA2DbContext())
                {
                    var existing = db.SharedComments.Where(x => x.LpAllPiKey.Equals(entity.LpAllPiKey) && x.SystemGridFieldID.Equals(entity.SystemGridFieldID) && x.AccountID.Equals(entity.AccountID) && x.UserID.Equals(entity.UserID)).FirstOrDefault();

                    if (existing == null)
                    {
                        if (!string.IsNullOrEmpty(entity.Value))
                        {
                            var record = new SharedComment
                            {

                                LpAllPiKey = entity.LpAllPiKey,
                                Value = entity.Value.Trim(),
                                ReportTypeID = Constants.SummaryReport.RiskQualityRatings,
                                CreatedDate = DateTime.UtcNow,
                                UpdatedByName = entity.UpdatedByName,
                                SystemGridFieldID = entity.SystemGridFieldID,
                                AccountID = entity.AccountID,
                                UserID = entity.UserID

                            };

                            db.SharedComments.Add(record);
                            db.SaveChanges();
                            isSaved = true;
                        }
                    }
                    else
                    {
                        if (existing.Value != entity.Value)
                        {
                            existing.Value = entity.Value;
                            isSaved = true;
                        }

                        existing.CreatedDate = DateTime.UtcNow;
                        existing.UpdatedByName = entity.UpdatedByName;
                        existing.SystemGridFieldID = entity.SystemGridFieldID;
                        existing.AccountID = entity.AccountID;
                        existing.UserID = entity.UserID;
                        if (isSaved)
                            db.SaveChanges();
                    }

                }
                return isSaved;
            }
            catch (DbEntityValidationException e)
            {
                return false;
                throw new Exception(Helpers.FormatValidationErrors(e));
            }



        }
        public bool InsertAndUpdateMyComment(SharedComment entity)
        {
            try
            {
                bool isSaved = false;
                using (var db = new MA2DbContext())
                {
                    var existing = db.SharedComments.FirstOrDefault(x => x.LpAllPiKey == entity.LpAllPiKey);

                    if (existing == null)
                    {
                        if (!string.IsNullOrEmpty(entity.Value))
                        {
                            var record = new SharedComment
                            {
                                LpAllPiKey = entity.LpAllPiKey,
                                Value = entity.Value,
                                ReportTypeID = Constants.SummaryReport.RiskQualityRatings,
                                CreatedDate = DateTime.UtcNow,
                                UpdatedByName = entity.UpdatedByName,
                                SystemGridFieldID = entity.SystemGridFieldID
                            };
                            db.SharedComments.Add(record);
                            db.SaveChanges();
                            isSaved = true;
                        }
                    }
                    else
                    {
                        if (existing.Value != entity.Value)
                        {
                            existing.Value = entity.Value;
                            isSaved = true;
                        }

                        existing.CreatedDate = DateTime.UtcNow;
                        existing.UpdatedByName = entity.UpdatedByName;
                        existing.SystemGridFieldID = entity.SystemGridFieldID;
                        if (isSaved)
                            db.SaveChanges();


                    }
                }
                return isSaved;
            }
            catch (DbEntityValidationException e)
            {
                return false;
                throw new Exception(Helpers.FormatValidationErrors(e));
            }


        }
        /// <summary>
        /// Given a list of Locations and Recommendations, return the current calculated RQR and projected RQR (should those Recommendations be implemented)
        /// </summary>
        /// <param name="lPAllPiKeys"></param>
        /// <param name="lPRecKeys"></param>
        /// <param name="db"></param>
        /// <returns></returns>
        public List<ProcGetRqrEstimatedEffectForRecommendationsReturnModel> LoadEstimatedRiskQualityRatingImprovement(IEnumerable<int> lPAllPiKeys, IEnumerable<int> lPRecKeys)
        {
            DataTable dataTableLocationIds = base.ConvertIntListToDataTable(lPAllPiKeys.ToList());
            DataTable dataTableRecommendationIds = base.ConvertIntListToDataTable(lPRecKeys.ToList());

            var results = new List<ProcGetRqrEstimatedEffectForRecommendationsReturnModel>();

            var locationIdsParam = new System.Data.SqlClient.SqlParameter { ParameterName = "@LocationIds", SqlDbType = System.Data.SqlDbType.Structured, Direction = System.Data.ParameterDirection.Input, Value = dataTableLocationIds, TypeName = "dbo.IDsList" };
            if (locationIdsParam.Value == null)
                locationIdsParam.Value = DBNull.Value;

            var recommendationIDsListParam = new System.Data.SqlClient.SqlParameter { ParameterName = "@RecommendationIds", SqlDbType = System.Data.SqlDbType.Structured, Direction = System.Data.ParameterDirection.Input, Value = dataTableRecommendationIds, TypeName = "dbo.IDsList" };
            if (recommendationIDsListParam.Value == null)
                recommendationIDsListParam.Value = DBNull.Value;

            using (var db = new MA2DbContext())
            {
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var cmd = connection.CreateCommand();

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "[dbo].[proc_GetRQREstimatedEffectForRecommendations]";
                    cmd.Parameters.Add(locationIdsParam);
                    cmd.Parameters.Add(recommendationIDsListParam);

                    using (var reader = cmd.ExecuteReader())
                    {
                        results = ((IObjectContextAdapter)db)
                            .ObjectContext
                            .Translate<ProcGetRqrEstimatedEffectForRecommendationsReturnModel>(reader)
                            .ToList();
                    }
                }
            }

            return results;
        }

        #endregion

        #region Potential RQR

        /// <summary>
        /// Get the ALL projected Location RQR Improvement records for the specified account and assuming that the specified recommendations have been completed
        /// </summary>
        /// <param name="lPAcctKey"></param>
        /// <param name="recommendationIds"></param>
        /// <returns></returns>
        public List<ProcGetRqrEstimatedEffectForRecommendationsReturnModel> GetAccountAverageRqrImprovements(int lPAcctKey, IEnumerable<int> recommendationIds = null)
        {
            var da = new RiskQualityDbAccess();
            LocationDbAccess lda = new LocationDbAccess(this.UserName);

            // Load the Ids of all Locations for the specified account
            var locationIds = lda.LoadLocationsByLPAcctKey(lPAcctKey).Select(item => item.LpAllPiKey);

            return da.LoadEstimatedRiskQualityRatingImprovement(locationIds, recommendationIds);
        }

        /// <summary>
        /// Get the Projected RQR for the specified account and assuming that the specified recommendations have been completed
        /// </summary>
        /// <param name="lPAcctKey"></param>
        /// <returns></returns>
        public decimal? GetAccountAverageRqrImprovement(int lPAcctKey, List<ProcGetRqrEstimatedEffectForRecommendationsReturnModel> locations)
        {
            var da = new RiskQualityDbAccess();
            LocationDbAccess lda = new LocationDbAccess(this.UserName);

            // Load the Ids of all Locations for the specified account
            var locationIds = lda.LoadLocationsByLPAcctKey(lPAcctKey).Select(item => item.LpAllPiKey);

            return (from loc in locations select loc.NewLocationRiskQualityRatingRatingWeighted).Average() * 10;
        }

        /// <summary>
        /// Get the Projected RQR for the every Division the specified user has access to within the specified Account
        /// Assuming that the specified recommendations have been completed
        /// </summary>
        /// <param name="lPAcctKey"></param>
        /// <param name="userId"></param>
        /// <param name="db"></param>
        /// <param name="locations"></param>
        /// <returns></returns>
        public decimal? GetDivisionAverageRqrImprovement(IEnumerable<int> lpAcctWebDivKeyInCurrentFilter, int userId, MA2DbContext db, List<ProcGetRqrEstimatedEffectForRecommendationsReturnModel> locations)
        {
            var da = new RiskQualityDbAccess();

            // Get a list of all of the locations across the list of Divisions
            IQueryable<Location> qryLocations = db.Locations;
            qryLocations = qryLocations.Where(item => lpAcctWebDivKeyInCurrentFilter.Any(lpAcctWebDivKey => lpAcctWebDivKey == item.LpAcctWebDivKey));
            var locationIds = (from item in qryLocations select item.LpAllPiKey).Distinct().ToList();

            //var locations = da.LoadEstimatedRiskQualityRatingImprovement(locationIds, recommendationIds);
            return (from loc in locations where locationIds.Contains(loc.LPAllPiKey) select loc.NewLocationRiskQualityRatingRatingWeighted).Average() * 10;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lPAcctKey"></param>
        /// <param name="locationIds"></param>
        /// <param name="locations"></param>
        /// <returns></returns>
        public decimal? GetLocationAverageRqrImprovement(IEnumerable<int> locationIds, List<ProcGetRqrEstimatedEffectForRecommendationsReturnModel> locations)
        {
            var da = new RiskQualityDbAccess();
            return (from loc in locations where locationIds.Contains(loc.LPAllPiKey) select loc.NewLocationRiskQualityRatingRatingWeighted).Average() * 10;
        }


        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbAccess.ExtensionMethods;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.DbModels.DbEnums;
using XLC.MyAnalysis2.Shared;

namespace XLC.MyAnalysis2.DbAccess
{
    public class UserDbAccess : BaseDataAccess
    {
        protected DataRepository Repo = new DataRepository();

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="userName">Current authenticated user</param>
        public UserDbAccess(string userName)
            : base(userName)
        {
        }

        #region Load

        public User GetById(int id)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<User> qry = null;

                qry = db.Users.Where(x => x.ID == id);

                qry = qry.Include(x => x.UserRoles);
                qry = qry.Include(x => x.UserRoles.Select(y => y.Role));
                qry = qry.Include(x => x.UserStatu);


                return qry.SingleOrDefault();
            }
        }

        public User GetByEDSCN(string edsCN)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<User> qry = null;

                qry = db.Users.Where(u => u.EdsCn == edsCN);

                qry = qry.Include(x => x.UserRoles);
                qry = qry.Include(x => x.UserRoles.Select(y => y.Role));
                qry = qry.Include(x => x.UserStatu);


                return qry.SingleOrDefault();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public UserLoginTracking GetUserLastLoginDate(int userId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<UserLoginTracking> qry = null;

                qry = db.UserLoginTrackings.Where(u => u.UserID == userId);
                qry = qry.OrderByDescending(u => u.LoginDate);

                // We don't want the latest as this will be the current login
                return qry.Skip(1).Take(1).SingleOrDefault();
            }
        }

        /// <summary>
        /// Get the User Account Profile for the User and Account combination
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="lpAcctKey"></param>
        /// <returns></returns>
        public UserAccountProfile GetUserAccountProfile(int userId, int lpAcctKey)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<UserAccountProfile> qry = db.UserAccountProfiles.Where(x => x.UserID == userId && x.LpAcctKey == lpAcctKey);

                return qry.SingleOrDefault();
            }
        }

        public List<LocationWithUserMetaData> GetLocationUsersAssociatedWithRecommendations(List<int> selectedRecommendations, int lpAcctKey, string searchTerm, int pageSize, int recordOffset, out int totalRows, bool useLocationNo, int userRole)
        {
            List<LocationWithUserMetaData> result = null;

            using (var db = new MA2DbContext())
            {


                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetLocationsByRecommendations]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@SearchTerm", searchTerm));


                    DataTable dataTableRecIds = ConvertIntListToDataTable(selectedRecommendations);
                    var recIdsParam = new SqlParameter("@SelectedRecommendations", dataTableRecIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(recIdsParam);

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", lpAcctKey));
                    command.Parameters.Add(new SqlParameter("@UseLocationNo", useLocationNo));

                    command.Parameters.Add(new SqlParameter("@UserRole", userRole));
                    command.Parameters.Add(new SqlParameter("@PageSize", pageSize));
                    command.Parameters.Add(new SqlParameter("@TotalRows", SqlDbType.Int) { Direction = ParameterDirection.Output });
                    command.Parameters.Add(new SqlParameter("@StartRowIndex", recordOffset));


                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<LocationWithUserMetaData>(reader)
                                .ToList();
                        }

                        var param = command.Parameters["@TotalRows"] as IDbDataParameter;
                        totalRows = param == null ? 0 : Convert.ToInt32(param.Value);
                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="lpAcctKey"></param>
        /// <returns></returns>
        public List<ProcUserLocationPriviledgesReturnModel> GetLocationPrivilegesReturnLpAllPiKeys(int userId, int lpAcctKey)
        {
            List<ProcUserLocationPriviledgesReturnModel> result = null;

            using (var db = new MA2DbContext())
            {
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_UserLocationPriviledges]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@UserID", userId));
                    command.Parameters.Add(new SqlParameter("@LPAcctKey", lpAcctKey));

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ProcUserLocationPriviledgesReturnModel>(reader)
                                .ToList();
                        }
                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return result;
        }

        public List<AllProvider> GetAllPrivileges(int LPAllPiKey)
        {
            List<AllProvider> result = null;

            using (var db = new MA2DbContext())
            {
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetReg_Class_OtherProvider]";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new SqlParameter("@LPAllPiKey", LPAllPiKey));

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<AllProvider>(reader)
                                .ToList();
                        }
                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Gets a list of User IDs who have been granted access to a Location through Either Account, Division or Location permissions
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="lpAcctKey"></param>
        /// <returns></returns>
        public List<ProcLocationLevelUsers> GetLocationLevelUsers(int lpAllPiKey, int lpAcctKey)
        {
            List<ProcLocationLevelUsers> result = null;

            using (var db = new MA2DbContext())
            {
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_LocationLevelUsers]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAllPiKey", lpAllPiKey));
                    command.Parameters.Add(new SqlParameter("@LPAcctKey", lpAcctKey));

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ProcLocationLevelUsers>(reader)
                                .ToList();
                        }
                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return result;
        }
        public List<ViewUserMerged> GetRecDetailsCollaborate( int lpAcctKey)
        {
            List<ViewUserMerged> result = null;

            using (var db = new MA2DbContext())
            {
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecDetails_Collaborate]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LPAcctKey", lpAcctKey));
                    command.CommandTimeout = 800;

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ViewUserMerged>(reader)
                                .ToList();
                        }
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error(" Error while proc_GetRecDetails_Collaborate", ex);
                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return result;
        }
        

        public List<EDSUser> GetEdsUserProfileFromCache(string userLastNameSearchTerm, string userMailSearchTerm, string commonName, List<string> lstCommonName)
        {
            List<EDSUser> result = new List<EDSUser>();
            using (var db = new MA2DbContext())
            {
                var entities = db.UserProfileCaches.AsEnumerable();

                if (entities != null)
                {
                    if (!String.IsNullOrEmpty(userLastNameSearchTerm))
                        entities = entities.Where(x => x.LastName.ToLower().Contains(userLastNameSearchTerm.ToLower()));
                    
                    if (!String.IsNullOrEmpty(userMailSearchTerm))
                        entities = entities.Where(x => x.Email.ToLower().Contains(userMailSearchTerm.ToLower()));
                    
                    if (!String.IsNullOrEmpty(commonName))
                        entities = entities.Where(x => x.EdsCn == commonName);

                    if (lstCommonName != null && lstCommonName.Count > 0)
                    {
                        entities = entities.Where(x => lstCommonName.Contains(x.EdsCn));
                    }

                    result = entities.Select(x => new EDSUser
                    {
                        FirstName = x.FirstName,
                        MiddleName = x.MiddleName,
                        Surname = x.LastName,
                        EDS_CN = x.EdsCn,
                        Email = x.Email,
                        InternalUser = x.Internal,
                        JobTitle = x.JobTitle,
                        MobilePhone = x.MobilePhone,
                        Telephone = x.TelePhone
                    }).ToList();
                }
            }

            return result;
        }
        #endregion

        #region Save

        public void WriteUsersToEdsCacheStage(List<EDSUser> users)
        {
            try
            {
                using (var db = new MA2DbContext())
                {
                    foreach (var user in users)
                    {
                        // prevent duplicate cached profiles
                        if (db.stage_UserProfileCaches.FirstOrDefault(x => x.EdsCn == user.EDS_CN) != null)
                        {
                            LogHelper.Info($"User {user.FirstName} {user.Surname} already exists in stage.UserProfileCache");
                            continue;
                        }

                        LogHelper.Info($"Writing user {user.FirstName} {user.Surname} to stage.UserProfileCache");

                        stage_UserProfileCache upc = new stage_UserProfileCache
                        {
                            FirstName = user.FirstName,
                            LastName = user.Surname,
                            MiddleName = user.MiddleName,
                            CreatedDate = DateTime.Now,
                            EdsCn = user.EDS_CN,
                            Email = user.Email,
                            Internal = user.InternalUser,
                            JobTitle = user.JobTitle,
                            MobilePhone = user.MobilePhone,
                            TelePhone = user.Telephone
                        };
                        db.stage_UserProfileCaches.Add(upc);

                        try
                        {
                            db.SaveChanges();
                        }
                        catch (Exception e)
                        {
                            LogHelper.Error($"Could not write user {user.FirstName} {user.Surname} ({user.EDS_CN}) to the database.", e);
                            continue;
                        }
                        LogHelper.Info($"User {user.FirstName} {user.Surname} written to stage.UserProfileCache");

                    }
                }
            }
            catch (Exception e)
            {
                LogHelper.Error($"Could not write user to the database.", e);
            }
        }
        
        public void WriteUsersToEdsCache(List<EDSUser> users)
        {
            try
            {
                using (var db = new MA2DbContext())
                {
                    foreach (var user in users)
                    {
                        // prevent duplicate cached profiles
                        if (db.UserProfileCaches.FirstOrDefault(x => x.EdsCn == user.EDS_CN) != null)
                        {
                            LogHelper.Info($"User {user.FirstName} {user.Surname} already exists in dbo.UserProfileCache");
                            continue;
                        }

                        LogHelper.Info($"Writing user {user.FirstName} {user.Surname} to dbo.UserProfileCache");

                        UserProfileCache upc = new UserProfileCache
                        {
                            FirstName = user.FirstName,
                            LastName = user.Surname,
                            MiddleName = user.MiddleName,
                            CreatedDate = DateTime.Now,
                            EdsCn = user.EDS_CN,
                            Email = user.Email,
                            Internal = user.InternalUser,
                            JobTitle = user.JobTitle,
                            MobilePhone = user.MobilePhone,
                            TelePhone = user.Telephone
                        };
                        db.UserProfileCaches.Add(upc);

                        try
                        {
                            db.SaveChanges();
                        }
                        catch (Exception e)
                        {
                            LogHelper.Error($"Could not write user {user.FirstName} {user.Surname} ({user.EDS_CN}) to the database.", e);
                            continue;
                        }
                        LogHelper.Info($"User {user.FirstName} {user.Surname} written to dbo.UserProfileCache");

                    }
                }
            }
            catch (Exception e)
            {
                LogHelper.Error($"Could not write user to the database.", e);
            }
        }

        public void RecordIncrementalCachingCompletion()
        {
            using (var db = new MA2DbContext())
            {
                var existing = db.UserProfileCacheProcessors.SingleOrDefault(x => x.UserProfileCacheProcessorTypeID == Constants.UserProfileCacheProcessorType.Incremental);

                if (existing != null)
                {
                    existing.LastProcessed = DateTime.UtcNow;
                }
                else
                {
                    db.UserProfileCacheProcessors.Add(new UserProfileCacheProcessor
                    {
                        LastProcessed = DateTime.UtcNow,
                        UserProfileCacheProcessorTypeID = Constants.UserProfileCacheProcessorType.Incremental
                    });
                }

                db.SaveChanges();
            }
        }
        public void RecordFullCachingCompletion()
        {
            using (var db = new MA2DbContext())
            {
                var existing = db.UserProfileCacheProcessors.SingleOrDefault(x => x.UserProfileCacheProcessorTypeID == Constants.UserProfileCacheProcessorType.Full);

                if (existing != null)
                {
                    existing.LastProcessed = DateTime.UtcNow;
                }
                else
                {
                    db.UserProfileCacheProcessors.Add(new UserProfileCacheProcessor
                    {
                        LastProcessed = DateTime.UtcNow,
                        UserProfileCacheProcessorTypeID = Constants.UserProfileCacheProcessorType.Full
                    });
                }

                db.SaveChanges();
            }
        }

        public void UserProfileCachePartitionSwitch()
        {
            try
            {
                LogHelper.Info("Performing Partition Switch");
                using (var db = new MA2DbContext(this.UserName))
                {
                    using (var connection = db.Database.Connection)
                    {
                        connection.Open();
                        var command = connection.CreateCommand();

                        command.CommandText = "[dbo].[proc_SwapUserProfileCacheSchema]";
                        command.CommandType = CommandType.StoredProcedure;
                        
                        command.ExecuteNonQuery();
                    }

                    LogHelper.Info($"Partition switch completed successfully ");
                }
            }
            catch (Exception e)
            {
                LogHelper.Error($"Partition switch failed", e);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public User UpsertUser(User entity, int userId)
        {
            User result = null;

            try
            {
                using (var db = new MA2DbContext(this.UserName))
                {
                    using (var transaction = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var existing = db.Users.FirstOrDefault(e => e.ID == entity.ID);

                            if (existing != null)
                            {
                                existing.LastActivityDate = entity.LastActivityDate;
                                existing.AccountAccessAll = entity.AccountAccessAll;
                                existing.AccountAccessNap = entity.AccountAccessNap;
                                existing.AccountAccessIp = entity.AccountAccessIp;
                                existing.LanguageID = entity.LanguageID;
                                existing.UserStatusID = entity.UserStatusID;
                                existing.SiteSurveyContact = entity.SiteSurveyContact;
                                existing.SiteRecResponseDesignee = entity.SiteRecResponseDesignee;
                                existing.SiteRecAssignedDesignee = entity.SiteRecAssignedDesignee;
                                existing.AccountAccessRestricted = entity.AccountAccessRestricted;
                                existing.Translator = entity.Translator;
                                existing.AccountAccessStandard = entity.AccountAccessAll;
                                //User Roles
                                var oldUserRoles = existing.UserRoles;
                                var updatedUserRoles = entity.UserRoles;
                                var addedUserRoles = updatedUserRoles.ExceptBy(oldUserRoles, x => x.RoleID).ToList();
                                var deletedUserRoles = oldUserRoles.ExceptBy(updatedUserRoles, x => x.RoleID).ToList();
                                deletedUserRoles.ForEach(x => db.Entry(x).State = EntityState.Deleted);
                                addedUserRoles.ForEach(x => db.Entry(x).State = EntityState.Added);

                                //User Account Level Access
                                var oldUserAccountLevelAccesses = existing.UserAccountLevelAccesses;
                                var orphanedAccountLevelAccesses = oldUserAccountLevelAccesses
                                    .Where(ouac => !db.Accounts.Any(acc => acc.LpAcctKey == ouac.LpAcctKey))
                                    .ToList(); //when an account is set to inactive (no longer in Account table) the permissions need to be preserved (see FS04 Account field)
                                var updatedUserAccountLevelAccesses = entity.UserAccountLevelAccesses.ToList();
                                var addedUserAccountLevelAccesses = updatedUserAccountLevelAccesses
                                    .ExceptBy(oldUserAccountLevelAccesses, x => x.LpAcctKey).ToList();
                                var deletedUserAccountLevelAccesses = oldUserAccountLevelAccesses
                                    .ExceptBy(updatedUserAccountLevelAccesses, x => x.LpAcctKey).ExceptBy(
                                        orphanedAccountLevelAccesses,
                                        x => x.LpAcctKey).ToList();
                                var updatedUlas = updatedUserAccountLevelAccesses.ExceptBy(addedUserAccountLevelAccesses,
                                     x => x.LpAcctKey).ToList();

                                foreach (var ula in updatedUlas)
                                {
                                    var existingUlaRecord = existing.UserAccountLevelAccesses.Single(y => y.LpAcctKey == ula.LpAcctKey);
                                    existingUlaRecord.ForceAllChildrenIncluded = ula.ForceAllChildrenIncluded;
                                    existingUlaRecord.StandardAccess = ula.StandardAccess;
                                    existingUlaRecord.UserAccountAccessStartDate = DateTime.SpecifyKind(ula.UserAccountAccessStartDate ?? DateTime.MinValue, DateTimeKind.Utc);
                                    existingUlaRecord.UserAccountAccessExpiryDate = DateTime.SpecifyKind(ula.UserAccountAccessExpiryDate ?? DateTime.MinValue, DateTimeKind.Utc);
                                }

                                deletedUserAccountLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Deleted);
                                addedUserAccountLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Added);

                                //User Division Access
                                var oldUserDivisionLevelAccesses = existing.UserDivisionLevelAccesses;
                                var ophanedDivisionLevelAccesses = oldUserDivisionLevelAccesses.Where(
                                        ouda => !db.Divisions.Any(acc => acc.LpAcctWebDivKey == ouda.LpAcctWebDivKey))
                                    .ToList(); //when a Division is set to inactive (no longer in Division table) the permissions need to be preserved (see FS04 Account field)
                                var updatedUserDivisionLevelAccesses = entity.UserDivisionLevelAccesses.ToList();
                                var addedUserDivisionLevelAccesses = updatedUserDivisionLevelAccesses.ExceptBy(
                                    oldUserDivisionLevelAccesses,
                                    x => x.LpAcctWebDivKey).ToList();
                                var deletedUserDivisionLevelAccesses = oldUserDivisionLevelAccesses
                                    .ExceptBy(updatedUserDivisionLevelAccesses, x => x.LpAcctWebDivKey).ExceptBy(
                                        ophanedDivisionLevelAccesses,
                                        x => x.LpAcctWebDivKey).ToList();
                                updatedUserDivisionLevelAccesses.ExceptBy(addedUserDivisionLevelAccesses,
                                    x => x.LpAcctWebDivKey).ToList()
                                    .ForEach(x => existing.UserDivisionLevelAccesses
                                    .Single(y => y.LpAcctWebDivKey == x.LpAcctWebDivKey)
                                    .ForceAllChildrenIncluded = x.ForceAllChildrenIncluded);
                                deletedUserDivisionLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Deleted);
                                addedUserDivisionLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Added);

                                //User Region Access
                                var oldUserRegionLevelAccesses = existing.UserRegionLevelAccesses;

                                var ophanedRegionLevelAccesses = oldUserRegionLevelAccesses.Where(
                                        oura => !db.AccountGroupTypes.Any(x => x.LpAcctDivGroupKey == oura.LpAcctDivGroupKey))
                                    .ToList(); //when a Region is set to inactive (no longer in Region table) the permissions need to be preserved (see FS04 Account field)
                                var updatedUserRegionLevelAccesses = entity.UserRegionLevelAccesses.ToList();
                                var addedUserRegionLevelAccesses = updatedUserRegionLevelAccesses.ExceptBy(
                                    oldUserRegionLevelAccesses,
                                    x => x.LpAcctDivGroupKey).ToList();
                                var deletedUserRegionLevelAccesses = oldUserRegionLevelAccesses
                                    .ExceptBy(updatedUserRegionLevelAccesses, x => x.LpAcctDivGroupKey).ExceptBy(
                                        ophanedRegionLevelAccesses,
                                        x => x.LpAcctDivGroupKey).ToList();
                                updatedUserRegionLevelAccesses.ExceptBy(addedUserRegionLevelAccesses,
                                    x => x.LpAcctDivGroupKey).ToList()
                                    .ForEach(x => existing.UserRegionLevelAccesses
                                    .Single(y => y.LpAcctDivGroupKey == x.LpAcctDivGroupKey)
                                    .ForceAllChildrenIncluded = x.ForceAllChildrenIncluded);
                                deletedUserRegionLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Deleted);
                                addedUserRegionLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Added);

                                //User Classification Access
                                var oldUserClassificationLevelAccesses = existing.UserClassificationLevelAccesses;

                                var ophanedClassificationLevelAccesses = oldUserClassificationLevelAccesses.Where(
                                        oura => !db.AccountGroupTypes.Any(x => x.LpAcctDivGroupKey == oura.LpAcctDivGroupKey))
                                    .ToList(); //when a Classification is set to inactive (no longer in Classification table) the permissions need to be preserved (see FS04 Account field)
                                var updatedUserClassificationLevelAccesses = entity.UserClassificationLevelAccesses.ToList();
                                var addedUserClassificationLevelAccesses = updatedUserClassificationLevelAccesses.ExceptBy(
                                    oldUserClassificationLevelAccesses,
                                    x => x.LpAcctDivGroupKey).ToList();
                                var deletedUserClassificationLevelAccesses = oldUserClassificationLevelAccesses
                                    .ExceptBy(updatedUserClassificationLevelAccesses, x => x.LpAcctDivGroupKey).ExceptBy(
                                        ophanedClassificationLevelAccesses,
                                        x => x.LpAcctDivGroupKey).ToList();
                                updatedUserClassificationLevelAccesses.ExceptBy(addedUserClassificationLevelAccesses,
                                    x => x.LpAcctDivGroupKey).ToList()
                                    .ForEach(x => existing.UserClassificationLevelAccesses
                                    .Single(y => y.LpAcctDivGroupKey == x.LpAcctDivGroupKey)
                                    .ForceAllChildrenIncluded = x.ForceAllChildrenIncluded);
                                deletedUserClassificationLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Deleted);
                                addedUserClassificationLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Added);

                                //User OtherProvider Access
                                var oldUserOtherProviderLevelAccesses = existing.UserOtherProviderLevelAccesses;

                                var ophanedOtherProviderLevelAccesses = oldUserOtherProviderLevelAccesses.Where(
                                        oura => !db.AccountGroupTypes.Any(x => x.LpAcctDivGroupKey == oura.LpAcctDivGroupKey))
                                    .ToList(); //when a OtherProvider is set to inactive (no longer in OtherProvider table) the permissions need to be preserved (see FS04 Account field)
                                var updatedUserOtherProviderLevelAccesses = entity.UserOtherProviderLevelAccesses.ToList();
                                var addedUserOtherProviderLevelAccesses = updatedUserOtherProviderLevelAccesses.ExceptBy(
                                    oldUserOtherProviderLevelAccesses,
                                    x => x.LpAcctDivGroupKey).ToList();
                                var deletedUserOtherProviderLevelAccesses = oldUserOtherProviderLevelAccesses
                                    .ExceptBy(updatedUserOtherProviderLevelAccesses, x => x.LpAcctDivGroupKey).ExceptBy(
                                        ophanedOtherProviderLevelAccesses,
                                        x => x.LpAcctDivGroupKey).ToList();
                                updatedUserOtherProviderLevelAccesses.ExceptBy(addedUserOtherProviderLevelAccesses,
                                    x => x.LpAcctDivGroupKey).ToList()
                                    .ForEach(x => existing.UserOtherProviderLevelAccesses
                                    .Single(y => y.LpAcctDivGroupKey == x.LpAcctDivGroupKey)
                                    .ForceAllChildrenIncluded = x.ForceAllChildrenIncluded);
                                deletedUserOtherProviderLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Deleted);
                                addedUserOtherProviderLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Added);

                                //User Sub Division Level Access
                                var oldUserSubDivisionLevelAccesses = existing.UserSubDivisionLevelAccesses;
                                var ophanedSubDivisionLevelAccesses = oldUserSubDivisionLevelAccesses.Where(
                                        ouda => !db.SubDivisions.Any(acc => acc.LpSubDivKey == ouda.LpSubDivKey))
                                    .ToList(); //when a SubDivision is set to inactive (no longer in SubDivision table) the permissions need to be preserved (see FS04 Account field)
                                var updatedUserSubDivisionLevelAccesses = entity.UserSubDivisionLevelAccesses.ToList();
                                var addedUserSubDivisionLevelAccesses = updatedUserSubDivisionLevelAccesses.ExceptBy(
                                    oldUserSubDivisionLevelAccesses,
                                    x => x.LpSubDivKey).ToList();
                                var deletedUserSubDivisionLevelAccesses = oldUserSubDivisionLevelAccesses
                                    .ExceptBy(updatedUserSubDivisionLevelAccesses, x => x.LpSubDivKey).ExceptBy(
                                        ophanedSubDivisionLevelAccesses,
                                        x => x.LpSubDivKey).ToList();
                                updatedUserSubDivisionLevelAccesses.ExceptBy(addedUserSubDivisionLevelAccesses,
                                    x => x.LpSubDivKey).ToList()
                                    .ForEach(x => existing.UserSubDivisionLevelAccesses
                                    .Single(y => y.LpSubDivKey == x.LpSubDivKey)
                                    .ForceAllChildrenIncluded = x.ForceAllChildrenIncluded);
                                deletedUserSubDivisionLevelAccesses.ForEach(
                                    x => db.Entry(x).State = EntityState.Deleted);
                                addedUserSubDivisionLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Added);

                                //User Location Level Access
                                var oldUserLocationLevelAccesses = existing.UserLocationLevelAccesses;
                                var ophanedLocationLevelAccesses = oldUserLocationLevelAccesses
                                    .Where(oula => !db.Locations.Any(acc => acc.LpAllPiKey == oula.LpAllPiKey))
                                    .ToList(); //when an Location is set to inactive (no longer in Location table) the permissions need to be preserved (see FS04 Account field)
                                var updatedUserLocationLevelAccesses = entity.UserLocationLevelAccesses;
                                var addedUserLocationLevelAccesses = updatedUserLocationLevelAccesses
                                    .ExceptBy(oldUserLocationLevelAccesses, x => x.LpAllPiKey).ToList();
                                var deletedUserLocationLevelAccesses = oldUserLocationLevelAccesses
                                    .ExceptBy(updatedUserLocationLevelAccesses, x => x.LpAllPiKey).ExceptBy(
                                        ophanedLocationLevelAccesses,
                                        x => x.LpAllPiKey).ToList();
                                deletedUserLocationLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Deleted);
                                addedUserLocationLevelAccesses.ForEach(x => db.Entry(x).State = EntityState.Added);

                                // set dates to keep SQL happy, usually this would be done automatically in DbContext.SaveChangesAsync
                                addedUserRoles.ForEach(x => x.CreatedDate = DateTime.UtcNow);
                                addedUserRoles.ForEach(x => x.UpdatedDate = DateTime.UtcNow);

                                //User Document Access
                                var oldUserDocumentAccesses = existing.UserDocumentAccesses;
                                var orphanedUserDocumentAccesses = oldUserDocumentAccesses.ExceptBy(
                                    oldUserDocumentAccesses,
                                    x => x.DocumentTypeID);
                                var updatedUserDocumentAcceses = entity.UserDocumentAccesses;
                                var addedUserDocumentAccesses = updatedUserDocumentAcceses.ExceptBy(
                                    oldUserDocumentAccesses,
                                    x => x.DocumentTypeID).ToList();
                                var deletedUserDocumentAccesses = oldUserDocumentAccesses
                                    .ExceptBy(updatedUserDocumentAcceses, x => x.DocumentTypeID).ExceptBy(
                                        orphanedUserDocumentAccesses,
                                        x => x.DocumentTypeID).ToList();

                                deletedUserDocumentAccesses.ForEach(x => db.Entry(x).State = EntityState.Deleted);
                                addedUserDocumentAccesses.ForEach(x => db.Entry(x).State = EntityState.Added);

                                existing.UpdatedDate = DateTime.UtcNow;
                                existing.UpdatedBy = userId;

                                result = existing;
                            }
                            else
                            {
                                entity.CreatedDate = DateTime.UtcNow; // this would be done by interceptor
                                entity.UpdatedDate = DateTime.UtcNow;
                                entity.CreatedBy = userId;

                                result = db.Users.Add(entity);
                            }

                            try
                            {
                                db.Configuration.AutoDetectChangesEnabled = false;
                                db.ChangeTracker.DetectChanges();
                                db.SaveChanges();
                                transaction.Commit();
                            }
                            catch (System.Exception e)
                            {
                                LogHelper.Error($"User save issue  {userId}");
                                transaction.Rollback();
                                throw;
                            }
                            finally
                            {
                                db.Configuration.AutoDetectChangesEnabled = true;
                            }
                        }
                        catch (System.Exception e)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (DbEntityValidationException e)
            {
                throw new Exception(Helpers.FormatValidationErrors(e));
            }

            return result;
        }

        public void RecordUserLogin(int userId)
        {
            using (var db = new MA2DbContext())
            {
                db.Database.ExecuteSqlCommand(
                    $"INSERT INTO [dbo].[UserLoginTracking] (UserID, LoginDate) SELECT {userId}, GETUTCDATE();");
            }
        }

        public void RecordUserLastActivityDate(int userId)
        {
            using (var db = new MA2DbContext())
            {
                db.Database.ExecuteSqlCommand(
                    $"UPDATE [dbo].[User] SET LastActivityDate = GETUTCDATE() WHERE ID = {userId};");
            }
        }


        public void UpdateUserLanguagePreference(int userId, int languageId, string updaterUserName)
        {
            using (var db = new MA2DbContext())
            {

                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        var existing = db.Users.First(x => x.ID == userId);
                        existing.LanguageID = languageId;
                        db.SaveChanges(updaterUserName);
                        transaction.Commit();
                    }
                    catch (Exception e)
                    {
                        transaction.Rollback();
                        throw e;
                    }
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userStatusId"></param>
        /// <param name="updaterUserName"></param>
        public void UpdateUserStatus(int userId, int userStatusId, string updaterUserName)
        {
            using (var db = new MA2DbContext())
            {

                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        var existing = db.Users.First(x => x.ID == userId);
                        existing.UserStatusID = userStatusId;
                        db.SaveChanges(updaterUserName);
                        transaction.Commit();
                    }
                    catch (Exception e)
                    {
                        transaction.Rollback();
                        throw e;
                    }
                }
            }
        }

        public UserPreference UpsertUserPreference(int userId, int userPreferenceTypeId, string value)
        {
            UserPreference result = null;

            try
            {
                using (var db = new MA2DbContext())
                {
                    var existing = db.UserPreferences.FirstOrDefault(x =>
                        x.UserID == userId && x.UserPreferenceTypeID == userPreferenceTypeId);

                    if (existing != null)
                    {
                        existing.UpdatedBy = userId;
                        existing.UpdatedDate = DateTime.UtcNow;
                        existing.Value = value;
                        result = existing;
                    }
                    else
                    {

                        UserPreference userPreference = new UserPreference
                        {
                            UserID = userId,
                            UserPreferenceTypeID = userPreferenceTypeId,
                            CreatedBy = userId,
                            UpdatedBy = userId,
                            CreatedDate = DateTime.UtcNow,
                            UpdatedDate = DateTime.UtcNow,
                            Value = value
                        };

                        result = db.UserPreferences.Add(userPreference);
                    }

                    db.SaveChanges();
                }
            }
            catch (DbEntityValidationException e)
            {
                throw new Exception(Helpers.FormatValidationErrors(e));
                throw e;
            }


            return result;
        }

        public async Task<UserAccountProfile> UpsertUserAccountProfileAsync(UserAccountProfile entity)
        {
            UserAccountProfile result = null;

            try
            {
                using (var db = new MA2DbContext())
                {
                    var existing = db.UserAccountProfiles.FirstOrDefault(x => x.LpAcctKey == entity.LpAcctKey && x.UserID == entity.UserID);

                    if (existing != null)
                    {
                        existing.UpdatedDate = DateTime.Now;
                        existing.UpdatedBy = entity.UserID;

                        existing.UseAccountNo = entity.UseAccountNo;
                        existing.UseLocationNo = entity.UseLocationNo;
                        existing.GlobalAsAtDateDay = entity.GlobalAsAtDateDay;
                        existing.GlobalAsAtDateMonth = entity.GlobalAsAtDateMonth;
                        existing.GlobalAsAtDateYear = entity.GlobalAsAtDateYear;

                        result = existing;
                    }
                    else
                    {
                        entity.CreatedDate = DateTime.Now;
                        entity.CreatedBy = entity.UserID;

                        result = db.UserAccountProfiles.Add(entity);
                    }

                    await db.SaveChangesAsync();
                }
            }
            catch (DbEntityValidationException e)
            {
                throw new Exception(Helpers.FormatValidationErrors(e));
            }

            return result;
        }

        public int UpsertUserSecurityExtractRecord(string zipFileName, UserSecurityExtractStatusEnum status, int userId,
            int? userSecurityExtractId, string statusDescription)
        {

            using (var db = new MA2DbContext())
            {
                try
                {
                    UserSecurityExport userSecurityExtract = null;
                    if (userSecurityExtractId == null)
                    {
                        userSecurityExtract = new UserSecurityExport
                        {
                            UserID = userId,
                            CreatedDate = DateTime.UtcNow,
                            CreatedBy = userId
                        };
                        db.UserSecurityExports.Add(userSecurityExtract);
                    }
                    else
                    {
                        userSecurityExtract = db.UserSecurityExports.Single(ude => ude.ID == userSecurityExtractId);
                    }

                    userSecurityExtract.UpdatedDate = DateTime.UtcNow;
                    userSecurityExtract.UpdatedBy = userId;
                    userSecurityExtract.Status = Enum.GetName(typeof(UserSecurityExtractStatusEnum), status);
                    userSecurityExtract.StatusDescription = statusDescription ?? String.Empty;
                    userSecurityExtract.ExportFilePath = zipFileName ?? String.Empty;

                    db.SaveChanges();

                    return userSecurityExtract.ID;
                }


                catch (Exception e)
                {
                    LogHelper.Error($"Could not update UserSecurityExports. User ID {userId}, User Security Extract Id: {userSecurityExtractId}, Status: {Enum.GetName(typeof(UserSecurityExtractStatusEnum), status)}", e);
                    throw;
                }
                finally
                {
                    db.Database.Connection.Close();
                }
            }
        }

        public List<ProcGetUserSecurityExtractReturnModel> GetUserSecurityExtract(int? lpAcctKey, List<string> edsCnList)
        {
            var results = new List<ProcGetUserSecurityExtractReturnModel>();
            using (var db = new MA2DbContext())
            {
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetUserSecurityExtract]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", lpAcctKey));

                    DataTable dataTableRecIds = ConvertStringListToDataTable(edsCnList);
                    var recIdsParam = new SqlParameter("@EdsCNList", dataTableRecIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsListString"
                    };

                    command.Parameters.Add(recIdsParam);
                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            results = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ProcGetUserSecurityExtractReturnModel>(reader)
                                .ToList();
                        }

                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return results;
        }

        public UserSecurityExport LoadUserSecurityExport(int UserSecurityExportId)
        {
            using (var db = new MA2DbContext())
            {
                return db.UserSecurityExports.Single(ude => ude.ID == UserSecurityExportId);
            }
        }

        #endregion

        #region Delete

        public void DropStageUserProfileCacheRecords()
        {
            using (var db = new MA2DbContext())
            {
                db.stage_UserProfileCaches.RemoveRange(db.stage_UserProfileCaches);
                db.SaveChanges();
            }
        }

        public void DropSwapUserProfileCacheRecords()
        {
            using (var db = new MA2DbContext())
            {
                db.swap_UserProfileCaches.RemoveRange(db.swap_UserProfileCaches);
                db.SaveChanges();
            }
        }

        public void DeleteUserPreferences(int userId, int userPreferenceTypeId)
        {
            using (var dbContext = new MA2DbContext())
            {
                var entities = dbContext.UserPreferences.Where(x =>
                    x.UserID == userId && x.UserPreferenceTypeID == userPreferenceTypeId);
                dbContext.UserPreferences.RemoveRange(entities);

                dbContext.SaveChanges();
            }

            LogHelper.Info($"User Preference type {userPreferenceTypeId} deleted for User {userId}");
        }
        #endregion

        public List<ViewUserMerged> GetUserEDS(string EDS_CN)
        {
            var results = new List<ViewUserMerged>();
            using (var db = new MA2DbContext())
            {
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();
                    command.CommandText = "[dbo].[proc_GetUsersEDS]";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new SqlParameter("@UserEDS", EDS_CN));
                    command.CommandTimeout = 1000;

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            results = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ViewUserMerged>(reader)
                                .ToList();
                        }
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error(" Error while fetching User data from LDAP - GetUserEDS", ex);
                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }
            return results;
        }

        public List<ViewUserMerged> GetDocumentUsersforEmail(string EDS_CN)
        {
            var results = new List<ViewUserMerged>();
            using (var db = new MA2DbContext())
            {
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();
                    command.CommandText = "[dbo].[proc_DocumentEmailNotification]";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new SqlParameter("@UserEDS", EDS_CN));
                    command.CommandTimeout = 1000;

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            results = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ViewUserMerged>(reader)
                                .ToList();
                        }
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error(" Error while fetching User data from LDAP - GetUserEDS", ex);
                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }
            return results;
        }
    }


}


public class ViewUserMerged
{
    public string Forename { get; set; }
    public string Surname { get; set; }
    public string FullName { get; set; }
    public string Email { get; set; }
    public int UserID { get; set; } // Sourced from MA2	
    public string EdsCn { get; set; } // Sourced from MA2	
    public string Status { get; set; } // Sourced from MA2	
    public int RoleID { get; set; } // Sourced from MA2	
    public string RoleName { get; set; } // Sourced from MA2	
    public string Client { get; set; } // Sourced from MA2	
    public string JobTitle { get; set; }
    public bool SiteSurveyContact { get; set; }
    public bool SiteRecommendationResponseDesignee { get; set; }
    public bool SiteRecommendationAssignedDesignee { get; set; }
    // If the user has not been assigned access via the account/division level, assume they have been assigned access at the Level	
    public bool LocationLevel => !AccountLevel && !DivisionLevel;
    public bool DivisionLevel { get; set; }
    public bool AccountLevel { get; set; }
    public bool Translator { get; set; }
}

public class AllProvider
{
    public int LPAllPiKey { get; set; }
    public int Division { get; set; }
    public int SubDivision { get; set; }
    public int Region { get; set; }
    public int Classification { get; set; }
    public int OtherProvider { get; set; }
}


﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Reflection;
using System.Transactions;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.Shared;
using static XLC.MyAnalysis2.DbModels.DbConstants.Constants;

namespace XLC.MyAnalysis2.DbAccess
{
    public class DBLanguageTransAccess : BaseDataAccess
    {

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="userName">Current authenticated user</param>
        public DBLanguageTransAccess(string userName)
            : base(userName)
        {
        }

        public List<DbLanguageTable> LoadLanguageTables()
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<DbLanguageTable> qry = null;
                qry = db.DbLanguageTables.OrderBy(x => x.SrcTableName);
                return qry.ToList();
            }
        }

        public List<DBTransModel> LoadTranslationforTable(string srcTablename, string destTablename, string srckey, string destkey, string srcColumn, string destColumn)
        {
            using (var db = new MA2DbContext())
            {
                if (srcTablename == LanguageTableName.RecommendationStatus)
                {

                    var queryString = " Select c.ID as SourceId,c.{4} as SourceName,b.ID as DestId,b.{5} as DestName,C.LCID,C.Sourcekey, C.SourceKey1,b.RowVersion " +
                    "From " +
                    "(" +
                    " Select a.ID,a.{4},a.{2} as SourceKey, L.LCID,a.LpStatusCode as SourceKey1" +
                    " From {0} a , Language L" +
                    ") c " +
                    "Left Join {1} b On (c.SourceKey = b.{3}  or  c.SourceKey1 = b.LpStatusCode)" +
                    " and  b.LCID = C.LCID " +
                    " Order by " +
                     "c.ID";

                    queryString = string.Format(queryString, srcTablename, destTablename, srckey, destkey, srcColumn, destColumn);

                    var res = db.Database.SqlQuery<DBTransModel>(queryString).ToList();

                    return res;


                }
                else if (srcTablename == LanguageTableName.IndustryClassification)
                {

                    var queryString = " Select c.ID as SourceId,c.{4} as SourceName,b.ID as DestId,b.{5} as DestName,C.LCID,C.Sourcekey,b.RowVersion " +
                        "From " +
                        "(" +
                        " Select a.ID,a.{4},a.{2} as SourceKey, L.LCID " +
                        " From {0} a , Language L" +
                        ") c " +
                        "Left Join {1} b On c.SourceKey = b.{3} " +
                        " and  b.LCID = C.LCID" +
                        " Order by " +
                         "c.ID";

                    queryString = string.Format(queryString, srcTablename, destTablename, srckey, destkey, srcColumn, destColumn);

                    var res = db.Database.SqlQuery<LPDBTransModel>(queryString).ToList();


                    try
                    {
                        List<DBTransModel> objlist = new List<DBTransModel>();

                        foreach (var lst in res)
                        {
                            DBTransModel obj = new DBTransModel();
                            obj.SourceID = lst.SourceID;
                            obj.SourceName = lst.SourceName;
                            obj.DestId = lst.DestId;
                            obj.DestName = lst.DestName;
                            obj.LCID = lst.LCID;
                            obj.Sourcekey = Convert.ToInt16(lst.Sourcekey);
                            obj.Sourcekey1 = lst.Sourcekey1;
                            obj.RowVersion = lst.RowVersion;

                            objlist.Add(obj);
                        }

                        return objlist;
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error($" Error while fetch data for IndustryClassification {ex}");
                        return null;
                    }

                }
                else
                {

                    var queryString = " Select c.ID as SourceId,c.{4} as SourceName,b.ID as DestId,b.{5} as DestName,C.LCID,C.Sourcekey,b.RowVersion " +
                        "From " +
                        "(" +
                        " Select a.ID,a.{4},a.{2} as SourceKey, L.LCID " +
                        " From {0} a , Language L" +
                        ") c " +
                        "Left Join {1} b On c.SourceKey = b.{3} " +
                        " and  b.LCID = C.LCID" +
                        " Order by " +
                         "c.ID";

                    queryString = string.Format(queryString, srcTablename, destTablename, srckey, destkey, srcColumn, destColumn);

                    var res = db.Database.SqlQuery<DBTransModel>(queryString).ToList();

                    return res;

                }
            }
        }


        public void SetProperty(string parameter, int value, dynamic obj, string TableName, string refval)
        {
            try
            {
                var properties = obj.GetType().GetProperty(parameter);
                if (properties != null)
                {
                    if (TableName == LanguageTableName.IndustryClassification)
                    {
                        properties.SetValue(obj, Convert.ToString(value), null);
                    }
                    else
                    {
                        properties.SetValue(obj, value, null);
                    }
                }

                if (TableName == LanguageTableName.RecommendationStatus && !string.IsNullOrEmpty(refval))
                {
                    var prts = obj.GetType().GetProperty("LpStatusCode");
                    if (prts != null)
                    {
                        prts.SetValue(obj, refval.ToString(), null);
                    }

                }
            }
            catch (Exception ex)
            {
                LogHelper.Error($"SetProperty error{ex} ");
            }

        }


        public Type GetDbSetType<TEntity>(System.Data.Entity.DbSet<TEntity> dbsetobject) where TEntity : class
        {
            return typeof(TEntity);
        }


        public bool Upsert(List<LanguageDBData> objTranslationList, string TableName, string DestTableName, string sKeyName, string EntityColName, string destColumnName)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    foreach (var tLst in objTranslationList)
                    {
                        try
                        {
                            using (var db = new MA2DbContext(this.UserName))
                            {
                                string sqlString = string.Format("SELECT VALUE st " +
                                  " FROM MA2DbContext.{0} AS st " +
                                  " WHERE st.LCID ={1} ", EntityColName, tLst.LCID);

                                if (TableName == "RecommendationStatus" && !string.IsNullOrEmpty(tLst.Sourcekey1))
                                {
                                    sqlString += string.Format(" AND (st.{0} = {1} or st.LpStatusCode = '{2}')", sKeyName, tLst.SourceKey, tLst.Sourcekey1);
                                }
                                else if (TableName == LanguageTableName.IndustryClassification)
                                {
                                    sqlString += string.Format(" AND st.{0} = {1}", sKeyName, "'" + tLst.SourceKey + "'");
                                }
                                else
                                {
                                    sqlString += string.Format(" AND st.{0} = {1}", sKeyName, tLst.SourceKey);
                                }


                                var objctx = (db as IObjectContextAdapter).ObjectContext;

                                ObjectQuery<dynamic> results = objctx.CreateQuery<dynamic>(sqlString);


                                if (!results.Any())
                                {
                                    try
                                    {

                                        PropertyInfo tableProps = typeof(XLC.MyAnalysis2.DbModels.MA2DbContext).GetProperty(EntityColName);
                                        dynamic tProperties = Convert.ChangeType(tableProps.GetValue(db, null), tableProps.PropertyType);


                                        Type dbType = GetDbSetType(tProperties);

                                        dynamic obj = Activator.CreateInstance(dbType);

                                        obj.Lcid = tLst.LCID ?? 0;

                                        if (TableName == LanguageTableName.Frequency)
                                        {
                                            obj.FrequencyString = tLst.LanguageName ?? string.Empty;
                                        }
                                        else if (TableName == LanguageTableName.NotificationType)
                                        {
                                            obj.Description = tLst.LanguageName ?? string.Empty;
                                        }
                                        else if (TableName == LanguageTableName.RecommendationType)
                                        {
                                            obj.SubRecName = tLst.LanguageName ?? string.Empty;
                                            obj.FullName = tLst.LanguageName ?? string.Empty;
                                            obj.Name = tLst.LanguageName ?? string.Empty;
                                        }
                                        else
                                        {
                                            obj.Name = tLst.LanguageName ?? string.Empty;
                                        }


                                        SetProperty(sKeyName, tLst.SourceKey ?? 0, obj, TableName, tLst.Sourcekey1);

                                        tProperties.Add(obj);
                                        db.SaveChanges(this.UserName);

                                        LogHelper.Info($"Save Changes for Insert {tLst.LanguageName}");
                                    }
                                    catch (Exception e)
                                    {
                                        LogHelper.Error("Error while trying to Insert new Records", e);
                                        throw e;
                                    }

                                }
                                else
                                {
                                    LogHelper.Info($"Update");

                                    dynamic record = results.First();

                                    if (record.GetType().GetProperty(destColumnName) != null)
                                    {
                                        //  db.Entry(record).OriginalValues["RowVersion"] = tLst.RowVersion;

                                        if (TableName == LanguageTableName.Frequency)
                                        {
                                            record.FrequencyString = tLst.LanguageName ?? string.Empty;
                                        }
                                        else if (TableName == LanguageTableName.NotificationType)
                                        {
                                            record.Description = tLst.LanguageName ?? string.Empty;
                                        }
                                        else if (TableName == LanguageTableName.RecommendationType)
                                        {
                                            record.SubRecName = tLst.LanguageName;
                                            record.Name = tLst.LanguageName;
                                            record.FullName = tLst.LanguageName;
                                        }
                                        else
                                        {
                                            record.Name = tLst.LanguageName;
                                        }

                                        db.SaveChanges(this.UserName);

                                        LogHelper.Info($"Update Success {tLst.LanguageName}");
                                    }
                                }
                            }
                        }
                        catch (DbUpdateConcurrencyException)
                        {
                            LogHelper.Error($"DbUpdateConcurrencyException");
                            return false;
                        }
                    }

                    LogHelper.Info($"Scope Complete");
                    scope.Complete();
                    return true;

                }
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Upsert Transaction Failed {ex}");
                return false;
            }


        }



    }
}





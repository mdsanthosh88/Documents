﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbAccess.ExtensionMethods;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.DbModels.DbEnums;
using XLC.MyAnalysis2.Shared;
using static XLC.MyAnalysis2.DbModels.DbConstants.Constants;

namespace XLC.MyAnalysis2.DbAccess
{
    public class RecommendationDbAccess : BaseDataAccess
    {
        #region Load

        public Recommendation LoadRecommendationById(int id)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Recommendation> qry = null;
                qry = db.Recommendations.Where(x => x.LpRecKey == id);
                return qry.Include("Location").SingleOrDefault();
            }
        }

        public Recommendation LoadRecommendationByLPRecKey(int lpRecKey)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Recommendation> qry = null;
                qry = db.Recommendations.Where(x => x.LpRecKey == lpRecKey);
                return qry.Include("Location").SingleOrDefault();
            }
        }

        public Recommendation LoadRecommendationByRecommendationId(int id)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Recommendation> qry = null;
                qry = db.Recommendations.Where(x => x.ID == id);
                return qry.Include("Location").SingleOrDefault();
            }
        }


        public List<Recommendation> LoadRecommendationsByAccount(int id)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Recommendation> qry = null;
                qry = db.Recommendations.Where(x => x.AccountID == id);
                return qry.ToList();
            }
        }

        public IQueryable<Recommendation> LoadRecommendationsByLocationId(int locationId, MA2DbContext db)
        {
            IQueryable<Recommendation> qry = null;
            qry = db.Recommendations.Where(x => x.LocationID == locationId);

            return qry.Include("Location").Include("RecommendationType")
                .Include("RecommendationStatu")
                .Include("Account").Include("Account.Currency").Distinct();
        }

        public List<Document> LoadUploadHistory(int lpRecKey, int lpAllPiKey)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<Document> qry = null;
                qry = db.Documents.Where(x => x.LpAllPiKey == lpAllPiKey && x.LpRecKey == lpRecKey);
                return qry.ToList();
            }
        }

        public IQueryable<Recommendation> LoadRecommendationsByLpAllPiKey(int LpAllPiKey, int LpAcctKey, MA2DbContext db)
        {
            IQueryable<Recommendation> qry = null;
            qry = db.Recommendations.Where(x => x.LpAllPiKey == LpAllPiKey && x.LpAcctKey == LpAcctKey);

            return qry.Include("Location").Include("RecommendationType")
                .Include("RecommendationStatu")
                .Include("Account").Include("Account.Currency").Distinct();
        }

        public IQueryable<Recommendation> LoadRecommendationDataForCurrentFilters(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, MA2DbContext db)
        {
            IQueryable<Recommendation> results = null;

            db.Configuration.LazyLoadingEnabled = true;
            // Always start with this block
            IQueryable<ViewDataFilter> qry = null;
            qry = db.ViewDataFilters;
            qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

            results =
                (from rec in qry
                 join x in db.Recommendations on
                     new { p1 = rec.RecommendationID.Value }
                     equals
                     new { p1 = x.ID }


                 select x);

            return results.Include("Location").Include("RecommendationType")
                    .Include("RecommendationStatu").Include("RecommendationClientIntent")
                    .Include("Account").Include("Account.Currency").Distinct();


        }

        public List<ProcGetRecommendationsByImplementationStatusReturnModel> LoadRecommendationsByImplementationStatus(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, RecommendationFilters filters, int accountId)
        {
            var results = new List<ProcGetRecommendationsByImplementationStatusReturnModel>();
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                List<int> locationIds = null;
                List<int?> lpRecKeys = (from exposure in qry select exposure.LpRecKey).Distinct().ToList();

                // lpRecKeys should only ever be used as a filter from the drill through. If we have a large list then set the value to All
                // otherwise there is a detrimental impact on performance


                locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecommendationsByImplementationStatus]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", accountId));


                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };


                    DataTable dataTableLpRecKeys = ConvertNullableIntListToDataTable(lpRecKeys);
                    var lpRecKeysParam = new SqlParameter("@LpRecKeyList", dataTableLpRecKeys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(lpRecKeysParam);


                    command.Parameters.Add(new SqlParameter("@AsAtDate", filters.AsAtDate));

                    command.Parameters.Add(locationIdsParam);

                    command.Parameters.Add(new SqlParameter("@NoPlansOrDisagreeGrouping", RecommendationStatus.NoPlansOrDisagreeValidated));
                    command.Parameters.Add(new SqlParameter("@VerifiedCompleteGrouping", RecommendationStatus.VerifiedComplete));
                    command.CommandTimeout = 500;

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            results = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ProcGetRecommendationsByImplementationStatusReturnModel>(reader)
                                .ToList();
                        }

                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return results;
        }
        public List<ProcGetRecommendationsByRecommendationStatusReturnModel> LoadRecommendationsByRecommendationStatus(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, RecommendationFilters filters, int accountId)
        {
            var results = new List<ProcGetRecommendationsByRecommendationStatusReturnModel>();
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                List<int> locationIds = null;
                List<int?> lpRecKeys = (from exposure in qry select exposure.LpRecKey).Distinct().ToList();

                locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecommendationsByRecommendationStatus]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", accountId));


                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };
                    command.Parameters.Add(locationIdsParam);


                    DataTable dataTableLpRecKeys = ConvertNullableIntListToDataTable(lpRecKeys);
                    var lpRecKeysParam = new SqlParameter("@LpRecKeyList", dataTableLpRecKeys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(lpRecKeysParam);

                    command.Parameters.Add(new SqlParameter("@AsAtDate", filters.AsAtDate));

                    command.Parameters.Add(new SqlParameter("@CompletedClient", RecommendationStatus.CompletedClient));
                    command.Parameters.Add(new SqlParameter("@ActiveExcludingCompletedClient", OverallRecommendationStatus.ActiveExcludingCompletedClient));
                    command.Parameters.Add(new SqlParameter("@CompletedClientActive", OverallRecommendationStatus.CompletedClientActive));
                    command.CommandTimeout = 500;

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            results = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ProcGetRecommendationsByRecommendationStatusReturnModel>(reader)
                                .ToList();
                        }

                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return results;
        }
        public List<ProcGetRecommendationsByResponseStatusReturnModel> LoadRecommendationsByResponseStatus(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, RecommendationFilters filters, int accountId)
        {
            var results = new List<ProcGetRecommendationsByResponseStatusReturnModel>();
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                List<int> locationIds = null;
                List<int?> lpRecKeys = (from exposure in qry select exposure.LpRecKey).Distinct().ToList();

                locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecommendationsByResponseStatus]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", accountId));


                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };


                    DataTable dataTableLpRecKeys = ConvertNullableIntListToDataTable(lpRecKeys);
                    var lpRecKeysParam = new SqlParameter("@LpRecKeyList", dataTableLpRecKeys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(lpRecKeysParam);

                    command.Parameters.Add(new SqlParameter("@AsAtDate", filters.AsAtDate));

                    command.Parameters.Add(new SqlParameter("@NoPlansOrDisagreeGrouping", RecommendationResponseStatus.NoPlansOrDisagree));
                    command.Parameters.Add(new SqlParameter("@VerifiedCompleteGrouping", RecommendationResponseStatus.VerifiedComplete));
                    command.Parameters.Add(new SqlParameter("@CompletedClientActiveGrouping", RecommendationResponseStatus.CompletedClient));
                    command.CommandTimeout = 500;

                    command.Parameters.Add(locationIdsParam);
                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            results = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ProcGetRecommendationsByResponseStatusReturnModel>(reader)
                                .ToList();
                        }

                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return results;
        }

        public List<RecommendationCategoryCountData> LoadRecommendationCategory(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, RecommendationFilters filters, int accountId, List<AccountCostConfiguration> lstcostConfigurations)
        {
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            var lstAccountConfigLst = lstcostConfigurations.Select(y => new AccountCostConfiguration
            {
                LowLv = y.LowLv,
                MediumLv = y.MediumLv,
                HighLv = y.HighLv
            }).ToList();

            List<RecommendationCategoryCountData> result = null;
            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                List<int> locationIds = null;
                List<int?> lpRecKeys = (from exposure in qry select exposure.LpRecKey).Distinct().ToList();

                if (lpRecKeys.Count > 1)
                    lpRecKeys = new List<int?> { Constants.RecommendationFilterParameters.All };

                locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecommendationSummary_Category]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", accountId));


                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(locationIdsParam);

                    DataTable dataTableLpRecKeys = ConvertNullableIntListToDataTable(lpRecKeys);
                    var lpRecKeysParam = new SqlParameter("@LpRecKeyList", dataTableLpRecKeys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(lpRecKeysParam);

                    DataTable dataTableFilterPerils = ConvertIntListToDataTable(filters.PerilFilter);
                    var filterPerilsParam = new SqlParameter("@FilterPeril", dataTableFilterPerils)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterPerilsParam);

                    DataTable dataTableFilterCategorys = ConvertIntListToDataTable(filters.CategoryFilter);
                    var filterCategoriesParam = new SqlParameter("@FilterCategory", dataTableFilterCategorys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterCategoriesParam);

                    DataTable dataTableFilterTypes = ConvertIntListToDataTable(filters.RecommendationTypesFilter);
                    var filterTypesParam = new SqlParameter("@FilterType", dataTableFilterTypes)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterTypesParam);

                    DataTable dataTableFilterImplementationStatuss = ConvertIntListToDataTable(filters.ImplementationStatusesFilter);
                    var filterImplementationStatusesParam = new SqlParameter("@FilterImplementationStatus", dataTableFilterImplementationStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterImplementationStatusesParam);

                    DataTable dataTableFilterRecommendationResponseStatuss = ConvertIntListToDataTable(filters.RecommendationResponseStatusesFilter);
                    var filterRecommendationResponseStatusesParam = new SqlParameter("@FilterRecommendationResponseStatus", dataTableFilterRecommendationResponseStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterRecommendationResponseStatusesParam);

                    DataTable dataTableFilterLEPriorToImplementations = ConvertIntListToDataTable(filters.LEFilter);
                    var filterLEPriorToImplementationsParam = new SqlParameter("@FilterLEPriorToImplementation", dataTableFilterLEPriorToImplementations)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterLEPriorToImplementationsParam);

                    DataTable dataTableFilterEstCostToCompleteCategorys = ConvertIntListToDataTable(filters.EstimatedCostFilter);
                    var filterEstCostToCompleteCategorysParam = new SqlParameter("@FilterEstCostToCompleteCategory", dataTableFilterEstCostToCompleteCategorys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterEstCostToCompleteCategorysParam);

                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_Low", lstAccountConfigLst[0].LowLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_Medium", lstAccountConfigLst[0].MediumLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_High", lstAccountConfigLst[0].HighLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryLowerThreshold_Critical", LEPriorToImplementationCategory.LowerThreshold_Critical));

                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteUpperThreshold_Low", lstAccountConfigLst[1].LowLv));
                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteUpperThreshold_Medium", lstAccountConfigLst[1].MediumLv));
                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteLowerThreshold_High", EstimatedCostToCompleteCategory.LowerThreshold_High));

                    command.Parameters.Add(new SqlParameter("@MachineryBreakdownLpRecSubTypeKey_Threshold_Lower", RecommendationPeril.MachineryBreakdown_LpRecSubRecTypKey_LowerLimit));
                    command.Parameters.Add(new SqlParameter("@MachineryBreakdownLpRecSubTypeKey_Threshold_Upper", RecommendationPeril.MachineryBreakdown_LpRecSubRecTypKey_UpperLimit));
                    command.Parameters.Add(new SqlParameter("@NaturalCatastropheLpRecSubTypeKey_Threshold_Lower", RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_LowerLimit));
                    command.Parameters.Add(new SqlParameter("@NaturalCatastropheLpRecSubTypeKey_Threshold_Upper", RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_UpperLimit));


                    DataTable dataTableFilterRecommendationStatuses = ConvertIntListToDataTable(filters.RecommendationStatusesFilter);
                    var filterRecommendationStatusesParam = new SqlParameter("@FilterOverallRecommendationStatus", dataTableFilterRecommendationStatuses)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterRecommendationStatusesParam);

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<RecommendationCategoryCountData>(reader)
                                .ToList();
                        }

                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return result;

        }

        public List<RecommendationHistoryData> GetRecommendationUpdate(int lpAllPiKey, int lpRecKey)
        {
            List<RecommendationHistoryData> result = null;
            using (var db = new MA2DbContext())
            {


                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecommendationUpdate]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAllPiKey", lpAllPiKey));
                    command.Parameters.Add(new SqlParameter("@LPRecKey", lpRecKey));

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<RecommendationHistoryData>(reader)
                                .ToList();
                        }

                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error($"Error on GetRecommendationUpdate", ex);
                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }

                return result;
            }
        }

        public List<RecommendationHistoryData> LoadRecommendationHistory(int lpRecKey, int lpAllPiKey)
        {
            List<RecommendationHistoryData> result = null;
            using (var db = new MA2DbContext())
            {


                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecommendationHistory]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LPRecKey", lpRecKey));
                    command.Parameters.Add(new SqlParameter("@LpAllPiKey", lpAllPiKey));

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<RecommendationHistoryData>(reader)
                                .ToList();
                        }

                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }

                return result;
            }
        }

        public List<RecommendationCategoryByType> LoadRecommendationCategoryByType(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, RecommendationFilters filters, int accountId, int lcid, List<AccountCostConfiguration> lstcostConfigurations)
        {
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            List<RecommendationCategoryByType> result = null;
            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                var lstAccountConfigLst = lstcostConfigurations.Select(y => new AccountCostConfiguration
                {
                    LowLv = y.LowLv,
                    MediumLv = y.MediumLv,
                    HighLv = y.HighLv
                }).ToList();

                List<int> locationIds = null;
                List<int?> lpRecKeys = (from exposure in qry select exposure.LpRecKey).Distinct().ToList();

                if (lpRecKeys.Count > 1)
                    lpRecKeys = new List<int?> { Constants.RecommendationFilterParameters.All };

                locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecommendationSummary_Physical_ByType]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", accountId));
                    command.Parameters.Add(new SqlParameter("@LCID", lcid));


                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    DataTable dataTableLpRecKeys = ConvertNullableIntListToDataTable(lpRecKeys);
                    var lpRecKeysParam = new SqlParameter("@LpRecKeyList", dataTableLpRecKeys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(lpRecKeysParam);

                    command.Parameters.Add(locationIdsParam);

                    DataTable dataTableFilterPerils = ConvertIntListToDataTable(filters.PerilFilter);
                    var filterPerilsParam = new SqlParameter("@FilterPeril", dataTableFilterPerils)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterPerilsParam);

                    DataTable dataTableFilterCategorys = ConvertIntListToDataTable(filters.CategoryFilter);
                    var filterCategoriesParam = new SqlParameter("@FilterCategory", dataTableFilterCategorys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterCategoriesParam);

                    DataTable dataTableFilterTypes = ConvertIntListToDataTable(filters.RecommendationTypesFilter);
                    var filterTypesParam = new SqlParameter("@FilterType", dataTableFilterTypes)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterTypesParam);

                    DataTable dataTableFilterImplementationStatuss = ConvertIntListToDataTable(filters.ImplementationStatusesFilter);
                    var filterImplementationStatusesParam = new SqlParameter("@FilterImplementationStatus", dataTableFilterImplementationStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterImplementationStatusesParam);

                    DataTable dataTableFilterRecommendationResponseStatuss = ConvertIntListToDataTable(filters.RecommendationResponseStatusesFilter);
                    var filterRecommendationResponseStatusesParam = new SqlParameter("@FilterRecommendationResponseStatus", dataTableFilterRecommendationResponseStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterRecommendationResponseStatusesParam);

                    DataTable dataTableFilterLEPriorToImplementations = ConvertIntListToDataTable(filters.LEFilter);
                    var filterLEPriorToImplementationsParam = new SqlParameter("@FilterLEPriorToImplementation", dataTableFilterLEPriorToImplementations)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterLEPriorToImplementationsParam);

                    DataTable dataTableFilterEstCostToCompleteCategorys = ConvertIntListToDataTable(filters.EstimatedCostFilter);
                    var filterEstCostToCompleteCategorysParam = new SqlParameter("@FilterEstCostToCompleteCategory", dataTableFilterEstCostToCompleteCategorys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterEstCostToCompleteCategorysParam);


                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_Low", lstAccountConfigLst[0].LowLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_Medium", lstAccountConfigLst[0].MediumLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_High", lstAccountConfigLst[0].HighLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryLowerThreshold_Critical", LEPriorToImplementationCategory.LowerThreshold_Critical));

                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteUpperThreshold_Low", lstAccountConfigLst[1].LowLv));
                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteUpperThreshold_Medium", lstAccountConfigLst[1].MediumLv));
                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteLowerThreshold_High", EstimatedCostToCompleteCategory.LowerThreshold_High));

                    command.Parameters.Add(new SqlParameter("@MachineryBreakdownLpRecSubTypeKey_Threshold_Lower", RecommendationPeril.MachineryBreakdown_LpRecSubRecTypKey_LowerLimit));
                    command.Parameters.Add(new SqlParameter("@MachineryBreakdownLpRecSubTypeKey_Threshold_Upper", RecommendationPeril.MachineryBreakdown_LpRecSubRecTypKey_UpperLimit));
                    command.Parameters.Add(new SqlParameter("@NaturalCatastropheLpRecSubTypeKey_Threshold_Lower", RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_LowerLimit));
                    command.Parameters.Add(new SqlParameter("@NaturalCatastropheLpRecSubTypeKey_Threshold_Upper", RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_UpperLimit));


                    DataTable dataTableFilterRecommendationStatuses = ConvertIntListToDataTable(filters.RecommendationStatusesFilter);
                    var filterRecommendationStatusesParam = new SqlParameter("@FilterOverallRecommendationStatus", dataTableFilterRecommendationStatuses)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterRecommendationStatusesParam);

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<RecommendationCategoryByType>(reader)
                                .ToList();
                        }

                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return result;

        }
        public List<RecommendationCategoryBySubType> LoadRecommendationCategoryBySubType(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, RecommendationFilters filters, int accountId, int lcid, List<AccountCostConfiguration> lstcostConfigurations)
        {
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            var lstAccountConfigLst = lstcostConfigurations.Select(y => new AccountCostConfiguration
            {
                LowLv = y.LowLv,
                MediumLv = y.MediumLv,
                HighLv = y.HighLv
            }).ToList();

            List<RecommendationCategoryBySubType> result = null;
            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                List<int> locationIds = null;
                List<int?> lpRecKeys = (from exposure in qry select exposure.LpRecKey).Distinct().ToList();


                if (lpRecKeys.Count > 1)
                    lpRecKeys = new List<int?> { Constants.RecommendationFilterParameters.All };

                locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecommendationSummary_HumanElement_BySubType]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", accountId));
                    command.Parameters.Add(new SqlParameter("@LCID", lcid));


                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(locationIdsParam);


                    DataTable dataTableLpRecKeys = ConvertNullableIntListToDataTable(lpRecKeys);
                    var lpRecKeysParam = new SqlParameter("@LpRecKeyList", dataTableLpRecKeys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(lpRecKeysParam);

                    DataTable dataTableFilterPerils = ConvertIntListToDataTable(filters.PerilFilter);
                    var filterPerilsParam = new SqlParameter("@FilterPeril", dataTableFilterPerils)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterPerilsParam);

                    DataTable dataTableFilterCategorys = ConvertIntListToDataTable(filters.CategoryFilter);
                    var filterCategoriesParam = new SqlParameter("@FilterCategory", dataTableFilterCategorys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterCategoriesParam);

                    DataTable dataTableFilterTypes = ConvertIntListToDataTable(filters.RecommendationTypesFilter);
                    var filterTypesParam = new SqlParameter("@FilterType", dataTableFilterTypes)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterTypesParam);

                    DataTable dataTableFilterImplementationStatuss = ConvertIntListToDataTable(filters.ImplementationStatusesFilter);
                    var filterImplementationStatusesParam = new SqlParameter("@FilterImplementationStatus", dataTableFilterImplementationStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterImplementationStatusesParam);

                    DataTable dataTableFilterRecommendationResponseStatuss = ConvertIntListToDataTable(filters.RecommendationResponseStatusesFilter);
                    var filterRecommendationResponseStatusesParam = new SqlParameter("@FilterRecommendationResponseStatus", dataTableFilterRecommendationResponseStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterRecommendationResponseStatusesParam);

                    DataTable dataTableFilterLEPriorToImplementations = ConvertIntListToDataTable(filters.LEFilter);
                    var filterLEPriorToImplementationsParam = new SqlParameter("@FilterLEPriorToImplementation", dataTableFilterLEPriorToImplementations)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterLEPriorToImplementationsParam);

                    DataTable dataTableFilterEstCostToCompleteCategorys = ConvertIntListToDataTable(filters.EstimatedCostFilter);
                    var filterEstCostToCompleteCategorysParam = new SqlParameter("@FilterEstCostToCompleteCategory", dataTableFilterEstCostToCompleteCategorys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterEstCostToCompleteCategorysParam);


                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_Low", lstAccountConfigLst[0].LowLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_Medium", lstAccountConfigLst[0].MediumLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_High", lstAccountConfigLst[0].HighLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryLowerThreshold_Critical", LEPriorToImplementationCategory.LowerThreshold_Critical));

                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteUpperThreshold_Low", lstAccountConfigLst[1].LowLv));
                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteUpperThreshold_Medium", lstAccountConfigLst[1].MediumLv));
                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteLowerThreshold_High", EstimatedCostToCompleteCategory.LowerThreshold_High));

                    command.Parameters.Add(new SqlParameter("@MachineryBreakdownLpRecSubTypeKey_Threshold_Lower", RecommendationPeril.MachineryBreakdown_LpRecSubRecTypKey_LowerLimit));
                    command.Parameters.Add(new SqlParameter("@MachineryBreakdownLpRecSubTypeKey_Threshold_Upper", RecommendationPeril.MachineryBreakdown_LpRecSubRecTypKey_UpperLimit));
                    command.Parameters.Add(new SqlParameter("@NaturalCatastropheLpRecSubTypeKey_Threshold_Lower", RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_LowerLimit));
                    command.Parameters.Add(new SqlParameter("@NaturalCatastropheLpRecSubTypeKey_Threshold_Upper", RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_UpperLimit));


                    DataTable dataTableFilterRecommendationStatuses = ConvertIntListToDataTable(filters.RecommendationStatusesFilter);
                    var filterRecommendationStatusesParam = new SqlParameter("@FilterOverallRecommendationStatus", dataTableFilterRecommendationStatuses)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterRecommendationStatusesParam);

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<RecommendationCategoryBySubType>(reader)
                                .ToList();
                        }

                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return result;

        }

        public List<RecommendationSummaryLEBeforeCategory> LoadRecommendationPhysicalLEBeforeCategories(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, RecommendationFilters filters, int accountId, int lcid, List<AccountCostConfiguration> lstcostConfigurations)
        {
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            var lstAccountConfigLst = lstcostConfigurations.Select(y => new AccountCostConfiguration
            {
                LowLv = y.LowLv,
                MediumLv = y.MediumLv,
                HighLv = y.HighLv
            }).ToList();

            List<RecommendationSummaryLEBeforeCategory> result = null;
            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);


                List<int> locationIds = null;
                List<int?> lpRecKeys = (from exposure in qry select exposure.LpRecKey).Distinct().ToList();

                if (lpRecKeys.Count > 1)
                    lpRecKeys = new List<int?> { Constants.RecommendationFilterParameters.All };

                locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecommendationSummary_Physical_EstLEPrior]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", accountId));

                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(locationIdsParam);


                    DataTable dataTableLpRecKeys = ConvertNullableIntListToDataTable(lpRecKeys);
                    var lpRecKeysParam = new SqlParameter("@LpRecKeyList", dataTableLpRecKeys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(lpRecKeysParam);

                    DataTable dataTableFilterPerils = ConvertIntListToDataTable(filters.PerilFilter);
                    var filterPerilsParam = new SqlParameter("@FilterPeril", dataTableFilterPerils)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterPerilsParam);

                    DataTable dataTableFilterCategorys = ConvertIntListToDataTable(filters.CategoryFilter);
                    var filterCategoriesParam = new SqlParameter("@FilterCategory", dataTableFilterCategorys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterCategoriesParam);

                    DataTable dataTableFilterTypes = ConvertIntListToDataTable(filters.RecommendationTypesFilter);
                    var filterTypesParam = new SqlParameter("@FilterType", dataTableFilterTypes)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterTypesParam);

                    DataTable dataTableFilterImplementationStatuss = ConvertIntListToDataTable(filters.ImplementationStatusesFilter);
                    var filterImplementationStatusesParam = new SqlParameter("@FilterImplementationStatus", dataTableFilterImplementationStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterImplementationStatusesParam);

                    DataTable dataTableFilterRecommendationResponseStatuss = ConvertIntListToDataTable(filters.RecommendationResponseStatusesFilter);
                    var filterRecommendationResponseStatusesParam = new SqlParameter("@FilterRecommendationResponseStatus", dataTableFilterRecommendationResponseStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterRecommendationResponseStatusesParam);

                    DataTable dataTableFilterLEPriorToImplementations = ConvertIntListToDataTable(filters.LEFilter);
                    var filterLEPriorToImplementationsParam = new SqlParameter("@FilterLEPriorToImplementation", dataTableFilterLEPriorToImplementations)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterLEPriorToImplementationsParam);

                    DataTable dataTableFilterEstCostToCompleteCategorys = ConvertIntListToDataTable(filters.EstimatedCostFilter);
                    var filterEstCostToCompleteCategorysParam = new SqlParameter("@FilterEstCostToCompleteCategory", dataTableFilterEstCostToCompleteCategorys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterEstCostToCompleteCategorysParam);


                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_Low", lstAccountConfigLst[0].LowLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_Medium", lstAccountConfigLst[0].MediumLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_High", lstAccountConfigLst[0].HighLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryLowerThreshold_Critical", LEPriorToImplementationCategory.LowerThreshold_Critical));

                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteUpperThreshold_Low", lstAccountConfigLst[1].LowLv));
                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteUpperThreshold_Medium", lstAccountConfigLst[1].MediumLv));
                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteLowerThreshold_High", EstimatedCostToCompleteCategory.LowerThreshold_High));

                    command.Parameters.Add(new SqlParameter("@MachineryBreakdownLpRecSubTypeKey_Threshold_Lower", lstAccountConfigLst[1].LowLv));
                    command.Parameters.Add(new SqlParameter("@MachineryBreakdownLpRecSubTypeKey_Threshold_Upper", lstAccountConfigLst[1].MediumLv));
                    command.Parameters.Add(new SqlParameter("@NaturalCatastropheLpRecSubTypeKey_Threshold_Lower", lstAccountConfigLst[1].HighLv));
                    command.Parameters.Add(new SqlParameter("@NaturalCatastropheLpRecSubTypeKey_Threshold_Upper", RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_UpperLimit));


                    DataTable dataTableFilterRecommendationStatuses = ConvertIntListToDataTable(filters.RecommendationStatusesFilter);
                    var filterRecommendationStatusesParam = new SqlParameter("@FilterOverallRecommendationStatus", dataTableFilterRecommendationStatuses)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterRecommendationStatusesParam);

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<RecommendationSummaryLEBeforeCategory>(reader)
                                .ToList();
                        }

                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return result;

        }

        public List<RecommendationSummaryEstCostCategory> LoadRecommendationPhysicalEstCostCategories(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, RecommendationFilters filters, int accountId, int lcid, List<AccountCostConfiguration> lstcostConfigurations)
        {
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            var lstAccountConfigLst = lstcostConfigurations.Select(y => new AccountCostConfiguration
            {
                LowLv = y.LowLv,
                MediumLv = y.MediumLv,
                HighLv = y.HighLv
            }).ToList();

            List<RecommendationSummaryEstCostCategory> result = null;
            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                List<int> locationIds = null;
                List<int?> lpRecKeys = (from exposure in qry select exposure.LpRecKey).Distinct().ToList();

                if (lpRecKeys.Count > 1)
                    lpRecKeys = new List<int?> { Constants.RecommendationFilterParameters.All };

                locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecommendationSummary_Physical_EstCost]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", accountId));

                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(locationIdsParam);


                    DataTable dataTableLpRecKeys = ConvertNullableIntListToDataTable(lpRecKeys);
                    var lpRecKeysParam = new SqlParameter("@LpRecKeyList", dataTableLpRecKeys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(lpRecKeysParam);

                    DataTable dataTableFilterPerils = ConvertIntListToDataTable(filters.PerilFilter);
                    var filterPerilsParam = new SqlParameter("@FilterPeril", dataTableFilterPerils)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterPerilsParam);

                    DataTable dataTableFilterCategorys = ConvertIntListToDataTable(filters.CategoryFilter);
                    var filterCategoriesParam = new SqlParameter("@FilterCategory", dataTableFilterCategorys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterCategoriesParam);

                    DataTable dataTableFilterTypes = ConvertIntListToDataTable(filters.RecommendationTypesFilter);
                    var filterTypesParam = new SqlParameter("@FilterType", dataTableFilterTypes)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterTypesParam);

                    DataTable dataTableFilterImplementationStatuss = ConvertIntListToDataTable(filters.ImplementationStatusesFilter);
                    var filterImplementationStatusesParam = new SqlParameter("@FilterImplementationStatus", dataTableFilterImplementationStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterImplementationStatusesParam);

                    DataTable dataTableFilterRecommendationResponseStatuss = ConvertIntListToDataTable(filters.RecommendationResponseStatusesFilter);
                    var filterRecommendationResponseStatusesParam = new SqlParameter("@FilterRecommendationResponseStatus", dataTableFilterRecommendationResponseStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterRecommendationResponseStatusesParam);

                    DataTable dataTableFilterLEPriorToImplementations = ConvertIntListToDataTable(filters.LEFilter);
                    var filterLEPriorToImplementationsParam = new SqlParameter("@FilterLEPriorToImplementation", dataTableFilterLEPriorToImplementations)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterLEPriorToImplementationsParam);

                    DataTable dataTableFilterEstCostToCompleteCategorys = ConvertIntListToDataTable(filters.EstimatedCostFilter);
                    var filterEstCostToCompleteCategorysParam = new SqlParameter("@FilterEstCostToCompleteCategory", dataTableFilterEstCostToCompleteCategorys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterEstCostToCompleteCategorysParam);

                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_Low", lstAccountConfigLst[0].LowLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_Medium", lstAccountConfigLst[0].MediumLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_High", lstAccountConfigLst[0].HighLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryLowerThreshold_Critical", LEPriorToImplementationCategory.LowerThreshold_Critical));

                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteUpperThreshold_Low", lstAccountConfigLst[1].LowLv));
                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteUpperThreshold_Medium", lstAccountConfigLst[1].MediumLv));
                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteLowerThreshold_High", EstimatedCostToCompleteCategory.LowerThreshold_High));


                    command.Parameters.Add(new SqlParameter("@MachineryBreakdownLpRecSubTypeKey_Threshold_Lower", RecommendationPeril.MachineryBreakdown_LpRecSubRecTypKey_LowerLimit));
                    command.Parameters.Add(new SqlParameter("@MachineryBreakdownLpRecSubTypeKey_Threshold_Upper", RecommendationPeril.MachineryBreakdown_LpRecSubRecTypKey_UpperLimit));
                    command.Parameters.Add(new SqlParameter("@NaturalCatastropheLpRecSubTypeKey_Threshold_Lower", RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_LowerLimit));
                    command.Parameters.Add(new SqlParameter("@NaturalCatastropheLpRecSubTypeKey_Threshold_Upper", RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_UpperLimit));


                    DataTable dataTableFilterRecommendationStatuses = ConvertIntListToDataTable(filters.RecommendationStatusesFilter);
                    var filterRecommendationStatusesParam = new SqlParameter("@FilterOverallRecommendationStatus", dataTableFilterRecommendationStatuses)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterRecommendationStatusesParam);

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<RecommendationSummaryEstCostCategory>(reader)
                                .ToList();
                        }

                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }
            }

            return result;

        }

        private List<int> GetDataFilterCriteria(DataFilter locationFilter)
        {
            List<int> ids = null;
            try
            {
                var db = new DataFilterDbAccess();

                var filter = db.GetDataFilterCriteria(locationFilter.ID);


                foreach (var criterion in filter)
                {
                    ids = new List<int>(criterion.Value.Split('|').Select(int.Parse));
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error on GetDataFilterCriteria from Recommendation L4 Report", ex);
            }

            return ids;
        }

        public List<RecommendationData> LoadRecommendationData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, RecommendationFilters filters, int accountId, string sortExpression, int pageSize,
            bool useLocationNo, int recordOffset, out int totalRows, List<AccountCostConfiguration> lstcostConfigurations, List<int> lpAllPiKeys = null)
        {
            if (locationsSelectorDataFilter == null)
                throw new ArgumentNullException(nameof(locationsSelectorDataFilter));

            List<RecommendationData> result = null;

            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                List<int> locationIds = null;
                List<int?> lpRecKeys = new List<int?>();

                bool IsDrillThru = false;
                if (dataFilter != null && (dataFilter.IsDrillThrough != false || dataFilter.Unsaved == true || dataFilter.Shared == true
                    || dataFilter.Name != "Filter Applied" || dataFilter.Name == "Filter Applied"))
                {
                    qry = db.ViewDataFilters;
                    qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);
                    lpRecKeys = (from exposure in qry select exposure.LpRecKey).Distinct().ToList();

                    List<DataFilterCriteria> criteria = new List<DataFilterCriteria>();
                    if (lpAllPiKeys == null)
                    {
                        locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                    }
                    else
                    {
                        locationIds = lpAllPiKeys;
                    }

                    IsDrillThru = true;
                }
                else
                {
                    if (lpAllPiKeys == null)
                    {
                        locationIds = GetDataFilterCriteria(locationsSelectorDataFilter);
                        // locationIds = (from exposure in qry select exposure.LpAllPiKey).Distinct().ToList();
                    }
                    else
                    {
                        locationIds = lpAllPiKeys;
                    }

                    lpRecKeys.Add(-1);

                    IsDrillThru = false;
                }

                var lstAccountConfigLst = lstcostConfigurations.Select(y => new AccountCostConfiguration
                {
                    LowLv = y.LowLv,
                    MediumLv = y.MediumLv,
                    HighLv = y.HighLv
                }).ToList();

                if (lstAccountConfigLst.Count < 1)
                {
                    lstAccountConfigLst[0].LowLv = LEPriorToImplementationCategory.Low;
                    lstAccountConfigLst[0].MediumLv = LEPriorToImplementationCategory.UpperThreshold_Medium;
                    lstAccountConfigLst[0].HighLv = LEPriorToImplementationCategory.UpperThreshold_High;

                    lstAccountConfigLst[1].LowLv = EstimatedCostToCompleteCategory.UpperThreshold_Low;
                    lstAccountConfigLst[1].MediumLv = EstimatedCostToCompleteCategory.UpperThreshold_Medium;
                }



                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_GetRecommendationData]";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@LpAcctKey", accountId));
                    command.Parameters.Add(new SqlParameter("@LocationID", filters.LocationId));
                    command.Parameters.Add(new SqlParameter("@SortExpression", sortExpression.Split(' ')[0]));
                    command.Parameters.Add(new SqlParameter("@SortDirection", sortExpression.ToLower().Contains("desc") ? "DESC" : "ASC"));
                    command.Parameters.Add(new SqlParameter("@PageSize", pageSize));
                    command.Parameters.Add(new SqlParameter("@UseLocationNo", useLocationNo ? 1 : 0));
                    command.Parameters.Add(new SqlParameter("@TotalRows", SqlDbType.Int) { Direction = ParameterDirection.Output });
                    command.Parameters.Add(new SqlParameter("@StartRowIndex", recordOffset));

                    DataTable dataTableLocationIds = ConvertIntListToDataTable(locationIds);
                    var locationIdsParam = new SqlParameter("@LocationIDsList", dataTableLocationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(locationIdsParam);

                    DataTable dataTableLpRecKeys = ConvertNullableIntListToDataTable(lpRecKeys);
                    var lpRecKeysParam = new SqlParameter("@LpRecKeyList", dataTableLpRecKeys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(lpRecKeysParam);


                    DataTable dtSelectedRecommendationIds = ConvertIntListToDataTable(filters.SelectedRecommendationIDs);
                    var recommendationIdsParam = new SqlParameter("@SelectedRecommendationIDsList", dtSelectedRecommendationIds)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(recommendationIdsParam);

                    DataTable dataTableFilterPerils = ConvertIntListToDataTable(filters.PerilFilter);
                    var filterPerilsParam = new SqlParameter("@FilterPeril", dataTableFilterPerils)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterPerilsParam);

                    DataTable dataTableFilterCategorys = ConvertIntListToDataTable(filters.CategoryFilter);
                    var filterCategoriesParam = new SqlParameter("@FilterCategory", dataTableFilterCategorys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterCategoriesParam);

                    DataTable dataTableFilterTypes = ConvertIntListToDataTable(filters.RecommendationTypesFilter);
                    var filterTypesParam = new SqlParameter("@FilterType", dataTableFilterTypes)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterTypesParam);

                    DataTable dataTableFilterRecommendationStatuss = ConvertIntListToDataTable(filters.RecommendationStatusesFilter);
                    var filterRecommendationStatussParam = new SqlParameter("@FilterRecommendationStatus", dataTableFilterRecommendationStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterRecommendationStatussParam);


                    DataTable dataTableFilterImplementationStatuss = ConvertIntListToDataTable(filters.ImplementationStatusesFilter);
                    var filterImplementationStatusesParam = new SqlParameter("@FilterImplementationStatus", dataTableFilterImplementationStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterImplementationStatusesParam);

                    DataTable dataTableFilterRecommendationResponseStatuss = ConvertIntListToDataTable(filters.RecommendationResponseStatusesFilter);
                    var filterRecommendationResponseStatusesParam = new SqlParameter("@FilterRecommendationResponseStatus", dataTableFilterRecommendationResponseStatuss)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterRecommendationResponseStatusesParam);

                    DataTable dataTableFilterLEPriorToImplementations = ConvertIntListToDataTable(filters.LEFilter);
                    var filterLEPriorToImplementationsParam = new SqlParameter("@FilterLEPriorToImplementation", dataTableFilterLEPriorToImplementations)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterLEPriorToImplementationsParam);

                    DataTable dataTableFilterEstCostToCompleteCategorys = ConvertIntListToDataTable(filters.EstimatedCostFilter);
                    var filterEstCostToCompleteCategorysParam = new SqlParameter("@FilterEstCostToCompleteCategory", dataTableFilterEstCostToCompleteCategorys)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.IDsList"
                    };

                    command.Parameters.Add(filterEstCostToCompleteCategorysParam);


                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_Low", lstAccountConfigLst[0].LowLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_Medium", lstAccountConfigLst[0].MediumLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryUpperThreshold_High", lstAccountConfigLst[0].HighLv));
                    command.Parameters.Add(new SqlParameter("@LECategoryLowerThreshold_Critical", LEPriorToImplementationCategory.LowerThreshold_Critical));

                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteUpperThreshold_Low", lstAccountConfigLst[1].LowLv));
                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteUpperThreshold_Medium", lstAccountConfigLst[1].MediumLv));
                    command.Parameters.Add(new SqlParameter("@EstCostToCompleteLowerThreshold_High", EstimatedCostToCompleteCategory.LowerThreshold_High));

                    command.Parameters.Add(new SqlParameter("@MachineryBreakdownLpRecSubTypeKey_Threshold_Lower", RecommendationPeril.MachineryBreakdown_LpRecSubRecTypKey_LowerLimit));
                    command.Parameters.Add(new SqlParameter("@MachineryBreakdownLpRecSubTypeKey_Threshold_Upper", RecommendationPeril.MachineryBreakdown_LpRecSubRecTypKey_UpperLimit));
                    command.Parameters.Add(new SqlParameter("@NaturalCatastropheLpRecSubTypeKey_Threshold_Lower", RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_LowerLimit));
                    command.Parameters.Add(new SqlParameter("@NaturalCatastropheLpRecSubTypeKey_Threshold_Upper", RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_UpperLimit));
                    //command.Parameters.Add(new SqlParameter("@AsAtDate", DateTime.SpecifyKind(filters.AsAtDate, DateTimeKind.Utc)));    
                    command.Parameters.Add(new SqlParameter("@AsAtDate", DateTime.Parse(filters.AsAtDate.ToUniversalTime().ToShortDateString().Trim() + " 23:59:59")));
                    command.Parameters.Add(new SqlParameter("@IsDrillThru", IsDrillThru));
                    command.CommandTimeout = 500;

                    LogHelper.Info($"L4 Rec UTC_1 date {filters.AsAtDate.ToUniversalTime().ToShortDateString().Trim()}");
                    LogHelper.Info($"L4 Rec UTC_2 date { DateTime.SpecifyKind(filters.AsAtDate, DateTimeKind.Utc)}");

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<RecommendationData>(reader)
                                .ToList();
                        }

                        var param = command.Parameters["@TotalRows"] as IDbDataParameter;
                        totalRows = param == null ? 0 : Convert.ToInt32(param.Value);

                    }
                    finally
                    {
                        db.Database.Connection.Close();

                    }
                }
            }

            return result;
        }

        /// <summary>
        /// LoadUserLocationPriviledge
        /// </summary>
        /// <param name="lpAllPiKeys"></param>
        public List<ViewUserLocationPriviledge> LoadUserLocationPriviledge(string lpAllPiKeys)
        {
            List<ViewUserLocationPriviledge> result = null;
            using (var db = new MA2DbContext())
            {

                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();
                    command.CommandText = "[dbo].[proc_UserLocationPriviledgesLPAllPiKey]";
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = 500;
                    command.Parameters.Add(new SqlParameter("@LPAllPiKeyIDsList", lpAllPiKeys));

                    try
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            result = ((IObjectContextAdapter)db)
                                .ObjectContext
                                .Translate<ViewUserLocationPriviledge>(reader)
                                .ToList();
                        }

                    }
                    finally
                    {
                        db.Database.Connection.Close();
                    }
                }

                return result;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <returns></returns>
        public List<DashboardRecommendationByStatusData> LoadTileRecommendationByStatusData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, int lpAllPiKey)
        {
            ReferenceDbAccess reference = new ReferenceDbAccess();
            var statuses = reference.GetRecommendationStatuses().Where(item => item.ID != RecommendationStatus.Unknown);

            using (var db = new MA2DbContext())
            {
                // Always start with this block
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                var uniqueRecommendations =
                (from result in qry
                 where result.RecommendationStatusID != null
                       && result.LpAllPiKey == lpAllPiKey
                 select new { result.RecommendationID, result.RecommendationStatusID }).Distinct();

                // Then either filter further or join with another query
                var results =
                (from rec in uniqueRecommendations
                 group rec by new
                 {
                     rec.RecommendationStatusID,
                 }
                into recommendationStatusGroup
                 select new
                 {
                     ID = recommendationStatusGroup.Key.RecommendationStatusID,
                     Total = recommendationStatusGroup.Count()
                 }).ToList();

                var series = new List<DashboardRecommendationByStatusData>();

                // foreach status in our list, add a new series to the output
                foreach (var status in statuses)
                {
                    var total = (from item in results
                                 where item.ID == status.ID
                                 select item.Total).SingleOrDefault();

                    series.Add(new DashboardRecommendationByStatusData
                    {
                        RecommendationStatusId = status.ID,
                        RecommendationStatusName = status.Name,
                        Total = total
                    });
                }

                return series;

            }
        }

        #endregion

        #region Save

        public RecommendationResponseBatch CreateRecommendationResponseBatchRecord(int sentByUserId, int notificationType, int notificationOption, string senderName, string senderEmail, string emailSubject)
        {
            RecommendationResponseBatch result = null;
            using (var db = new MA2DbContext())
            {
                try
                {

                    var record = new RecommendationResponseBatch
                    {
                        CreatedBy = sentByUserId,
                        CreatedDate = DateTime.UtcNow,
                        NotificationOption = notificationOption,
                        NotificationType = notificationType,
                        SenderName = senderName,
                        SenderEmail = senderEmail,
                        EmailSubject = emailSubject
                    };

                    result = db.RecommendationResponseBatches.Add(record);
                    db.SaveChanges();
                    return result;
                }
                catch (Exception e)
                {
                    LogHelper.Error("Could not save Recommendation Response Batch record", e);
                    throw;
                }
            }
        }

        public void CreateRecommendationResponseHistoryRecord(string recipientUser, int responseBatchId, int lpRecKey, int lpAllPiKey)
        {
            RecommendationResponseHistory result = null;
            using (var db = new MA2DbContext())
            {
                try
                {
                    var record = new RecommendationResponseHistory
                    {
                        CreatedDate = DateTime.UtcNow,
                        RecipientUserNameOrEmailAddress = recipientUser,
                        RecommendationResponseBatchID = responseBatchId,
                        LpRecKey = lpRecKey,
                        LpAllPiKey = lpAllPiKey
                    };

                    db.RecommendationResponseHistories.Add(record);
                    db.SaveChanges();

                }
                catch (Exception e)
                {
                    LogHelper.Error("Could not save Recommendation Response History record", e);
                    throw;
                }
            }
        }
        public async Task<Recommendation> UpdateRecommendationAsync(Recommendation entity)
        {

            Recommendation result = null;

            using (var db = new MA2DbContext())
            {
                try
                {
                    var existing = db.Recommendations.FirstOrDefault((x => x.ID == entity.ID));

                    if (existing != null)
                    {
                        existing.EstCostToComplete = entity.EstCostToComplete;
                        existing.Priority = entity.Priority;
                        existing.TargetDate = entity.TargetDate;
                        existing.CompletedDate = entity.CompletedDate;
                        existing.CustomerIntentDescription = entity.CustomerIntentDescription;

                        if (existing.RecommendationStatusID != entity.RecommendationStatusID)
                        {
                            existing.RecommendationStatusChangedDate = DateTime.UtcNow;
                        }

                        existing.RecommendationResponseStatusChangeDate = DateTime.UtcNow;
                        existing.RecommendationResponseStatusID = Constants.RecommendationResponseStatus.ResponseReceivedWithin30Days;

                        existing.RecommendationStatusID = entity.RecommendationStatusID;

                        result = existing;
                    }

                    await db.SaveChangesAsync();

                }
                catch (DbEntityValidationException e)
                {
                    throw new Exception(Helpers.FormatValidationErrors(e));
                }
            }

            return result;
        }

        public Recommendation UpdateRecommendationforExcel(Recommendation entity)
        {

            Recommendation result = null;

            using (var db = new MA2DbContext())
            {
                try
                {
                    var existing = db.Recommendations.FirstOrDefault((x => x.ID == entity.ID));

                    if (existing != null)
                    {
                        string exstngComments = FormatHelper.FormatDescriptionForHtmlValue(FormatHelper.HtmlDecode(existing.CustomerIntentDescription));
                        string entyComments = FormatHelper.FormatDescriptionForHtmlValue(FormatHelper.HtmlDecode(entity.CustomerIntentDescription));

                        exstngComments = exstngComments.Replace("\r", string.Empty).Replace("\n", string.Empty);
                        entyComments = entyComments.Replace("\r", string.Empty).Replace("\n", string.Empty);

                        exstngComments = !string.IsNullOrEmpty(exstngComments) ? FormatHelper.RemoveWhiteSpaceintoSingeSpace(exstngComments) : string.Empty;
                        entyComments = !string.IsNullOrEmpty(entyComments) ? FormatHelper.RemoveWhiteSpaceintoSingeSpace(entyComments) : string.Empty;

                        string entyPrty = !string.IsNullOrEmpty(entity.Priority) ? entity.Priority : "";
                        string extngPrty = !string.IsNullOrEmpty(existing.Priority) ? existing.Priority : "";


                        if (existing.EstCostToComplete != entity.EstCostToComplete || extngPrty != entyPrty ||
                            existing.TargetDate != entity.TargetDate || existing.CompletedDate != entity.CompletedDate ||
                            exstngComments != entyComments ||
                            existing.RecommendationStatusID != entity.RecommendationStatusID)
                        {
                            LogHelper.Info($"Rec upload old Comments {existing.LpRecKey} - {exstngComments}");
                            LogHelper.Info($"Rec upload new Comments { existing.LpRecKey} - {entyComments}");

                            existing.RecommendationResponseStatusChangeDate = DateTime.UtcNow;
                            existing.RecommendationResponseStatusID = Constants.RecommendationResponseStatus.ResponseReceivedWithin30Days;
                        }

                        existing.EstCostToComplete = entity.EstCostToComplete;
                        existing.Priority = entity.Priority;
                        existing.TargetDate = entity.TargetDate;
                        existing.CompletedDate = entity.CompletedDate;
                        existing.CustomerIntentDescription = entity.CustomerIntentDescription;

                        if (existing.RecommendationStatusID != entity.RecommendationStatusID)
                        {
                            existing.RecommendationStatusChangedDate = DateTime.UtcNow;
                        }

                        existing.RecommendationStatusID = entity.RecommendationStatusID;

                        result = existing;
                    }

                    db.SaveChanges();

                }
                catch (DbEntityValidationException ex)
                {
                    LogHelper.Error("UpdateRecommendationforExcel", ex);
                }
            }

            return result;
        }


        public RecommendationPermanentData InsertRecommendationUpdate(RecommendationPermanentData entity, String updatedByName)
        {
            RecommendationPermanentData result = null;

            try
            {
                using (var db = new MA2DbContext())
                {
                    var record = new RecommendationPermanentData();


                    record.LpRecKey = entity.LpRecKey;
                    record.LpAllPiKey = entity.LpAllPiKey;
                    record.EstCostToComplete = entity.EstCostToComplete;
                    record.ActCostToComplete = entity.ActCostToComplete;
                    record.CreatedDate = entity.CreatedDate;
                    record.RecommendationUpdateID = entity.RecommendationUpdateID;
                    record.IsModified = entity.IsModified;
                    result = db.RecommendationPermanentDatas.Add(record);

                    db.SaveChanges();
                }
            }
            catch (DbEntityValidationException e)
            {
                throw new Exception(Helpers.FormatValidationErrors(e));
            }

            return result;
        }



        public RecommendationUpdate InsertRecommendationUpdate(RecommendationUpdate entity)
        {
            RecommendationUpdate result = null;

            try
            {
                using (var db = new MA2DbContext())
                {
                    var record = new RecommendationUpdate();

                    record.UpdatedByName = entity.UpdatedByName;
                    record.UpdatedByEmail = entity.UpdatedByEmail;
                    record.UpdatedRecommendationStatusID = entity.UpdatedRecommendationStatusID;
                    record.RecommendationStatusIDChanged = entity.RecommendationStatusIDChanged;
                    record.UpdatedEstCostToComplete = entity.UpdatedEstCostToComplete;
                    record.EstCostToCompleteChanged = entity.EstCostToCompleteChanged;
                    record.UpdatedPriority = entity.UpdatedPriority;
                    record.PriorityChanged = entity.PriorityChanged;
                    record.UpdatedTargetDate = entity.UpdatedTargetDate;
                    record.TargetDateChanged = entity.TargetDateChanged;
                    record.UpdatedCompletedDate = entity.UpdatedCompletedDate;
                    record.CompletedDateChanged = entity.CompletedDateChanged;
                    record.Comment = entity.Comment;
                    record.CreatedDate = entity.CreatedDate;
                    record.LpRecKey = entity.LpRecKey;
                    record.LpAllPiKey = entity.LpAllPiKey;

                    result = db.RecommendationUpdates.Add(entity);

                    db.SaveChanges();
                }
            }
            catch (DbEntityValidationException e)
            {
                throw new Exception(Helpers.FormatValidationErrors(e));
            }



            return result;
        }

        #endregion

        #region FS-09 Type/Status Report



        /// <summary>
        /// 
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <returns></returns>
        public List<RecommendationByTypeStatusData> LoadRecommendationByTypeStatusData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, bool activeRecommendationsOnly = false)
        {
            ReferenceDbAccess reference = new ReferenceDbAccess();
            IEnumerable<RecommendationStatu> statuses = reference.GetRecommendationStatuses().Where(item => item.ID != RecommendationStatus.Unknown);

            if (activeRecommendationsOnly)
            {
                statuses = statuses.Where(x => ActiveRecommendationStatuses.Contains(x.ID));
            }

            using (var db = new MA2DbContext())
            {
                // Always start with this block
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                var uniqueRecommendations =
                (from result in qry
                 where result.RecommendationStatusID != null && result.RecommendationCategoryID != null
                 select new { result.RecommendationID, result.RecommendationCategoryID, result.RecommendationStatusID }).Distinct();

                // Then either filter further or join with another query
                var results =
                (from rec in uniqueRecommendations
                 group rec by new
                 {
                     rec.RecommendationStatusID,
                     rec.RecommendationCategoryID
                 }
                into recommendationStatusGroup
                 select new
                 {
                     recommendationStatusGroup.Key.RecommendationStatusID,
                     recommendationStatusGroup.Key.RecommendationCategoryID,
                     Total = recommendationStatusGroup.Count()
                 }).ToList();

                var series = new List<RecommendationByTypeStatusData>();

                // foreach status in our list, add a new series to the output
                foreach (var status in statuses)
                {
                    // load our physical recommendations for this status
                    var physical = (from item in results
                                    where item.RecommendationStatusID == status.ID && item.RecommendationCategoryID ==
                                          Constants.RecommendationCategory.PhysicalProtection
                                    select item.Total).SingleOrDefault();

                    // load our human recommendations for this status
                    var human = (from item in results
                                 where item.RecommendationStatusID == status.ID && item.RecommendationCategoryID ==
                                       Constants.RecommendationCategory.HumanElement
                                 select item.Total).SingleOrDefault();

                    series.Add(new RecommendationByTypeStatusData
                    {
                        RecommendationStatusId = status.ID,
                        RecommendationStatusName = status.Name,
                        RecommendationCategoriesPhysical = physical,
                        RecommendationCategoriesHuman = human
                    });
                }

                return series;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <param name="recommendationCategoryId"></param>
        /// <returns></returns>
        public List<RecommendationByCategoryData> LoadRecommendationByCategoryData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, int recommendationCategoryId, bool activeRecommendationsOnly = false)
        {
            ReferenceDbAccess reference = new ReferenceDbAccess();
            IEnumerable<RecommendationStatu> statuses = reference.GetRecommendationStatuses().Where(item => item.ID != Constants.RecommendationStatus.Unknown);

            if (activeRecommendationsOnly)
            {
                statuses = statuses.Where(x => ActiveRecommendationStatuses.Contains(x.ID));
            };

            var categories = reference.GetRecommendationCategories();
            var types = reference.GetRecommendationTypes();

            // unique RecommendationType.Name records (ideally will normalise this out to a parent table)
            var uniqueTypes = reference.GetRecommendationTypes()
                .Where(item => item.ID != Constants.RecommendationType.Unknown).GroupBy(item => item.Name)
                .Select(x => x.FirstOrDefault()).ToList();

            using (var db = new MA2DbContext())
            {
                // Always start with this block
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                qry = qry.Where(item => item.RecommendationCategoryID == recommendationCategoryId);

                var uniqueRecommendations =
                (from result in qry
                 where result.RecommendationStatusID != null &&
                 result.RecommendationTypeID != null &&
                 result.RecommendationCategoryID == recommendationCategoryId
                 select new { result.RecommendationID, result.RecommendationTypeID, result.RecommendationCategoryID, result.RecommendationStatusID }).Distinct();

                var results =
                    (from rec in uniqueRecommendations
                     group rec by new
                     {
                         rec.RecommendationStatusID,
                         rec.RecommendationTypeID
                     }
                        into recommendationStatusGroup
                     select new
                     {
                         recommendationStatusGroup.Key.RecommendationStatusID,
                         recommendationStatusGroup.Key.RecommendationTypeID,
                         Total = recommendationStatusGroup.Count()
                     }).ToList();

                var series = new List<RecommendationByCategoryData>();

                // foreach status in our list, add a new series to the output
                foreach (var status in statuses)
                {
                    var obj = new RecommendationByCategoryData
                    {
                        RecommendationStatusName = status.Name,
                        RecommendationStatusId = status.ID,
                        RecommendationCategoryId = recommendationCategoryId,
                        RecommendationCategoryName = categories.Find(item => item.ID == recommendationCategoryId).Name,
                        RecommendationByCategoryDataRecommendationTypes =
                            new List<RecommendationByCategoryDataRecommendationType>()
                    };

                    // iterate over distinct RecommendationType.Name records
                    foreach (var type in uniqueTypes)
                    {
                        var name = type.Name;

                        // list of RecommendationType.ID which sit under the distinct RecommendationType.Name
                        var typeIds = (from item in types where item.Name == type.Name select item.ID).ToList();

                        // aggregate results and group by distinct RecommendationType.Name
                        var total = (from item in results
                                     where item.RecommendationStatusID == status.ID &&
                                           typeIds.Contains(item.RecommendationTypeID.Value)
                                     select item.Total).Sum();

                        if (total > 0)
                        {
                            obj.RecommendationByCategoryDataRecommendationTypes.Add(new RecommendationByCategoryDataRecommendationType
                            {
                                RecommendationTypeName = name,
                                RecommendationTypeTotal = total
                            });
                        }
                    }

                    series.Add(obj);
                }

                return series;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <param name="recommendationCategoryId"></param>
        /// <param name="recommendationStatusId"></param>
        /// <returns></returns>
        public List<RecommendationByStatusData> LoadRecommendationByStatusData(DataFilter locationsSelectorDataFilter, DataFilter dataFilter, int recommendationCategoryId, int recommendationStatusId)
        {
            ReferenceDbAccess reference = new ReferenceDbAccess();
            var status = reference.GetRecommendationStatuses().Single(item => item.ID == recommendationStatusId);
            var category = reference.GetRecommendationCategories().Single(item => item.ID == recommendationCategoryId);
            var types = reference.GetRecommendationTypes();

            // unique RecommendationType.Name records (ideally will normalise this out to a parent table)
            var uniqueTypes = reference.GetRecommendationTypes()
                .Where(item => item.ID != Constants.RecommendationType.Unknown).GroupBy(item => item.Name)
                .Select(x => x.FirstOrDefault()).ToList();

            using (var db = new MA2DbContext())
            {
                // Always start with this block
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                qry = qry.Where(item => item.RecommendationCategoryID == recommendationCategoryId);
                qry = qry.Where(item => item.RecommendationStatusID == recommendationStatusId);

                var uniqueRecommendations =
                (from result in qry
                 where result.RecommendationTypeID != null &&
                 result.RecommendationCategoryID == recommendationCategoryId &&
                 result.RecommendationStatusID == recommendationStatusId
                 select new { result.RecommendationID, result.RecommendationStatusID, result.RecommendationTypeID }).Distinct();

                var results =
                (from rec in uniqueRecommendations
                 group rec by new
                 {
                     rec.RecommendationStatusID,
                     rec.RecommendationTypeID
                 }
                into recommendationStatusGroup
                 select new
                 {
                     recommendationStatusGroup.Key.RecommendationStatusID,
                     recommendationStatusGroup.Key.RecommendationTypeID,
                     Total = recommendationStatusGroup.Count()
                 }).ToList();

                var series = new List<RecommendationByStatusData>();
                var obj = new RecommendationByStatusData
                {
                    RecommendationStatusName = status.Name,
                    RecommendationStatusId = status.ID,
                    RecommendationCategoryName = category.Name,
                    RecommendationByStatusDataRecommendationTypes =
                        new List<RecommendationByStatusDataRecommendationType>()
                };

                // iterate over distinct RecommendationType.Name records
                foreach (var type in uniqueTypes)
                {
                    var name = type.Name;
                    var id = type.ID;
                    var group = type.RecommendationTypeGroup;

                    // list of RecommendationType.ID which sit under the distinct RecommendationType.Name
                    var typeIds = (from item in types where item.Name == type.Name select item.ID).ToList();

                    // aggregate results and group by distinct RecommendationType.Name
                    var total = (from item in results
                                 where typeIds.Contains(item.RecommendationTypeID.GetValueOrDefault(0))
                                 select item.Total).Sum();

                    if (total > 0)
                    {
                        obj.RecommendationByStatusDataRecommendationTypes.Add(new RecommendationByStatusDataRecommendationType
                        {
                            RecommendationTypeName = name,
                            RecommendationTypeTotal = total,
                            RecommendationCategoryId = recommendationCategoryId,
                            RecommendationStatusId = recommendationStatusId,
                            RecommendationTypeId = id,
                            RecommendationTypeGroup = group
                        });
                    }
                }

                series.Add(obj);
                return series;
            }
        }

        #endregion
    }
}

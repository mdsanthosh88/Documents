﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Linq;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.Shared;

namespace XLC.MyAnalysis2.DbAccess
{
    public class SystemGridDbAccess : BaseDataAccess
    {
        #region Load

        /// <summary>
        /// 
        /// </summary>
        /// <param name="systemGridRef"></param>
        /// <param name="userId"></param>
        /// <param name="restore"></param>
        /// <param name="localeSpecific"></param>
        /// <returns></returns>
        public UserSystemGridDTO LoadSystemGridForUser(int systemGridRef, int userId, bool restore,
           bool isInternalUser, bool localeSpecific = true, int accountId = 0)
        {
            UserSystemGridDTO result = null;
            var results = new List<ProcLoadGridSettingsReturnModel>();

            using (var db = new MA2DbContext())
            {
                using (var connection = db.Database.Connection)
                {
                    connection.Open();
                    var command = connection.CreateCommand();

                    command.CommandText = "[dbo].[proc_LoadGridSettings]";
                    command.CommandType = CommandType.StoredProcedure;

                    var systemGridRefParam = new SqlParameter
                    {
                        ParameterName = "@SystemGridRef",
                        SqlDbType = SqlDbType.Int,
                        Direction = ParameterDirection.Input,
                        Value = systemGridRef
                    };
                    var userIdParam = new SqlParameter
                    {
                        ParameterName = "@UserID",
                        SqlDbType = SqlDbType.Int,
                        Direction = ParameterDirection.Input,
                        Value = userId
                    };
                    var accountIdParam = new SqlParameter
                    {
                        ParameterName = "@LPAcctKey",
                        SqlDbType = SqlDbType.Int,
                        Direction = ParameterDirection.Input,
                        Value = accountId
                    };

                    var localeSpecificParam = new SqlParameter
                    {
                        ParameterName = "@LCID",
                        SqlDbType = SqlDbType.Int,
                        Direction = ParameterDirection.Input,
                        Value = CurrentLcid
                    };
                    if (!localeSpecific)
                        localeSpecificParam.Value = DBNull.Value;

                    var restoreParam = new SqlParameter
                    {
                        ParameterName = "@Restore",
                        SqlDbType = SqlDbType.Bit,
                        Direction = ParameterDirection.Input,
                        Value = restore
                    };

                    var successParam = new SqlParameter
                    { ParameterName = "@Success", SqlDbType = SqlDbType.Bit, Direction = ParameterDirection.Output };
                    var errorParam = new SqlParameter
                    {
                        ParameterName = "@ErrorMsg",
                        SqlDbType = SqlDbType.NVarChar,
                        Size = -1,
                        Direction = ParameterDirection.Output
                    };

                    command.Parameters.Add(systemGridRefParam);
                    command.Parameters.Add(userIdParam);
                    command.Parameters.Add(accountIdParam);
                    command.Parameters.Add(localeSpecificParam);
                    command.Parameters.Add(restoreParam);

                    command.Parameters.Add(successParam);
                    command.Parameters.Add(errorParam);

                    using (var reader = command.ExecuteReader())
                    {
                        results = ((IObjectContextAdapter)db)
                            .ObjectContext
                            .Translate<ProcLoadGridSettingsReturnModel>(reader)
                            .ToList();
                    }

                    result = MapViewToDTO(results, isInternalUser);
                }
            }

            return result;
        }

        // to be used to override particular groups from being enabled by users, see US 215369 for an example
        // of groups which cannot be enabled by external users
        public bool UserCanEnableGridGroup(int gridGroupId, bool isInternalUser)
        {
            switch (gridGroupId)
            {
                case Constants.SystemGridGroup.RiskQualityRatings_Class:
                    return isInternalUser;
                default:
                    return true;
            }
        }

        public bool UserCanEnableGridField(int gridFieldId, bool isInternalUser)
        {
            switch (gridFieldId)
            {
                case Constants.SystemGridFieldRef.RiskQualityRatings_OccupancyClassNACE:
                case Constants.SystemGridFieldRef.RiskQualityRatings_OccupancyClassSIC:
                case Constants.SystemGridFieldRef.RiskQualityRatings_FireClass:
                    return isInternalUser;
                default:
                    return true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private UserSystemGridDTO MapViewToDTO(List<ProcLoadGridSettingsReturnModel> data, bool isInternalUser)
        {
            var results = (from grid in data
                           group grid by new
                           {
                               grid.SystemGridID,
                               grid.SystemGridSystemScreenID,
                               grid.SystemGridName,
                               grid.SystemGridSystemGridRef
                           }
                into gridGroup
                           select new UserSystemGridDTO
                           {
                               SystemGridID = gridGroup.Key.SystemGridID,
                               SystemGridSystemScreenID = gridGroup.Key.SystemGridSystemScreenID,
                               SystemGridName = gridGroup.Key.SystemGridName,
                               SystemGridSystemGridRef = gridGroup.Key.SystemGridSystemGridRef,
                               Groups = (from grp in gridGroup
                                         group grp by new
                                         {
                                             grp.SystemGridGroupID,
                                             grp.SystemGridGroupName,
                                             grp.SystemGridSystemGridID,
                                             grp.SystemGridSystemGridGroupRef,
                                             grp.SystemGridVisible,
                                             grp.SystemGridRank,
                                             grp.UserSystemGridGroupID,
                                             grp.UserSystemGridGroupCreatedDate,
                                             grp.UserSystemGridGroupCreatedBy,
                                             grp.UserSystemGridGroupUpdatedDate,
                                             grp.UserSystemGridGroupUpdatedBy,
                                             grp.UserSystemGridGroupUserID,
                                             grp.UserSystemGridGroupSystemGridGroupID,
                                             grp.UserSystemGridGroupVisible,
                                             grp.UserSystemGridGroupRank,
                                             grp.UserSystemGridGroupIsDefault
                                         }
                                   into grpGroup
                                         select new UserSystemGridGroupDTO
                                         {
                                             SystemGridGroupID = grpGroup.Key.SystemGridGroupID,
                                             SystemGridGroupName =FormatHelper.HtmlDecode(grpGroup.Key.SystemGridGroupName),
                                             SystemGridGroupSystemGridID = grpGroup.Key.SystemGridSystemGridID,
                                             SystemGridGroupSystemGridGroupRef = grpGroup.Key.SystemGridSystemGridGroupRef,
                                             SystemGridGroupVisible = grpGroup.Key.SystemGridVisible,
                                             SystemGridGroupRank = grpGroup.Key.SystemGridRank,
                                             UserSystemGridGroupID = grpGroup.Key.UserSystemGridGroupID,
                                             UserSystemGridGroupCreatedDate = grpGroup.Key.UserSystemGridGroupCreatedDate,
                                             UserSystemGridGroupCreatedBy = grpGroup.Key.UserSystemGridGroupCreatedBy,
                                             UserSystemGridGroupUpdatedDate = grpGroup.Key.UserSystemGridGroupUpdatedDate,
                                             UserSystemGridGroupUpdatedBy = grpGroup.Key.UserSystemGridGroupUpdatedBy,
                                             UserSystemGridGroupUserID = grpGroup.Key.UserSystemGridGroupUserID,
                                             UserSystemGridGroupSystemGridGroupID = grpGroup.Key.UserSystemGridGroupSystemGridGroupID,
                                             UserSystemGridGroupVisible = grpGroup.Key.UserSystemGridGroupVisible,
                                             UserSystemGridGroupRank = grpGroup.Key.UserSystemGridGroupRank,
                                             UserSystemGridGroupIsDefault = grpGroup.Key.UserSystemGridGroupIsDefault,
                                             UserCanEnable = UserCanEnableGridGroup(grpGroup.Key.SystemGridGroupID, isInternalUser),
                                             Fields = (from fld in grpGroup
                                                       group fld by new
                                                       {
                                                           fld.SystemGridFieldID,
                                                           fld.SystemGridFieldName,
                                                           fld.SystemGridFieldSystemGridGroupID,
                                                           fld.SystemGridFieldSystemGridFieldRef,
                                                           fld.SystemGridFieldVisible,
                                                           fld.SystemGridFieldRank,
                                                           fld.UserSystemGridFieldID,
                                                           fld.UserSystemGridFieldCreatedDate,
                                                           fld.UserSystemGridFieldCreatedBy,
                                                           fld.UserSystemGridFieldUpdatedDate,
                                                           fld.UserSystemGridFieldUpdatedBy,
                                                           fld.UserSystemGridFieldUserID,
                                                           fld.UserSystemGridFieldFieldID,
                                                           fld.UserSystemGridFieldVisible,
                                                           fld.UserSystemGridFieldRank,
                                                           fld.UserSystemGridFieldIsDefault,
                                                           fld.SystemGridFieldWidth,
                                                           fld.SystemGridFieldUserCanOverride,
                                                           fld.UserSystemGridFieldSortByField,
                                                           fld.UserSystemGridFieldSortDirection
                                                       }
                                                 into grpField
                                                       select new UserSystemGridFieldDTO
                                                       {
                                                           SystemGridFieldID = grpField.Key.SystemGridFieldID,
                                                           SystemGridFieldName = FormatHelper.HtmlDecode(grpField.Key.SystemGridFieldName),
                                                           SystemGridFieldSystemGridGroupID = grpField.Key.SystemGridFieldSystemGridGroupID,
                                                           SystemGridFieldSystemGridFieldRef = grpField.Key.SystemGridFieldSystemGridFieldRef,
                                                           SystemGridFieldVisible = grpField.Key.SystemGridFieldVisible,
                                                           SystemGridFieldRank = grpField.Key.SystemGridFieldRank,
                                                           SystemGridFieldWidth = grpField.Key.SystemGridFieldWidth,
                                                           SystemGridFieldUserCanOverride = grpField.Key.SystemGridFieldUserCanOverride,
                                                           UserSystemGridFieldID = grpField.Key.UserSystemGridFieldID,
                                                           UserSystemGridFieldCreatedDate = grpField.Key.UserSystemGridFieldCreatedDate,
                                                           UserSystemGridFieldCreatedBy = grpField.Key.UserSystemGridFieldCreatedBy,
                                                           UserSystemGridFieldUpdatedDate = grpField.Key.UserSystemGridFieldUpdatedDate,
                                                           UserSystemGridFieldUpdatedBy = grpField.Key.UserSystemGridFieldUpdatedBy,
                                                           UserSystemGridFieldUserID = grpField.Key.UserSystemGridFieldUserID,
                                                           UserSystemGridFieldSystemGridFieldID = grpField.Key.UserSystemGridFieldFieldID,
                                                           UserSystemGridFieldVisible = grpField.Key.UserSystemGridFieldVisible,
                                                           UserSystemGridFieldRank = grpField.Key.UserSystemGridFieldRank,
                                                           UserSystemGridFieldIsDefault = grpField.Key.UserSystemGridFieldIsDefault,
                                                           UserSystemGridFieldSortByField = grpField.Key.UserSystemGridFieldSortByField,
                                                           UserSystemGridFieldSortDirection = grpField.Key.UserSystemGridFieldSortDirection,
                                                           UserCanEnable = UserCanEnableGridField(grpField.Key.SystemGridFieldID, isInternalUser),
                                                       }).ToList()
                                         }).ToList()

                           }).ToList();


            return results.First();

        }



        public void UpdateUserSystemGridFieldRecord(UserSystemGridField userSystemGridField)
        {
            using (var db = new MA2DbContext())
            {
                var existing = db.UserSystemGridFields.Single(x => x.ID == userSystemGridField.ID);

                existing.SortByField = userSystemGridField.SortByField;
                existing.SortDirection = userSystemGridField.SortDirection;

                db.SaveChanges();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="SystemGridRef"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<UserSystemGridField> LoadUserSystemGridFieldsForGrid(int SystemGridRef, int userId)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<UserSystemGridField> qry = db.UserSystemGridFields;
                qry.Include(x => x.SystemGridField);
                qry.Include(x => x.SystemGridField.SystemGridGroup);
                qry.Include(x => x.SystemGridField.SystemGridGroup.SystemGrid);
                qry = qry.Where(x => x.SystemGridField.SystemGridGroup.SystemGrid.SystemGridRef == SystemGridRef);
                qry = qry.Where(x => x.UserID == userId);
                qry = qry.OrderBy(x => x.Rank);
                return qry.ToList();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="systemGridRef"></param>
        /// <param name="systemGridGroupRef"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public UserSystemGridGroup LoadUserSystemGridGroup(int systemGridRef, int systemGridGroupRef, int userId, int lpAcctKey = 0)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<UserSystemGridGroup> qry = db.UserSystemGridGroups;
                qry.Include(x => x.SystemGridGroup);
                qry.Include(x => x.SystemGridGroup.SystemGrid);
                qry = qry.Where(x => x.SystemGridGroup.SystemGrid.SystemGridRef == systemGridRef);
                qry = qry.Where(x => x.SystemGridGroup.SystemGridGroupRef == systemGridGroupRef);
                qry = qry.Where(x => x.UserID == userId);
                qry = qry.Where(x => x.LpAcctKey == lpAcctKey);
                return qry.SingleOrDefault();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="systemGridRef"></param>
        /// <param name="systemGridFieldRef"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public UserSystemGridField LoadUserSystemGridField(int systemGridRef, int systemGridFieldRef, int userId, int lpAcctKey = 0)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<UserSystemGridField> qry = db.UserSystemGridFields;
                qry.Include(x => x.SystemGridField);
                qry.Include(x => x.SystemGridField.SystemGridGroup);
                qry.Include(x => x.SystemGridField.SystemGridGroup.SystemGrid);
                qry = qry.Where(x => x.SystemGridField.SystemGridGroup.SystemGrid.SystemGridRef == systemGridRef);
                qry = qry.Where(x => x.SystemGridField.SystemGridFieldRef == systemGridFieldRef);
                qry = qry.Where(x => x.UserID == userId);
                qry = qry.Where(x => x.LpAcctKey == lpAcctKey); 
               
                qry = qry.OrderBy(x => x.Rank);
                return qry.SingleOrDefault();
            }
        }

        #endregion

        #region Save

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userSystemGridGroup"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public UserSystemGridGroup UpsertUserSystemGridGroup(UserSystemGridGroup userSystemGridGroup, int userId)
        {
            UserSystemGridGroup result = null;

            try
            {
                using (var db = new MA2DbContext())
                {
                    var existing = db.UserSystemGridGroups.FirstOrDefault(e => e.ID == userSystemGridGroup.ID);

                    if (existing != null)
                    {
                        existing.UserID = userSystemGridGroup.UserID;
                        existing.Visible = userSystemGridGroup.Visible;
                        existing.Rank = userSystemGridGroup.Rank;
                        existing.IsDefault = userSystemGridGroup.IsDefault;
                        existing.SystemGridGroupID = userSystemGridGroup.SystemGridGroupID;

                        existing.UpdatedDate = DateTime.UtcNow;
                        existing.UpdatedBy = userId;
                        existing.LpAcctKey = userSystemGridGroup.LpAcctKey;
                        result = existing;
                    }
                    else
                    {
                        userSystemGridGroup.UserID = userId;
                        userSystemGridGroup.CreatedDate = DateTime.UtcNow; // this would be done by interceptor
                        userSystemGridGroup.UpdatedDate = DateTime.UtcNow;
                        userSystemGridGroup.CreatedBy = userId;
                        userSystemGridGroup.LpAcctKey = userSystemGridGroup.LpAcctKey;
                        result = db.UserSystemGridGroups.Add(userSystemGridGroup);
                    }

                    db.SaveChanges();
                }
            }
            catch (DbEntityValidationException e)
            {
                throw new Exception(Helpers.FormatValidationErrors(e));
                throw e;
            }

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userSystemGridField"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public UserSystemGridField UpsertUserSystemGridField(UserSystemGridField userSystemGridField, int userId)
        {
            UserSystemGridField result = null;

            try
            {
                using (var db = new MA2DbContext())
                {
                    var existing = db.UserSystemGridFields.FirstOrDefault(e => e.ID == userSystemGridField.ID);

                    if (existing != null)
                    {
                        existing.UserID = userSystemGridField.UserID;
                        existing.Visible = userSystemGridField.Visible;
                        existing.Rank = userSystemGridField.Rank;
                        existing.IsDefault = userSystemGridField.IsDefault;
                        existing.SystemGridFieldID = userSystemGridField.SystemGridFieldID;
                        if (!string.IsNullOrEmpty(userSystemGridField.Name))
                        {
                            existing.Name = userSystemGridField.Name;
                        }
                        existing.LpAcctKey = userSystemGridField.LpAcctKey;
                        existing.UpdatedDate = DateTime.UtcNow;
                        existing.UpdatedBy = userId;

                        result = existing;
                    }
                    else
                    {

                        userSystemGridField.UserID = userId;
                        userSystemGridField.CreatedDate = DateTime.UtcNow; // this would be done by interceptor
                        userSystemGridField.UpdatedDate = DateTime.UtcNow;
                        userSystemGridField.CreatedBy = userId;
                        userSystemGridField.LpAcctKey = userSystemGridField.LpAcctKey;
                        result = db.UserSystemGridFields.Add(userSystemGridField);
                    }

                    db.SaveChanges();
                }
            }
            catch (DbEntityValidationException e)
            {
                throw new Exception(Helpers.FormatValidationErrors(e));
                throw e;
            }

            return result;
        }
        #endregion
    }
}

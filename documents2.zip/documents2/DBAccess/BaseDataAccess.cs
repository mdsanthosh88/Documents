﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using XLC.MyAnalysis2.DbAccess.ExtensionMethods;
using XLC.MyAnalysis2.DbModels;

namespace XLC.MyAnalysis2.DbAccess
{
    public abstract class BaseDataAccess
    {
        protected int CurrentLcid { get; set; }

        protected string UserName { get; private set; }

        protected BaseDataAccess()
        {
            CurrentLcid = Thread.CurrentThread.CurrentUICulture.LCID;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="userName">Name of the authenticated user</param>
        protected BaseDataAccess(string userName)
        {
            this.UserName = userName;
        }

        #region Data Filters

        /// <summary>
        /// Return a list of filtered data to join the contexual query on to
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <returns></returns>
        public List<ViewDataFilter> FilteredData(DataFilter dataFilter, DataFilter locationsSelectorDataFilter)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;

                // apply the custom data filter criteria
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                return qry.ToList();
            }
        }

        #endregion

        #region Helpers

        protected DataTable ConvertIntListToDataTable(List<int> input)
        {
            var dataTable = new DataTable();
            dataTable.Columns.Add(new DataColumn("ID", typeof(int)));
            foreach (int id in input)
                dataTable.Rows.Add(id);

            return dataTable;
        }

        protected DataTable ConvertNullableIntListToDataTable(List<int?> input)
        {
            var dataTable = new DataTable();
            dataTable.Columns.Add(new DataColumn("ID", typeof(int)));
            foreach (var id in input)
                dataTable.Rows.Add(id);

            return dataTable;
        }

        protected DataTable ConvertStringListToDataTable(List<string> input)
        {
            var dataTable = new DataTable();
            dataTable.Columns.Add(new DataColumn("ID", typeof(string)));
            foreach (string id in input)
                dataTable.Rows.Add(id);

            return dataTable;
        }

        /// <summary>
        /// Given a Location filter and Data filter, return a list of unique Location IDs
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <returns></returns>
        public List<int> GetDataFilterUniqueLocations(DataFilter locationsSelectorDataFilter, DataFilter dataFilter)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                var results =
                    (from risk in qry
                     select risk);

                return (from result in results select result.LpAllPiKey).Distinct().ToList();
            }
        }

        /// <summary>
        /// Given a Location filter and Data filter, return a list of unique Recommendation IDs
        /// </summary>
        /// <param name="locationsSelectorDataFilter"></param>
        /// <param name="dataFilter"></param>
        /// <returns></returns>
        public List<int> GetDataFilterUniqueRecommendations(DataFilter locationsSelectorDataFilter, DataFilter dataFilter)
        {
            using (var db = new MA2DbContext())
            {
                IQueryable<ViewDataFilter> qry = null;
                qry = db.ViewDataFilters;
                qry = qry.ApplyCriteria(locationsSelectorDataFilter, dataFilter);

                var results =
                    (from risk in qry
                     select risk);

                return (from result in results select result.RecommendationID.GetValueOrDefault()).Distinct().ToList();
            }
        }

        #endregion
    }
}

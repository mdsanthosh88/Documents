﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Messaging;
using System.Threading.Tasks;
using System.Web;
using Newtonsoft.Json;
using XLC.MyAnalysis2.DbAccess;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.DbModels.DbEnums;
using XLC.MyAnalysis2.DocumentService;
using XLC.MyAnalysis2.Logic.DTO;
using XLC.MyAnalysis2.Logic.DTO.MessageQueueDTO;
using XLC.MyAnalysis2.Resources;
using XLC.MyAnalysis2.Shared;
using XLC.MyAnalysis2.Shared.ReportExport;
using System.Xml.Serialization;
using String = System.String;

namespace XLC.MyAnalysis2.Logic
{
    public class UserLogic
    {
        protected DataRepository Repo = new DataRepository();
        protected LdapDbAccess EdsData = new LdapDbAccess();

        private readonly string _userName;


        public UserLogic() : base() { }
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="userName">Current authenticated user</param>
        public UserLogic(string userName)
        {
            this._userName = userName;
        }

        public User GetByEDSCN(string userName)
        {
            UserDbAccess db = new UserDbAccess(this._userName);
            return db.GetByEDSCN(userName);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public UserLoginTracking GetUserLastLoginDate(int userId)
        {
            UserDbAccess db = new UserDbAccess(this._userName);
            return db.GetUserLastLoginDate(userId);
        }

        #region UserAccountProfile
        /// <summary>
        /// If the user has a Global As At Date defined in their Account User Profile then return this
        /// Else null
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="lpAcctKey"></param>p
        /// <returns></returns>
        public DateTime? GetAnyGlobalAsAtDateForUser(int userId, int lpAcctKey)
        {
            DateTime? globalAsAtDate = null;

            var db = new UserDbAccess(this._userName);
            var userAccountProfile = db.GetUserAccountProfile(userId, lpAcctKey);
            if (userAccountProfile?.GlobalAsAtDateDay != null
                && userAccountProfile.GlobalAsAtDateMonth != null)
            {
                int year = userAccountProfile.GlobalAsAtDateYear ?? DateTime.Today.Year;

                globalAsAtDate = new DateTime(year, (int)userAccountProfile.GlobalAsAtDateMonth, (int)userAccountProfile.GlobalAsAtDateDay);

                // If the recursive global As At Date is set for a date in the future, i.e. set to recur every 01-May, 
                // then set to the previous year
                if (userAccountProfile.GlobalAsAtDateYear == null && globalAsAtDate >= DateTime.Now)
                    globalAsAtDate = globalAsAtDate.Value.AddYears(-1);
            }

            return globalAsAtDate;
        }

        public UserAccountProfile GetUserAccountProfileRecordForUser(int userId, int lpAcctKey)
        {
            var db = new UserDbAccess(this._userName);

            return db.GetUserAccountProfile(userId, lpAcctKey);
        }

        public async Task<UserAccountProfile> UpsertUserAccountProfileAsync(UserAccountProfile entity)
        {
            var db = new UserDbAccess(this._userName);

            return await db.UpsertUserAccountProfileAsync(entity);
        }
        #endregion


        public Role GetRole(int id)
        {
            return Repo.GetById<Role>(id);
        }

        public User GetUser(int userId)
        {
            UserDbAccess db = new UserDbAccess(this._userName);

            return db.GetById(userId);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="user"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public User UpsertUser(User user, int userId)
        {
            UserDbAccess db = new UserDbAccess(this._userName);

            user.AccountAccessRestricted = (!user.AccountAccessAll
                                            && user.UserAccountLevelAccesses.Count > 0);

            return db.UpsertUser(user, userId);
        }



        public void UpdateUserLanguage(UserMerged target, int languageId, string updaterUserName)
        {
            UserDbAccess db = new UserDbAccess(this._userName);
            db.UpdateUserLanguagePreference(target.ID, languageId, updaterUserName);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        /// <param name="userStatusId"></param>
        /// <param name="updaterUserName"></param>
        public void UpdateUserStatus(UserMerged target, int userStatusId, string updaterUserName)
        {
            UserDbAccess db = new UserDbAccess(this._userName);
            db.UpdateUserStatus(target.ID, userStatusId, updaterUserName);
        }

        #region UserProfileCache
        /// <summary>
        /// Searches EDS for users who have been created after the supplied createDateTime
        /// </summary>
        /// <param name="createDateTime"></param>
        /// <returns></returns>
        public List<EDSUser> GetNewlyCreatedUsers(DateTime createDateTime)
        {
            var internalConnectionString = ConfigHelper.GetAppSetting("EDSInternalOU");
            var externalConnectionString = ConfigHelper.GetAppSetting("EDSExternalOU");

            var internalUserName = EncryptedItemHelper.GetDecryptedValue(EncryptedItemHelper.EncryptedItemEnum.EdsInternalUserName);
            var externalUsername = EncryptedItemHelper.GetDecryptedValue(EncryptedItemHelper.EncryptedItemEnum.EdsExternalUserName);

            var internalPassword = EncryptedItemHelper.GetDecryptedValue(EncryptedItemHelper.EncryptedItemEnum.EdsInternalPassword);
            var externalPassword = EncryptedItemHelper.GetDecryptedValue(EncryptedItemHelper.EncryptedItemEnum.EdsExternalPassword);

            var internalUsers = EdsData.GetUpsertedUsers(createDateTime, internalConnectionString, internalUserName, internalPassword, true);
            var externalUsers = EdsData.GetUpsertedUsers(createDateTime, externalConnectionString, externalUsername, externalPassword, false);

            return internalUsers.Concat(externalUsers).ToList();
        }

        public List<EDSUser> GetAllUsers()
        {
            var internalConnectionString = ConfigHelper.GetAppSetting("EDSInternalOU");
            var externalConnectionString = ConfigHelper.GetAppSetting("EDSExternalOU");

            var internalUserName = EncryptedItemHelper.GetDecryptedValue(EncryptedItemHelper.EncryptedItemEnum.EdsInternalUserName);
            var externalUsername = EncryptedItemHelper.GetDecryptedValue(EncryptedItemHelper.EncryptedItemEnum.EdsExternalUserName);

            var internalPassword = EncryptedItemHelper.GetDecryptedValue(EncryptedItemHelper.EncryptedItemEnum.EdsInternalPassword);
            var externalPassword = EncryptedItemHelper.GetDecryptedValue(EncryptedItemHelper.EncryptedItemEnum.EdsExternalPassword);

            var internalUsers = EdsData.GetAllUsers(internalConnectionString, internalUserName, internalPassword, true);
            var externalUsers = EdsData.GetAllUsers(externalConnectionString, externalUsername, externalPassword, false);

            return internalUsers.Concat(externalUsers).ToList();
        }

        public DateTime? GetLastIncrementalCachingDateTime()
        {
            return Repo.GetAll<UserProfileCacheProcessor>().SingleOrDefault(x => x.UserProfileCacheProcessorTypeID == Constants.UserProfileCacheProcessorType.Incremental)?.LastProcessed;
        }

        public DateTime? GetLastFullIncrementalCachingDateTime()
        {
            return Repo.GetAll<UserProfileCacheProcessor>().SingleOrDefault(x => x.UserProfileCacheProcessorTypeID == Constants.UserProfileCacheProcessorType.Full)?.LastProcessed;
        }

        public void RecordIncrementalCachingCompletion()
        {
            var db = new UserDbAccess(this._userName);
            db.RecordIncrementalCachingCompletion();
        }
        public void RecordFullCachingCompletion()
        {
            var db = new UserDbAccess(this._userName);
            db.RecordFullCachingCompletion();
        }


        public void DropStageUserProfileCacheRecords()
        {
            var db = new UserDbAccess(this._userName);
            db.DropStageUserProfileCacheRecords();
        }

        public void DropSwapUserProfileCacheRecords()
        {
            var db = new UserDbAccess(this._userName);
            db.DropSwapUserProfileCacheRecords();
        }
        public void WriteUsersToEdsCacheStage(List<EDSUser> users)
        {
            var db = new UserDbAccess(this._userName);
            db.WriteUsersToEdsCacheStage(users);
        }

        public void WriteUsersToEdsCache(List<EDSUser> users)
        {
            var db = new UserDbAccess(this._userName);
            db.WriteUsersToEdsCache(users);
        }

        public void UserProfileCachePartitionSwitch()
        {
            var db = new UserDbAccess(this._userName);
            db.UserProfileCachePartitionSwitch();
        }

        #endregion



        /// <summary>
        /// Gets full user data as a combination of
        /// 1) PII data from EDS
        /// 2) MA2 specific data (user permissions etc) from MA2Data DB
        /// </summary>
        /// <param name="EdsCn"></param>
        /// <returns></returns>
        public UserMerged GetMergedUserByEdsCn(string EdsCn)
        {
            var m = Repo.GetAll<User>().SingleOrDefault(x => x.EdsCn == EdsCn);
            var e = EdsData.GetEdsUserProfileDataForSingleUser((m != null) ? m.EdsCn : EdsCn);

            ReferenceListLogic referenceListLogic = new ReferenceListLogic();
            var userStatuses = referenceListLogic.GetUserStatuses();

            return (new UserMerged
            {
                ForeName = (e != null) ? e.FirstName : "",
                Surname = (e != null) ? e.Surname : "",
                MiddleName = (e != null) ? e.MiddleName : "",
                JobTitle = (e != null) ? e.JobTitle : "",
                PhoneNumber = (e != null) ? e.Telephone : "",
                Mobile = (e != null) ? e.MobilePhone : "",
                Email = (e != null) ? e.Email : "",
                HasEdsRecord = e != null,
                ID = m?.ID ?? -1,
                CreatedDate = m?.CreatedDate ?? DateTime.Now,
                CreatedBy = m?.CreatedBy ?? -1,
                UpdatedDate = m?.UpdatedDate ?? DateTime.Now,
                UpdatedBy = m?.UpdatedBy ?? -1,
                EdsCn = EdsCn,
                UserTitleID = (m != null) ? m.UserTitleID : -1,
                LastActivityDate = (m != null) ? m.LastActivityDate : DateTime.UtcNow,
                InternalUser = (e != null) ? e.InternalUser : false,
                IpAddress = (m != null) ? m.IpAddress : "",
                LanguageID = m?.LanguageID ?? Constants.SystemDefaultLanguage,
                UserStatusID = m?.UserStatusID ?? Constants.UserStatus.Pending,
                SiteSurveyContact = m?.SiteSurveyContact ?? false,
                SiteRecResponseDesignee = (m != null) && m.SiteRecResponseDesignee,
                SiteRecAssignedDesignee = (m != null) && m.SiteRecAssignedDesignee,
                AccountAccessAll = m?.AccountAccessAll ?? false,
                AccountAccessIp = (m != null) && m.AccountAccessIp,
                AccountAccessNap = m?.AccountAccessNap ?? false,
                AccountAccessRestricted = (m != null) && m.AccountAccessRestricted,
                CurrentLpAcctKey = (m != null) ? m.CurrentLpAcctKey : -1,
                MigratedFromMa1 = m?.MigratedFromMa1 ?? false,
                DataFilters = (m != null) ? m.DataFilters : new List<DataFilter>(),
                UserAccountLevelAccesses =
                    (m != null) ? m.UserAccountLevelAccesses : new List<UserAccountLevelAccess>(),
                UserDivisionLevelAccesses =
                    (m != null) ? m.UserDivisionLevelAccesses : new List<UserDivisionLevelAccess>(),
                UserRegionLevelAccesses =
                    (m != null) ? m.UserRegionLevelAccesses : new List<UserRegionLevelAccess>(),
                UserClassificationLevelAccesses =
                    (m != null) ? m.UserClassificationLevelAccesses : new List<UserClassificationLevelAccess>(),
                UserOtherProviderLevelAccesses =
                    (m != null) ? m.UserOtherProviderLevelAccesses : new List<UserOtherProviderLevelAccess>(),
                UserDocumentAccesses = (m != null) ? m.UserDocumentAccesses : new List<UserDocumentAccess>(),
                UserLocationLevelAccesses =
                    (m != null) ? m.UserLocationLevelAccesses : new List<UserLocationLevelAccess>(),
                UserLoginTrackings = (m != null) ? m.UserLoginTrackings : new List<UserLoginTracking>(),
                UserReportHistories = (m != null) ? m.UserReportHistories : new List<UserReportHistory>(),
                UserRoles = (m != null) ? m.UserRoles : new List<UserRole>(),
                UserSubDivisionLevelAccesses =
                    (m != null) ? m.UserSubDivisionLevelAccesses : new List<UserSubDivisionLevelAccess>(),
                WhatIfScenarios = (m != null) ? m.WhatIfScenarios : new List<WhatIfScenario>(),
                Language = (m != null) ? m.Language : new Language() { ID = Constants.SystemDefaultLanguage },
                UserStatu = (m != null)
                    ? m.UserStatu
                    : userStatuses.Single(us => us.ID == Constants.UserStatus.Pending), //initial state = Pending
                UserTitle = (m != null) ? m.UserTitle : new UserTitle(),
                Translator = (m != null) ? m.Translator : false,
                AccountAccessStandard = (m != null) ? m.AccountAccessStandard : false
            });
        }

        /// <summary>
        /// Gets MA2 specific data from MA2Data DB. Does not obtain the PII data from EDS.
        /// </summary>
        /// <param name="EdsCn"></param>
        /// <returns></returns>
        public UserMerged GetLocalUserByEdsCn(string EdsCn)
        {
            var m = Repo.GetAll<User>().SingleOrDefault(x => x.EdsCn == EdsCn);

            ReferenceListLogic referenceListLogic = new ReferenceListLogic();
            var userStatuses = referenceListLogic.GetUserStatuses();

            return (new UserMerged
            {
                ID = m?.ID ?? -1,
                CreatedDate = m?.CreatedDate ?? DateTime.Now,
                CreatedBy = m?.CreatedBy ?? -1,
                UpdatedDate = m?.UpdatedDate ?? DateTime.Now,
                UpdatedBy = m?.UpdatedBy ?? -1,
                EdsCn = EdsCn,
                UserTitleID = (m != null) ? m.UserTitleID : -1,
                LastActivityDate = (m != null) ? m.LastActivityDate : DateTime.UtcNow,
                IpAddress = (m != null) ? m.IpAddress : "",
                LanguageID = m?.LanguageID ?? Constants.SystemDefaultLanguage,
                UserStatusID = m?.UserStatusID ?? Constants.UserStatus.Pending,
                SiteSurveyContact = m?.SiteSurveyContact ?? false,
                SiteRecResponseDesignee = (m != null) && m.SiteRecResponseDesignee,
                SiteRecAssignedDesignee = (m != null) && m.SiteRecAssignedDesignee,
                AccountAccessAll = m?.AccountAccessAll ?? false,
                AccountAccessIp = (m != null) && m.AccountAccessIp,
                AccountAccessNap = m?.AccountAccessNap ?? false,
                AccountAccessRestricted = (m != null) && m.AccountAccessRestricted,
                CurrentLpAcctKey = (m != null) ? m.CurrentLpAcctKey : -1,
                MigratedFromMa1 = m?.MigratedFromMa1 ?? false,
                DataFilters = (m != null) ? m.DataFilters : new List<DataFilter>(),
                UserRoles = (m != null) ? m.UserRoles : new List<UserRole>(),
                Language = (m != null) ? m.Language : new Language() { ID = Constants.SystemDefaultLanguage },
                UserStatu = (m != null)
                    ? m.UserStatu
                    : userStatuses.Single(us => us.ID == Constants.UserStatus.Pending), //initial state = Pending
                UserTitle = (m != null) ? m.UserTitle : new UserTitle(),
                Translator = m?.Translator ?? false,
                AccountAccessStandard = m?.AccountAccessStandard ?? false
            });
        }

        /// <summary>
        /// Given a CN - execute an LDAP query to determine whether user has access (is assigned to the xlExtAppID of the current instance)
        /// </summary>
        /// <param name="EdsCn"></param>
        /// <returns></returns>
        public bool UserIsAssignedToXlExtAppID(string EdsCn)
        {
            var e = EdsData.GetEdsUserProfileDataForSingleUser(EdsCn);
            return true;
        }

        public List<Role> GetAllRoles()
        {
            return new List<Role>(Repo.GetAll<Role>());
        }

        /// <summary>
        /// Given a list of [dbo].[User] IDs, return a basic User Profile from the cache
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public List<ViewUserMerged> GetUserProfileCacheByUserIds(List<int> userIds)
        {
            var maUsers = Repo.GetAll<ViewUser>().Where(x => userIds.Contains(x.UserID));

            List<string> uniqueEdsCn = maUsers.Select(x => x.EdsCn).ToList();

            var edsUsers = EdsData.GetEdsUserProfileDataForAllUsers(null, null, null, uniqueEdsCn);
            var filteredList = new List<ViewUserMerged>();

            //return edsUsers.Select(x => new ViewUserMerged
            //{
            //    Forename = x.FirstName,
            //    Surname = x.Surname,
            //    FullName = x.FirstName + " " + x.Surname,
            //    EdsCn = x.EDS_CN,
            //    Email = x.Email,
            //    UserID = x.U

            //}).ToList();

            var qry = filteredList.Concat(from m in edsUsers
                                          join e in maUsers on m.EDS_CN equals e.EdsCn into ps
                                          from e in ps.DefaultIfEmpty()
                                          select new ViewUserMerged
                                          {
                                              Forename = m.FirstName,
                                              Surname = m.Surname,
                                              FullName = m.FirstName + " " + m.Surname,
                                              EdsCn = m.EDS_CN,
                                              Email = m.Email,
                                              UserID = (e != null) ? e.UserID : -1
                                          });
            return qry.ToList();
        }
               
        public List<ViewUserMerged> GetUsers(PagingInfo paging, UsersFilters filters, string sortExpression)
        {
            var filteredList = new List<ViewUserMerged>();
            var edsUsers = EdsData.GetEdsUserProfileDataForAllUsers(userLastNameSearchTerm: null, userMailSearchTerm: null).ToList();

            //var qry = userList.AsEnumerable();

            //if (qry == null || edsUsers.Count != userCount)
            //{
            UserDbAccess userDbAccess = new UserDbAccess(this._userName);
            var qry = userDbAccess.GetUserEDS(toXML(edsUsers)).AsEnumerable();

            //userList = result.ToList();
            //paging.TotalRecords = result.Count;

            //userCount = edsUsers.Count;

            //return result.Skip(paging.PageOffset)
            //    .Take(paging.PageSize)
            //    .ToList();

            //}

            //if (qry == null || edsUsers.Count != userCount)
            //{
            //    userCount = edsUsers.Count();

            //var maUsers = Repo.GetAll<ViewUser>();

            //qry = (from m in edsUsers
            //       join e in maUsers on m.EDS_CN equals e.EdsCn into ps
            //       from e in ps.DefaultIfEmpty()
            //       select new ViewUserMerged
            //       {
            //           Forename = m.FirstName,
            //           Surname = m.Surname,
            //           FullName = m.FirstName + " " + m.Surname,
            //           EdsCn = m.EDS_CN,
            //           RoleID = (e != null) ? e.RoleID : -1,
            //           RoleName = (e != null) ? e.RoleName : default(string),
            //           Status = (e != null) ? e.Status : "Pending",
            //           Client = (e != null) ? e.Client : default(string),
            //           UserID = (e != null) ? e.UserID : -1,
            //           Email = m.Email
            //       });



            //userList = qry.ToList();
            //}

            if (filters != null)
            {
                if (filters.RoleIDFilter != null && filters.RoleIDFilter.Count > 0)
                    qry = qry.Where(x => filters.RoleIDFilter.Contains(x.RoleID));

                if (!string.IsNullOrEmpty(filters.LastNameFilter))
                    qry = qry.Where(x => x.Surname == filters.LastNameFilter);

                if (!string.IsNullOrEmpty(filters.EmailFilter))
                    qry = qry.Where(x => x.Email == filters.EmailFilter);

                if (filters.AccountsFilter != null && filters.AccountsFilter.Count > 0)
                {
                    var userAccountPriviledges = Repo.GetAll<ViewUserAccountPriviledge>();
                    qry = qry.Where(x => userAccountPriviledges.Any(uap => uap.UserId == x.UserID && filters.AccountsFilter.Contains(uap.LpAcctKey)));
                }

                if (filters.DivisionsFilter != null && filters.DivisionsFilter.Count > 0)
                {
                    var userDivisionPriviledges = Repo.GetAll<ViewUserDivisionPriviledge>();
                    qry = qry.Where(x => userDivisionPriviledges.Any(udp => udp.UserId == x.UserID && filters.DivisionsFilter.Contains(udp.LpAcctWebDivKey)));
                }

                if (filters.SubDivisionsFilter != null && filters.SubDivisionsFilter.Count > 0)
                {
                    var userSubDivisionPriviledges = Repo.GetAll<ViewUserSubDivisionPriviledge>();
                    qry = qry.Where(x => userSubDivisionPriviledges.Any(usdp => usdp.UserId == x.UserID && filters.SubDivisionsFilter.Contains(usdp.LpSubDivKey)));
                }

                if (filters.LocationsFilter != null && filters.LocationsFilter.Count > 0)
                {
                    var userLocationPriviledges = Repo.GetAll<ViewUserLocationPriviledge>();
                    qry = qry.Where(x => userLocationPriviledges.Any(ulp => ulp.UserId == x.UserID && filters.LocationsFilter.Contains(ulp.LpAllPiKey)));
                }

                if (filters.RegionsFilter != null && filters.RegionsFilter.Count > 0)
                {
                    var userRegionPriviledges = Repo.GetAll<ViewUserRegionPriviledge>();
                    qry = qry.Where(x => userRegionPriviledges.Any(ulp => ulp.UserId == x.UserID && filters.RegionsFilter.Contains(ulp.LpAcctDivGroupKey)));
                }

                if (filters.ClassificationsFilter != null && filters.ClassificationsFilter.Count > 0)
                {
                    var userClassificationPriviledges = Repo.GetAll<ViewUserClassificationPriviledge>();
                    qry = qry.Where(x => userClassificationPriviledges.Any(ulp => ulp.UserId == x.UserID && filters.ClassificationsFilter.Contains(ulp.LpAcctDivGroupKey)));
                }

                if (filters.OtherProvidersFilter != null && filters.OtherProvidersFilter.Count > 0)
                {
                    var userOtherProviderPriviledges = Repo.GetAll<ViewUserOtherProviderPriviledge>();
                    qry = qry.Where(x => userOtherProviderPriviledges.Any(ulp => ulp.UserId == x.UserID && filters.OtherProvidersFilter.Contains(ulp.LpAcctDivGroupKey)));
                }
            }



            if (!string.IsNullOrEmpty(sortExpression))
            {
                var sortDescending = !string.IsNullOrEmpty(sortExpression) &&
                                 sortExpression.ToLower().Contains("desc");

                if (sortExpression.Contains("EDS_CN"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.EdsCn)
                            .ThenBy(x => x.Forename)
                            .ThenBy(x => x.UserID)
                        : qry.OrderBy(x => x.EdsCn)
                            .ThenBy(x => x.Forename)
                            .ThenBy(x => x.UserID);

                if (sortExpression.Contains("FullName") || sortExpression.Equals("Name"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Surname)
                            .ThenBy(x => x.Forename)
                            .ThenBy(x => x.UserID)
                        : qry.OrderBy(x => x.Surname)
                            .ThenBy(x => x.Forename)
                            .ThenBy(x => x.UserID);

                if (sortExpression.Contains("Client"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Client)
                            .ThenBy(x => x.Surname)
                            .ThenBy(x => x.Forename)
                            .ThenBy(x => x.UserID)
                        : qry.OrderBy(x => x.Client)
                            .ThenBy(x => x.Surname)
                            .ThenBy(x => x.Forename)
                            .ThenBy(x => x.UserID);

                if (sortExpression.Contains("RoleName"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.RoleName)
                            .ThenBy(x => x.Surname)
                            .ThenBy(x => x.Forename)
                            .ThenBy(x => x.UserID)
                        : qry.OrderBy(x => x.RoleName)
                            .ThenBy(x => x.Surname)
                            .ThenBy(x => x.Forename)
                            .ThenBy(x => x.UserID);

                if (sortExpression.Contains("Status"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Status)
                            .ThenBy(x => x.Surname)
                            .ThenBy(x => x.Forename)
                            .ThenBy(x => x.UserID)
                        : qry.OrderBy(x => x.Status)
                            .ThenBy(x => x.Surname)
                            .ThenBy(x => x.Forename)
                            .ThenBy(x => x.UserID);

                if (sortExpression.Contains("Email"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Email)
                            .ThenBy(x => x.Surname)
                            .ThenBy(x => x.Forename)
                            .ThenBy(x => x.UserID)
                        : qry.OrderBy(x => x.Email)
                            .ThenBy(x => x.Surname)
                            .ThenBy(x => x.Forename)
                            .ThenBy(x => x.UserID);
            }
            else
            {
                qry = qry.OrderBy(x => x.Surname)
                    .ThenBy(x => x.Forename)
                    .ThenBy(x => x.UserID);
            }
            try
            {

                using (var db = new MA2DbContext())
                {

                    db.Configuration.AutoDetectChangesEnabled = false;
                    db.Configuration.LazyLoadingEnabled = false;
                    db.Configuration.ProxyCreationEnabled = false;


                    db.Database.CommandTimeout = 1200;

                    paging.TotalRecords = qry.Count();


                    var result = qry.Skip(paging.PageOffset).ToArray();

                    var res = result.Take(paging.PageSize).ToList();

                    return res;
                }

            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error while fetching user data -- GetUsers", ex);
            }

            paging.TotalRecords = qry.Count();

            return qry.Skip(paging.PageOffset)
                .Take(paging.PageSize)
                .ToList();

        }


        public List<ViewUserMerged> SearchByLastName(string term)
        {
            var edsUsers = EdsData.GetEdsUserProfileDataForAllUsers(term).ToList();

            var filteredList = (from e in edsUsers
                                where e.Surname.ToLower().Contains(term.ToLower())
                                select new ViewUserMerged
                                {
                                    Forename = (e != null) ? e.FirstName : "",
                                    Surname = (e != null) ? e.Surname : "",
                                    FullName = (e != null) ? e.FirstName + " " + e.Surname : "",
                                    EdsCn = (e != null) ? e.EDS_CN : ""
                                }).ToList();
            return filteredList;
        }

        public List<ViewUserMerged> SearchByEmail(string term)
        {
            var edsUsers = EdsData.GetEdsUserProfileDataForAllUsers(userMailSearchTerm: term).ToList();

            var filteredList = (from e in edsUsers
                                where e.Email.ToLower().Contains(term.ToLower())
                                select new ViewUserMerged
                                {
                                    Forename = (e != null) ? e.FirstName : "",
                                    Surname = (e != null) ? e.Surname : "",
                                    FullName = (e != null) ? e.FirstName + " " + e.Surname : "",
                                    Email = (e != null) ? e.Email : "",
                                    EdsCn = (e != null) ? e.EDS_CN : ""
                                }).ToList();
            return filteredList;
        }

        public List<ViewUserMerged> GetAllActiveUsers()
        {
            UserDbAccess userDbAccess = new UserDbAccess(this._userName);

            try
            {
                var edsUsers = EdsData.GetEdsUserProfileDataForAllUsers(userLastNameSearchTerm: null).ToList();
                var result = userDbAccess.GetDocumentUsersforEmail(toXML(edsUsers));

                return result.ToList();
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error while fetching user data -- GetAllActiveUsers for  email notification ", ex);
                return null;
            }



            //var maUsers = Repo.GetAll<ViewUser>();

            //return (from edsUser in edsUsers
            //        join viewUser in maUsers on edsUser.EDS_CN equals viewUser.EdsCn into dbUsers
            //        from dbUser in dbUsers
            //        select new ViewUserMerged
            //        {
            //            Forename = edsUser.FirstName,
            //            Surname = edsUser.Surname,
            //            FullName = edsUser.FirstName + " " + edsUser.Surname,
            //            EdsCn = edsUser.EDS_CN,
            //            RoleID = dbUser.RoleID,
            //            RoleName = dbUser.RoleName,
            //            Status = dbUser.Status,
            //            Client = dbUser.Client,
            //            UserID = dbUser.UserID,
            //            Email = edsUser.Email
            //        }).ToList();
        }

        public List<ViewUserMerged> GetFilteredReportUsers(UsersFilters filters)
        {
            var filteredList = new List<ViewUserMerged>();

            var edsUsers = EdsData.GetEdsUserProfileDataForAllUsers(userLastNameSearchTerm: null).ToList();

            var maUsers = Repo.GetAll<ViewUser>();

            var userAccountPriviledges = Repo.GetAll<ViewUserAccountPriviledge>();
            var userDivisionPriviledges = Repo.GetAll<ViewUserDivisionPriviledge>();
            var userSubDivisionPriviledges = Repo.GetAll<ViewUserSubDivisionPriviledge>();
            var userLocationPriviledges = Repo.GetAll<ViewUserLocationPriviledge>();

            var qry = filteredList.Concat(from m in edsUsers
                                          join e in maUsers on m.EDS_CN equals e.EdsCn into ps
                                          from e in ps.DefaultIfEmpty()
                                          select new ViewUserMerged
                                          {
                                              Forename = m.FirstName,
                                              Surname = m.Surname,
                                              FullName = m.FirstName + " " + m.Surname,
                                              EdsCn = m.EDS_CN,
                                              RoleID = (e != null) ? e.RoleID : -1,
                                              RoleName = (e != null) ? e.RoleName : default(string),
                                              Status = (e != null) ? e.Status : "Pending",
                                              Client = (e != null) ? e.Client : default(string),
                                              UserID = (e != null) ? e.UserID : -1,
                                              Email = m.Email
                                          });


            if (filters.RoleIDFilter != null && filters.RoleIDFilter.Count > 0)
                qry = qry.Where(x => filters.RoleIDFilter.Contains(x.RoleID));

            if (!string.IsNullOrEmpty(filters.LastNameFilter))
                qry = qry.Where(x => x.Surname == filters.LastNameFilter);

            if (filters.AccountsFilter != null && filters.AccountsFilter.Count > 0)
            {
                qry = qry.Where(x => userAccountPriviledges.Any(uap => uap.UserId == x.UserID && filters.AccountsFilter.Contains(uap.ID)));
            }

            if (filters.DivisionsFilter != null && filters.DivisionsFilter.Count > 0)
            {
                qry = qry.Where(x => userDivisionPriviledges.Any(udp => udp.UserId == x.UserID && filters.DivisionsFilter.Contains(udp.ID)));
            }

            if (filters.SubDivisionsFilter != null && filters.SubDivisionsFilter.Count > 0)
            {
                qry = qry.Where(x => userSubDivisionPriviledges.Any(usdp => usdp.UserId == x.UserID && filters.SubDivisionsFilter.Contains(usdp.ID)));
            }

            if (filters.LocationsFilter != null && filters.LocationsFilter.Count > 0)
            {
                qry = qry.Where(x => userLocationPriviledges.Any(ulp => ulp.UserId == x.UserID && filters.LocationsFilter.Contains(ulp.ID)));
            }

            return qry.ToList();
        }

        public List<ViewUserMerged> GetUsersForSelectedAccount(PagingInfo paging, int lpAcctKey, string sortExpression)
        {
            List<ViewUserMerged> users = new List<ViewUserMerged>();

            var edsUsers = EdsData.GetEdsUserProfileDataForAllUsers(userLastNameSearchTerm: null).ToList();

            var maUsers = Repo.GetAll<ViewUser>();


            var ap = Repo.GetAll<ViewUserAccountPriviledge>().Where(x => x.LpAcctKey == lpAcctKey).Select(y => y.UserId);
            var qry = users.Concat(from m in edsUsers
                                   join e in maUsers on m.EDS_CN equals e.EdsCn into ps
                                   from e in ps.DefaultIfEmpty()
                                   select new ViewUserMerged
                                   {
                                       Forename = m.FirstName,
                                       Surname = m.Surname,
                                       FullName = m.FirstName + " " + m.Surname,
                                       EdsCn = m.EDS_CN,
                                       RoleID = (e != null) ? e.RoleID : -1,
                                       RoleName = (e != null) ? e.RoleName : default(string),
                                       Status = (e != null) ? e.Status : "Pending",
                                       Client = (e != null) ? e.Client : default(string),
                                       UserID = (e != null) ? e.UserID : -1,
                                       Email = m.Email,
                                       JobTitle = m.JobTitle,
                                       SiteSurveyContact = (e != null) ? e.SiteSurveyContact : false,
                                       SiteRecommendationResponseDesignee = (e != null) ? e.SiteRecResponseDesignee : false
                                   });

            qry = qry.Where(x => ap.Contains(x.UserID));

            if (!string.IsNullOrEmpty(sortExpression))
            {
                var sortDescending = !string.IsNullOrEmpty(sortExpression) &&
                                 sortExpression.ToLower().Contains("desc");

                if (sortExpression.Equals("FirstName"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Forename)
                            .ThenBy(x => x.UserID)
                        : qry.OrderBy(x => x.Forename)
                            .ThenBy(x => x.UserID);

                if (sortExpression.Contains("LastName"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Surname)
                            .ThenBy(x => x.UserID)
                        : qry.OrderBy(x => x.Surname)
                            .ThenBy(x => x.UserID);


                if (sortExpression.Contains("JobTitle"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.JobTitle)
                            .ThenBy(x => x.UserID)
                        : qry.OrderBy(x => x.JobTitle)
                            .ThenBy(x => x.UserID);


                if (sortExpression.Contains("Role"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.RoleName)
                            .ThenBy(x => x.UserID)
                        : qry.OrderBy(x => x.RoleName)
                            .ThenBy(x => x.UserID);

                if (sortExpression.Contains("Email"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Email)
                            .ThenBy(x => x.UserID)
                        : qry.OrderBy(x => x.Email)
                            .ThenBy(x => x.UserID);

                // TODO - we are not retrieving Address info at present
                if (sortExpression.Contains("GapsLocationID"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.UserID)
                        : qry.OrderBy(x => x.UserID);

                if (sortExpression.Contains("StreetAddress1"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.UserID)
                        : qry.OrderBy(x => x.UserID);

                if (sortExpression.Contains("City"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.UserID)
                        : qry.OrderBy(x => x.UserID);

                if (sortExpression.Contains("Country"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.UserID)
                        : qry.OrderBy(x => x.UserID);
            }
            else
            {
                qry = qry.OrderBy(x => x.Surname)
                    .ThenBy(x => x.Forename)
                    .ThenBy(x => x.UserID);
            }

            paging.TotalRecords = qry.Count();

            return qry.Skip(paging.PageOffset)
                .Take(paging.PageSize)
                .ToList();


        }

        public List<ViewUserMerged> GetUsersForSelectedAccount(int lpAcctKey, int? lpAllPiKey = null)
        {
            try
            {
            var qry = GetRecDetailsCollaborate(lpAcctKey).AsEnumerable();
            if (lpAllPiKey == null)
            {
                var ap = Repo.GetAll<ViewUserAccountPriviledge>().Where(x => x.LpAcctKey == lpAcctKey);
                // get users for the account if LpAllPiKey is null by looking at ViewUserAccountPriviledge
                qry = qry.Where(x => ap.Select(y => y.UserId).Contains(x.UserID));
            }
            else
            {
                // get users for the account if LpAllPiKey is null by looking at Account/Division/Location permissions
                var lp = GetUsersForLocation(lpAllPiKey.Value, lpAcctKey);
                qry = qry.Where(x => lp.Select(y => y.UserID).Contains(x.UserID));
            }
                        qry = qry.OrderByDescending(x => x.LocationLevel)
                .ThenByDescending(x => x.DivisionLevel)
                .ThenByDescending(x => x.AccountLevel)
                .ThenBy(x => x.Surname)
                .ThenBy(x => x.Forename)
                .ThenBy(x => x.UserID);

            return qry.ToList();

            }
            catch (Exception ex)
            {
               
                LogHelper.Error("Could not find a GetUsersForSelectedAccount", ex);
                return null;
            }

        }

        public List<Recipient> GetUserEmailAddressesFromIds(List<int> userIdList)
        {
            List<Recipient> users = new List<Recipient>();

            var edsUsers = EdsData.GetEdsUserProfileDataForAllUsers(userLastNameSearchTerm: null).ToList();

            var maUsers = Repo.GetAll<ViewUser>().Where(x => userIdList.Contains(x.UserID));

            var qry = users.Concat(from m in edsUsers
                                   join e in maUsers on m.EDS_CN equals e.EdsCn into ps
                                   from e in ps.DefaultIfEmpty()
                                   select new Recipient
                                   {
                                       Name = m.FirstName + " " + m.Surname,
                                       EmailAddress = m.Email,
                                       UserId = (e != null) ? e.UserID : -1,
                                   }
                                   ).Where(x => x.UserId >= 0).ToList();

            return qry;


        }

        public List<User> GetAllSiteSurveyContacts(int lpAcctKey)
        {
            return Repo.GetAll<User>().Where(x => x.SiteSurveyContact == true).ToList();
        }

        /// <summary>
        /// Given a list of EDS_CN strings, convert and return these with their corresponding SiteForward UserID
        /// </summary>
        /// <param name="edsCnList"></param>
        /// <returns></returns>
        public List<int> GetUserIDsFromEDSCN(List<string> edsCnList)
        {

            List<int> result = new List<int>();
            var users = Repo.GetAll<User>();

            foreach (var edsCn in edsCnList)
            {
                try
                {
                    result.Add(users.Single(x => x.EdsCn == edsCn).ID);
                }
                catch (Exception e)
                {
                    LogHelper.Error("Could not find a single user with corresponding EDS_CN - either does not exist in Users table or more than one record is found", e);
                    continue;
                }
            }

            return result;


        }
        /// <summary>
        /// Get the list of Account(s) the user has access to.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<Account> GetAccountPrivileges(int userId)
        {
            return Repo.GetAll<Account>()
                    .Join(Repo.GetAll<ViewUserAccountPriviledge>(), // the source table of the inner join
                        acc => acc.LpAcctKey,                       // PK
                        uap => uap.LpAcctKey,                       // FK
                        (acc, uap) => new { Acc = acc, Uap = uap })
                    .Where(j => j.Uap.UserId == userId)
                    .OrderBy(j => j.Acc.Name)
                    .Select(j => j.Acc)
                    .ToList();
        }

        /// <summary>
        /// Determines whether a user has access to a particular account
        /// </summary>
        /// <param name="userId">The user identifier</param>
        /// <param name="accountKey">the account key</param>
        /// <returns></returns>
        public bool UserHasAccessToAccount(int userId, int accountKey)
        {
            bool hasAccess = Repo.GetAll<ViewUserAccountPriviledge>().Any(priv => priv.UserId == userId && priv.LpAcctKey == accountKey);
            return hasAccess;
        }

        /// <summary>
        /// Get the list of Division(s) the user has access to.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="lPAcctKey"></param>
        /// <returns></returns>
        public List<Division> GetDivisionPrivileges(int userId, int lPAcctKey)
        {
            return Repo.GetAll<Division>()
                .Join(Repo.GetAll<ViewUserDivisionPriviledge>(), // the source table of the inner join
                    div => div.LpAcctWebDivKey,                       // PK
                    udp => udp.LpAcctWebDivKey,                       // FK
                    (div, uap) => new { Div = div, Uap = uap })
                .Where(j => j.Uap.UserId == userId
                                && j.Uap.LpAcctKey == lPAcctKey)
                .OrderBy(j => j.Div.Name)
                .Select(j => j.Div)
                .ToList();
        }

        /// <summary>
        /// Get the list of SubDivision(s) the user has access to.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="lPAcctKey"></param>
        /// <returns></returns>
        public List<SubDivision> GetSubDivisionPrivileges(int userId, int lPAcctKey)
        {
            return Repo.GetAll<SubDivision>()
                .Join(Repo.GetAll<ViewUserSubDivisionPriviledge>(), // the source table of the inner join
                    sdiv => sdiv.LpSubDivKey,                       // PK
                    udp => udp.LpSubDivKey,                       // FK
                    (sdiv, usdp) => new { Sdiv = sdiv, Usdp = usdp })
                .Where(j => j.Usdp.UserId == userId
                            && j.Usdp.LpAcctKey == lPAcctKey)
                .OrderBy(j => j.Sdiv.Name)
                .Select(j => j.Sdiv)
                .ToList();
        }

        /// <summary>
        /// Get the list of Location(s) the user has access to.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="lPAcctKey"></param>
        /// <returns></returns>
        public List<Location> GetLocationPrivileges(int userId, int lPAcctKey)
        {
            var locationLogic = new LocationLogic(this._userName);

            return locationLogic.GetLocationsByLpAcctKey(lPAcctKey)
                .Join(GetLocationPrivilegesReturnLpAllPiKeys(userId, lPAcctKey), // the source table of the inner join
                    loc => loc.LpAllPiKey,                      // PK
                    udp => udp,                                 // FK
                    (loc, ulp) => new { Loc = loc, Ulp = ulp })
                .OrderBy(j => j.Loc.Name)
                .Select(j => j.Loc)
                .ToList();
        }

        public List<Location> GetLocationsFromLpAllPiKeys(List<int> lpAllPiKeys)
        {
            var locationLogic = new LocationLogic(this._userName);

            return Repo.GetAll<Location>().Where(x => lpAllPiKeys.Contains(x.LpAllPiKey)).ToList();
        }

        public List<int> GetLocationPrivilegesReturnLpAllPiKeys(int userId, int lpAcctKey)
        {
            UserDbAccess db = new UserDbAccess(this._userName);
            return db.GetLocationPrivilegesReturnLpAllPiKeys(userId, lpAcctKey).Select(x => x.LPAllPiKey).ToList();
        }

        public List<AllProvider> GetAllPrivileges(int LPAllPiKey)
        {
            UserDbAccess db = new UserDbAccess(this._userName);
            return db.GetAllPrivileges(LPAllPiKey);
        }

        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="lpAllPiKeys"></param>
        /// <returns></returns>
        public List<ViewUserLocationPriviledge> GetLocationPrivilegesForUsersReturnLpAllPiKeys(List<int> userIds, List<int> lpAllPiKeys)
        {
            var qry = Repo.GetAll<ViewUserLocationPriviledge>().Where(x => userIds.Contains(x.UserId) && lpAllPiKeys.Contains(x.LpAllPiKey));
            return qry.ToList();
        }

        public List<ProcLocationLevelUsers> GetUsersForLocation(int lpAllPiKey, int lpAcctKey)
        {
            UserDbAccess db = new UserDbAccess(this._userName);

            return db.GetLocationLevelUsers(lpAllPiKey, lpAcctKey);
        }
        public List<ViewUserMerged> GetRecDetailsCollaborate(int lpAcctKey)
        {
            UserDbAccess db = new UserDbAccess(this._userName);

            return db.GetRecDetailsCollaborate(lpAcctKey);
        }
        

        /// <summary>
        /// Get the list of Region(s) to which the user has access.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<ViewUserRegionPriviledge> GetRegionPrivileges(int userId, int lPAcctKey)
        {
            return Repo.GetAll<ViewUserRegionPriviledge>().Where(x => x.UserId == userId && x.LpAcctKey == lPAcctKey && x.GroupTypeID == Constants.GroupType.Region).ToList();
        }

        /// <summary>
        /// Get the list of Classification(s) to which the user has access.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<ViewUserClassificationPriviledge> GetClassificationPrivileges(int userId, int lPAcctKey)
        {
            return Repo.GetAll<ViewUserClassificationPriviledge>().Where(x => x.UserId == userId && x.LpAcctKey == lPAcctKey && x.GroupTypeID == Constants.GroupType.Classification).ToList();
        }

        /// <summary>
        /// Get the list of Other Provider(s) to which the user has access.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<ViewUserOtherProviderPriviledge> GetOtherProviderPrivileges(int userId, int lPAcctKey)
        {
            return Repo.GetAll<ViewUserOtherProviderPriviledge>().Where(x => x.UserId == userId && x.LpAcctKey == lPAcctKey && x.GroupTypeID == Constants.GroupType.OtherProvider).ToList();
        }



        public List<int> GetUserLocationPrivilegesIdsOnly(int userId, int? lpAllPiKey)
        {
            return Repo.GetAll<ViewUserLocationPriviledge>()
                        .Where(vulp => vulp.UserId == userId
                                       && (lpAllPiKey == null || lpAllPiKey == vulp.LpAllPiKey))
                        .Select(vulp => vulp.LpAllPiKey)
                        .ToList();
        }

        public List<ViewUtilizationReportAggregated> GetUtilizationHeaderData()
        {
            return Repo.GetAll<ViewUtilizationReportAggregated>().ToList();
        }

        public List<ViewUtilizationReportDetail> GetUtilizationDetailData()
        {
            return Repo.GetAll<ViewUtilizationReportDetail>().ToList();
        }

        public List<EDSUser> GetEdsUsers()
        {
            var logic = new LdapDbAccess();
            return logic.GetEdsUserProfileDataForAllUsers(userLastNameSearchTerm: null);
        }

        public List<DocumentType> GetAllDocuments()
        {
            return Repo.GetAll<DocumentType>().ToList();
        }

        public List<Division> GetAllDivisions()
        {
            return Repo.GetAll<Division>().ToList();
        }

        public List<AccountGroupType> GetAllRegions()
        {
            return Repo.GetAll<AccountGroupType>()
                .Where(x => x.LpDivGroupTypeKey == Constants.GroupType.Region)
                .ToList();
        }

        public List<AccountGroupType> GetAllClassifications()
        {
            return Repo.GetAll<AccountGroupType>()
                .Where(x => x.LpDivGroupTypeKey == Constants.GroupType.Classification)
                .ToList();
        }

        public List<AccountGroupType> GetAllOtherProviders()
        {
            return Repo.GetAll<AccountGroupType>()
                .Where(x => x.LpDivGroupTypeKey == Constants.GroupType.OtherProvider)
                .ToList();
        }


        public IEnumerable<Division> GetDivisionsForAccount(int accountId)
        {
            return Repo.GetAll<Division>()
                .Where(div => div.AccountID == accountId)
                .OrderBy(div => div.Name);
        }

        public IEnumerable<Division> GetDivisionsForLocation(int LpAcctWebDivKey)
        {
            return Repo.GetAll<Division>()
                .Where(div => div.LpAcctWebDivKey == LpAcctWebDivKey)
                .OrderBy(div => div.Name);
        }

        public IEnumerable<SubDivision> GetSubDivisionsForAccount(int accountId)
        {
            return Repo.GetAll<SubDivision>()
                .Where(sd => sd.AccountID == accountId)
                .OrderBy(sd => sd.Name);
        }

        public IEnumerable<Location> GetLocationsForAccount(int accountId)
        {
            return Repo.GetAll<Location>()
                .Where(loc => loc.AccountID == accountId)
                .OrderBy(loc => loc.Name);
        }

        public List<AccountGroupType> GetRegionsForAccount(int accountId)
        {
            return Repo.GetAll<AccountGroupType>()
                .Where(x => x.LpDivGroupTypeKey == Constants.GroupType.Region && x.AccountID == accountId)
                .OrderBy(x => x.Name)
                .ToList();
        }

        public List<AccountGroupType> GetClassificationsForAccount(int accountId)
        {
            return Repo.GetAll<AccountGroupType>()
                .Where(x => x.LpDivGroupTypeKey == Constants.GroupType.Classification && x.AccountID == accountId)
                .OrderBy(x => x.Name)
                .ToList();
        }

        public List<AccountGroupType> GetOtherProvidersForAccount(int accountId)
        {
            return Repo.GetAll<AccountGroupType>()
                .Where(x => x.LpDivGroupTypeKey == Constants.GroupType.OtherProvider && x.AccountID == accountId)
                .OrderBy(x => x.Name)
                .ToList();
        }

        public List<SubDivision> GetSubDivisionsForDivision(int divisionId)
        {
            return Repo.GetAll<SubDivision>()
                .Where(sdiv => sdiv.DivisionID == divisionId)
                .OrderBy(sdiv => sdiv.Name)
                .ToList();
        }

        public ViewUserAccountPriviledge GetUserAccountPrivilege(int userId, int lpAcctKey)
        {
            return Repo.GetAll<ViewUserAccountPriviledge>().SingleOrDefault(x => x.UserId == userId && x.LpAcctKey == lpAcctKey);
        }

        public List<ViewUserAccountPriviledge> GetUserAccountPrivileges(int userId)
        {
            return Repo.GetAll<ViewUserAccountPriviledge>().Where(x => x.UserId == userId).ToList();
        }

        public List<UserAccountLevelAccess> GetAccountLevelAccessesForUser(int userId)
        {
            return Repo.GetAll<UserAccountLevelAccess>().Where(x => x.UserID == userId).ToList();
        }
        public UserAccountLevelAccess GetAccountLevelAccessForUser(int userId, int lpAcctKey)
        {
            return Repo.GetAll<UserAccountLevelAccess>().SingleOrDefault(x => x.UserID == userId && x.LpAcctKey == lpAcctKey);
        }
        public List<UserDivisionLevelAccess> GetDivisionLevelAccessesForUser(int userId)
        {
            return Repo.GetAll<UserDivisionLevelAccess>().Where(x => x.UserID == userId).ToList();
        }
        public UserDivisionLevelAccess GetDivisionLevelAccessForUser(int userId, int lpAcctWebDivKey)
        {
            return Repo.GetAll<UserDivisionLevelAccess>().SingleOrDefault(x => x.UserID == userId && x.LpAcctWebDivKey == lpAcctWebDivKey);
        }

        public UserSubDivisionLevelAccess GetSubDivisionLevelAccessForUser(int userId, int lpSubDivKey)
        {
            return Repo.GetAll<UserSubDivisionLevelAccess>().SingleOrDefault(x => x.UserID == userId && x.LpSubDivKey == lpSubDivKey);
        }
        public List<UserSubDivisionLevelAccess> GetSubDivisionLevelAccessesForUser(int userId)
        {
            return Repo.GetAll<UserSubDivisionLevelAccess>().Where(x => x.UserID == userId).ToList();
        }

        public List<UserRegionLevelAccess> GetRegionLevelAccessesForUser(int userId)
        {
            return Repo.GetAll<UserRegionLevelAccess>().Where(x => x.UserID == userId).ToList();
        }

        public UserRegionLevelAccess GetRegionLevelAccessForUser(int userId, int lpAcctDivGroupKey)
        {
            return Repo.GetAll<UserRegionLevelAccess>().SingleOrDefault(x => x.UserID == userId && x.LpAcctDivGroupKey == lpAcctDivGroupKey);
        }

        public List<UserClassificationLevelAccess> GetClassificationLevelAccessesForUser(int userId)
        {
            return Repo.GetAll<UserClassificationLevelAccess>().Where(x => x.UserID == userId).ToList();
        }

        public UserClassificationLevelAccess GetClassificationLevelAccessForUser(int userId, int lpAcctDivGroupKey)
        {
            return Repo.GetAll<UserClassificationLevelAccess>().SingleOrDefault(x => x.UserID == userId && x.LpAcctDivGroupKey == lpAcctDivGroupKey);
        }

        public List<UserOtherProviderLevelAccess> GetOtherProviderLevelAccessesForUser(int userId)
        {
            return Repo.GetAll<UserOtherProviderLevelAccess>().Where(x => x.UserID == userId).ToList();
        }
        public UserOtherProviderLevelAccess GetOtherProviderLevelAccessForUser(int userId, int lpAcctDivGroupKey)
        {
            return Repo.GetAll<UserOtherProviderLevelAccess>().SingleOrDefault(x => x.UserID == userId && x.LpAcctDivGroupKey == lpAcctDivGroupKey);
        }
        public List<UserLocationLevelAccess> GetLocationLevelAccessesForUser(int userId)
        {
            return Repo.GetAll<UserLocationLevelAccess>().Where(x => x.UserID == userId).ToList();
        }
        public UserLocationLevelAccess GetLocationLevelAccessForUser(int userId, int lpAllPiKey)
        {
            return Repo.GetAll<UserLocationLevelAccess>().SingleOrDefault(x => x.UserID == userId && x.LpAllPiKey == lpAllPiKey);
        }


        public bool UserHasAccessToDivision(int lpAcctWebDivKey, int userId)
        {
            using (var db = new MA2DbContext())
            {
                return db.UserDivisionLevelAccesses.Any(x => x.UserID == userId && x.LpAcctWebDivKey == lpAcctWebDivKey);
            }
        }

        public bool UserHasAccessToLocation(int lpAllPiKey, int userId)
        {
            using (var db = new MA2DbContext())
            {
                return db.UserLocationLevelAccesses.Any(x => x.UserID == userId && x.LpAllPiKey == lpAllPiKey);
            }
        }

        public bool UserHasAccessToViewLocation(int lpAllPiKey, int userId)
        {
            using (var db = new MA2DbContext())
            {
                return db.ViewUserLocationPriviledges.Any(x => x.UserId == userId && x.LpAllPiKey == lpAllPiKey);
            }
        }

        /// <summary>
        /// Returns whether or not a user has been granted access to Location by means of Division parentage
        /// </summary>
        /// <param name="lpAllPiKey"></param>
        /// <param name="userId"></param>
        /// <param name="lpAcctWebDivKey"></param>
        /// <returns></returns>
        public bool UserHasAccessToLocationThroughParentDivision(int lpAllPiKey, int userId, int lpAcctWebDivKey)
        {
            var locationLogic = new LocationLogic("");

            var location = locationLogic.LoadLocationByLpAllPiKey(lpAllPiKey);

            return UserHasAccessToLocation(lpAllPiKey, userId) && UserHasAccessToDivision(lpAcctWebDivKey, userId) && location.LpAcctWebDivKey == lpAcctWebDivKey;
        }



        /// <summary>
        /// Returns whether or not a user has been granted access to Location by means of SubDivision parentage
        /// </summary>
        /// <param name="lpAllPiKey"></param>
        /// <param name="userId"></param>
        /// <param name="lpAcctWebDivKey"></param>
        /// <returns></returns>
        public bool UserHasAccessToLocationThroughParentSubDivision(int lpAllPiKey, int userId, int lpSubDivKey)
        {
            var locationLogic = new LocationLogic("");

            var location = locationLogic.LoadLocationByLpAllPiKey(lpAllPiKey);

            return UserHasAccessToLocation(lpAllPiKey, userId) && UserHasAccessToSubDivision(lpSubDivKey, userId) && location.LPsubDivKey == lpSubDivKey;

        }

        /// <summary>
        /// Returns whether or not a user has been granted access to Location by means of Division parentage
        /// </summary>
        /// <param name="lpAllPiKey"></param>
        /// <param name="userId"></param>
        /// <param name="lpAcctWebDivKey"></param>
        /// <returns></returns>
        public bool UserHasAccessToLocationThroughParentRegion(int lpAllPiKey, int userId, int lpAcctDivGroupKey)
        {
            return UserHasAccessToLocation(lpAllPiKey, userId) && GetRegionLevelAccessForUser(userId, lpAcctDivGroupKey) != null;
        }

        /// <summary>
        /// Returns whether or not a user has been granted access to Location by means of Division parentage
        /// </summary>
        /// <param name="lpAllPiKey"></param>
        /// <param name="userId"></param>
        /// <param name="lpAcctWebDivKey"></param>
        /// <returns></returns>
        public bool UserHasAccessToLocationThroughParentClassification(int lpAllPiKey, int userId, int lpAcctDivGroupKey)
        {
            return UserHasAccessToLocation(lpAllPiKey, userId) && GetClassificationLevelAccessForUser(userId, lpAcctDivGroupKey) != null;
        }

        /// <summary>
        /// Returns whether or not a user has been granted access to Location by means of Division parentage
        /// </summary>
        /// <param name="lpAllPiKey"></param>
        /// <param name="userId"></param>
        /// <param name="lpAcctWebDivKey"></param>
        /// <returns></returns>
        public bool UserHasAccessToLocationThroughParentOtherProvider(int lpAllPiKey, int userId, int lpAcctDivGroupKey)
        {
            return UserHasAccessToLocation(lpAllPiKey, userId) && GetOtherProviderLevelAccessForUser(userId, lpAcctDivGroupKey) != null;
        }


        public bool UserHasAccessToSubDivision(int lpSubDivKey, int userId)
        {
            using (var db = new MA2DbContext())
            {
                return db.UserSubDivisionLevelAccesses.Any(x => x.UserID == userId && x.LpSubDivKey == lpSubDivKey);
            }
        }

        public List<SubDivision> GetAllSubDivisions()
        {
            return Repo.GetAll<SubDivision>().ToList();
        }

        public IEnumerable<ViewSecurityReportAggregated> GetHeaderDataForSecurityReport()
        {
            return Repo.GetAll<ViewSecurityReportAggregated>();
        }

        public IQueryable<ViewSecurityReportDetail> GetDetailDataForSecurityReport(bool isDataForExport)
        {
            return Repo.GetAll<ViewSecurityReportDetail>();
        }

        public IQueryable<ViewSecurityReportRegionDetail> GetRegionDetailDataForSecurityReport()
        {
            return Repo.GetAll<ViewSecurityReportRegionDetail>();
        }

        public IQueryable<ViewSecurityReportClassificationDetail> GetClassificationDetailDataForSecurityReport()
        {
            return Repo.GetAll<ViewSecurityReportClassificationDetail>();
        }

        public IQueryable<ViewSecurityReportOtherProviderDetail> GetOtherProviderDetailDataForSecurityReport()
        {
            return Repo.GetAll<ViewSecurityReportOtherProviderDetail>();
        }

        public DataTable GetDataTableForUtilizationReport(UsersFilters filters)
        {
            var datatable = new DataTable();
            datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Users_UserName });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Users_Thirty });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.Users_FortyFive });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field4", Caption = WebPageResources.Users_Ninety });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field5", Caption = WebPageResources.Users_ThreeSixFive });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field6", Caption = WebPageResources.Users_ReportName });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field7", Caption = WebPageResources.Users_Hits });

            var edsUsers = GetFilteredReportUsers(filters);

            var dataset = (

                           from e in edsUsers
                           join h in GetUtilizationHeaderData() on e.EdsCn equals h.EdsCn into z
                           from y in z.DefaultIfEmpty()
                           join d in GetUtilizationDetailData() on (y != null) ? y.UserID : -1 equals (d != null) ? d.UserID : -1 into ps
                           from x in ps.DefaultIfEmpty()

                           select new
                           {
                               Name = e.FullName,
                               C0To30 = (y != null) ? y.C0To30 : 0,
                               C31To45 = (y != null) ? y.C31To45 : 0,
                               C46To90 = (y != null) ? y.C46To90 : 0,
                               C90To365 = (y != null) ? y.C90To365 : 0,
                               reportName = (x != null) ? x.Name : default(string),
                               Hits = (x != null) ? x.Hits : 0
                           }).ToList();

            foreach (var item in dataset)
            {
                Object[] O = { item.Name, item.C0To30, item.C31To45, item.C46To90,
                    item.C90To365, item.reportName, item.Hits };
                datatable.Rows.Add(O);
            }
            return datatable;
        }



        public List<DataTable> GetDataTableForSecurityReport(UsersFilters filters)
        {
            List<DataTable> userSecurityDetails = new List<DataTable>();


            // First table - Division/SubDivision info
            userSecurityDetails.Add(GetSecurityDivisionDataTable(filters));

            userSecurityDetails.Add(GetSecurityRegionDataTable(filters));

            userSecurityDetails.Add(GetSecurityClassificationDataTable(filters));

            userSecurityDetails.Add(GetSecurityOtherProviderDataTable(filters));

            // finally - return our list of datatables
            return userSecurityDetails;
        }

        public DataTable GetSecurityDivisionDataTable(UsersFilters filters)
        {
            var divisionDataTable = new DataTable();
            divisionDataTable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Users_TableCol_Name });
            divisionDataTable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Users_TableCol_Client });
            divisionDataTable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.Documents_TableCol_Division });
            divisionDataTable.Columns.Add(new DataColumn { ColumnName = "Field4", Caption = WebPageResources.Users_Filter_SubDivision });

            var edsUsers = GetFilteredReportUsers(filters);

            var dataset = (from m in edsUsers
                           join h in GetDetailDataForSecurityReport(true) on m.EdsCn equals h.EdsCn into ps
                           from h in ps.DefaultIfEmpty()

                           select new
                           {
                               Name = m.FullName,
                               Client = (h != null) ? h.Client : default(string),
                               DivisionName = (h != null) ? h.DivisionName : default(string),
                               SubDivisionName = (h != null) ? h.SubDivisionName : default(string),
                               Location = (h != null) ? default(string) : default(string),
                               Email = (h != null) ? m.Email : default(string),

                           }).ToList();

            foreach (var item in dataset)
            {
                Object[] O =
                {
                    item.Name,
                    item.Client,
                    item.DivisionName,
                    item.SubDivisionName
                };
                divisionDataTable.Rows.Add(O);
            }

            return divisionDataTable;
        }

        public DataTable GetSecurityRegionDataTable(UsersFilters filters)
        {
            var regionDataTable = new DataTable();
            regionDataTable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Users_TableCol_Name });
            regionDataTable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Users_TableCol_Client });
            regionDataTable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.Region });

            var edsUsers = GetFilteredReportUsers(filters);


            var dataset = (from m in edsUsers
                           join h in GetRegionDetailDataForSecurityReport() on m.EdsCn equals h.EdsCn into ps
                           from h in ps.DefaultIfEmpty()

                           select new
                           {
                               Name = m.FullName ?? h.EdsCn,
                               Client = (h != null) ? h.Client : default(string),
                               Region = (h != null) ? h.Region : default(string)
                           }).ToList();

            foreach (var item in dataset)
            {
                Object[] o =
                {
                    item.Name,
                    item.Client,
                    item.Region
                };
                regionDataTable.Rows.Add(o);
            }

            return regionDataTable;
        }

        public DataTable GetSecurityClassificationDataTable(UsersFilters filters)
        {
            var ClassificationDataTable = new DataTable();
            ClassificationDataTable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Users_TableCol_Name });
            ClassificationDataTable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Users_TableCol_Client });
            ClassificationDataTable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.Classification });

            var edsUsers = GetFilteredReportUsers(filters);

            var dataset = (from m in edsUsers
                           join h in GetClassificationDetailDataForSecurityReport() on m.EdsCn equals h.EdsCn into ps
                           from h in ps.DefaultIfEmpty()

                           select new
                           {
                               Name = m.FullName ?? h.EdsCn,
                               Client = (h != null) ? h.Client : default(string),
                               Classification = (h != null) ? h.Classification : default(string)
                           }).ToList();

            foreach (var item in dataset)
            {
                Object[] o =
                {
                    item.Name,
                    item.Client,
                    item.Classification
                };
                ClassificationDataTable.Rows.Add(o);
            }

            return ClassificationDataTable;
        }


        public DataTable GetSecurityOtherProviderDataTable(UsersFilters filters)
        {
            var OtherProviderDataTable = new DataTable();
            OtherProviderDataTable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Users_TableCol_Name });
            OtherProviderDataTable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Users_TableCol_Client });
            OtherProviderDataTable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.OtherProvider });


            var edsUsers = GetFilteredReportUsers(filters);

            var dataset = (from m in edsUsers
                           join h in GetOtherProviderDetailDataForSecurityReport() on m.EdsCn equals h.EdsCn into ps
                           from h in ps.DefaultIfEmpty()

                           select new
                           {
                               Name = m.FullName ?? h.EdsCn,
                               Client = (h != null) ? h.Client : default(string),
                               OtherProvider = (h != null) ? h.OtherProvider : default(string)
                           }).ToList();

            foreach (var item in dataset)
            {
                Object[] o =
                {
                    item.Name,
                    item.Client,
                    item.OtherProvider
                };
                OtherProviderDataTable.Rows.Add(o);
            }

            return OtherProviderDataTable;
        }


        /// <summary>
        /// Get the name of the Risk Consultant for the first account (by name, alphabetically) the user has priviledges to access.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public string GetRiskConsultantNameForUser(int userId)
        {
            return GetAccountPrivileges(userId)
                            .FirstOrDefault()?.RiskConsultant;
        }

        public BaseExportHelper.ExportFormat GetExportFormat(string format)
        {
            switch (format)
            {
                case "PDF":
                    return BaseExportHelper.ExportFormat.PDF;
                case "Word":
                    return BaseExportHelper.ExportFormat.Word;
                case "Excel":
                    return BaseExportHelper.ExportFormat.Excel;
                default:
                    return BaseExportHelper.ExportFormat.Excel;
            }
        }

        public void Dispose()
        {
            Repo.Dispose();
        }

        public void RecordUserLogin(int userId)
        {
            var db = new UserDbAccess(this._userName);
            db.RecordUserLogin(userId);
        }

        /// <summary>
        /// Update the Users LastActivityDate
        /// </summary>
        /// <param name="userId"></param>
        public void RecordUserLastActivityDate(int userId)
        {
            UserDbAccess db = new UserDbAccess(this._userName);
            db.RecordUserLastActivityDate(userId);
        }

        /// <summary>
        /// Gets UserDocumentExport (bulk doc download) recs for the user.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="readyExportsOnly"></param>
        /// <returns></returns>
        public List<UserDocumentExport> GetUserDocumentExportsForUser(int userId, bool readyExportsOnly = false)
        {
            string statusReadyName = Enum.GetName(typeof(UserDocumentExportStatusEnum), UserDocumentExportStatusEnum.Ready);
            return Repo.GetAll<UserDocumentExport>()
                            .Where(ude => ude.UserID == userId
                                                    && (!readyExportsOnly || ude.Status == statusReadyName))
                            .OrderByDescending(ude => ude.CreatedDate)
                            .ToList();
        }

        public List<UserSecurityExport> GetUserSecurityExports(int userId, bool readyExportsOnly = false)
        {
            string statusReadyName = Enum.GetName(typeof(UserDocumentExportStatusEnum), UserDocumentExportStatusEnum.Ready);
            return Repo.GetAll<UserSecurityExport>()
                .Where(ude => ude.UserID == userId
                              && !readyExportsOnly || ude.Status == statusReadyName)
                .OrderByDescending(ude => ude.CreatedDate)
                .ToList();
        }


        public List<UserPreference> GetUserPreferencesForUser(int userId)
        {
            return Repo.GetAll<UserPreference>().Where(x => x.UserID == userId).ToList();
        }

        public void DeleteUserPreferences(int userId, int userPreferenceTypeId)
        {
            UserDbAccess db = new UserDbAccess(this._userName);

            db.DeleteUserPreferences(userId, userPreferenceTypeId);
        }

        public void UpsertUserPreference(int userId, int userPreferenceTypeId, string value)
        {
            UserDbAccess db = new UserDbAccess(this._userName);
            db.UpsertUserPreference(userId, userPreferenceTypeId, value);
        }

        /// <summary>
        /// Returns true if the specified Summary Report has been configured to allow users lower than RC and Admin access
        /// via the Account Profile for the specified account.
        /// </summary>
        /// <param name="summaryReportId"></param>
        /// <param name="lpAcctKey"></param>
        /// <returns></returns>
        public bool UserHasAccessToSummaryReport(int summaryReportId, int lpAcctKey)
        {
            return Repo.GetAll<ViewReportAccess>().Any(ra => ra.LpAcctKey == lpAcctKey
                                                             && ra.IsSelected == true
                                                             && ra.ID == summaryReportId);
        }

        public List<LocationWithUserMetaData> GetLocationUsersAssociatedWithRecommendations(PagingInfo paging, List<int> selectedRecommendations, SelectRecipientsFilters filters, bool useLocationNo, int userRole)
        {
            UserDbAccess db = new UserDbAccess(this._userName);
            int totalRows = 0;
            var result = db.GetLocationUsersAssociatedWithRecommendations(
                selectedRecommendations,
                filters.LpAcctKey,
                filters.SearchTerm,
                paging.PageSize,
                paging.PageOffset,
                out totalRows,
                useLocationNo,
                userRole
            );


            paging.TotalRecords = totalRows;

            return result;
        }

        public List<ViewUserLocationPriviledge> GetSiteRecommendationDesigneesByLocation(List<int> lpAllPiKeys)
        {
            return Repo.GetAll<ViewUserLocationPriviledge>().Where(x => lpAllPiKeys.Contains(x.LpAllPiKey) && (x.SiteRecAssignedDesignee || x.SiteRecResponseDesignee)).ToList();
        }

        public bool QueueSecurityExtractRequest(SecurityExtractMSMQ securityExtractMSMQ)
        {
            var msg = new Message
            {
                Body = JsonConvert.SerializeObject(securityExtractMSMQ, new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Serialize }),
                Label = Constants.MessageQueueTypes.MessageType_SecurityExtractRequest
            };
            var messageQueueLocation = ConfigHelper.GetAppSetting("QueueLocation");
            MessageQueue queue = new MessageQueue(messageQueueLocation);

            if (queue.Transactional)
            {
                var trans = new MessageQueueTransaction();
                trans.Begin();
                msg.Formatter = new XmlMessageFormatter(new Type[] { typeof(String) });
                queue.Send(msg, trans);
                trans.Commit();
            }
            else
            {
                queue.Send(msg);
            }
            return true;

        }

        /// <summary>
        /// Initiate the processing of the document bulk download request.
        /// 1) Retrieve metadata for each applicable document from the filter criteria in the message
        /// 2) Download each document and compress into .ZIP
        /// 3) Write the .ZIP to the temp folder
        /// 4) Write a UserDocumentExport record (to make the new download available in the UI)
        /// </summary>
        /// <param name="bulkDocumentExportMsmq"></param>
        /// <param name="messageId"></param>
        /// <returns></returns>
        public bool InitiateSecurityExtractRequestForMessage(SecurityExtractMSMQ securityExtractMSMQ, string messageId)
        {
            // guard
            //if (bulkDocumentExportMsmq.RecordsSelected == null || bulkDocumentExportMsmq.RecordsSelected.Count == 0)
            //    throw new ArgumentNullException("BulkDocumentExportMSMQ.RecordsSelected is null or empty");

            int userId = securityExtractMSMQ.CreatedBy;
            string zipFilePath = null;
            string zipFileName = null;
            int? userSecurityExtractId = null;

            var userDbAccess = new UserDbAccess(this._userName);

            try
            {
                userSecurityExtractId = userDbAccess.UpsertUserSecurityExtractRecord(null, UserSecurityExtractStatusEnum.New, userId, null, null);

                zipFileName = $"{Guid.NewGuid()}.ZIP";
                zipFilePath = Path.Combine(ConfigHelper.GetAppSetting("TempDocumentDownloadFolderPath"), zipFileName);

                LogHelper.Info("Calling proc_GetUserSecurityExtract");
                userDbAccess.UpsertUserSecurityExtractRecord(zipFileName, UserSecurityExtractStatusEnum.Downloading, userId, userSecurityExtractId, null);

                List<String> targetEdsUsers = new List<String>();
                foreach (var userEds in securityExtractMSMQ.ExtractedUsers)
                {
                    targetEdsUsers.Add(userEds.Trim());
                }
                var userSecurityExtract = userDbAccess.GetUserSecurityExtract(securityExtractMSMQ.LpAcctKey, targetEdsUsers);

                userDbAccess.UpsertUserSecurityExtractRecord(zipFileName, UserSecurityExtractStatusEnum.Processing, userId, userSecurityExtractId, null);

                LogHelper.Info($"Processing User Security Extract, data table row count: {userSecurityExtract.Count}");
                ProcessUserSecurityExtract(userSecurityExtract);

                userDbAccess.UpsertUserSecurityExtractRecord(zipFileName, UserSecurityExtractStatusEnum.Packaging, userId, userSecurityExtractId, null);

                LogHelper.Info("Packaging User Security Extract");
                var dataTable = GetDataTableForUserSecurityExtract(userSecurityExtract);
                ExportSecurityExtract(dataTable, zipFilePath);

                userDbAccess.UpsertUserSecurityExtractRecord(zipFileName, UserSecurityExtractStatusEnum.Ready, userId, userSecurityExtractId, null);

                LogHelper.Info("User Security Extract completed successfully");
                return true;
            }
            catch (Exception exception)
            {
                LogHelper.Error($"Unexpected error attempting to initiate security extract download request. MessageId = {messageId}", exception);
                userDbAccess.UpsertUserSecurityExtractRecord(zipFileName, UserSecurityExtractStatusEnum.Error, userId, userSecurityExtractId, $"Exception: '{exception.Message}' MessageId: {messageId}");
                return false;
            }
        }

        public List<ProcGetUserSecurityExtractReturnModel> GetUserSecurityExtract(int lpAcctKey, List<string> edsCnList)
        {
            var db = new UserDbAccess(this._userName);
            return db.GetUserSecurityExtract(lpAcctKey, edsCnList);
        }

        public void ProcessUserSecurityExtract(List<ProcGetUserSecurityExtractReturnModel> userSecurityExtract)
        {
            // we repeat a large number of rows for every user, so no need to query EDS every single time.

            Dictionary<string, UserMerged> cachedUsers = new Dictionary<string, UserMerged>();
            foreach (var row in userSecurityExtract)
            {
                UserMerged edsUser;
                if (!cachedUsers.ContainsKey(row.EDS_CN))
                {
                    edsUser = GetMergedUserByEdsCn(row.EDS_CN);
                    cachedUsers.Add(row.EDS_CN, edsUser);
                }
                else
                {
                    edsUser = cachedUsers.First(x => x.Key == row.EDS_CN).Value;
                }

                row.Name = $"{edsUser.ForeName} {edsUser.Surname}";
                row.Email = edsUser.Email;
            }
        }

        public DataTable GetDataTableForUserSecurityExtract(List<ProcGetUserSecurityExtractReturnModel> userSecurityExtract)
        {
            DataTable dataTable = new DataTable();

            dataTable.Columns.Add(new DataColumn { ColumnName = "AXA_XL_EDS_CN", Caption = WebPageResources.SecurityExtract_EDSCN });
            dataTable.Columns.Add(new DataColumn { ColumnName = "LastLogin", Caption = WebPageResources.Impairment_Filter_ReceivedAsOfDate_LastLogin });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Name", Caption = WebPageResources.Users_UserName });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Email", Caption = WebPageResources.User_Email });
            dataTable.Columns.Add(new DataColumn { ColumnName = "CreatedOn", Caption = WebPageResources.Recommendations_History_CreatedDate });
            dataTable.Columns.Add(new DataColumn { ColumnName = "CreatedBy", Caption = WebPageResources.SecurityExtract_CreatedBy });
            dataTable.Columns.Add(new DataColumn { ColumnName = "AccountNo", Caption = WebPageResources.SecurityExtract_AccountNo });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Account_Code", Caption = WebPageResources.SecurityExtract_AccountCode });
            dataTable.Columns.Add(new DataColumn { ColumnName = "AccountName", Caption = WebPageResources.Recommendations_AccountName });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Account_StartDate", Caption = WebPageResources.SecurityExtract_AccountStartDate });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Account_ExpiryDate", Caption = WebPageResources.SecurityExtract_AccountExpiryDate });
            dataTable.Columns.Add(new DataColumn { ColumnName = "RecResponse", Caption = WebPageResources.User_SiteRecommendationResponseDesignee });
            dataTable.Columns.Add(new DataColumn { ColumnName = "AssignedDesignee", Caption = WebPageResources.SelectRecipients_AssignedDesignees });
            dataTable.Columns.Add(new DataColumn { ColumnName = "AccessLevel", Caption = WebPageResources.SecurityExtract_AccessLevel });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Division", Caption = WebPageResources.Users_Filter_Division });
            dataTable.Columns.Add(new DataColumn { ColumnName = "SubDivision", Caption = WebPageResources.Documents_Table_SubDivision });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Region", Caption = WebPageResources.Region });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Classification", Caption = WebPageResources.Classification });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Other_Provider", Caption = WebPageResources.OtherProvider });
            dataTable.Columns.Add(new DataColumn { ColumnName = "LocationNumber", Caption = WebPageResources.SecurityExtract_LocationNo });
            dataTable.Columns.Add(new DataColumn { ColumnName = "LocationCode", Caption = WebPageResources.SecurityExtract_LocationCode });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Address", Caption = WebPageResources.CopeSummary_Table_Address });
            dataTable.Columns.Add(new DataColumn { ColumnName = "City", Caption = WebPageResources.CopeSummary_Table_City });
            dataTable.Columns.Add(new DataColumn { ColumnName = "State", Caption = WebPageResources.Documents_Table_State });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Country", Caption = WebPageResources.CopeSummary_Table_Country });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Role", Caption = WebPageResources.User_Role });
            dataTable.Columns.Add(new DataColumn { ColumnName = "UpdatedBy", Caption = WebPageResources.RecommendationHistory_UpdatedBy });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Documents", Caption = WebPageResources.Tile_Documents });


            foreach (var row in userSecurityExtract)
            {
                Object[] O =
                {
                    row.EDS_CN,
                    row.LastLogin,
                    row.Name,
                    row.Email,
                    FormatHelper.FormatDate(row.CreatedOn),
                    row.CreatedBy,
                    row.AccountNo,
                    row.Account_Code,
                    row.Account_Name,
                    FormatHelper.FormatDate(row.AccountStartDate),
                    FormatHelper.FormatDate(row.AccountEndDate),
                    row.RecResponse,
                    row.AssignedDesignee,
                    row.AccessLevel,
                    row.Division,
                    row.SubDivision,
                    row.Region,
                    row.Classification,
                    row.OtherProvider,
                    row.LocationNumber,
                    row.LocationCode,
                    row.StreetAddress,
                    row.City,
                    row.State,
                    row.Country,
                    row.Role,
                    row.UpdatedBy,
                    row.Documents
                };
                dataTable.Rows.Add(O);
            }

            return dataTable;
        }

        public void ExportSecurityExtract(DataTable dataTable, string zipFilePath)
        {
            var dataTables = new List<DataTable>();
            GenericExportHelper reportHelper = new GenericExportHelper();

            dataTables.Add(dataTable);
            dataTables.Add(dataTable);

            List<string[]> columnWidths = new List<string[]>
            {
                new[] {
                    "4cm",
                    "4cm" ,
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "4cm",
                    "20cm"} };

            var fileName = $"User Security Extract {DateTime.UtcNow.ToString()}.xlsx";

            var noErrorMessage = WebPageResources.Export_NoDataMessage;

            var content = reportHelper.RenderChartExportReportTest(fileName, " ",
                null, dataTables, columnWidths, reportHelper.GetExportFormat("Excel"), fileName, false,
                out string mimeType, out string fullFilename, noErrorMessage, false);

            using (var fileStream = new FileStream(zipFilePath, FileMode.Create))
            {
                using (var archive = new ZipArchive(fileStream, ZipArchiveMode.Create))
                {
                    ZipArchiveEntry entry = archive.CreateEntry(FormatHelper.CleanFilename(fileName, string.Empty));
                    using (content)
                    {
                        using (Stream zipStream = entry.Open())
                        {
                            content.CopyTo(zipStream);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Get the .ZIP file related to the UserDocumentExport record userDocumentExportId as a byte[]
        /// </summary>
        /// <param name="userDocumentExportId"></param>
        /// <returns></returns>
        public byte[] GetSecurityExportZIPFile(int userSecurityReportId, int userId)
        {
            var UserDbAccess = new UserDbAccess(this._userName);
            var userSecurityExport = UserDbAccess.LoadUserSecurityExport(userSecurityReportId);

            if (userSecurityExport.UserID != userId)
            {
                LogHelper.Warn($"Attempt to download .ZIP file belonging to UserID {userSecurityExport.UserID} by {userId}");

                return new byte[] { };
            }

            string zipFileName = userSecurityExport.ExportFilePath;
            string zipFilePath = Path.Combine(ConfigHelper.GetAppSetting("TempDocumentDownloadFolderPath"), zipFileName);
            LogHelper.Info(
                $"Extracting .ZIP file from path {zipFilePath} for UserSecurityExport Id={userSecurityExport}");

            Byte[] byteArray = null;
            using (FileStream fileStream = new FileStream(zipFilePath, FileMode.Open, FileAccess.Read))
            {
                byteArray = new byte[fileStream.Length];

                fileStream.Read(byteArray, 0, Convert.ToInt32(fileStream.Length));
            }

            LogHelper.Info(
                $"Extracted .ZIP file from path {zipFilePath} for UserSecurityExport Id={userSecurityExport}. {byteArray.Length} bytes read.");

            return byteArray;
        }

        private string toXML<T>(T xml)
        {
            var stringwriter = new System.IO.StringWriter();
            var serializer = new XmlSerializer(typeof(T));
            serializer.Serialize(stringwriter, xml);
            return stringwriter.ToString();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.Entity.SqlServer;
using System.Linq;
using XLC.MyAnalysis2.DbAccess;
using XLC.MyAnalysis2.DbModels;

namespace XLC.MyAnalysis2.Logic
{
    /// <summary>
    /// 
    /// </summary>
    public class ConnectionLogic : BaseLogic
    {
        /// <summary>
        /// 
        /// </summary>
        private ConnectionDbAccess _da;

        /// <summary>
        /// 
        /// </summary>
        public ConnectionLogic()
        {
            _da = new ConnectionDbAccess();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<UserConnection> GetConnectionsForUser(int userId)
        {
            return _da.GetConnectionsForUser(userId);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<UserConnection> GetActiveConnectionsForUser(int userId)
        {
            return _da.GetActiveConnectionsForUser(userId);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public List<UserConnection> GetActiveConnectionsForUsers(List<int> userIds)
        {
            return _da.GetActiveConnectionsForUsers(userIds);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userIds"></param>
        /// <param name="connection">Connection to exclude</param>
        /// <returns></returns>
        public List<UserConnection> GetActiveConnectionsForUsersExcludeConn(List<int> userIds, Guid connection)
        {
            return _da.GetActiveConnectionsForUsersExcludeConn(userIds, connection);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lPAcctKey"></param>
        /// <returns></returns>
        public List<UserConnection> GetActiveConnectionsForLpAcctKey(int lPAcctKey)
        {
            return _da.GetActiveConnectionsForLpAcctKey(lPAcctKey);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<UserConnection> GetActiveUsers()
        {
            return _da.GetActiveUsers();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="connectionId"></param>
        /// <param name="userAgent"></param>
        /// <param name="lPAcctKey"></param>
        /// <returns></returns>
        public bool AddConnection(int userId, System.Guid connectionId, string userAgent, int? lPAcctKey)
        {
            return _da.AddConnection(userId, connectionId, userAgent, lPAcctKey);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionId"></param>
        /// <returns></returns>
        public bool RemoveConnection(System.Guid connectionId)
        {
            return _da.RemoveConnection(connectionId);
        }

        public void Check(int zombieThreshold)
        {
            using (var db = new MA2DbContext())
            {
                // Remove all connections that haven't been updated based on our threshold
                var zombies = db.UserConnections.Where(c =>
                    SqlFunctions.DateDiff("ss", c.UpdatedDate, DateTimeOffset.UtcNow) >= zombieThreshold);

                var staleConnections = zombies.ToList();
                // We're doing ToList() since there's no MARS support on azure
                foreach (var connection in staleConnections)
                {
                    db.UserConnections.Remove(connection);
                }

                if (staleConnections.Count > 0)
                {
                    db.SaveChanges();
                }
            }
        }
    }
}

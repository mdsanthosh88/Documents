﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using XLC.MyAnalysis2.DbAccess;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.DbModels.DbEnums;
using XLC.MyAnalysis2.Logic.DTO;
using XLC.MyAnalysis2.Resources;
using XLC.MyAnalysis2.Shared;
using XLC.MyAnalysis2.WebPortal.Helpers;

namespace XLC.MyAnalysis2.Logic
{
    public class RiskQualityLogic : BaseLogic
    {
        protected DataRepository Repo = new DataRepository();

        #region Load


        public List<LocationRiskQualityRating> LoadRiskQualityRatingsData(PagingInfo paging, DataFilter dataFilter,
            int userId, string sortExpression, bool? weightedAverage = null)
        {

            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter != null)
            {
                RiskQualityDbAccess db = new RiskQualityDbAccess();
                using (var ma2DbContext = new MA2DbContext())
                {
                    var qry = db.LoadRiskQualityRatingDataForCurrentFilters(anyLocationsSelectorDataFilter, dataFilter,
                        ma2DbContext);




                    // Method is shared by FS13 (Benchmarking) and FS14 (RQR) -
                    // FS13 uses client side processing 
                    // FS14 which uses server-side processing.

                    if (paging != null)
                    {
                        paging.TotalRecords = qry.Count();

                        if (!string.IsNullOrEmpty(sortExpression))
                        {
                            var sortDescending = !string.IsNullOrEmpty(sortExpression)
                                                 && sortExpression.ToLower().Contains("desc");

                            if (sortExpression.Contains(@WebPageResources.RiskQualityRatings_Table_LocationID))
                                qry = sortDescending
                                          ? qry.OrderByDescending(x => x.LocationID)
                                          : qry.OrderBy(x => x.LocationID);

                            if (sortExpression.Contains(@WebPageResources.RiskQualityRatings_Table_Country.Replace(" ", string.Empty)))
                                qry = sortDescending
                                          ? qry.OrderByDescending(x => x.Location.Country)
                                          : qry.OrderBy(x => x.Location.Country);

                            if (sortExpression.Contains(@WebPageResources.RiskQualityRatings_Table_City.Replace(" ", string.Empty)))
                                qry = sortDescending
                                          ? qry.OrderByDescending(x => x.Location.City)
                                          : qry.OrderBy(x => x.Location.City);

                            if (sortExpression.Contains(@WebPageResources.RiskQualityRatings_Table_Address.Replace(" ", string.Empty)))
                                qry = sortDescending
                                          ? qry.OrderByDescending(x => x.Location.FullAddress)
                                          : qry.OrderBy(x => x.Location.FullAddress);

                            if (sortExpression.Contains(@WebPageResources.RiskQualityRatings_Table_StateProvince.Replace(" ", string.Empty).Replace(@"/", "")))
                                qry = sortDescending
                                    ? qry.OrderByDescending(x => x.Location.State)
                                    : qry.OrderBy(x => x.Location.State);

                            if (sortExpression.Contains(@WebPageResources.RiskQualityRatings_Table_PropertyValue.Replace(" ", string.Empty)))
                                qry = sortDescending
                                    ? qry.OrderByDescending(x => x.Location.LocationValue)
                                    : qry.OrderBy(x => x.Location.LocationValue);

                            if (sortExpression.Contains(@WebPageResources.RiskQualityRatings_Table_PredominantConstruction.Replace(" ", string.Empty)))
                                qry = sortDescending
                                    ? qry.OrderByDescending(x => x.Location.PredominantConstructionType.Name)
                                    : qry.OrderBy(x => x.Location.PredominantConstructionType.Name);

                            if (sortExpression.Contains(@WebPageResources.RiskQualityRatings_Table_FireDeptType.Replace(" ", string.Empty)))
                                qry = sortDescending
                                    ? qry.OrderByDescending(x => x.Location.FireDepartmentType.Name)
                                    : qry.OrderBy(x => x.Location.FireDepartmentType.Name);

                            if (sortExpression.Contains(@WebPageResources.RiskQualityRatings_Table_Location.Replace(" ", string.Empty)))
                                qry = sortDescending
                                    ? qry.OrderByDescending(x => x.Location.Name)
                                    : qry.OrderBy(x => x.Location.Name);


                            if (sortExpression.Contains(@WebPageResources.RiskQualityRatings_Table_RQR.Replace(" ", string.Empty)))
                                qry = sortDescending
                                    ? (weightedAverage != null && weightedAverage == true)
                                        ?
                                        qry.OrderByDescending(x => x.Location.RqrScoreWeighted)
                                        : qry.OrderByDescending(x => x.Location.RqrScore)
                                    : (weightedAverage != null && weightedAverage == true)
                                        ? qry.OrderBy(x => x.Location.RqrScoreWeighted)
                                        : qry.OrderBy(x => x.Location.RqrScore);
                        }


                        return qry.Skip(paging.PageOffset)
                            .Take(paging.PageSize)
                            .ToList();
                    }
                    else
                    {
                        return qry.ToList();
                    }
                }
            }
            return new List<LocationRiskQualityRating>();
        }

        /// <summary>
        /// USER STORY 80519
        /// Gather main data for Dashboard RQR Overtime tile
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <param name="lpAcctKey"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public List<RQROverTimeData> LoadRQROverTimeData(DataFilter dataFilter,
                                                            int userId, int lpAcctKey, DateTime toDate, PagedRiskQualityRatingFilters filters = null)
        {

            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter != null)
            {
                RatingTypesEnum ratingType = GetAccountRatingType(lpAcctKey);

                var riskQualityDbAccess = new RiskQualityDbAccess();

                if (filters == null)
                {
                    filters = new PagedRiskQualityRatingFilters();
                }

                if (filters.CurrentRqrRatingsFilter == null || filters.CurrentRqrRatingsFilter.Count == 0)
                {
                    filters.CurrentRqrRatingsFilter = new List<int> { Constants.RiskQualityRatingFilters.CurrentLocationCategoryRating.All };
                }

                if (filters.CurrentRqrTivFilter == null || filters.CurrentRqrTivFilter.Count == 0)
                {
                    filters.CurrentRqrTivFilter = new List<int> { Constants.RiskQualityRatingFilters.TivQuartile.All };
                }


                var qry = riskQualityDbAccess.LoadRQROverTimeData(anyLocationsSelectorDataFilter,
                                                                    dataFilter,
                                                                    ratingType,
                                                                    toDate,
                                                                    lpAcctKey,
                                                                    filters.CurrentRqrRatingsFilter,
                                                                    filters.CurrentRqrTivFilter);

                return qry.ToList();
            }

            return null;
        }

        /// <summary>
        /// USER STORY 134579
        /// Gather main data for Dashboard LQR / RQR Over Time Tile Two
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <param name="lpAcctKey"></param>
        /// <param name="selectedAsAtDate"></param>
        /// <param name="selectedLocationCategoryRatingsList"></param>
        /// <returns></returns>
        public List<RQROverTimeTileTwoData> LoadRQROverTimeTileTwoData(DataFilter dataFilter,
                                                                        int userId, int lpAcctKey,
                                                                        DateTime selectedAsAtDate,
                                                                        List<int> selectedLocationCategoryRatingsList,
                                                                        List<int> selectedTivOptionsFilter)
        {

            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter != null)
            {
                RatingTypesEnum ratingType = GetAccountRatingType(lpAcctKey);

                var riskQualityDbAccess = new RiskQualityDbAccess();

                var userLogic = new UserLogic();
                var userLoginTracking = userLogic.GetUserLastLoginDate(userId);
                var userLastLoginDate = DateTime.UtcNow;
                if (userLoginTracking != null) userLastLoginDate = userLoginTracking.LoginDate;


                if (selectedLocationCategoryRatingsList == null || selectedLocationCategoryRatingsList.Count == 0)
                {
                    selectedLocationCategoryRatingsList = new List<int> { Constants.RiskQualityRatingFilters.CurrentLocationCategoryRating.All };
                }

                if (selectedTivOptionsFilter == null || selectedTivOptionsFilter.Count == 0)
                {
                    selectedTivOptionsFilter = new List<int> { Constants.RiskQualityRatingFilters.TivQuartile.All };
                }

                var qry = riskQualityDbAccess.LoadRQROverTimeTileTwoData(anyLocationsSelectorDataFilter,
                                                                        dataFilter,
                                                                        ratingType,
                                                                        selectedAsAtDate,
                                                                        userLastLoginDate,
                                                                        lpAcctKey,
                                                                        selectedLocationCategoryRatingsList,
                                                                        selectedTivOptionsFilter);

                return qry.ToList();
            }

            return null;
        }




        /// <summary>
        /// Get the Risk Quality Rating category name (localised), depending on the account Rating Type
        /// When Account Rating is LQR the score range is as follows: 
        /// Excellent>15
        /// Good>12
        /// Fair>=9
        /// Poor&lt9
        ///
        /// When Account Rating is RQR the score range is as follows:
        /// Excellent>=7.5
        /// Good>6
        /// Fair>=4.5
        /// Poor&lt4.5
        /// (When Account Rating is 'as per contract' then omit the range figures)
        /// 
        /// </summary>
        /// <param name="ratingCategory"></param>
        /// <param name="accountRatingType"></param>
        /// <returns></returns>
        public string GetRatingCategoryLocalisedName(RatingCategoriesEnum ratingCategory, RatingTypesEnum accountRatingType)
        {
            switch (ratingCategory)
            {

                case RatingCategoriesEnum.Excellent:
                    return ((accountRatingType == RatingTypesEnum.LQR || accountRatingType == RatingTypesEnum.LQI) ? @WebPageResources.Dashboard_RiskRating_Excellent_LQR
                                : (accountRatingType == RatingTypesEnum.RQR_Calculated || accountRatingType == RatingTypesEnum.RQR_Validated || accountRatingType == RatingTypesEnum.RQI) ? @WebPageResources.Dashboard_RiskRating_Excellent_RQR
                                    : @WebPageResources.Dashboard_RiskRating_Excellent);
                case RatingCategoriesEnum.Good:
                    return ((accountRatingType == RatingTypesEnum.LQR || accountRatingType == RatingTypesEnum.LQI) ? @WebPageResources.Dashboard_RiskRating_Good_LQR
                                : (accountRatingType == RatingTypesEnum.RQR_Calculated || accountRatingType == RatingTypesEnum.RQR_Validated || accountRatingType == RatingTypesEnum.RQI) ? @WebPageResources.Dashboard_RiskRating_Good_RQR
                                    : @WebPageResources.Dashboard_RiskRating_Good);
                case RatingCategoriesEnum.Fair:
                    return ((accountRatingType == RatingTypesEnum.LQR || accountRatingType == RatingTypesEnum.LQI) ? @WebPageResources.Dashboard_RiskRating_Fair_LQR
                                : (accountRatingType == RatingTypesEnum.RQR_Calculated || accountRatingType == RatingTypesEnum.RQR_Validated || accountRatingType == RatingTypesEnum.RQI) ? @WebPageResources.Dashboard_RiskRating_Fair_RQR
                                    : @WebPageResources.Dashboard_RiskRating_Fair);
                case RatingCategoriesEnum.Poor:
                    return ((accountRatingType == RatingTypesEnum.LQR || accountRatingType == RatingTypesEnum.LQI) ? @WebPageResources.Dashboard_RiskRating_Poor_LQR
                                : (accountRatingType == RatingTypesEnum.RQR_Calculated || accountRatingType == RatingTypesEnum.RQR_Validated || accountRatingType == RatingTypesEnum.RQI) ? @WebPageResources.Dashboard_RiskRating_Poor_RQR
                                    : @WebPageResources.Dashboard_RiskRating_Poor);
                default:
                    throw new NotImplementedException("Invalid ratingCategory");
            }
        }

        /// <summary>
        /// Get the Risk Quality Rating category name, depending on the account Rating Type 
        /// Excellent
        /// Good
        /// Fair
        /// Poor
        /// </summary>
        /// <param name="ratingCategory"></param>
        /// <param name="accountRatingType"></param>
        /// <returns></returns>
        public string GetRatingCategoryName(RatingCategoriesEnum ratingCategory, RatingTypesEnum accountRatingType)
        {
            switch (ratingCategory)
            {
                case RatingCategoriesEnum.Excellent:
                    return (accountRatingType == RatingTypesEnum.LQR ? @WebPageResources.Dashboard_RiskRating_Excellent
                                : (accountRatingType == RatingTypesEnum.RQR_Calculated || accountRatingType == RatingTypesEnum.RQR_Validated ? @WebPageResources.Dashboard_RiskRating_Excellent
                                    : @WebPageResources.Dashboard_RiskRating_Excellent));
                case RatingCategoriesEnum.Good:
                    return (accountRatingType == RatingTypesEnum.LQR ? @WebPageResources.Dashboard_RiskRating_Good
                                : (accountRatingType == RatingTypesEnum.RQR_Calculated || accountRatingType == RatingTypesEnum.RQR_Validated ? @WebPageResources.Dashboard_RiskRating_Good
                                    : @WebPageResources.Dashboard_RiskRating_Good));
                case RatingCategoriesEnum.Fair:
                    return (accountRatingType == RatingTypesEnum.LQR ? @WebPageResources.Dashboard_RiskRating_Fair
                                : (accountRatingType == RatingTypesEnum.RQR_Calculated || accountRatingType == RatingTypesEnum.RQR_Validated ? @WebPageResources.Dashboard_RiskRating_Fair
                                    : @WebPageResources.Dashboard_RiskRating_Fair));
                case RatingCategoriesEnum.Poor:
                    return (accountRatingType == RatingTypesEnum.LQR ? @WebPageResources.Dashboard_RiskRating_Poor
                                : (accountRatingType == RatingTypesEnum.RQR_Calculated || accountRatingType == RatingTypesEnum.RQR_Validated ? @WebPageResources.Dashboard_RiskRating_Poor
                                    : @WebPageResources.Dashboard_RiskRating_Poor));
                default:
                    throw new NotImplementedException("Invalid ratingCategory");
            }
        }


        public string GetRatingCategoryColour(RatingCategoriesEnum ratingCategory)
        {
            switch (ratingCategory)
            {
                case RatingCategoriesEnum.Excellent:
                    return Constants.RQRColours.RQRColour_Excellent;
                case RatingCategoriesEnum.Good:
                    return Constants.RQRColours.RQRColour_Good;
                case RatingCategoriesEnum.Fair:
                    return Constants.RQRColours.RQRColour_Fair;
                case RatingCategoriesEnum.Poor:
                    return Constants.RQRColours.RQRColour_Poor;
                default:
                    throw new NotImplementedException("Invalid ratingCategory");
            }
        }

        public DataTable GetDataTableForRqrExport(PagingInfo paging, DataFilter dataFilter, int accountId, int lpAcctKey, int userId, RiskQualityFilters filters, string sortExpression, bool useLocationNo, List<int> lpAllPiKeys, List<Dictionary<string, string>> replacementHeaders = null, Dictionary<string, Dictionary<string, string>> replacementFields = null, string Format = null)
        {
            var datatable = new DataTable();

            var systemGridLogic = new SystemGridLogic();

            var rqrSystemGridFields = systemGridLogic.LoadSystemGridForUser(Constants.SystemGridRef.RiskQualityRatings, userId, false, lpAcctKey);

            var userSelectedColumns = GetUserReportExportColumnOptions(userId, Constants.SystemGridRef.RiskQualityRatings, replacementHeaders, replacementFields, lpAcctKey);

            if (userSelectedColumns != null)
            {
                var counter = 1;
                foreach (KeyValuePair<int, string> kvp in userSelectedColumns)
                {
                    // Don't print the Actions column
                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_Actions)
                        continue;

                    // Don't print the multiselect Actions column
                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_Actions2)
                        continue;

                    var gridGroup = rqrSystemGridFields.Groups.First(g => g.Fields.Any(f => f.SystemGridFieldSystemGridFieldRef == kvp.Key));
                    var gridFieldsCount = gridGroup.Fields.Count(f => f.UserSystemGridFieldVisible);
                    // string Kvptext = Regex.Replace(kvp.Value.TrimEnd(), @"[^0-9a-zA-Z]+", " ");

                    datatable.Columns.Add(
                          new DataColumn
                          {
                              ColumnName = $"Field{counter}",
                              Caption = $"{gridGroup.SystemGridGroupName.TrimEnd()}-{gridFieldsCount}|{kvp.Value.Replace("'", "").Replace("%", "").Replace("&", "").Replace("-", "").Replace("°", "").TrimEnd()}",
                              DataType = Format == Constants.ExportFormats.Excel ? Type.GetType(SetColumnsType(kvp.Key, useLocationNo)) : Type.GetType(Constants.GetTypeSystem.Sys_String)


                          });

                    counter++;
                }
            }


            var dataSet = LoadRqrLqrLevelFourData(paging, dataFilter, accountId, lpAcctKey, userId, filters, sortExpression, useLocationNo, lpAllPiKeys);

            AddDatasetToCustomisableReport(datatable, dataSet, userSelectedColumns, useLocationNo, Format);
            return datatable;
        }

        private string SetColumnsType(int Key, bool useLocationNo)
        {
            try
            {
                if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_LocationID)
                {
                    switch (useLocationNo)
                    {
                        case true:
                            {
                                return Constants.GetTypeSystem.Sys_String;
                            }
                        case false:
                            return Constants.GetTypeSystem.Sys_String;
                    }
                }

                if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_ClientLocationID)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_LocationName)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_Division)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_SubDivision)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_StreetAddress1)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_StreetAddress2)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_City)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_State)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_Country)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_TotalPropertyValue)
                    return Constants.GetTypeSystem.Sys_Long; //Constants.GetTypeSystem.Sys_Long;
                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_BusinessInterruptionValue)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_TotalInsurableValue)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_MPL)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_NLE)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_NLEoverPML)
                    return Constants.GetTypeSystem.Sys_Decimal;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_OccupancyClassSIC)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_OccupancyClassNACE)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_FireClass)
                    return Constants.GetTypeSystem.Sys_Int;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_CurrentRiskQualityRating)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RatingPerContract)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingCalculated)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingValidated)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_Vulnerability)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_LQR)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RQI)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_LQI)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_ManagementProgramsQualityRating)
                    return Constants.GetTypeSystem.Sys_Decimal;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_SprinklerProtectionQualityRating)
                    return Constants.GetTypeSystem.Sys_Decimal;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_PreEmergencyPlanningRating)
                    return Constants.GetTypeSystem.Sys_Decimal;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_SurveillanceQualityRating)
                    return Constants.GetTypeSystem.Sys_Decimal;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_OtherProtectionQualityRating)
                    return Constants.GetTypeSystem.Sys_Decimal;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_HazardsQualityRating)
                    return Constants.GetTypeSystem.Sys_Decimal;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_WaterSupplyQualityRating)
                    return Constants.GetTypeSystem.Sys_Decimal;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_HighPileStorageRating)
                    return Constants.GetTypeSystem.Sys_Decimal;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_FireDepartmentRating)
                    return Constants.GetTypeSystem.Sys_Decimal;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_PredominantConstructionRating)
                    return Constants.GetTypeSystem.Sys_Decimal;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_BIExposureQualityRating)
                    return Constants.GetTypeSystem.Sys_Decimal;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_PredominantConstruction)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_FireDepartmentType)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskManagement)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_PassiveProtection)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_OccupancyRelatedHazards)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_HumanElement)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_ActiveProtection)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_Surveillance)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_ThirdPartyExposure)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_BIExposure)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_CurrentRiskQualityRating2)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofJan1YMinus1)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofJan1YMinus2)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofJan1YMinus3)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofJan1YMinus4)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofJan1YMinus5)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_CurrentRiskQualityRating3)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_LastSurveyDate)
                    return Constants.GetTypeSystem.Sys_DateTime;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofPriorSurvey1)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_PriorSurvey1Date)
                    return Constants.GetTypeSystem.Sys_DateTime;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofPriorSurvey2)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_PriorSurvey2Date)
                    return Constants.GetTypeSystem.Sys_DateTime;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofPriorSurvey3)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_PriorSurvey3Date)
                    return Constants.GetTypeSystem.Sys_DateTime;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofPriorSurvey4)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_PriorSurvey4Date)
                    return Constants.GetTypeSystem.Sys_DateTime;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofPriorSurvey5)
                    return Constants.GetTypeSystem.Sys_Double;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_PriorSurvey5Date)
                    return Constants.GetTypeSystem.Sys_DateTime;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_Comment1)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_Comment2)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_Comment3)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_SharedComment)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingWithImpactofCompletedClient)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingswithImpactofALLHE)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatinsgwithImpactofPhysType_w_EstimatedCost)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingswithImpactofALLHEPhysTypeRecommendationsw_EstimatedCost)
                    return Constants.GetTypeSystem.Sys_String;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_EstiamtedCosttoAchieveFairRiskQualityRating)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_EstiamtedCosttoAchieveGoodRiskQualityRating)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_EstiamtedCosttoAchieveExcellentRiskQualityRating)
                    return Constants.GetTypeSystem.Sys_Long;

                else if (Key == Constants.SystemGridFieldRef.RiskQualityRatings_ClientRatings)
                    return Constants.GetTypeSystem.Sys_Double;
                else
                    return Constants.GetTypeSystem.Sys_String;


            }
            catch (Exception ex)
            {

                LogHelper.Error($"Could not load SetColumnsType {Key}", ex);
                return Constants.GetTypeSystem.Sys_String; ;

            }

        }

        public List<RqrLevel4Data> LoadRqrLqrLevelFourData(PagingInfo paging, DataFilter dataFilter, int accountId, int lpAcctKey, int userId, RiskQualityFilters filters, string sortExpression, bool useLocationNo, List<int> lpAllPiKeys = null)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter != null)
            {
                RatingTypesEnum ratingType = GetAccountRatingType(lpAcctKey);

                var riskQualityDbAccess = new RiskQualityDbAccess();

                int totalRows = 0;

                var qry = riskQualityDbAccess.LoadRqrLevel4Data(anyLocationsSelectorDataFilter,
                    dataFilter,
                    ratingType,
                    filters.CurrentLocationCategoryRating,
                    filters.TivQuartilesFilter,
                    filters.ShowFilter,
                    filters.SinceFilter,
                    filters.AsOfFilter,
                    accountId,
                    lpAcctKey,
                    sortExpression,
                    paging.PageSize,
                    useLocationNo,
                    paging.PageOffset,
                    out totalRows,
                     filters.SurveyedDate,
                     userId,
                    lpAllPiKeys);

                paging.TotalRecords = totalRows;

                return qry.ToList();
            }

            return null;

        }

        public decimal CalculateAverageRiskQualityRatingForDivisionList(List<RiskQualityRatingNode> nodes, Constants.RiskQualityAverageWeightingMode averageWeightingMode, Constants.RiskQualityRatingNodeSubType subType)
        {
            decimal avg = 0.00M;
            decimal totalTIV = 0;

            if (averageWeightingMode == Constants.RiskQualityAverageWeightingMode.LocationCount)
            {
                if (nodes != null && nodes.Count > 0)
                {
                    int noOfDivisionsWithLocations = 0;

                    foreach (var division in nodes)
                    {
                        var kvp = GetTotalScoreForDivisionChildren(division, averageWeightingMode);
                        avg += kvp.Key;
                        noOfDivisionsWithLocations += kvp.Value;
                    }

                    if (subType == Constants.RiskQualityRatingNodeSubType.My)
                        return CalculateAverageRqr(averageWeightingMode, avg, noOfDivisionsWithLocations);

                    if (subType == Constants.RiskQualityRatingNodeSubType.Filtered)
                        return CalculateAverageRqr(averageWeightingMode, avg, noOfDivisionsWithLocations);
                }
            }

            else if (averageWeightingMode == Constants.RiskQualityAverageWeightingMode.TIV)
            {
                if (nodes != null && nodes.Count > 0)
                {
                    int noOfDivisionsWithLocations = 0;

                    foreach (var division in nodes)
                    {
                        var kvp = GetTotalScoreForDivisionChildren(division, averageWeightingMode);
                        totalTIV += kvp.Key;
                        noOfDivisionsWithLocations += kvp.Value;


                        if (subType == Constants.RiskQualityRatingNodeSubType.My)
                            return CalculateTIVAverageRqr(division, averageWeightingMode, totalTIV);

                        if (subType == Constants.RiskQualityRatingNodeSubType.Filtered)
                            return CalculateTIVAverageRqr(division, averageWeightingMode, totalTIV);
                    }

                }
            }

            return avg;
        }

        private KeyValuePair<decimal, int> GetTotalScoreForDivisionChildren(RiskQualityRatingNode node, Constants.RiskQualityAverageWeightingMode averageWeightingMode)
        {
            decimal avg = 0.00M;
            decimal totalTiv = 0;
            int nodesCounted = 0;

            KeyValuePair<decimal, int> averageorTotalTIVAndNumberOfLocations = new KeyValuePair<decimal, int>();

            if (averageWeightingMode == Constants.RiskQualityAverageWeightingMode.LocationCount)
            {
                switch (node.SubType)
                {
                    case Constants.RiskQualityRatingNodeSubType.My:

                        foreach (var child in node.MyChildren)
                        {
                            if (child.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                            {
                                if (child.RatingScore != null)
                                {
                                    nodesCounted++;
                                    avg += (decimal)child.RatingScore.Value;

                                }
                            }

                            if (child.Type == Constants.RiskQualityRatingNodeType.SubDivisionSingle)
                            {
                                foreach (var grandchild in child.MyChildren)
                                {
                                    if (grandchild.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                                    {
                                        if (grandchild.RatingScore != null)
                                        {
                                            nodesCounted++;
                                            avg += (decimal)grandchild.RatingScore.Value;

                                        }
                                    }
                                }
                            }
                        }
                        break;
                    case Constants.RiskQualityRatingNodeSubType.Filtered:
                        foreach (var child in node.FilteredChildren)
                        {
                            if (child.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                            {
                                if (child.RatingScore != null)
                                {
                                    nodesCounted++;
                                    avg += (decimal)child.RatingScore.Value;
                                }
                            }

                            if (child.Type == Constants.RiskQualityRatingNodeType.SubDivisionSingle)
                            {
                                foreach (var grandchild in child.FilteredChildren)
                                {
                                    if (grandchild.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                                    {
                                        if (grandchild.RatingScore != null)
                                        {
                                            nodesCounted++;
                                            avg += (decimal)grandchild.RatingScore.Value;
                                        }
                                    }
                                }
                            }
                        }
                        break;
                }
                averageorTotalTIVAndNumberOfLocations = new KeyValuePair<decimal, int>(avg, nodesCounted);

            }

            else if (averageWeightingMode == Constants.RiskQualityAverageWeightingMode.TIV)
            {
                switch (node.SubType)
                {
                    case Constants.RiskQualityRatingNodeSubType.My:

                        foreach (var child in node.MyChildren)
                        {
                            if (child.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                            {
                                if (child.TIV != null)
                                {
                                    nodesCounted++;
                                    totalTiv += child.TIV.Value;

                                }
                            }

                            if (child.Type == Constants.RiskQualityRatingNodeType.SubDivisionSingle)
                            {
                                foreach (var grandchild in child.MyChildren)
                                {
                                    if (grandchild.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                                    {
                                        if (grandchild.TIV != null)
                                        {
                                            nodesCounted++;
                                            totalTiv += grandchild.TIV.Value;

                                        }
                                    }
                                }
                            }
                        }
                        break;
                    case Constants.RiskQualityRatingNodeSubType.Filtered:
                        foreach (var child in node.FilteredChildren)
                        {
                            if (child.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                            {
                                if (child.TIV != null)
                                {
                                    nodesCounted++;
                                    totalTiv += child.TIV.Value;
                                }
                            }

                            if (child.Type == Constants.RiskQualityRatingNodeType.SubDivisionSingle)
                            {
                                foreach (var grandchild in child.FilteredChildren)
                                {
                                    if (grandchild.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                                    {
                                        if (grandchild.TIV != null)
                                        {
                                            nodesCounted++;
                                            totalTiv += grandchild.TIV.Value;
                                        }
                                    }
                                }
                            }
                        }
                        break;
                }
                averageorTotalTIVAndNumberOfLocations = new KeyValuePair<decimal, int>(totalTiv, nodesCounted);
            }
            return averageorTotalTIVAndNumberOfLocations;
        }

        public bool SaveSharedComment(SharedComment sharedComment)
        {
            RiskQualityDbAccess db = new RiskQualityDbAccess();

            return db.InsertAndUpdateSharedComment(sharedComment);

        }
        public bool SaveMyComment(SharedComment sharedComment)
        {
            RiskQualityDbAccess db = new RiskQualityDbAccess();

            return db.InsertAndUpdateMyComment(sharedComment);

        }

        public decimal CalculateAverageRiskQualityRatingForLocationList(List<RiskQualityRatingNode> nodes, Constants.RiskQualityAverageWeightingMode averageWeightingMode)
        {

            decimal result = 0.00M;
            if (averageWeightingMode == Constants.RiskQualityAverageWeightingMode.LocationCount)
            {
                if (nodes != null && nodes.Count > 0)
                {
                    decimal counter = 0.00M;
                    var numberOfNodesCounted = 0;

                    foreach (var child in nodes)
                    {
                        if (child.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                        {
                            if (child.RatingScore != null)
                            {
                                counter += (decimal)child.RatingScore.Value;
                                numberOfNodesCounted += 1;
                            }
                        }

                        if (child.Type == Constants.RiskQualityRatingNodeType.DivisionSingle || child.Type == Constants.RiskQualityRatingNodeType.DivisionAggregate)
                        {
                            if (child.SubDivisionNodes != null && child.SubDivisionNodes.Count > 0)
                            {
                                counter += CalculateAverageRiskQualityRatingForLocationList(child.SubDivisionNodes, averageWeightingMode);
                            }

                            else
                            {
                                var targetNodes = child.SubType == Constants.RiskQualityRatingNodeSubType.My ? child.MyChildren : child.LocationNodes;
                                counter += CalculateAverageRiskQualityRatingForLocationList(targetNodes, averageWeightingMode);
                                numberOfNodesCounted += 1;
                            }

                        }
                        else if (child.Type == Constants.RiskQualityRatingNodeType.SubDivisionSingle)
                        {
                            var targetNodes = child.SubType == Constants.RiskQualityRatingNodeSubType.My ? child.MyChildren : child.LocationNodes;
                            counter += CalculateAverageRiskQualityRatingForLocationList(targetNodes, averageWeightingMode);
                            numberOfNodesCounted += 1;
                        }
                    }

                    result = CalculateAverageRqr(averageWeightingMode, counter, numberOfNodesCounted);
                }
            }

            else if (averageWeightingMode == Constants.RiskQualityAverageWeightingMode.TIV)
            {
                decimal totalTiv = 0;
                List<RiskQualityRatingNode> tivNodes = new List<RiskQualityRatingNode>();

                if (nodes != null && nodes.Count > 0)
                {
                    foreach (var child in nodes)
                    {
                        if (child.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                        {
                            if (child.TIV != null && child.RatingScore != null)
                            {
                                totalTiv += child.TIV.Value;
                                tivNodes.Add(child);
                            }
                        }

                        if (child.Type == Constants.RiskQualityRatingNodeType.DivisionSingle || child.Type == Constants.RiskQualityRatingNodeType.DivisionAggregate)
                        {
                            if (child.SubDivisionNodes != null && child.SubDivisionNodes.Count > 0)
                            {
                                totalTiv += CalculateAverageRiskQualityRatingForLocationList(child.SubDivisionNodes, averageWeightingMode);
                            }

                            else
                            {
                                var targetNodes = child.SubType == Constants.RiskQualityRatingNodeSubType.My ? child.MyChildren : child.LocationNodes;
                                totalTiv += CalculateAverageRiskQualityRatingForLocationList(targetNodes, averageWeightingMode);

                            }

                        }
                        else if (child.Type == Constants.RiskQualityRatingNodeType.SubDivisionSingle)
                        {
                            var targetNodes = child.SubType == Constants.RiskQualityRatingNodeSubType.My ? child.MyChildren : child.LocationNodes;
                            totalTiv += CalculateAverageRiskQualityRatingForLocationList(targetNodes, averageWeightingMode);

                        }
                    }

                    foreach (var locationNode in tivNodes)
                    {
                        if (locationNode.RatingScore != null && locationNode.TIV != null && totalTiv > 0)
                        {
                            result += ((decimal)locationNode.RatingScore.Value * (locationNode.TIV.Value / totalTiv));
                        }

                    }
                }




            }

            return result;
        }

        private void CalculateQuartilesForLocationList(List<RiskQualityRatingNode> nodes, QuartileData quartileData)
        {
            var tmpList = nodes.OrderBy(x => x.RatingScore).ToList();
            // remove null ratings from the list
            tmpList.RemoveAll(x => x.RatingScore == null);

            var tmpListCount = tmpList.Count;

            if (tmpListCount == 0)
            {
                quartileData.Maximum = 0;
                quartileData.UpperQuartile = 0;
                quartileData.Median = 0;
                quartileData.LowerQuartile = 0;
                quartileData.Minimum = 0;
                return;
            }

            // max 
            var maximum = tmpList.Max(i => i.RatingScore.GetValueOrDefault(0));

            // upper
            var skipUpperQuartile = tmpList.Count * 3 / 4;
            var upperQuartile = tmpList.Skip(skipUpperQuartile).Take(1).FirstOrDefault()?.RatingScore;

            // lower
            var skipLowerQuartile = tmpList.Count * 1 / 4;
            var lowerQuartile = tmpList.Skip(skipLowerQuartile).Take(1).FirstOrDefault()?.RatingScore;

            // median
            var skipVal = (int)Math.Round(tmpList.Count * 0.5);
            var median = tmpList.Skip(skipVal).Take(1).FirstOrDefault()?.RatingScore;

            // min 
            var minimum = tmpList.Min(i => i.RatingScore.GetValueOrDefault(0));

            quartileData.Maximum = maximum;
            quartileData.UpperQuartile = upperQuartile;
            quartileData.Median = median;
            quartileData.LowerQuartile = lowerQuartile;
            quartileData.Minimum = minimum;
        }

        private void CalculateQuartilesForDivisionList(List<RiskQualityRatingNode> nodes, QuartileData quartileData)
        {
            var ratingScoreList = new List<double>();

            // Traverse (Division - Location), (Division - SubDivision - Location) to accrue all RatingScores
            foreach (var node in nodes)
            {
                if (node.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                {
                    if (node.RatingScore != null)
                    {
                        ratingScoreList.Add(node.RatingScore.Value);
                    }
                }

                if (node.Type == Constants.RiskQualityRatingNodeType.DivisionSingle || node.Type == Constants.RiskQualityRatingNodeType.DivisionAggregate)
                {
                    if (node.SubDivisionNodes != null && node.SubDivisionNodes.Count > 0)
                    {
                        foreach (var subDivisionNode in node.SubDivisionNodes)
                        {
                            if (node.SubType == Constants.RiskQualityRatingNodeSubType.My)
                            {
                                foreach (var locationNode in subDivisionNode.MyChildren)
                                {
                                    if (locationNode.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                                    {
                                        if (locationNode.RatingScore != null) ratingScoreList.Add(locationNode.RatingScore.Value);
                                    }
                                }
                            }
                            else if (node.SubType == Constants.RiskQualityRatingNodeSubType.Filtered)
                            {
                                foreach (var locationNode in subDivisionNode.LocationNodes)
                                {
                                    if (locationNode.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                                    {
                                        if (locationNode.RatingScore != null) ratingScoreList.Add(locationNode.RatingScore.Value);
                                    }
                                }
                            }

                        }
                    }

                    if (node.SubType == Constants.RiskQualityRatingNodeSubType.My)
                    {
                        foreach (var myLocation in node.MyChildren.Where(x => x.Type == Constants.RiskQualityRatingNodeType.LocationSingle))
                        {
                            if (myLocation.RatingScore != null) ratingScoreList.Add(myLocation.RatingScore.Value);
                        }
                    }
                    else if (node.SubType == Constants.RiskQualityRatingNodeSubType.Filtered)
                    {
                        foreach (var filteredLocation in node.LocationNodes.Where(x => x.Type == Constants.RiskQualityRatingNodeType.LocationSingle))
                        {
                            if (filteredLocation.RatingScore != null) ratingScoreList.Add(filteredLocation.RatingScore.Value);
                        }
                    }

                }
            }

            var ratingScoreListCount = ratingScoreList.Count;

            ratingScoreList = ratingScoreList.OrderBy(x => x).ToList();

            if (ratingScoreListCount == 0)
            {
                quartileData.Maximum = 0;
                quartileData.UpperQuartile = 0;
                quartileData.Median = 0;
                quartileData.LowerQuartile = 0;
                quartileData.Minimum = 0;

                return;
            }

            // max 
            var maximum = ratingScoreList.Max(i => i);

            // upper
            var skipUpperQuartile = ratingScoreList.Count * 3 / 4;
            var upperQuartile = ratingScoreList.Skip(skipUpperQuartile).Take(1).FirstOrDefault();

            // lower
            var skipLowerQuartile = ratingScoreList.Count * 1 / 4;
            var lowerQuartile = ratingScoreList.Skip(skipLowerQuartile).Take(1).FirstOrDefault();

            // median
            var skipVal = (int)Math.Round(ratingScoreList.Count * 0.5);
            var median = ratingScoreList.Skip(skipVal).Take(1).FirstOrDefault();

            // min 
            var minimum = ratingScoreList.Min(i => i);

            quartileData.Maximum = maximum;
            quartileData.UpperQuartile = upperQuartile;
            quartileData.Median = median;
            quartileData.LowerQuartile = lowerQuartile;
            quartileData.Minimum = minimum;
        }
        /// <summary>
        /// Returns a simple mean average (Risk Rating Value) over a list of locations
        /// </summary>
        /// <param name="averageWeightingMode"></param>
        /// <param name="average"></param>
        /// <param name="numberOfLocationsCounted"></param>
        /// <returns></returns>
        private static decimal CalculateAverageRqr(Constants.RiskQualityAverageWeightingMode averageWeightingMode, decimal average, int numberOfLocationsCounted)
        {
            decimal result = 0.00M;

            result = average / (numberOfLocationsCounted == 0 ? 1 : numberOfLocationsCounted);


            return result;
        }

        /// <summary>
        /// Returns a TIV weighted average (Risk Rating Value) over a list of locations
        /// </summary>
        /// <param name="nodes"></param>
        /// <param name="averageWeightingMode"></param>
        /// <param name="totalTiv"></param>
        /// <returns></returns>
        private static decimal CalculateTIVAverageRqr(RiskQualityRatingNode nodes, Constants.RiskQualityAverageWeightingMode averageWeightingMode, decimal totalTiv)
        {
            decimal result = 0;
            List<RiskQualityRatingNode> tivNodes = new List<RiskQualityRatingNode>();

            foreach (var child in nodes.MyChildren)
            {
                if (child.Type == Constants.RiskQualityRatingNodeType.LocationSingle)
                {
                    if (child.TIV != null && child.RatingScore != null)
                    {
                        tivNodes.Add(child);
                    }
                }
            }

            foreach (var locationNode in tivNodes)
            {
                if (locationNode.RatingScore != null && locationNode.TIV != null)
                {
                    if (totalTiv > 0)
                        result += ((decimal)locationNode.RatingScore.Value * (locationNode.TIV.Value / totalTiv));
                }

            }
            return result;
        }

        /// <summary>
        /// Loads RQR/LQL Level Three data and translates the stored procedure's output from raw result sets into a map of RiskQualityRatingNodes, following task:
        /// https://xlcatlin.visualstudio.com/AXA%20XL%20Risk%20Engineering/_workitems/edit/136410
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="lpAcctKey"></param>
        /// <param name="userId"></param>
        /// <param name="filters"></param>
        /// <param name="averageWeightingMode"></param>
        /// <param name="accountName"></param>
        /// <returns></returns>
        public RiskQualityBenchmarkingData LoadRqrLqrLevelThreeData(DataFilter dataFilter, int lpAcctKey, int userId, RiskQualityFilters filters, Constants.RiskQualityAverageWeightingMode averageWeightingMode, string accountName, bool useLocationNo)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);


            // Step 1 - Add top-level node (Account Node)
            RiskQualityBenchmarkingData result = new RiskQualityBenchmarkingData();
            result.Children = new List<RiskQualityRatingNode>();
            result.AccountName = accountName;

            if (anyLocationsSelectorDataFilter != null)
            {
                RatingTypesEnum ratingType = GetAccountRatingType(lpAcctKey);

                var riskQualityDbAccess = new RiskQualityDbAccess();

                var qry = riskQualityDbAccess.LoadRqrLevel3Data(
                    anyLocationsSelectorDataFilter,
                    dataFilter,
                    lpAcctKey,
                    userId,
                    filters.AsOfFilter,
                    (int)ratingType,
                    filters.CurrentLocationCategoryRating,
                    filters.TivQuartilesFilter,
                    useLocationNo
                );

                var locationsResultSet = qry.LocationResultSet;
                var subDivisionsResultSet = qry.SubDivisionResultSet;
                var divisionsResultSet = qry.DivisionResultSet;


                // Step 2 - Add (any) Location node(s) within filter for Account (direct children)
                // all Locations for the account
                var allLocations = locationsResultSet.Where(x => x.HasAccess == 0 && x.IsFiltered == 0).Select(y => new RiskQualityRatingNode { TIV = y.TIV, FullLocationName = y.FullLocationName, LocationId = y.LocationId, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.All, LpAllPiKey = y.LpAllPiKey }).ToList();

                foreach (var location in allLocations)
                {
                    // Account - Location direct descendants (with no Division as a parent)
                    if (location.LpAcctWebDivKey == null && location.LpSubDivKey == null)
                        result.Children.Add(location);

                }

                // Calculate the top level node's average Risk Quality Rating across all locations
                result.AccountAllAverage = FormatHelper.FormatRqr(CalculateAverageRiskQualityRatingForLocationList(allLocations, averageWeightingMode));
                CalculateQuartilesForLocationList(allLocations, result.AllLocationQuartileData);

                // Step 3 - Add (any) Division node(s) for Account. This step only loads the "All" Divisions - "My" and "Filtered" are loaded during Step 7
                List<RiskQualityRatingNode> permissionBasedDivisionsList = divisionsResultSet.Where(x => x.HasAccess == 1 && x.IsFiltered == 0).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, Type = Constants.RiskQualityRatingNodeType.DivisionSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAcctWebDivKey = y.LpAcctWebDivKey }).ToList();
                List<RiskQualityRatingNode> filteredDivisionsList = divisionsResultSet.Where(x => x.HasAccess == 1 && x.IsFiltered == 1).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, Type = Constants.RiskQualityRatingNodeType.DivisionAggregate, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAcctWebDivKey = y.LpAcctWebDivKey }).ToList();

                LoadDivisionsForAccount(averageWeightingMode, filteredDivisionsList, permissionBasedDivisionsList, locationsResultSet, subDivisionsResultSet, result, accountName);

                // Calculate the top level node's average Risk Quality Rating across My Divisions
                result.MyDivisionsAverage = FormatHelper.FormatRqr(CalculateAverageRiskQualityRatingForDivisionList(result.MyDivisions, averageWeightingMode, Constants.RiskQualityRatingNodeSubType.My));
                CalculateQuartilesForDivisionList(result.MyDivisions, result.MyDivisionsQuartileData);


                // Calculate the top level node's average Risk Quality Rating across My Divisions
                result.MyDivisionsAverageFiltered = FormatHelper.FormatRqr(CalculateAverageRiskQualityRatingForDivisionList(filteredDivisionsList, averageWeightingMode, Constants.RiskQualityRatingNodeSubType.Filtered));
                CalculateQuartilesForDivisionList(filteredDivisionsList, result.FilteredDivisionsQuartileData);

                // Load "My Locations" Average
                List<RiskQualityRatingNode> permissionBasedLocations = locationsResultSet.Where(x => x.HasAccess == 1 && x.IsFiltered == 0).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAcctWebDivKey = y.LpAcctWebDivKey }).ToList();
                result.MyLocationsAverage = FormatHelper.FormatRqr(CalculateAverageRiskQualityRatingForLocationList(permissionBasedLocations, averageWeightingMode));

                // Load Quartiles for My Locations
                CalculateQuartilesForDivisionList(permissionBasedLocations, result.MyLocationsQuartileData);

                // Load "My Filtered Locations" Average
                List<RiskQualityRatingNode> filteredLocations = locationsResultSet.Where(x => x.HasAccess == 1 && x.IsFiltered == 1).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAcctWebDivKey = y.LpAcctWebDivKey }).ToList();
                result.MyLocationsAverageFiltered = FormatHelper.FormatRqr(CalculateAverageRiskQualityRatingForLocationList(filteredLocations, averageWeightingMode));

                // Load Quartiles for Filtered Locations
                CalculateQuartilesForDivisionList(filteredLocations, result.FilteredLocationsQuartileData);
                result.MyDivisionsAverageFilteredWidth = result.MyDivisionsAverageFiltered > 130 ? 130 : result.MyDivisionsAverageFiltered;
            }


            return result;
        }

        private void LoadDivisionsForAccount(Constants.RiskQualityAverageWeightingMode averageWeightingMode, List<RiskQualityRatingNode> filteredDivisionsList, List<RiskQualityRatingNode> myDivisionsList, List<ProcGetLqrrqrLevelThreeDataReturnModel.ResultSetModel1> locationsResultSet, List<ProcGetLqrrqrLevelThreeDataReturnModel.ResultSetModel2> subDivisionsResultSet, RiskQualityBenchmarkingData result, string accountName)
        {
            result.FilteredDivisions = new List<RiskQualityRatingNode>();
            result.MyDivisions = new List<RiskQualityRatingNode>();

            // Load "Filtered" Divisions
            foreach (var division in filteredDivisionsList)
            {
                if (division != null)
                {
                    // Create a deep copy of the Parent record (Division), with no children records in order to preserve the relationship between Parent-Child node, without creating a circular reference

                    RiskQualityRatingNode parentCopyDivision = new RiskQualityRatingNode
                    {
                        LpAcctWebDivKey = division.LpAcctWebDivKey,
                        Name = division.Name
                    };

                    division.MyChildren = new List<RiskQualityRatingNode>();
                    division.FilteredChildren = new List<RiskQualityRatingNode>();

                    division.MyChildren = locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.LpSubDivKey == null && x.HasAccess == 1 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { TIV = y.TIV, FullLocationName = y.FullLocationName, LocationId = y.LocationId, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey }).ToList();
                    division.FilteredChildren = locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.LpSubDivKey == null && x.HasAccess == 1 && x.IsFiltered == 1).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { TIV = y.TIV, FullLocationName = y.FullLocationName, LocationId = y.LocationId, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList();

                    division.AverageAllFilteredChildren = (int)CalculateAverageRiskQualityRatingForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 1).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), averageWeightingMode);
                    division.AverageAllMyChildren = (int)CalculateAverageRiskQualityRatingForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), averageWeightingMode);
                    division.AverageAllChildren = (int)CalculateAverageRiskQualityRatingForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 0 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), averageWeightingMode);

                    // Calculate "All" Quartiles for this Division
                    CalculateQuartilesForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 01 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey }).ToList(), division.AllQuartileData);
                    // Calculate My Quartiles for this filtered Division
                    CalculateQuartilesForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey }).ToList(), division.MyChildrenQuartileData);
                    // Calculate Filtered Quartiles for this filtered Division
                    CalculateQuartilesForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 1).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey }).ToList(), division.MyFilteredQuartileData);

                    var mySubDivisionChildren = subDivisionsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 0);
                    var filteredSubDivisionChildren = subDivisionsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 1);

                    LoadMySubDivisions(averageWeightingMode, locationsResultSet, mySubDivisionChildren, parentCopyDivision, division, accountName);
                    LoadFilteredSubDivisions(averageWeightingMode, locationsResultSet, filteredSubDivisionChildren, parentCopyDivision, division, accountName);

                    result.FilteredDivisions.Add(division);
                }
            }

            // Load "My" Divisions - i.e. all those to which I have access
            foreach (var division in myDivisionsList)
            {
                if (division != null)
                {
                    // Create a deep copy of the Parent record (Division), with no children records in order to preserve the relationship between Parent-Child node, without creating a circular reference

                    RiskQualityRatingNode parentCopyDivision = new RiskQualityRatingNode
                    {
                        LpAcctWebDivKey = division.LpAcctWebDivKey,
                        Name = division.Name
                    };

                    division.MyChildren = new List<RiskQualityRatingNode>();
                    division.FilteredChildren = new List<RiskQualityRatingNode>();

                    division.MyChildren = locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.LpSubDivKey == null && x.HasAccess == 1 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey }).ToList();
                    division.FilteredChildren = locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.LpSubDivKey == null && x.HasAccess == 1 && x.IsFiltered == 1).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList();

                    division.AverageAllFilteredChildren = (int)CalculateAverageRiskQualityRatingForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 1).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), averageWeightingMode);
                    division.AverageAllMyChildren = (int)CalculateAverageRiskQualityRatingForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), averageWeightingMode);
                    division.AverageAllChildren = (int)CalculateAverageRiskQualityRatingForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 0 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), averageWeightingMode);


                    // Calculate "All" Quartiles for this Division
                    CalculateQuartilesForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 01 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey }).ToList(), division.AllQuartileData);
                    // Calculate My Quartiles for this "My" Division
                    CalculateQuartilesForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey }).ToList(), division.MyChildrenQuartileData);
                    // Calculate Filtered Quartiles for this "My" Division
                    CalculateQuartilesForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 1).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey }).ToList(), division.MyFilteredQuartileData);


                    var mySubDivisionChildren = subDivisionsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 0);
                    var filteredSubDivisionChildren = subDivisionsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 1);

                    LoadMySubDivisions(averageWeightingMode, locationsResultSet, mySubDivisionChildren, parentCopyDivision, division, accountName);
                    LoadFilteredSubDivisions(averageWeightingMode, locationsResultSet, filteredSubDivisionChildren, parentCopyDivision, division, accountName);

                    result.MyDivisions.Add(division);
                }
            }
        }

        private void LoadMySubDivisions(Constants.RiskQualityAverageWeightingMode averageWeightingMode, List<ProcGetLqrrqrLevelThreeDataReturnModel.ResultSetModel1> locationsResultSet, IEnumerable<ProcGetLqrrqrLevelThreeDataReturnModel.ResultSetModel2> mySubDivisionChildren, RiskQualityRatingNode parentCopyDivision, RiskQualityRatingNode division, string accountName)
        {
            foreach (var subDivision in mySubDivisionChildren)
            {
                // Create a deep copy of the Parent Record (SubDivision), with no children records in order to preserve the relationship between Parent-Child node, without creating a circular reference
                RiskQualityRatingNode parentCopySubDivision = new RiskQualityRatingNode
                {
                    LpSubDivKey = subDivision.LpSubDivKey,
                    Name = subDivision.Name,
                    AccountName = accountName
                };

                var subDivisionNode = new RiskQualityRatingNode
                {
                    Name = subDivision.Name,
                    SubDivisionName = subDivision.Name,
                    AccountName = accountName,
                    Type = Constants.RiskQualityRatingNodeType.SubDivisionSingle,
                    SubType = Constants.RiskQualityRatingNodeSubType.My,
                    LpSubDivKey = subDivision.LpSubDivKey,
                    Parent = parentCopyDivision,
                    MyChildren = locationsResultSet.Where(x => x.LpSubDivKey == subDivision.LpSubDivKey && x.HasAccess == 1 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, FullLocationName = y.FullLocationName, LocationId = y.LocationId, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey, Parent = parentCopySubDivision }).ToList(),
                    FilteredChildren = locationsResultSet.Where(x => x.LpSubDivKey == subDivision.LpSubDivKey && x.HasAccess == 1 && x.IsFiltered == 1).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, FullLocationName = y.FullLocationName, LocationId = y.LocationId, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey, Parent = parentCopySubDivision }).ToList()
                };


                subDivisionNode.AverageAllFilteredChildren = (int)CalculateAverageRiskQualityRatingForLocationList(locationsResultSet.Where(x => x.LpSubDivKey == subDivisionNode.LpSubDivKey && x.HasAccess == 1 && x.IsFiltered == 1).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), averageWeightingMode);
                subDivisionNode.AverageAllMyChildren = (int)CalculateAverageRiskQualityRatingForLocationList(locationsResultSet.Where(x => x.LpSubDivKey == subDivisionNode.LpSubDivKey && x.HasAccess == 1 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), averageWeightingMode);
                subDivisionNode.AverageAllChildren = (int)CalculateAverageRiskQualityRatingForLocationList(locationsResultSet.Where(x => x.LpSubDivKey == subDivisionNode.LpSubDivKey && x.HasAccess == 0 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), averageWeightingMode);


                // Calculate "All" Quartiles for this SubDivision
                CalculateQuartilesForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 01 && x.IsFiltered == 0 && x.LpSubDivKey == subDivisionNode.LpSubDivKey).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = subDivisionNode, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey }).ToList(), subDivisionNode.AllQuartileData);
                // Calculate My Quartiles for this SubDivision
                CalculateQuartilesForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 0 && x.LpSubDivKey == subDivisionNode.LpSubDivKey).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = subDivisionNode, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey }).ToList(), subDivisionNode.MyChildrenQuartileData);
                // Calculate Filtered Quartiles for this SubDivision
                CalculateQuartilesForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 1 && x.LpSubDivKey == subDivisionNode.LpSubDivKey).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = subDivisionNode, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey }).ToList(), subDivisionNode.MyFilteredQuartileData);


                division.MyChildren.Add(subDivisionNode);
            }
        }
        private void LoadFilteredSubDivisions(Constants.RiskQualityAverageWeightingMode averageWeightingMode, List<ProcGetLqrrqrLevelThreeDataReturnModel.ResultSetModel1> locationsResultSet, IEnumerable<ProcGetLqrrqrLevelThreeDataReturnModel.ResultSetModel2> mySubDivisionChildren, RiskQualityRatingNode parentCopyDivision, RiskQualityRatingNode division, string accountName)
        {
            foreach (var subDivision in mySubDivisionChildren)
            {
                // Create a deep copy of the Parent Record (SubDivision), with no children records in order to preserve the relationship between Parent-Child node, without creating a circular reference
                RiskQualityRatingNode parentCopySubDivision = new RiskQualityRatingNode
                {
                    LpSubDivKey = subDivision.LpSubDivKey,
                    Name = subDivision.Name,
                    AccountName = accountName
                };

                var subDivisionNode = new RiskQualityRatingNode
                {
                    Name = subDivision.Name,
                    AccountName = accountName,
                    Type = Constants.RiskQualityRatingNodeType.SubDivisionSingle,
                    SubType = Constants.RiskQualityRatingNodeSubType.Filtered,
                    LpSubDivKey = subDivision.LpSubDivKey,
                    Parent = parentCopyDivision,
                    MyChildren = locationsResultSet.Where(x => x.LpSubDivKey == subDivision.LpSubDivKey && x.HasAccess == 1 && x.IsFiltered == 0).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.My, LpAllPiKey = y.LpAllPiKey, Parent = parentCopySubDivision }).ToList(),
                    FilteredChildren = locationsResultSet.Where(x => x.LpSubDivKey == subDivision.LpSubDivKey && x.HasAccess == 1 && x.IsFiltered == 1).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey, Parent = parentCopySubDivision }).ToList()
                };


                subDivisionNode.AverageAllFilteredChildren = (int)CalculateAverageRiskQualityRatingForLocationList(locationsResultSet.Where(x => x.LpSubDivKey == subDivisionNode.LpSubDivKey && x.HasAccess == 1 && x.IsFiltered == 1).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), averageWeightingMode);
                subDivisionNode.AverageAllMyChildren = (int)CalculateAverageRiskQualityRatingForLocationList(locationsResultSet.Where(x => x.LpSubDivKey == subDivisionNode.LpSubDivKey && x.HasAccess == 1 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), averageWeightingMode);
                subDivisionNode.AverageAllChildren = (int)CalculateAverageRiskQualityRatingForLocationList(locationsResultSet.Where(x => x.LpSubDivKey == subDivisionNode.LpSubDivKey && x.HasAccess == 0 && x.IsFiltered == 0).OrderByDescending(x => x.RiskRating).Select(y => new RiskQualityRatingNode { TIV = y.TIV, AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = parentCopyDivision, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), averageWeightingMode);

                // Calculate "All" Quartiles for this SubDivision
                CalculateQuartilesForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 01 && x.IsFiltered == 0 && x.LpSubDivKey == subDivisionNode.LpSubDivKey).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = subDivisionNode, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), subDivisionNode.AllQuartileData);
                // Calculate My Quartiles for this SubDivision
                CalculateQuartilesForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 0 && x.LpSubDivKey == subDivisionNode.LpSubDivKey).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = subDivisionNode, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), subDivisionNode.MyChildrenQuartileData);
                // Calculate Filtered Quartiles for this SubDivision
                CalculateQuartilesForLocationList(locationsResultSet.Where(x => x.LpAcctWebDivKey == division.LpAcctWebDivKey && x.HasAccess == 1 && x.IsFiltered == 1 && x.LpSubDivKey == subDivisionNode.LpSubDivKey).OrderByDescending(x => x.RiskRating).ThenBy(x => x.Name).Select(y => new RiskQualityRatingNode { AccountName = accountName, Name = y.Name, RatingScore = FormatHelper.FormatRqr(y.RiskRating), Parent = subDivisionNode, Type = Constants.RiskQualityRatingNodeType.LocationSingle, SubType = Constants.RiskQualityRatingNodeSubType.Filtered, LpAllPiKey = y.LpAllPiKey }).ToList(), subDivisionNode.MyFilteredQuartileData);

                division.FilteredChildren.Add(subDivisionNode);
            }
        }


        public void AddDatasetToCustomisableReport(DataTable dataTable, List<RqrLevel4Data> dataSet, List<KeyValuePair<int, string>> userSelectedColumns, bool useLocationNo, string Format)
        {
            foreach (var item in dataSet)
            {
                List<Object> rowData = new List<object>();

                foreach (KeyValuePair<int, string> kvp in userSelectedColumns)
                {
                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_LocationID)
                    {
                        switch (useLocationNo)
                        {
                            case true:
                                rowData.Add(item?.LocationNo);
                                break;
                            case false:
                                rowData.Add(item?.LocationCode);
                                break;
                        }
                    }

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_ClientLocationID)
                        rowData.Add(item?.ClientLocationNo);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_LocationName)
                        rowData.Add(item?.LocationName);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_Division)
                        rowData.Add(item?.DivisionName);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_SubDivision)
                        rowData.Add(item?.SubDivisionName);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_StreetAddress1)
                        rowData.Add(item?.AddressLine1);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_StreetAddress2)
                        rowData.Add(item?.AddressLine2);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_City)
                        rowData.Add(item?.City);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_State)
                        rowData.Add(item?.State);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_Country)
                        rowData.Add(item?.Country);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_TotalPropertyValue)
                    {
                        if (Format != Constants.ExportFormats.Excel)
                            rowData.Add(item?.PDValue?.ToString("N0"));
                        else
                            rowData.Add(item?.PDValue);
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_BusinessInterruptionValue)
                    {
                        if (Format != Constants.ExportFormats.Excel)
                            rowData.Add(item?.BIValue?.ToString("N0"));
                        else
                            rowData.Add(item?.BIValue);
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_TotalInsurableValue)
                    {
                        if (Format != Constants.ExportFormats.Excel)
                            rowData.Add(FormatHelper.FormatCurrency(item?.TotalInsurableValue));
                        else
                            rowData.Add(item?.TotalInsurableValue);
                    }

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_MPL)
                    {
                        if (Format != Constants.ExportFormats.Excel)
                            rowData.Add(FormatHelper.FormatCurrency(item?.FireMFLTotal));
                        else
                            rowData.Add(item?.FireMFLTotal);
                    }

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_NLE)
                    {
                        if (Format != Constants.ExportFormats.Excel)
                            rowData.Add(FormatHelper.FormatCurrency(item?.FireNLETotal));
                        else
                            rowData.Add(item?.FireNLETotal);
                    }

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_NLEoverPML)
                    {
                        if (Format != Constants.ExportFormats.Excel)
                            rowData.Add(item?.NLEoverMPL + "%");
                        else
                            rowData.Add(FormatHelper.NLEoverPML(item?.NLEoverMPL));
                    }

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_OccupancyClassSIC)
                        rowData.Add(item?.OccupancyClassSIC);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_OccupancyClassNACE)
                        rowData.Add(item?.OccupancyClassNACE);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_FireClass)
                        rowData.Add(item?.FireClass);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_CurrentRiskQualityRating)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentRiskQualityRating));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RatingPerContract)
                        rowData.Add(FormatHelper.FormatRqr(item?.RatingPerContract));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingCalculated)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentRQRCalculated));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingValidated)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentRQRValidated));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_Vulnerability)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentLQRVulnerability));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_LQR)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentLQR));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RQI)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentRQI));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_LQI)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentLQI));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_ManagementProgramsQualityRating)
                        rowData.Add(FormatHelper.FormatRqr(item?.ManagementProgramsQualityRatings));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_SprinklerProtectionQualityRating)
                        rowData.Add(FormatHelper.FormatRqr(item?.SprinklerProtectionQualityRating));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_PreEmergencyPlanningRating)
                        rowData.Add(FormatHelper.FormatRqr(item?.PreEmergencyPlanningRating));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_SurveillanceQualityRating)
                        rowData.Add(FormatHelper.FormatRqr(item?.SurveillanceQualityRating));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_OtherProtectionQualityRating)
                        rowData.Add(FormatHelper.FormatRqr(item?.OtherProtectionQualityRating));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_HazardsQualityRating)
                        rowData.Add(FormatHelper.FormatRqr(item?.HazardsQualityRating));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_WaterSupplyQualityRating)
                        rowData.Add(FormatHelper.FormatRqr(item?.WaterSupplyQualityRating));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_HighPileStorageRating)
                        rowData.Add(FormatHelper.FormatRqr(item?.HighPileStorage));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_FireDepartmentRating)
                        rowData.Add(FormatHelper.FormatRqr(item?.FireDepartmentRating));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_PredominantConstructionRating)
                        rowData.Add(FormatHelper.FormatRqr(item?.PredominantConstructionRating));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_BIExposureQualityRating)
                        rowData.Add(FormatHelper.FormatRqr(item?.BIExposureQualityRating));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_PredominantConstruction)
                        rowData.Add(item?.PredominantConstruction);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_FireDepartmentType)
                        rowData.Add(item?.FireDepartmentType);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskManagement)
                        rowData.Add(item?.RiskManagement);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_PassiveProtection)
                        rowData.Add(item?.PassiveProtection);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_OccupancyRelatedHazards)
                        rowData.Add(item?.OccupancyRelatedHazards);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_HumanElement)
                        rowData.Add(item?.HumanElement);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_ActiveProtection)
                        rowData.Add(item?.ActiveProtection);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_Surveillance)
                        rowData.Add(item?.Surveillance);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_ThirdPartyExposure)
                        rowData.Add(item?.ThirdPartyExposure);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_BIExposure)
                        rowData.Add(item?.BIExposure);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_CurrentRiskQualityRating2)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentRiskQualityRating));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofJan1YMinus1)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentRiskQualityRatingPrevYear1));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofJan1YMinus2)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentRiskQualityRatingPrevYear2));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofJan1YMinus3)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentRiskQualityRatingPrevYear3));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofJan1YMinus4)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentRiskQualityRatingPrevYear4));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofJan1YMinus5)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentRiskQualityRatingPrevYear5));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_CurrentRiskQualityRating3)
                        rowData.Add(FormatHelper.FormatRqr(item?.CurrentRiskQualityRating));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_LastSurveyDate)
                    {
                        if (Format != Constants.ExportFormats.Excel)
                            rowData.Add(FormatHelper.FormatDate(item?.LastSurveyDate));
                        else
                        {
                            if (item?.LastSurveyDate.HasValue == true)
                            {
                                rowData.Add(DateTime.ParseExact(FormatHelper.FormatDate(item?.LastSurveyDate), "dd-MMM-yyyy", CultureInfo.CurrentCulture));
                            }
                            else
                                rowData.Add(item?.LastSurveyDate);

                        }

                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofPriorSurvey1)
                        rowData.Add(FormatHelper.FormatRqr(item?.RQRRatingPriorSurvey1Value));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_PriorSurvey1Date)
                    {
                        if (Format != Constants.ExportFormats.Excel)
                            rowData.Add(FormatHelper.FormatDate(item?.RQRRatingPriorSurvey1Date));
                        else
                        {
                            if (item?.RQRRatingPriorSurvey1Date.HasValue == true)
                            {
                                rowData.Add(DateTime.ParseExact(FormatHelper.FormatDate(item?.RQRRatingPriorSurvey1Date), "dd-MMM-yyyy", CultureInfo.CurrentCulture));
                            }
                            else
                                rowData.Add(item?.RQRRatingPriorSurvey1Date);
                        }
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofPriorSurvey2)
                        rowData.Add(FormatHelper.FormatRqr(item?.RQRRatingPriorSurvey2Value));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_PriorSurvey2Date)
                    {
                        if (Format != Constants.ExportFormats.Excel)
                            rowData.Add(FormatHelper.FormatDate(item?.RQRRatingPriorSurvey2Date));
                        else
                        {
                            if (item?.RQRRatingPriorSurvey2Date.HasValue == true)
                            {
                                rowData.Add(DateTime.ParseExact(FormatHelper.FormatDate(item?.RQRRatingPriorSurvey2Date), "dd-MMM-yyyy", CultureInfo.CurrentCulture));
                            }
                            else
                                rowData.Add(item?.RQRRatingPriorSurvey2Date);

                        }
                    }

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofPriorSurvey3)
                        rowData.Add(FormatHelper.FormatRqr(item?.RQRRatingPriorSurvey3Value));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_PriorSurvey3Date)
                    {
                        if (Format != Constants.ExportFormats.Excel)
                            rowData.Add(FormatHelper.FormatDate(item?.RQRRatingPriorSurvey3Date));
                        else
                        {
                            if (item?.RQRRatingPriorSurvey3Date.HasValue == true)
                            {
                                rowData.Add(DateTime.ParseExact(FormatHelper.FormatDate(item?.RQRRatingPriorSurvey3Date), "dd-MMM-yyyy", CultureInfo.CurrentCulture));
                            }
                            else
                                rowData.Add(item?.RQRRatingPriorSurvey3Date);
                        }
                    }

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofPriorSurvey4)
                        rowData.Add(FormatHelper.FormatRqr(item?.RQRRatingPriorSurvey4Value));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_PriorSurvey4Date)
                    {
                        if (Format != Constants.ExportFormats.Excel)
                            rowData.Add(FormatHelper.FormatDate(item?.RQRRatingPriorSurvey4Date));
                        else
                        {
                            if (item?.RQRRatingPriorSurvey4Date.HasValue == true)
                            {
                                rowData.Add(DateTime.ParseExact(FormatHelper.FormatDate(item?.RQRRatingPriorSurvey4Date), "dd-MMM-yyyy", CultureInfo.CurrentCulture));
                            }
                            else
                                rowData.Add(item?.RQRRatingPriorSurvey4Date);
                        }
                    }

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingAsofPriorSurvey5)
                        rowData.Add(FormatHelper.FormatRqr(item?.RQRRatingPriorSurvey5Value));

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_PriorSurvey5Date)
                    {
                        if (Format != Constants.ExportFormats.Excel)
                            rowData.Add(FormatHelper.FormatDate(item?.RQRRatingPriorSurvey5Date));
                        else
                        {
                            if (item?.RQRRatingPriorSurvey5Date.HasValue == true)
                            {
                                rowData.Add(DateTime.ParseExact(FormatHelper.FormatDate(item?.RQRRatingPriorSurvey5Date), "dd-MMM-yyyy", CultureInfo.CurrentCulture));
                            }
                            else
                                rowData.Add(item?.RQRRatingPriorSurvey5Date);
                        }
                    }

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_Comment1)
                        rowData.Add(item?.CommentOne);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_Comment2)
                        rowData.Add(item?.CommentTwo);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_Comment3)
                        rowData.Add(item?.CommentThree);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_SharedComment)
                        rowData.Add(item?.SharedComment);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingWithImpactofCompletedClient)
                        rowData.Add(item?.RiskQualityRatingWithImpactOfCompletedClient);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingswithImpactofALLHE)
                        rowData.Add(item?.RiskQualityRatingWithImpactOfAllHe);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatinsgwithImpactofPhysType_w_EstimatedCost)
                        rowData.Add(item?.RiskQualityRatingWithImpactOfPhysTypeWithEstCost);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_RiskQualityRatingswithImpactofALLHEPhysTypeRecommendationsw_EstimatedCost)
                        rowData.Add(item?.RiskQualityRatingWithImpactOfAllHeAndPhysTypeWithEstCost);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_EstiamtedCosttoAchieveFairRiskQualityRating)
                        rowData.Add(item?.EstCostToAchieveFair);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_EstiamtedCosttoAchieveGoodRiskQualityRating)
                        rowData.Add(item?.EstCostToAchieveGood);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_EstiamtedCosttoAchieveExcellentRiskQualityRating)
                        rowData.Add(item?.EstCostToAchieveExcellent);

                    if (kvp.Key == Constants.SystemGridFieldRef.RiskQualityRatings_ClientRatings)
                        rowData.Add(FormatHelper.FormatRqr(item?.ClientRatings));



                }

                dataTable.Rows.Add(rowData.ToArray());
            }
        }


        public List<LocationRiskQualityRatingGrouped> LoadRiskQualityRatingsDataGrouped(PagingInfo paging, DataFilter dataFilter, int userId, string sortExpression, bool useLocationNo)
        {

            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter != null)
            {
                RiskQualityDbAccess db = new RiskQualityDbAccess();
                using (var ma2DbContext = new MA2DbContext())
                {
                    var qry = db.LoadRiskQualityRatingDataForCurrentFilters(anyLocationsSelectorDataFilter, dataFilter,
                        ma2DbContext);

                    var groupedData = qry
                        .GroupBy(x => new { groupedAddress = x.AccountID, groupedLocation = x.Location, groupedLocationId = x.LocationID })
                        .Select(g => new LocationRiskQualityRatingGrouped
                        {
                            AccountID = g.Key.groupedAddress,
                            LocationID = g.Key.groupedLocationId,
                            LocationNo = g.Key.groupedLocation.LocationNo,
                            LocationCode = g.Key.groupedLocation.LocationCode,
                            Country = g.Key.groupedLocation.Country,
                            City = g.Key.groupedLocation.City,
                            State = g.Key.groupedLocation.State,
                            Address = g.Key.groupedLocation.FullAddress,
                            PropertyValue = g.Key.groupedLocation.LocationValue,
                            PredominantConstruction = g.Key.groupedLocation.PredominantConstructionType.Name,
                            FireDeptType = g.Key.groupedLocation.FireDepartmentType.Name,
                            LocationName = g.Key.groupedLocation.Name,
                            IsValidated = g.Key.groupedLocation.IsValidated,
                            RQR = g.Key.groupedLocation.RqrScore,
                            RQRWeighted = g.Key.groupedLocation.RqrScoreWeighted,
                            LPAllPiKey = g.Key.groupedLocation.LpAllPiKey,
                            Location = g.Key.groupedLocation

                        });

                    if (!string.IsNullOrEmpty(sortExpression))
                    {
                        var sortDescending = !string.IsNullOrEmpty(sortExpression)
                                             && sortExpression.ToLower().Contains("desc");

                        if (sortExpression.Contains("LocationNo") || sortExpression.Contains("LocationGapsOrAxaID") || sortExpression.Contains("LocID"))
                        {
                            if (useLocationNo)
                            {
                                groupedData = sortDescending
                                    ? groupedData.OrderByDescending(x => x.LocationNo)
                                    : groupedData.OrderBy(x => x.LocationNo);
                            }
                            else
                            {
                                groupedData = sortDescending
                                    ? groupedData.OrderByDescending(x => x.LocationCode)
                                    : groupedData.OrderBy(x => x.LocationCode);
                            }

                        }

                        if (sortExpression.Contains("Country"))
                            groupedData = sortDescending
                                      ? groupedData.OrderByDescending(x => x.Country)
                                      : groupedData.OrderBy(x => x.Country);

                        if (sortExpression.Contains("City"))
                            groupedData = sortDescending
                                      ? groupedData.OrderByDescending(x => x.City)
                                      : groupedData.OrderBy(x => x.City);

                        if (sortExpression.Contains("Address"))
                            groupedData = sortDescending
                                      ? groupedData.OrderByDescending(x => x.Address)
                                      : groupedData.OrderBy(x => x.Address);

                        if (sortExpression.Contains("State"))
                            groupedData = sortDescending
                                ? groupedData.OrderByDescending(x => x.State)
                                : groupedData.OrderBy(x => x.State);

                        if (sortExpression.Contains("PropertyValue"))
                            groupedData = sortDescending
                                ? groupedData.OrderByDescending(x => x.PropertyValue)
                                : groupedData.OrderBy(x => x.PropertyValue);

                        if (sortExpression.Contains("PredominantConstruction"))
                            groupedData = sortDescending
                                ? groupedData.OrderByDescending(x => x.PredominantConstruction)
                                : groupedData.OrderBy(x => x.PredominantConstruction);

                        if (sortExpression.Contains("FireDept"))
                            groupedData = sortDescending
                                ? groupedData.OrderByDescending(x => x.FireDeptType)
                                : groupedData.OrderBy(x => x.FireDeptType);

                        if (sortExpression.Equals("Location"))
                            groupedData = sortDescending
                                ? groupedData.OrderByDescending(x => x.LocationName)
                                : groupedData.OrderBy(x => x.LocationName);
                    }

                    if (paging != null)
                    {
                        paging.TotalRecords = groupedData.ToList().Count;
                        return groupedData.ToList().Skip(paging.PageOffset).Take(paging.PageSize).ToList();
                    }
                    else
                    {
                        return groupedData.ToList();
                    }
                }

            }

            return new List<LocationRiskQualityRatingGrouped>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lpAllPiKey"></param>
        /// <returns></returns>
        public List<ViewLocationRiskQualityRatingDetail> GetRiskQualitySummaryDetails(int lpAllPiKey)
        {
            LocationLogic locationLogic = new LocationLogic(this.UserName);
            var locationHasBi = locationLogic.LocationHasBi(lpAllPiKey);
            var location = locationLogic.LoadLocationByLpAllPiKey(lpAllPiKey);

            var qry = Repo.GetAll<ViewLocationRiskQualityRatingDetail>();
            qry = qry.Where(x => lpAllPiKey == x.LpAllPiKey);
            qry = qry.Where(x => x.RiskQualityCategoryID != (int)Constants.RiskQualityCategory.Unknown);
            qry = qry.Where(x => locationHasBi || (!locationHasBi && !x.IsBiCategory));
            qry = qry.Where(x => !x.IsLqrCategory); // TODO - for now just hide our LQR categories
            var result = qry.ToList();

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <param name="lPAcctKey"></param>
        /// <returns></returns>
        public List<RiskQualityRatingBoxPlotQuartileData> LoadTileRiskQualityRatingData(DataFilter dataFilter, int userId, int lPAcctKey)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

            if (anyLocationsSelectorDataFilter != null)
            {
                RiskQualityDbAccess db = new RiskQualityDbAccess();
                return db.LoadTileRiskQualityRatingData(anyLocationsSelectorDataFilter, dataFilter, lPAcctKey, userId);
            }

            return null;
        }


        public List<RiskQualityCategory> GetRiskQualityCategories()
        {
            RiskQualityDbAccess riskQualityDbAccess = new RiskQualityDbAccess();
            return riskQualityDbAccess.GetRiskQualityCategories();
        }

        /// <summary>
        /// Given a list of Locations and Recommendations, return the current calculated RQR and projected RQR (should those Recommendations be implemented)
        /// </summary>
        /// <param name="lPAllPiKeys"></param>
        /// <param name="lPRecKeys"></param>
        /// <returns></returns>
        public List<ProcGetRqrEstimatedEffectForRecommendationsReturnModel> LoadEstimatedRiskQualityRatingImprovement(IEnumerable<int> lPAllPiKeys, IEnumerable<int> lPRecKeys)
        {
            RiskQualityDbAccess riskQualityDbAccess = new RiskQualityDbAccess();
            return riskQualityDbAccess.LoadEstimatedRiskQualityRatingImprovement(lPAllPiKeys, lPRecKeys);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountLevel"></param>
        /// <returns></returns>
        public string LoadAccountTypeDisplayName(AccountLevelEnum accountLevel, int lpAcctKey, int dataFilterId, int userId)
        {
            var result = string.Empty;
            var acctLogic = new AccountLogic();
            var dfLogic = new DataFilterLogic();
            var dashboardLogic = new DashboardLogic();
            var dataFilter = dfLogic.LoadDataFilterById(dataFilterId);

            var divisionSubDivisionLocationKeys = dashboardLogic.LoadDivisionSubDivisionLocationKeysForCurrentFilters(dataFilter, userId);

            switch (accountLevel)
            {
                case AccountLevelEnum.Account:
                    result = acctLogic.GetAccount(lpAcctKey).AccountName;
                    break;
                case AccountLevelEnum.Division:
                    result = divisionSubDivisionLocationKeys.LpAcctWebDivKeys.Count == 0 ?
                        WebPageResources.RiskQualityRatings_Benchmarking_NoDivisions :
                        (divisionSubDivisionLocationKeys.LpAcctWebDivKeys.Count == 1 ?
                        acctLogic.GetDivisionByLpAcctWebDivKey(divisionSubDivisionLocationKeys.LpAcctWebDivKeys.First()).Name :
                        WebPageResources.RiskQualityRatings_Benchmarking_MultipleDivisions);
                    break;
                case AccountLevelEnum.Location:
                    result = divisionSubDivisionLocationKeys.LpAllPiKeys.Count == 0 ?
                        WebPageResources.RiskQualityRatings_Benchmarking_NoLocations :
                        (divisionSubDivisionLocationKeys.LpAllPiKeys.Count == 1 ?
                        acctLogic.GetLocationById(divisionSubDivisionLocationKeys.LpAllPiKeys.First()).Name :
                        WebPageResources.RiskQualityRatings_Benchmarking_MultipleLocations);
                    break;
            }

            return result;
        }


        #endregion

        #region Export
        public DataTable GetDataTableForRiskQualityReport(DataFilter dataFilter, int userId, bool useLocationNo, string sortOrder)
        {

            var datatable = new DataTable();

            datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = @WebPageResources.RiskQualityRatings_Table_LocationID });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = @WebPageResources.RiskQualityRatings_Table_Country });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = @WebPageResources.RiskQualityRatings_Table_City });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field4", Caption = @WebPageResources.RiskQualityRatings_Table_StateProvince });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field5", Caption = @WebPageResources.RiskQualityRatings_Table_Address });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field6", Caption = @WebPageResources.RiskQualityRatings_Table_PropertyValue });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field7", Caption = @WebPageResources.RiskQualityRatings_Table_PredominantConstruction });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field8", Caption = @WebPageResources.RiskQualityRatings_Table_FireDeptType });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field9", Caption = @WebPageResources.RiskQualityRatings_Table_RQR });


            var dataset = LoadRiskQualityRatingsDataGrouped(null, dataFilter, userId, sortOrder, useLocationNo);

            foreach (var item in dataset)
            {
                Object[] O =
                {
                        useLocationNo ? item.LocationNo : item.LocationCode,
                        item.Country,
                        item.City,
                        item.State,
                        FormatHelper.ConvertCharInstancesToCRLFs(item.Address,
                            DbModels.DbConstants.Constants.LocationAddressSeparatorChar, addCommas: true),
                        item.PropertyValue.HasValue
                            ? Regex.Replace(item.PropertyValue.Value.ToString("N0"),
                                @"/\B(?=(\d{3})+(?!\d))/g, ", ",")
                            : string.Empty,
                        item.PredominantConstruction,
                        item.FireDeptType,
                        FormatHelper.FormatRqr((item.IsValidated != null && item.IsValidated.Value)
                            ? item.RQRWeighted * 10
                            : item.RQR * 10)
                    };

                datatable.Rows.Add(O);
            }

            return datatable;
        }

        public DataTable GetDataTableForRiskQualityReportByLocationAndAccount(int lpAllPiKey)
        {
            var datatable = new DataTable();
            datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = @WebPageResources.RiskQualityRatings_Table_RiskType });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = @WebPageResources.RiskQualityRatings_Table_Rating });

            var dataset = GetRiskQualitySummaryDetails(lpAllPiKey);

            foreach (var item in dataset)
            {
                Object[] O =
                {
                    //item.Name, item.Rating.GetValueOrDefault(0) > 0 ? (FormatHelper.FormatRqr(item.Rating ?? 0) * 10).ToString() : "-"
                   item.Name, FormatHelper.FormatRqr((item.Rating ?? 0) * 10)

                 };
                datatable.Rows.Add(O);
            }
            return datatable;
        }

        public List<LocationRiskQualityRating> LoadRiskQualityRatingsData(DataFilter dataFilter, int userId, bool? weightedAverage)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

            if (anyLocationsSelectorDataFilter != null)
            {
                var db = new RiskQualityDbAccess();
                using (var ma2DbContext = new MA2DbContext())
                {
                    var qry = db.LoadRiskQualityRatingDataForCurrentFilters(anyLocationsSelectorDataFilter, dataFilter, ma2DbContext);

                    if (weightedAverage != null && weightedAverage.Value)
                    {
                        return qry.OrderByDescending(x => x.Location.RqrScoreWeighted).ToList();
                    }

                    return qry.OrderByDescending(x => x.Location.RqrScore).ToList();
                }
            }

            return null;
        }



        #region Export FS17 RQR Over Time



        /// <summary>
        /// Given the current criteria, return all the datatables required for the SSRS export
        /// </summary>
        /// <param name="paging"></param>
        /// <param name="selectedRecommendationsOrder"></param>
        /// <param name="addRecommendationsOrder"></param>
        /// <param name="chartOnly"></param>
        /// <param name="columnWidths"></param>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <param name="lpAcctKey"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="displayMode"></param>
        /// <returns></returns>
        public List<DataTable> GetRQROverTimeExport(PagingInfo paging, bool chartOnly, out List<string[]> columnWidths, DataFilter dataFilter, int userId, int lpAcctKey, string formatFromDate, string formatToDate, string displayMode, string sortOrderFrom, string sortOrderTo, string culture)
        {
            var dataTables = new List<DataTable>();

            columnWidths = new List<string[]>
            {
                new[] {"3cm", "3cm"},
                new[] {"3cm", "3cm"},
                new[] {"6cm", "3cm"}
            };

            DateTime dDate;
            var isFormat = DateTime.TryParseExact(formatToDate, "dd/MM/yyyy", CultureInfo.GetCultureInfo(culture), DateTimeStyles.None, out dDate);
            if (!isFormat)
            {
                dDate = DateTime.Now.Date;
            }

            var qr2 = LoadRQROverTimeData(dataFilter, userId, lpAcctKey, dDate);


            // RQR From Date (left grid)
            dataTables.Add(GetRQROverTimeData(paging, chartOnly, dataFilter, userId, qr2, lpAcctKey, displayMode, sortOrderFrom, null));

            // RQR To Date (right grid)
            dataTables.Add(GetRQROverTimeData(paging, chartOnly, dataFilter, userId, qr2, lpAcctKey, displayMode, null, sortOrderTo));


            return dataTables;
        }

        //      public List<LocationRiskQualityRatingHistoryCount> GetLocationRiskQualityRatingHistoryCounts
        //(List<ViewLocationRiskQualityRatingHistory> dataset)
        //      {
        //          var dataBreakdown = new List<LocationRiskQualityRatingHistoryCount>();

        //          if (dataset == null)
        //              return dataBreakdown;

        //          dataBreakdown.Add(new LocationRiskQualityRatingHistoryCount
        //          {

        //              RiskQualityRatingDisplayName = @WebPageResources.Dashboard_RiskRating_Excellent,
        //              RQRRange = "75-100",
        //              LocationCount = dataset.Count(x => x.Rating != null && x.Rating.Value >= (decimal)7.5)

        //          });

        //          dataBreakdown.Add(new LocationRiskQualityRatingHistoryCount
        //          {

        //              RiskQualityRatingDisplayName = @WebPageResources.Dashboard_RiskRating_Good,
        //              RQRRange = "60-74",
        //              LocationCount = dataset.Count(x => x.Rating != null && x.Rating.Value >= (decimal)6.0 && x.Rating.Value <= (decimal)7.4)
        //          });


        //          dataBreakdown.Add(new LocationRiskQualityRatingHistoryCount
        //          {
        //              RiskQualityRatingDisplayName = @WebPageResources.Dashboard_RiskRating_Fair,
        //              RQRRange = "45-59",
        //              LocationCount = dataset.Count(x => x.Rating != null && x.Rating.Value >= (decimal)4.5 && x.Rating.Value <= (decimal)5.9)
        //          });


        //          dataBreakdown.Add(new LocationRiskQualityRatingHistoryCount
        //          {

        //              RiskQualityRatingDisplayName = @WebPageResources.Dashboard_RiskRating_Poor,
        //              RQRRange = "1-44",
        //              LocationCount = dataset.Count(x => x.Rating != null && x.Rating.Value >= (decimal)0.1 && x.Rating.Value <= (decimal)4.4)
        //          });

        //          dataBreakdown.Add(new LocationRiskQualityRatingHistoryCount
        //          {
        //              RiskQualityRatingDisplayName = @WebPageResources.RiskQualityRatings_Table_Total,
        //              LocationCount = dataset.Count
        //          });

        //          return dataBreakdown;
        //      }

        public List<RQROverTimeExportData> GetRQROverTimeData(List<RQROverTimeData> dataset, int lpAcctKey, string displayMode, string sortOrderFrom, string sortOrderTo)
        {
            var riskQualityLogic = new RiskQualityLogic();
            RatingTypesEnum accountRatingType = riskQualityLogic.GetAccountRatingType(lpAcctKey);

            int fromCol = 0;
            int toCol = 0;

            var fromvalues = sortOrderFrom?.Split(',');
            int.TryParse(fromvalues?[0], out fromCol);

            string fromorder = fromvalues?[1];

            var toValues = sortOrderTo?.Split(',');
            int.TryParse(toValues?[0], out toCol);
            string toOrder = toValues?[1];

            var dataBreakdown = (from item in dataset
                                 select new RQROverTimeExportData
                                 {
                                     RatingCategoryIndex = item.RatingCategoryIndex,
                                     RatingCategory = riskQualityLogic.GetRatingCategoryName((RatingCategoriesEnum)item.RatingCategoryIndex,
                                                                                                                  accountRatingType),
                                     LocationCount = item.LocationCount,
                                     LocationCountPerc = item.LocationCountPerc,
                                     TotalTIV = FormatHelper.FormatCurrency(item.TotalTIV),
                                     LocationTIVPerc = item.LocationTIVPerc,
                                 });


            //From Date DataTable

            if (fromorder == "asc" && displayMode == "locationCount")
            {
                switch (fromCol)
                {
                    case 0:
                        dataBreakdown = dataBreakdown.OrderBy(item => item.RatingCategoryIndex)
                                .ToList();
                        break;
                    case 1:
                        dataBreakdown = dataBreakdown.OrderBy(item => item.LocationCount)
                               .ToList();
                        break;
                    case 2:
                        dataBreakdown = dataBreakdown.OrderBy(item => item.LocationCountPerc)
                               .ToList();
                        break;

                }
            }

            if (fromorder == "desc" && displayMode == "locationCount")
            {
                switch (fromCol)
                {
                    case 0:
                        dataBreakdown = dataBreakdown.OrderByDescending(item => item.RatingCategoryIndex)
                                .ToList();
                        break;
                    case 1:
                        dataBreakdown = dataBreakdown.OrderByDescending(item => item.LocationCount)
                               .ToList();
                        break;
                    case 2:
                        dataBreakdown = dataBreakdown.OrderByDescending(item => item.LocationCountPerc)
                               .ToList();
                        break;

                }
            }

            if (fromorder == "asc" && displayMode == "locationTIV")
            {
                switch (fromCol)
                {
                    case 0:
                        dataBreakdown = dataBreakdown.OrderBy(item => item.RatingCategoryIndex)
                                .ToList();
                        break;
                    case 1:
                        dataBreakdown = dataBreakdown.OrderBy(item => item.TotalTIV)
                               .ToList();
                        break;
                    case 2:
                        dataBreakdown = dataBreakdown.OrderBy(item => item.LocationTIVPerc)
                               .ToList();
                        break;

                }
            }

            if (fromorder == "desc" && displayMode == "locationTIV")
            {
                switch (fromCol)
                {
                    case 0:
                        dataBreakdown = dataBreakdown.OrderByDescending(item => item.RatingCategoryIndex)
                                .ToList();
                        break;
                    case 1:
                        dataBreakdown = dataBreakdown.OrderByDescending(item => item.TotalTIV)
                               .ToList();
                        break;
                    case 2:
                        dataBreakdown = dataBreakdown.OrderByDescending(item => item.LocationTIVPerc)
                               .ToList();
                        break;

                }
            }


            //To Date DataTable

            if (toOrder == "asc" && displayMode == "locationCount")
            {
                switch (toCol)
                {
                    case 0:
                        dataBreakdown = dataBreakdown.OrderBy(item => item.RatingCategoryIndex)
                                .ToList();
                        break;
                    case 1:
                        dataBreakdown = dataBreakdown.OrderBy(item => item.LocationCount)
                               .ToList();
                        break;
                    case 2:
                        dataBreakdown = dataBreakdown.OrderBy(item => item.LocationCountPerc)
                               .ToList();
                        break;

                }
            }

            if (toOrder == "desc" && displayMode == "locationCount")
            {
                switch (toCol)
                {
                    case 0:
                        dataBreakdown = dataBreakdown.OrderByDescending(item => item.RatingCategoryIndex)
                                .ToList();
                        break;
                    case 1:
                        dataBreakdown = dataBreakdown.OrderByDescending(item => item.LocationCount)
                               .ToList();
                        break;
                    case 2:
                        dataBreakdown = dataBreakdown.OrderByDescending(item => item.LocationCountPerc)
                               .ToList();
                        break;

                }
            }

            if (toOrder == "asc" && displayMode == "locationTIV")
            {
                switch (toCol)
                {
                    case 0:
                        dataBreakdown = dataBreakdown.OrderBy(item => item.RatingCategoryIndex)
                                .ToList();
                        break;
                    case 1:
                        dataBreakdown = dataBreakdown.OrderBy(item => item.TotalTIV)
                               .ToList();
                        break;
                    case 2:
                        dataBreakdown = dataBreakdown.OrderBy(item => item.LocationTIVPerc)
                               .ToList();
                        break;

                }
            }

            if (toOrder == "desc" && displayMode == "locationTIV")
            {
                switch (toCol)
                {
                    case 0:
                        dataBreakdown = dataBreakdown.OrderByDescending(item => item.RatingCategoryIndex)
                                .ToList();
                        break;
                    case 1:
                        dataBreakdown = dataBreakdown.OrderByDescending(item => item.TotalTIV)
                               .ToList();
                        break;
                    case 2:
                        dataBreakdown = dataBreakdown.OrderByDescending(item => item.LocationTIVPerc)
                               .ToList();
                        break;

                }

            }

            return dataBreakdown.ToList();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="paging"></param>
        /// <param name="filters"></param>
        /// <param name="chartOnly"></param>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <param name="lpAcctKey"></param>
        /// <param name="displayMode"></param>
        /// <param name="sortOrderFrom"></param>
        /// <param name="sortOrderTo"></param>
        /// <returns></returns>
        ///
        /// 
        public DataTable GetRQROverTimeData(PagingInfo paging, bool chartOnly, DataFilter dataFilter, int userId, List<RQROverTimeData> fromResults, int lpAcctKey, string displayMode, string sortOrderFrom, string sortOrderTo)
        {
            var riskQualityLogic = new RiskQualityLogic();
            if (chartOnly)
                return new DataTable();

            // TODO - Localise
            var datatable = new DataTable();

            if (displayMode == "locationCount")
            {
                datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = "Rating Category" });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = "Count" });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = "%" });
            }
            else
            {
                datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = "Rating Category" });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = "TIV" });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = "%" });

            }

            var dataSet = GetRQROverTimeData(fromResults, lpAcctKey, displayMode, sortOrderFrom, sortOrderTo);

            foreach (var item in dataSet)
            {
                RatingTypesEnum accountRatingType = GetAccountRatingType(lpAcctKey);


                if (sortOrderFrom != null)
                {
                    if (displayMode == "locationCount")
                    {
                        item.RatingCategory = GetRatingCategoryName((RatingCategoriesEnum)item.RatingCategoryIndex, accountRatingType);
                        datatable.Rows.Add(new object[]
                        {
                           item.RatingCategory, item.LocationCount, item.LocationCountPerc
                        });

                    }

                    else
                    {
                        item.RatingCategory = GetRatingCategoryName((RatingCategoriesEnum)item.RatingCategoryIndex, accountRatingType);
                        datatable.Rows.Add(new object[]
                        {
                                   item.RatingCategory, item.TotalTIV, item.LocationTIVPerc
                        });
                    }
                }

                if (sortOrderTo != null)
                {
                    if (displayMode == "locationCount")
                    {
                        item.RatingCategory = GetRatingCategoryName((RatingCategoriesEnum)item.RatingCategoryIndex, accountRatingType);
                        datatable.Rows.Add(new object[]
                        {
                           item.RatingCategory, item.LocationCount, item.LocationCountPerc
                        });

                    }

                    else
                    {
                        item.RatingCategory = GetRatingCategoryName((RatingCategoriesEnum)item.RatingCategoryIndex, accountRatingType);
                        datatable.Rows.Add(new object[]
                        {
                                   item.RatingCategory, item.TotalTIV, item.LocationTIVPerc
                        });
                    }

                }





            }

            return datatable;

        }






        //public DataTable GetRQROverTimeLocationCount(PagingInfo paging, bool chartOnly, DataFilter dataFilter, int userId, List<ViewLocationRiskQualityRatingHistory> fromResults, List<ViewLocationRiskQualityRatingHistory> toResults)
        //{
        //    if (chartOnly)
        //        return new DataTable();

        //    // TODO - Localise
        //    var datatable = new DataTable();
        //    datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = "Total Locations Added (First Survey Only)" });
        //    datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = "Count" });


        //    var addedLocations = toResults.Where(x => !fromResults.Any(z => z.LocationID == x.LocationID));

        //    var dataSet = GetLocationRiskQualityRatingHistoryCounts(addedLocations.ToList());


        //    foreach (var item in dataSet)
        //    {
        //        datatable.Rows.Add(new object[]
        //        {
        //            item.RiskQualityRatingDisplayName, item.LocationCount
        //        });
        //    }

        //    return datatable;

        //}


        #endregion


        #endregion
    }
}

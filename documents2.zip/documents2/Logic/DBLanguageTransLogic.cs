﻿using Serialize.Linq.Serializers;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using XLC.MyAnalysis2.DbAccess;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.DbModels.DbEnums;
using XLC.MyAnalysis2.Logic.DTO;
using System.Transactions;
using static XLC.MyAnalysis2.DbModels.DbConstants.Constants;
using static XLC.MyAnalysis2.Shared.FormatHelper;
using XLC.MyAnalysis2.Shared;
using XLC.MyAnalysis2.DbAccess.DTO;


namespace XLC.MyAnalysis2.Logic
{
    public class DBLanguageTransLogic : BaseLogic
    {
        private string _userName;

        public DBLanguageTransLogic()
        {
        }

        public DBLanguageTransLogic(string userName)
        {
            this._userName = userName;
        }

        /// <summary>
        /// Load all filters
        /// </summary>
        /// <returns></returns>
        public List<DbLanguageTable> LoadLanguageTables()
        {
            DBLanguageTransAccess db = new DBLanguageTransAccess(_userName);
            return db.LoadLanguageTables();
        }

        public bool Upsert(List<LanguageDBData> objTranslationList, string TableName, string DestTableName, string sKeyName, string EntityColName, string destColumnName)
        {
            DBLanguageTransAccess db = new DBLanguageTransAccess(_userName);
            return db.Upsert(objTranslationList, TableName, DestTableName, sKeyName, EntityColName, destColumnName);
        }

        public List<LanguageDBResult> LoadTranslationforTable(string srcTablename, string destTablename, string srckey, string destkey, string srcColumn, string destColumn)
        {
            DBLanguageTransAccess db = new DBLanguageTransAccess(_userName);
            var result = db.LoadTranslationforTable(srcTablename, destTablename, srckey, destkey, srcColumn, destColumn).Where(x => x.LCID != null).ToList();

            var res = new List<LanguageDBResult>();

            if (result != null)
            {

                for (int i = 0; i < result.Count; i++)
                {
                    if (res.Any(y => y.SourceId == result[i].SourceID))
                    {
                        if (result[i].LCID == LanguageLCID.French)
                        {
                            var obj = res.FirstOrDefault(x => x.SourceId == result[i].SourceID);

                            obj.objfrdata.LCID = LanguageLCID.French;
                            obj.objfrdata.LanguageName = HtmlDecode(result[i].DestName);
                            obj.objfrdata.SourceKey = result[i].Sourcekey;
                            obj.objfrdata.RowVersion = result[i].RowVersion;
                            obj.objfrdata.Sourcekey1 = !string.IsNullOrEmpty(result[i].Sourcekey1) ? result[i].Sourcekey1.TrimEnd() : string.Empty;
                        }
                        else if (result[i].LCID == LanguageLCID.Spanish)
                        {
                            var obj = res.FirstOrDefault(x => x.SourceId == result[i].SourceID);

                            obj.objSpdata.LCID = LanguageLCID.Spanish;
                            obj.objSpdata.LanguageName = HtmlDecode(result[i].DestName);
                            obj.objSpdata.SourceKey = result[i].Sourcekey;
                            obj.objSpdata.RowVersion = result[i].RowVersion;
                            obj.objSpdata.Sourcekey1 = !string.IsNullOrEmpty(result[i].Sourcekey1) ? result[i].Sourcekey1.TrimEnd() : string.Empty;
                        }
                        else if (result[i].LCID == LanguageLCID.English)
                        {
                            var obj = res.FirstOrDefault(x => x.SourceId == result[i].SourceID);

                            obj.objEndata.LCID = LanguageLCID.English;
                            obj.objEndata.LanguageName = result[i].DestName == null ? HtmlDecode(result[i].SourceName) : HtmlDecode(result[i].DestName);
                            obj.objEndata.SourceKey = result[i].Sourcekey;
                            obj.objEndata.RowVersion = result[i].RowVersion;
                            obj.objEndata.Sourcekey1 = !string.IsNullOrEmpty(result[i].Sourcekey1) ? result[i].Sourcekey1.TrimEnd() : string.Empty;
                        }
                        else if (result[i].LCID == LanguageLCID.German)
                        {
                            var obj = res.FirstOrDefault(x => x.SourceId == result[i].SourceID);

                            obj.objGedata.LCID = LanguageLCID.German;
                            obj.objGedata.LanguageName = HtmlDecode(result[i].DestName);
                            obj.objGedata.SourceKey = result[i].Sourcekey;
                            obj.objGedata.RowVersion = result[i].RowVersion;
                            obj.objGedata.Sourcekey1 = !string.IsNullOrEmpty(result[i].Sourcekey1) ? result[i].Sourcekey1.TrimEnd() : string.Empty;
                        }
                        else if (result[i].LCID == LanguageLCID.Italian)
                        {
                            var obj = res.FirstOrDefault(x => x.SourceId == result[i].SourceID);

                            obj.objItdata.LCID = LanguageLCID.Italian;
                            obj.objItdata.LanguageName = HtmlDecode(result[i].DestName);
                            obj.objItdata.SourceKey = result[i].Sourcekey;
                            obj.objItdata.RowVersion = result[i].RowVersion;
                            obj.objItdata.Sourcekey1 = !string.IsNullOrEmpty(result[i].Sourcekey1) ? result[i].Sourcekey1.TrimEnd() : string.Empty;
                        }
                        else if (result[i].LCID == LanguageLCID.Portuguese)
                        {
                            var obj = res.FirstOrDefault(x => x.SourceId == result[i].SourceID);

                            obj.objPedata.LCID = LanguageLCID.Portuguese;
                            obj.objPedata.LanguageName = HtmlDecode(result[i].DestName);
                            obj.objPedata.SourceKey = result[i].Sourcekey;
                            obj.objPedata.RowVersion = result[i].RowVersion;
                            obj.objPedata.Sourcekey1 = !string.IsNullOrEmpty(result[i].Sourcekey1) ? result[i].Sourcekey1.TrimEnd() : string.Empty;
                        }
                    }
                    else
                    {

                        LanguageDBData objEn = new LanguageDBData();
                        LanguageDBData objPr = new LanguageDBData();
                        LanguageDBData objGe = new LanguageDBData();
                        LanguageDBData objFr = new LanguageDBData();
                        LanguageDBData objSp = new LanguageDBData();
                        LanguageDBData objIt = new LanguageDBData();



                        if (result[i].LCID == LanguageLCID.French)
                        {
                            // objFr.SourceKey = result[i].DestId;
                            objFr.LanguageName = HtmlDecode(result[i].DestName);
                            objFr.LCID = LanguageLCID.French;
                        }
                        else if (result[i].LCID == LanguageLCID.English)
                        {
                            // objEn.SourceKey = result[i].DestId;
                            objEn.LanguageName = result[i].DestName == null ? HtmlDecode(result[i].SourceName) : HtmlDecode(result[i].DestName);
                            objEn.LCID = LanguageLCID.English;
                        }
                        else if (result[i].LCID == LanguageLCID.German)
                        {
                            // objGe.SourceKey = result[i].DestId;
                            objGe.LanguageName = HtmlDecode(result[i].DestName);
                            objGe.LCID = LanguageLCID.German;
                        }
                        else if (result[i].LCID == LanguageLCID.Italian)
                        {
                            // objIt.SourceKey = result[i].DestId;
                            objIt.LanguageName = HtmlDecode(result[i].DestName);
                            objIt.LCID = LanguageLCID.Italian;
                        }
                        else if (result[i].LCID == LanguageLCID.Portuguese)
                        {
                            // objPr.SourceKey = result[i].DestId;
                            objPr.LanguageName = HtmlDecode(result[i].DestName);
                            objPr.LCID = LanguageLCID.Portuguese;
                        }
                        else if (result[i].LCID == LanguageLCID.Spanish)
                        {
                            // objSp.SourceKey = result[i].DestId;
                            objSp.LanguageName = HtmlDecode(result[i].DestName);
                            objSp.LCID = LanguageLCID.Spanish;
                        }

                        objEn.SourceKey = result[i].Sourcekey;
                        objFr.SourceKey = result[i].Sourcekey;
                        objGe.SourceKey = result[i].Sourcekey;
                        objIt.SourceKey = result[i].Sourcekey;
                        objPr.SourceKey = result[i].Sourcekey;
                        objSp.SourceKey = result[i].Sourcekey;

                        objEn.Sourcekey1 = !string.IsNullOrEmpty(result[i].Sourcekey1) ? result[i].Sourcekey1.TrimEnd() : string.Empty;
                        objFr.Sourcekey1 = !string.IsNullOrEmpty(result[i].Sourcekey1) ? result[i].Sourcekey1.TrimEnd() : string.Empty;
                        objGe.Sourcekey1 = !string.IsNullOrEmpty(result[i].Sourcekey1) ? result[i].Sourcekey1.TrimEnd() : string.Empty;
                        objIt.Sourcekey1 = !string.IsNullOrEmpty(result[i].Sourcekey1) ? result[i].Sourcekey1.TrimEnd() : string.Empty;
                        objPr.Sourcekey1 = !string.IsNullOrEmpty(result[i].Sourcekey1) ? result[i].Sourcekey1.TrimEnd() : string.Empty;
                        objSp.Sourcekey1 = !string.IsNullOrEmpty(result[i].Sourcekey1) ? result[i].Sourcekey1.TrimEnd() : string.Empty;

                        res.Add(new LanguageDBResult
                        {
                            SourceId = result[i].SourceID,
                            objEndata = objEn,
                            objPedata = objPr,
                            objGedata = objGe,
                            objfrdata = objFr,
                            objItdata = objIt,
                            objSpdata = objSp

                        });
                    }
                }
            }

            return res;
        }
    }
}
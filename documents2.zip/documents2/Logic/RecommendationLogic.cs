﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Messaging;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using OfficeOpenXml;
using XLC.MyAnalysis2.DbAccess;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.Logic.DTO;
using XLC.MyAnalysis2.Resources;
using XLC.MyAnalysis2.Shared;
using XLC.MyAnalysis2.WebPortal.Helpers;
using System.Text.RegularExpressions;
using System.Drawing;
using OfficeOpenXml.Style;
using Serialize.Linq.Extensions;
using System.Globalization;

namespace XLC.MyAnalysis2.Logic
{
    public class RecommendationLogic : BaseLogic
    {
        protected DataRepository Repo = new DataRepository();



        #region Load

        public List<Recommendation> LoadRecommendationByAccount(int accountID)
        {
            var qry = Repo.GetAll<Recommendation>();
            qry = qry.Where(x => accountID == x.AccountID);
            return qry.ToList();
        }

        public Recommendation GetRecommendation(int id)
        {
            return Repo.GetAll<Recommendation>().SingleOrDefault(x => x.ID == id);
        }

        public List<DashboardRecommendationByStatusData> LoadRecommendationByAccountAndLocation(int lpAllPiKey, int userId, DataFilter dataFilter)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            var series = new List<object>();

            if (anyLocationsSelectorDataFilter != null)
            {
                RecommendationDbAccess db = new RecommendationDbAccess();
                return db.LoadTileRecommendationByStatusData(anyLocationsSelectorDataFilter, dataFilter, lpAllPiKey);
            }

            return null;
        }

        public List<Recommendation> LoadRecommendationsDataForExport(DataFilter dataFilter, int userId, List<int> recIds, bool? useLocationNo, string sortExpression, int lpAcctKey)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

            if (anyLocationsSelectorDataFilter != null)
            {
                RecommendationDbAccess db = new RecommendationDbAccess();
                using (var ma2DbContext = new MA2DbContext())
                {
                    var qry = db.LoadRecommendationDataForCurrentFilters(anyLocationsSelectorDataFilter, dataFilter, ma2DbContext);

                    if (recIds != null && recIds.Count > 0)
                    {
                        qry = qry.Where(x => recIds.Contains(x.LpRecKey) && x.LpAcctKey == lpAcctKey);
                    }

                    // Sort expression
                    if (!string.IsNullOrEmpty(sortExpression))
                    {

                        var sortDescending = !string.IsNullOrEmpty(sortExpression)
                                             && sortExpression.ToLower().EndsWith(" desc");


                        sortExpression = sortExpression.Replace(" desc", "").Replace(" asc", "").Replace(",desc", "")
                            .Replace(",asc", "").Replace(" ", "");

                        if (sortExpression.Contains("LocID"))
                        {
                            switch (useLocationNo)
                            {
                                case true:
                                    qry = sortDescending
                                        ? qry.OrderByDescending(x => x.Location.LocationNo)
                                        : qry.OrderBy(x => x.Location.LocationNo);
                                    break;
                                case false:
                                    qry = sortDescending
                                        ? qry.OrderByDescending(x => x.Location.LocationCode)
                                        : qry.OrderBy(x => x.Location.LocationCode);
                                    break;
                            }
                        }


                        if (sortExpression.Contains("Country"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.Location.Country)
                                      : qry.OrderBy(x => x.Location.Country);

                        if (sortExpression.Contains("City"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.Location.City)
                                      : qry.OrderBy(x => x.Location.City);

                        if (sortExpression.Contains("Address"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.Location.Country).ThenByDescending(x => x.Location.City).ThenByDescending(x => x.Location.FullAddress)
                                      : qry.OrderBy(x => x.Location.Country).ThenBy(x => x.Location.City).ThenBy(x => x.Location.FullAddress);

                        if (sortExpression.Contains("RecID"))
                            qry = sortDescending ? qry.OrderByDescending(x => x.RecID) : qry.OrderBy(x => x.RecID);

                        if (sortExpression.Contains("RecType"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.RecommendationType.Name)
                                      : qry.OrderBy(x => x.RecommendationType.Name);

                        if (sortExpression.Contains("Status"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.RecommendationStatu.Name)
                                      : qry.OrderBy(x => x.RecommendationStatu.Name);

                        if (sortExpression.Contains("IssuedDate"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.IssuedDate)
                                      : qry.OrderBy(x => x.IssuedDate);

                        if (sortExpression.Contains("EstCost"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.EstCostToComplete)
                                      : qry.OrderBy(x => x.EstCostToComplete);

                        if (sortExpression.Contains("TargetDate"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.TargetDate)
                                      : qry.OrderBy(x => x.TargetDate);


                        if (sortExpression.Contains("Completed"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.CompletedDate)
                                      : qry.OrderBy(x => x.CompletedDate);

                    }

                    return qry.ToList();
                }

            }

            return null;
        }

        public List<Document> LoadUploadHistory(int lpRecKey, int lpAllPiKey)
        {
            var db = new RecommendationDbAccess();
            return db.LoadUploadHistory(lpRecKey, lpAllPiKey);
        }

        public List<Recommendation> LoadRecommendationsData(PagingInfo paging, DataFilter dataFilter, int userId, RecommendationFilters filters, string sortExpression, bool useLocationNo, int lpAcctKey)
        {
            IQueryable<Recommendation> qry = null;
            using (var ma2DbContext = new MA2DbContext())
            {
                RecommendationDbAccess db = new RecommendationDbAccess();

                if (filters.LocationId.HasValue && filters.LocationId > 0)
                {

                    qry = db.LoadRecommendationsByLocationId(filters.LocationId.Value, ma2DbContext);
                }
                else
                {
                    var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

                    if (anyLocationsSelectorDataFilter != null)
                    {
                        {
                            qry = db.LoadRecommendationDataForCurrentFilters(
                                anyLocationsSelectorDataFilter,
                                dataFilter,
                                ma2DbContext);
                        }
                    }
                }

                if (qry != null)
                {


                    if (filters != null && filters.SelectedRecommendationIDs != null &&
                        filters.SelectedRecommendationIDs.Count > 0)
                    {
                        qry = qry.Where(x => filters.SelectedRecommendationIDs.Contains(x.LpRecKey) && x.LpAcctKey == lpAcctKey);
                    }


                    if (filters != null && filters.RecommendationTypesFilter != null
                                        && filters.RecommendationTypesFilter.Count > 0)
                    {
                        qry = qry.Where(
                            x => x.RecommendationTypeID != null
                                 && filters.RecommendationTypesFilter.Contains(x.RecommendationTypeID.Value));
                    }

                    if (filters != null && filters.RecommendationStatusesFilter != null
                                        && filters.RecommendationStatusesFilter.Count > 0)
                    {
                        qry = qry.Where(
                            x => filters.RecommendationStatusesFilter.Contains(x.RecommendationStatusID));
                    }

                    if (filters != null && filters.CategoryFilter != null && filters.CategoryFilter.Count > 0)
                    {
                        qry = qry.Where(
                            x => filters.CategoryFilter.Contains(x.RecommendationType.RiskQualityCategoryID));
                    }
                    paging.TotalRecords = qry.Count();

                    if (!string.IsNullOrEmpty(sortExpression))
                    {
                        var sortDescending = !string.IsNullOrEmpty(sortExpression)
                                             && sortExpression.ToLower().Contains("desc");


                        if (sortExpression.Contains("LocationGapsOrAxaID") || sortExpression.Contains("LocID"))
                        {
                            switch (useLocationNo)
                            {
                                case true:
                                    qry = sortDescending
                                        ? qry.OrderByDescending(x => x.Location.LocationNo)
                                        : qry.OrderBy(x => x.Location.LocationNo);
                                    break;
                                case false:
                                    qry = sortDescending
                                        ? qry.OrderByDescending(x => x.Location.LocationCode)
                                        : qry.OrderBy(x => x.Location.LocationCode);
                                    break;
                            }
                        }


                        if (sortExpression.Contains("Country"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.Location.Country)
                                      : qry.OrderBy(x => x.Location.Country);

                        if (sortExpression.Contains("City"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.Location.City)
                                      : qry.OrderBy(x => x.Location.City);

                        if (sortExpression.Contains("Address"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.Location.Country).ThenByDescending(x => x.Location.City).ThenByDescending(x => x.Location.FullAddress)
                                      : qry.OrderBy(x => x.Location.Country).ThenBy(x => x.Location.City).ThenBy(x => x.Location.FullAddress);

                        if (sortExpression.Contains("RecID"))
                            qry = sortDescending ? qry.OrderByDescending(x => x.RecID) : qry.OrderBy(x => x.RecID);

                        if (sortExpression.Contains("RecType"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.RecommendationType.Name)
                                      : qry.OrderBy(x => x.RecommendationType.Name);

                        if (sortExpression.Contains("Status"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.RecommendationStatu.Name)
                                      : qry.OrderBy(x => x.RecommendationStatu.Name);

                        if (sortExpression.Contains("IssuedDate"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.IssuedDate)
                                      : qry.OrderBy(x => x.IssuedDate);

                        if (sortExpression.Contains("EstCostToCompleteFormatted") || sortExpression.Contains("EstCost"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.EstCostToComplete).ThenByDescending(x => x.LpRecKey)
                                      : qry.OrderBy(x => x.EstCostToComplete).ThenBy(x => x.LpRecKey);

                        if (sortExpression.Contains("TargetDate"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.TargetDate)
                                      : qry.OrderBy(x => x.TargetDate);


                        if (sortExpression.Contains("CompletedDate") || sortExpression.Contains("Completed"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.CompletedDate)
                                      : qry.OrderBy(x => x.CompletedDate);

                        if (sortExpression.Contains("State"))
                            qry = sortDescending
                                      ? qry.OrderByDescending(x => x.Location.State)
                                      : qry.OrderBy(x => x.Location.State);

                    }
                    else
                    {
                        qry = qry.OrderBy(x => x.LocationID);
                    }

                    return qry.Skip(paging.PageOffset).Take(paging.PageSize).ToList();
                }
            }

            return new List<Recommendation>(); // return empty response
        }

        public List<RecommendationSummaryCategory> LoadDashboardRecommendationSummaryData(DataFilter dataFilter, int lpAcctKey, RecommendationFilters filters, int userId, string displayMode, string sortOrder)
        {

            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter == null) return null;

            var refLogic = new ReferenceListLogic();
            var results = new List<RecommendationSummaryCategory>();

            var recommendationResponses = refLogic.GetRecommendationResponseStatuses();
            var implementationStatuses = refLogic.GetRecommendationStatuses();
            var overallRecommendationStatuses = refLogic.GetOverallRecommendationStatus();

            implementationStatuses.RemoveAll(x => x.ID == Constants.RecommendationStatus.Unknown);
            overallRecommendationStatuses.RemoveAll(x => x.ID == Constants.OverallRecommendationStatus.Active);

            // append pseudo statuses
            implementationStatuses.Add(new RecommendationStatu
            {
                Name = overallRecommendationStatuses.Single(x => x.ID == Constants.OverallRecommendationStatus.NoPlansOrDisagreeValidated).Name,
                ID = Constants.RecommendationStatus.NoPlansOrDisagreeValidated
            });

            recommendationResponses.Add(new RecommendationResponseStatu
            {
                Name = overallRecommendationStatuses.Single(x => x.ID == Constants.OverallRecommendationStatus.VerifiedComplete).Name,
                ID = Constants.RecommendationResponseStatus.VerifiedComplete,
                Active = true
            });

            recommendationResponses.Add(new RecommendationResponseStatu
            {
                Name = overallRecommendationStatuses.Single(x => x.ID == Constants.OverallRecommendationStatus.NoPlansOrDisagreeValidated).Name,
                ID = Constants.RecommendationResponseStatus.NoPlansOrDisagree,
                Active = true
            });

            recommendationResponses.Add(new RecommendationResponseStatu
            {
                Name = implementationStatuses.Single(x => x.ID == Constants.RecommendationStatus.CompletedClient).Name,
                ID = Constants.RecommendationResponseStatus.CompletedClient,
                Active = true
            });


            var db = new RecommendationDbAccess();

            switch (displayMode)
            {
                case Constants.RecommendationSummaryDisplayModes.RecommendationSummary_ImplementationStatus:

                    var impData = db.LoadRecommendationsByImplementationStatus(anyLocationsSelectorDataFilter, dataFilter, filters, lpAcctKey);
                    impData.RemoveAll(x => x.RecommendationStatusID == Constants.RecommendationStatus.Unknown);


                    foreach (var impStatus in implementationStatuses)
                    {
                        var dbResult = impData.SingleOrDefault(x => x.RecommendationStatusID == impStatus.ID);
                        results.Add(new RecommendationSummaryCategory
                        {
                            ID = impStatus.ID,
                            Name = impStatus.Name,
                            Count = (dbResult != null) ? dbResult.Count ?? 0 : 0,
                            Color = MapImplementationStatusToColour(impStatus.ID),
                            IsActive = (impStatus.ID != Constants.RecommendationStatus.VerifiedComplete && impStatus.ID != Constants.RecommendationStatus.NoPlansOrDisagreeValidated)
                        });
                    }
                    break;
                case Constants.RecommendationSummaryDisplayModes.RecommendationSummary_RecommendationStatus:

                    var recData = db.LoadRecommendationsByRecommendationStatus(anyLocationsSelectorDataFilter, dataFilter, filters, lpAcctKey);

                    foreach (var status in overallRecommendationStatuses)
                    {
                        var dbResult = recData.SingleOrDefault(x => x.OverallRecommendationStatus == status.ID);
                        results.Add(new RecommendationSummaryCategory
                        {
                            ID = status.ID,
                            Name = status.Name,
                            Count = (dbResult != null) ? dbResult.Count ?? 0 : 0,
                            Color = MapOverallRecommendationStatusToColour(status.ID)
                        });
                    }

                    var activeExcludingCompletedClient = recData.SingleOrDefault(x => x.OverallRecommendationStatus == Constants.OverallRecommendationStatus.ActiveExcludingCompletedClient);
                    var completedClientActive = recData.SingleOrDefault(x => x.OverallRecommendationStatus == Constants.OverallRecommendationStatus.CompletedClientActive);

                    // add the "split" Active categories
                    results.Add(new RecommendationSummaryCategory
                    {
                        ID = 0,
                        Name = WebPageResources.Dashboard_RecStatusSummary_ActiveExcludingCompletedClient,
                        Count = (activeExcludingCompletedClient != null) ? activeExcludingCompletedClient.Count ?? 0 : 0,
                        Color = MapOverallRecommendationStatusToColour(Constants.OverallRecommendationStatus.ActiveExcludingCompletedClient)
                    });

                    results.Add(new RecommendationSummaryCategory
                    {
                        ID = 1,
                        Name = WebPageResources.Dashboard_RecStatusSummary_CompletedClientActive,
                        Count = (completedClientActive != null) ? completedClientActive.Count ?? 0 : 0,
                        Color = MapOverallRecommendationStatusToColour(Constants.OverallRecommendationStatus.CompletedClientActive)
                    });

                    break;

                case Constants.RecommendationSummaryDisplayModes.RecommendationSummary_ResponseStatus:

                    var resData = db.LoadRecommendationsByResponseStatus(anyLocationsSelectorDataFilter, dataFilter, filters, lpAcctKey);

                    var inactiveResponseStatuses = recommendationResponses.Where(x => !x.Active).ToList().Select(y => y.ID);

                    recommendationResponses.RemoveAll(x => inactiveResponseStatuses.Contains(x.ID));
                    // resData.RemoveAll(x => inactiveResponseStatuses.Contains(x.RecommendationResponseStatusID));

                    foreach (var responseStatus in recommendationResponses)
                    {
                        var dbResult = resData.SingleOrDefault(x => x.RecommendationResponseStatusID == responseStatus.ID);

                        results.Add(new RecommendationSummaryCategory
                        {
                            ID = responseStatus.ID,
                            Name = responseStatus.Name,
                            Count = (dbResult != null) ? dbResult.Count ?? 0 : 0,
                            Color = MapRecommendationResponseStatusToColour(responseStatus.ID)
                        });
                    }

                    break;
            }

            double resultsTotal = (double)results.Sum(x => x.Count);

            if (resultsTotal > 0) // prevent divide by zero exception
            {
                foreach (var result in results)
                {
                    result.Percentage = Math.Round((result.Count / resultsTotal) * 100, 0, MidpointRounding.AwayFromZero);
                }
            }

            if (!String.IsNullOrEmpty(sortOrder))
            {
                var desc = sortOrder.ToLower().Contains("desc") && !sortOrder.ToLower().StartsWith("desc");
                if (sortOrder.Contains("Name"))
                    results = desc
                        ? results.OrderByDescending(x => x.Name).ToList()
                        : results.OrderBy(x => x.Name).ToList();

                if (sortOrder.Contains("Count"))
                    results = desc
                        ? results.OrderByDescending(x => x.Count).ToList()
                        : results.OrderBy(x => x.Count).ToList();

                if (sortOrder.Contains("Percentage"))
                    results = desc
                        ? results.OrderByDescending(x => x.Percentage).ToList()
                        : results.OrderBy(x => x.Percentage).ToList();

                return results;
            }

            else

            {

                switch (displayMode)
                {
                    case Constants.RecommendationSummaryDisplayModes.RecommendationSummary_RecommendationStatus:
                        {
                            string[] overallStatusesOrder =
                            {
                                overallRecommendationStatuses.Single(x => x.ID == Constants.OverallRecommendationStatus.VerifiedComplete).Name,
                                WebPageResources.Dashboard_RecStatusSummary_CompletedClientActive,
                                WebPageResources.Dashboard_RecStatusSummary_ActiveExcludingCompletedClient,
                                overallRecommendationStatuses.Single(x => x.ID == Constants.OverallRecommendationStatus.NoPlansOrDisagreeValidated).Name
                            };
                            return results.OrderBy(x => Array.IndexOf(overallStatusesOrder, x.Name)).ToList();
                        }

                    case Constants.RecommendationSummaryDisplayModes.RecommendationSummary_ImplementationStatus:

                        string[] implementationStatusesOrder =
                        {
                            implementationStatuses.Single(x => x.ID == Constants.RecommendationStatus.VerifiedComplete).Name,
                            implementationStatuses.Single(x => x.ID == Constants.RecommendationStatus.CompletedClient).Name,
                            implementationStatuses.Single(x => x.ID == Constants.RecommendationStatus.InProgress).Name,
                            implementationStatuses.Single(x => x.ID == Constants.RecommendationStatus.UnderReview).Name,
                            implementationStatuses.Single(x => x.ID == Constants.RecommendationStatus.NoPlansOrDisagree).Name,
                            implementationStatuses.Single(x => x.ID == Constants.RecommendationStatus.AwaitingResponse).Name,
                            overallRecommendationStatuses.Single(x => x.ID == Constants.OverallRecommendationStatus.NoPlansOrDisagreeValidated).Name

                        };
                        return results.OrderBy(x => Array.IndexOf(implementationStatusesOrder, x.Name)).ToList();

                    case Constants.RecommendationSummaryDisplayModes.RecommendationSummary_ResponseStatus:

                        string[] recResponseOrder =
                        {
                            implementationStatuses.Single(x => x.ID == Constants.RecommendationStatus.VerifiedComplete).Name,
                            implementationStatuses.Single(x => x.ID == Constants.RecommendationStatus.CompletedClient).Name,
                            recommendationResponses.Single(x => x.ID == Constants.RecommendationResponseStatus.ResponseReceivedWithin30Days).Name,
                            recommendationResponses.Single(x => x.ID == Constants.RecommendationResponseStatus.ResponseReceived31To60).Name,
                            recommendationResponses.Single(x => x.ID == Constants.RecommendationResponseStatus.ResponseReceived61To90).Name,
                            recommendationResponses.Single(x => x.ID == Constants.RecommendationResponseStatus.ResponseReceived91To180).Name,
                            recommendationResponses.Single(x => x.ID == Constants.RecommendationResponseStatus.ResponseReceived181To365).Name,
                            recommendationResponses.Single(x => x.ID == Constants.RecommendationResponseStatus.ResponseReceivedOver365).Name,
                            overallRecommendationStatuses.Single(x => x.ID == Constants.OverallRecommendationStatus.NoPlansOrDisagreeValidated).Name
                        };

                        return results.OrderBy(x => Array.IndexOf(recResponseOrder, x.Name)).ToList();
                    default:

                        return results.OrderByDescending(x => x.Percentage).ToList();
                }
            }
        }

        private string MapOverallRecommendationStatusToColour(int? overallRecommendationStatusID)
        {
            switch (overallRecommendationStatusID)
            {
                case Constants.OverallRecommendationStatus.VerifiedComplete:
                    return Constants.AXAColours.Igloo;
                case Constants.OverallRecommendationStatus.CompletedClientActive:
                    return Constants.AXAColours.Greyjoy;
                case Constants.OverallRecommendationStatus.ActiveExcludingCompletedClient:
                    return Constants.AXAColours.Tosca;
                case Constants.OverallRecommendationStatus.NoPlansOrDisagreeValidated:
                    return Constants.AXAColours.Dune;
                default:
                    return String.Empty;
            }
        }

        private string MapImplementationStatusToColour(int? implementationStatusId)
        {
            switch (implementationStatusId)
            {
                case Constants.RecommendationStatus.VerifiedComplete:
                    return Constants.AXAColours.Igloo;
                case Constants.RecommendationStatus.CompletedClient:
                    return Constants.AXAColours.Greyjoy;
                case Constants.RecommendationStatus.AwaitingResponse:
                    return Constants.AXAColours.Tosca;
                case Constants.RecommendationStatus.InProgress:
                    return Constants.AXAColours.CottonCandy;
                case Constants.RecommendationStatus.NoPlansOrDisagree:
                    return Constants.AXAColours.Tosca_LightVariant1;
                case Constants.RecommendationStatus.NoPlansOrDisagreeValidated:
                    return Constants.AXAColours.Dune;
                case Constants.RecommendationStatus.UnderReview:
                    return Constants.AXAColours.Azalea;
                default:
                    return String.Empty;
            }
        }

        private string MapRecommendationResponseStatusToColour(int? implementationStatusId)
        {
            switch (implementationStatusId)
            {
                case Constants.RecommendationResponseStatus.VerifiedComplete:
                    return Constants.AXAColours.Igloo;
                case Constants.RecommendationResponseStatus.CompletedClient:
                    return Constants.AXAColours.Greyjoy;
                case Constants.RecommendationResponseStatus.ResponseReceivedWithin30Days:
                    return Constants.AXAColours.CottonCandy;
                case Constants.RecommendationResponseStatus.ResponseReceived31To60:
                    return Constants.AXAColours.Tosca_LightVariant4;
                case Constants.RecommendationResponseStatus.ResponseReceived61To90:
                    return Constants.AXAColours.Tosca_LightVariant3;
                case Constants.RecommendationResponseStatus.ResponseReceived91To180:
                    return Constants.AXAColours.Tosca_LightVariant2;
                case Constants.RecommendationResponseStatus.ResponseReceived181To365:
                    return Constants.AXAColours.Tosca_LightVariant1;
                case Constants.RecommendationResponseStatus.ResponseReceivedOver365:
                    return Constants.AXAColours.Tosca;
                case Constants.RecommendationResponseStatus.NoPlansOrDisagree:
                    return Constants.AXAColours.Dune;
                default:
                    return String.Empty;
            }
        }

        public List<RecommendationData> LoadRecommendationSummaryData(PagingInfo paging, DataFilter dataFilter, RecommendationFilters filters, int userId,
            int accountId, string sortExpression, int pageSize,
            bool useLocationNo, int recordOffset, List<int> lpAllPiKeys = null)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter != null)
            {
                var db = new RecommendationDbAccess();

                int totalRows = 0;

                AccountLogic objAcclogic = new AccountLogic();
                var account = objAcclogic.GetAccount(accountId);
                var resultCostConfig = objAcclogic.GetAccountCostConfig(account.LpAcctKey);

                if (filters.SelectedRecommendationIDs == null || filters.SelectedRecommendationIDs.Count == 0)
                    filters.SelectedRecommendationIDs = new List<int> { Constants.RecommendationFilterParameters.All };
                if (filters.PerilFilter == null || filters.PerilFilter.Count == 0)
                    filters.PerilFilter = new List<int> { Constants.RecommendationFilterParameters.All };
                if (filters.CategoryFilter == null || filters.CategoryFilter.Count == 0)
                    filters.CategoryFilter = new List<int> { Constants.RecommendationFilterParameters.All };
                if (filters.RecommendationTypesFilter == null || filters.RecommendationTypesFilter.Count == 0)
                    filters.RecommendationTypesFilter = new List<int> { Constants.RecommendationFilterParameters.All };
                if (filters.RecommendationStatusesFilter == null || filters.RecommendationStatusesFilter.Count == 0)
                    filters.RecommendationStatusesFilter = new List<int> { Constants.RecommendationFilterParameters.All };
                if (filters.ImplementationStatusesFilter == null || filters.ImplementationStatusesFilter.Count == 0)
                    filters.ImplementationStatusesFilter = new List<int> { Constants.RecommendationFilterParameters.All };
                if (filters.RecommendationResponseStatusesFilter == null || filters.RecommendationResponseStatusesFilter.Count == 0)
                    filters.RecommendationResponseStatusesFilter = new List<int> { Constants.RecommendationFilterParameters.All };
                if (filters.LEFilter == null || filters.LEFilter.Count == 0)
                    filters.LEFilter = new List<int> { Constants.RecommendationFilterParameters.All };
                if (filters.EstimatedCostFilter == null || filters.EstimatedCostFilter.Count == 0)
                    filters.EstimatedCostFilter = new List<int> { Constants.RecommendationFilterParameters.All };
                if (filters.LocationId == 0)
                    filters.LocationId = null;
                if (filters.SelectedRecommendationIDs == null || filters.SelectedRecommendationIDs.Count == 0)
                    filters.SelectedRecommendationIDs = new List<int> { Constants.RecommendationFilterParameters.All };
                if (sortExpression == null)
                    sortExpression = "EstimatedCostToComplete";

                var qry = db.LoadRecommendationData(anyLocationsSelectorDataFilter, dataFilter, filters, accountId, sortExpression, pageSize, useLocationNo, recordOffset, out totalRows, resultCostConfig, lpAllPiKeys);

                paging.TotalRecords = totalRows;

                return qry.ToList();
            }

            return null;
        }

        /// <summary>
        /// Refer to User Story 84636 to see mappings between LpRecSubTypeKeys and associated Peril
        /// </summary>
        /// <param name="lpRecSubKeyToPerilType"></param>
        /// <returns></returns>
        public string MapLpRecSubKeyToPerilType(int? lpRecSubKeyToPerilType)
        {
            if (lpRecSubKeyToPerilType == null || lpRecSubKeyToPerilType == 0)
                return WebPageResources.Peril_Fire;

            switch (lpRecSubKeyToPerilType)
            {
                case int n when (n >= Constants.RecommendationPeril.MachineryBreakdown_LpRecSubRecTypKey_LowerLimit && n <= Constants.RecommendationPeril.MachineryBreakdown_LpRecSubRecTypKey_UpperLimit):
                    return WebPageResources.Peril_MachineryBreakdown;
                case int n when (n >= Constants.RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_LowerLimit && n <= Constants.RecommendationPeril.NaturalCatastrophe_LpRecSubRecTypKey_UpperLimit):
                    return WebPageResources.Peril_NaturalCatastrophe;
                default:
                    return WebPageResources.Peril_Fire;
            }
        }

        public string MapLossType(int? lossType)
        {
            if (lossType == null || lossType == 0)
                return WebPageResources.Peril_Fire;

            switch (lossType)
            {
                case int n when (n == Constants.LossType.BM):
                    return WebPageResources.Peril_MachineryBreakdown;
                case int n when (n == Constants.LossType.Other):
                    return WebPageResources.Peril_NaturalCatastrophe;
                default:
                    return WebPageResources.Peril_Fire;
            }
        }

        public string MapLEPriorToImplementationToCategory(long? lePriorToImplementation, List<AccountCostConfiguration> accountCostConfig)
        {



            var resultCostConfig = accountCostConfig.Where(x => x.CategoryType == Constants.AccountCostConfigValues.LEPriorCategorytypeID).ToList();

            long? LowLv = resultCostConfig.Select(x => x.LowLv).FirstOrDefault();
            long? HighLv = resultCostConfig.Select(x => x.HighLv).FirstOrDefault();
            long? MediumLv = resultCostConfig.Select(x => x.MediumLv).FirstOrDefault();


            switch (lePriorToImplementation)
            {
                case long l when (l <= LowLv):
                    return WebPageResources.LossEstimatePriorToCompletionCategory_Low;
                case long l when (l > LowLv && l <= MediumLv):
                    return WebPageResources.LossEstimatePriorToCompletionCategory_Medium;
                case long l when (l > MediumLv && l <= HighLv):
                    return WebPageResources.LossEstimatePriorToCompletionCategory_High;
                case long l when (l > HighLv):
                    return WebPageResources.LossEstimatePriorToCompletionCategory_Critical;
                default:
                    return string.Empty;
            }
        }

        public string MapEstCostToCompleteToCategory(long? estCostToComplete, List<AccountCostConfiguration> accountCostConfig)
        {
            var resultCostConfig = accountCostConfig.Where(x => x.CategoryType == Constants.AccountCostConfigValues.EstimatedCostCategorytypeID).ToList();

            long? LowLv = resultCostConfig.Select(x => x.LowLv).FirstOrDefault();
            long? HighLv = resultCostConfig.Select(x => x.HighLv).FirstOrDefault();
            long? MediumLv = resultCostConfig.Select(x => x.MediumLv).FirstOrDefault();


            switch (estCostToComplete)
            {
                case long l when (l <= LowLv):
                    return WebPageResources.LossEstimatePriorToCompletionCategory_Low;
                case long l when (l > LowLv && l <= MediumLv):
                    return WebPageResources.LossEstimatePriorToCompletionCategory_Medium;
                case long l when (l > MediumLv):
                    return WebPageResources.LossEstimatePriorToCompletionCategory_High;
                default:
                    return string.Empty;
            }
        }

        public void MapLocationsToResponseDesignees(List<RecommendationData> recommendationData, ref Dictionary<int, List<string>> recResponseDesignees, ref Dictionary<int, List<string>> recAssignedDesignees)
        {

            if (recommendationData == null || recommendationData.Count == 0)
                return;

            UserLogic userLogic = new UserLogic();
            var db = new RecommendationDbAccess();
            var uniqueLocations = recommendationData.GroupBy(x => x.LPAllPiKey).Select(y => y.Key).ToList();

            // A list of all users who have access to a location AND have either the Rec Response/Rec Assigned Designee
            // flag set against their User record
            var userLocationPrivileges = db.LoadUserLocationPriviledge(string.Join(",", uniqueLocations));

            // i.e. Users 1,2,3,4
            var uniqueUsers = userLocationPrivileges.GroupBy(x => x.UserId).Select(y => y.Key).ToList();

            // i.e. Users 1,2,3,4 with Email Address info obtained through EDS
            var mergedUsers = userLogic.GetUserProfileCacheByUserIds(uniqueUsers);

            Dictionary<int, string> users = new Dictionary<int, string>();

            foreach (var mu in mergedUsers.Where(x => x.UserID > -1))
            {
                users.Add(mu.UserID, mu.Email);
            }

            foreach (var uniqueLocation in uniqueLocations)
            {
                List<string> recResponseEmailAddresses = new List<string>();
                List<string> recAssignedEmailAddresses = new List<string>();

                foreach (var ulp in userLocationPrivileges.Where(x => x.LpAllPiKey == uniqueLocation))
                {
                    if (ulp.SiteRecResponseDesignee)
                        recResponseEmailAddresses.Add(users.SingleOrDefault(x => x.Key == ulp.UserId).Value);

                    if (ulp.SiteRecAssignedDesignee)
                        recAssignedEmailAddresses.Add(users.SingleOrDefault(x => x.Key == ulp.UserId).Value);
                }

                recResponseDesignees.Add(uniqueLocation, recResponseEmailAddresses);
                recAssignedDesignees.Add(uniqueLocation, recAssignedEmailAddresses);
            }
        }

        public ViewRecommendationSummaryReportDetail GetRecommendationSummaryReportDetails(int lPAllPiKey, int lPRecKey)
        {
            var qry = Repo.GetAll<ViewRecommendationSummaryReportDetail>();
            qry = qry.Where(x => x.LpAllPiKey == lPAllPiKey && x.LpRecKey == lPRecKey);
            return qry.SingleOrDefault();
        }

        public Recommendation GetRecommendationDetails(int lPAllPiKey, int lPRecKey)
        {
            var qry = Repo.GetAll<Recommendation>();
            qry = qry.Where(x => x.LpAllPiKey == lPAllPiKey && x.LpRecKey == lPRecKey);
            return qry.SingleOrDefault();
        }

        public Recommendation GetRecommendationDetailsByLPRecKey(int lpRecKey, int lpAcctKey)
        {
            var qry = Repo.GetAll<Recommendation>();
            qry = qry.Where(x => lpRecKey == x.LpRecKey && x.LpAcctKey == lpAcctKey);
            return qry.Include("Location").SingleOrDefault();
        }

        public long GetRecommendationCostBenefitRatio(long? estCostToComplete, long? leBefore, long? leAfter)
        {
            long beforeImplementationVals = leBefore ?? 0;
            long afterImplementationVals = leAfter ?? 0;
            long estimationCost = estCostToComplete ?? 1;

            if (estimationCost == 0)
                return 0; // if attempting to divide by 0 then return CB Ratio of 0:1

            return (beforeImplementationVals - afterImplementationVals) / estimationCost;
        }

        public long GetRecommendationRiskReduction(long? leBefore, long? leAfter)
        {
            long beforeImplementationVals = leBefore ?? 0;
            long afterImplementationVals = leAfter ?? 0;

            return (beforeImplementationVals - afterImplementationVals);
        }

        /// <summary>
        /// Load all a Recommendations update Records
        /// TODO - provide a Location key. LpRecKeys are unforunately not unique, and we need to guard against loading
        /// TODO - any update records which belong to a separate Recommendation
        /// </summary>
        /// <param name="LPRecKey"></param>
        /// <param name="LPAllPiKey"></param>
        /// <returns></returns>
        public List<RecommendationUpdate> LoadRecommendationUpdatesByRecommendation(int LPRecKey, int LPAllPiKey)
        {
            var qry = Repo.GetAll<RecommendationUpdate>();
            qry = qry.Where(x => x.LpRecKey == LPRecKey && x.LpAllPiKey == LPAllPiKey);
            return qry.ToList();
        }

        /// <summary>
        /// Load all a Recommendations Comments if not  Update Recommendation Comments 
        /// TODO - provide a Location key. LpRecKeys are unforunately not unique, and we need to guard against loading
        /// TODO - any update records which belong to a separate Recommendation
        /// </summary>
        /// <param name="LPRecKey"></param>
        /// <param name="LPAllPiKey"></param>
        /// <returns></returns>
        public string LoadRecommendationComments(int LPRecKey, int LPAllPiKey)
        {
            string comments = string.Empty;
            try
            {
                var qryUpdatecomments = Repo.GetAll<RecommendationUpdate>();
                comments = qryUpdatecomments.Where(x => x.LpRecKey == LPRecKey).OrderByDescending(x => x.CreatedDate).Select(x => x.Comment).FirstOrDefault();

                if (string.IsNullOrEmpty(comments))
                {
                    var qryRecComments = Repo.GetAll<RecommendationComment>();

                    comments = qryRecComments.Where(x => x.LpRecKey == LPRecKey).OrderByDescending(x => x.CreatedDate).Select(x => x.Comment).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error Loading Recommendation Comments - LoadRecommendationComments", ex);
            }

            return comments;

        }

        /// <summary>
        /// Load all Recommendation permanent data
        /// TODO - provide a Location key. LpRecKeys are unforunately not unique, and we need to guard against loading
        /// TODO - any update records which belong to a separate Recommendation
        /// </summary>
        /// <param name="LPRecKey"></param>
        /// <param name="LPAllPiKey"></param>
        /// <returns></returns>
        public List<RecommendationPermanentData> LoadRecommendationPermanentData(int LPRecKey, int LPAllPiKey)
        {
            var qry = Repo.GetAll<RecommendationPermanentData>();
            qry = qry.Where(x => x.LpRecKey == LPRecKey && x.LpAllPiKey == LPAllPiKey);
            return qry.ToList();
        }

        public List<RecommendationHistoryData> GetRecommendationUpdate(int lpAllPiKey, int lpRecKey)
        {
            var db = new RecommendationDbAccess();
            return db.GetRecommendationUpdate(lpAllPiKey, lpRecKey);
        }

        public List<RecommendationHistoryData> LoadRecommendationHistory(int lpRecKey, int lpAllPiKey)
        {
            var db = new RecommendationDbAccess();
            return db.LoadRecommendationHistory(lpRecKey, lpAllPiKey);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="recommendationTypeGroup"></param>
        /// <returns></returns>
        public List<RecommendationType> LoadRecommendationTypesGroup(int recommendationTypeGroup)
        {
            var qry = Repo.GetAll<RecommendationType>();
            qry = qry.Where(x => recommendationTypeGroup == x.RecommendationTypeGroup);
            return qry.ToList();
        }

        #endregion

        #region Report Export 
        public DataTable GetDataTableForRecommendationsReport(PagingInfo paging, DataFilter dataFilter, int lpAcctKey, int userId, bool useLocationNo, string sortExpression, RecommendationFilters filters, string format, Dictionary<string, Dictionary<string, string>> replacementFields = null)
        {
            var datatable = new DataTable();
            var systemGridLogic = new SystemGridLogic();
            var accountLogic = new AccountLogic();
            var accountId = accountLogic.GetByLpAcctKey(lpAcctKey).ID;
            var recommendationSystemGridFields = systemGridLogic.LoadSystemGridForUser(Constants.SystemGridRef.RecommendationSummary, userId, false, lpAcctKey);

            var userSelectedColumns = GetUserReportExportColumnOptions(userId, Constants.SystemGridRef.RecommendationSummary, null, replacementFields, lpAcctKey);



            if (userSelectedColumns != null)
            {
                var counter = 1;
                foreach (KeyValuePair<int, string> kvp in userSelectedColumns)
                {
                    // Don't print the Actions column
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_Actions)
                        continue;

                    // Don't print the multiselect Actions column
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_Hyphen)
                        continue;

                    // Don't print the multiselect Edit column
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_Edit)
                        continue;

                    var gridGroup = recommendationSystemGridFields.Groups.First(g => g.Fields.Any(f => f.SystemGridFieldSystemGridFieldRef == kvp.Key));
                    var gridFieldsCount = gridGroup.Fields.Count(f => f.UserSystemGridFieldVisible);
                    datatable.Columns.Add(
                        new DataColumn
                        {
                            ColumnName = $"Field{counter}",
                            //Caption = $"{gridGroup.SystemGridGroupName}-{gridFieldsCount}|{kvp.Value}",
                            Caption = $"{gridGroup.SystemGridGroupName.TrimEnd()}-{gridFieldsCount}|{kvp.Value.Replace("'", "").Replace("%", "").Replace("&", "").Replace("-", "").Replace("°", "").TrimEnd()}",
                            DataType = format == Constants.ExportFormats.Excel ? Type.GetType(SetColumnsType(kvp.Key, useLocationNo)) : Type.GetType(Constants.GetTypeSystem.Sys_String)
                        });

                    counter++;
                }
            }

            var dataset = LoadRecommendationSummaryData(paging, dataFilter, filters, userId, lpAcctKey, sortExpression, paging.PageSize, useLocationNo, paging.PageOffset);

            AddDatasetToCustomisableReport(datatable, dataset, userSelectedColumns, useLocationNo, lpAcctKey, format);
            return datatable;
        }
        private string SetColumnsType(int Key, bool useLocationNo)
        {
            try
            {
                if (Key == Constants.SystemGridFieldRef.RecommendationDetails_LocationID)
                {
                    switch (useLocationNo)
                    {
                        case true:
                            return Constants.GetTypeSystem.Sys_String;
                        case false:
                            return Constants.GetTypeSystem.Sys_String;
                    }
                }

                if (Key == Constants.SystemGridFieldRef.RecommendationDetails_ClientLocationID)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_LocationName)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_Division)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_SubDivision)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_StreetAddress1)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_StreetAddress2)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_City)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_State)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_Country)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_TotalPropertyValue)
                    return Constants.GetTypeSystem.Sys_Long;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_BusinessInterruptionValue)
                    return Constants.GetTypeSystem.Sys_Long;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_TotalInsurableValue)
                    return Constants.GetTypeSystem.Sys_Long;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationID)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatus)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatusChangeDate)
                    return Constants.GetTypeSystem.Sys_DateTime;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationSummary)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_LineofBusiness)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_Peril)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_Category)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_Type)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_SubType)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_IntentAtTimeOfSurvey)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_FacilityComment)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_Probability)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_DateIssued)
                    return Constants.GetTypeSystem.Sys_DateTime;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationSource)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_LastSurveyConsultant)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_LastSurveyDate)
                    return Constants.GetTypeSystem.Sys_DateTime;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_NextSurveyConsultant)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_NextSurveyDate)
                    return Constants.GetTypeSystem.Sys_DateTime;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_AssignedPriority)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_EstimatedRiskReduction)
                    return Constants.GetTypeSystem.Sys_Long;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_LossEstimatePriortoImplementation)
                    return Constants.GetTypeSystem.Sys_Long;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_LossEstimatePriortoImplementationCategory)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_LossEstimateAfterImplementation)
                    return Constants.GetTypeSystem.Sys_Long;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_EstimatedCosttoComplete)
                    return Constants.GetTypeSystem.Sys_Long;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_EstimatedCosttoCompleteCategory)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_CostBenefitRatio)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_LossScenario)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatus)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatusChangeDate)
                    return Constants.GetTypeSystem.Sys_DateTime;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatus)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatusChangeDate)
                    return Constants.GetTypeSystem.Sys_DateTime;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_TargetDate)
                    return Constants.GetTypeSystem.Sys_DateTime;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_Comments)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_ActualCostToComplete)
                    return Constants.GetTypeSystem.Sys_Long;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_Priority)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseDesigneeEmail)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationAssignedDesigneeEmail)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_MyComment1)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_MyComment2)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_MyComment3)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_SharedComment)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_CurrentRecommendationStatus)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatusAsOfDateYearMinusOne)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatusAsOfDateYearMinusTwo)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatusAsOfDateYearMinusThree)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatusAsOfDateYearMinusFour)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatusAsOfDateYearMinusFive)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_CurrentImplementationStatus)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatusAsOfDateYearMinusOne)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatusAsOfDateYearMinusTwo)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatusAsOfDateYearMinusThree)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatusAsOfDateYearMinusFour)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatusAsOfDateYearMinusFive)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_CurrentRecommendationResponseStatus)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatusAsOfDateYearMinusOne)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatusAsOfDateYearMinusTwo)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatusAsOfDateYearMinusThree)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatusAsOfDateYearMinusFour)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatusAsOfDateYearMinusFive)
                    return Constants.GetTypeSystem.Sys_String;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_DateCompleted)
                    return Constants.GetTypeSystem.Sys_DateTime;
                else if (Key == Constants.SystemGridFieldRef.RecommendationDetails_DetailedRecommendation)
                    return Constants.GetTypeSystem.Sys_String;
                else
                    return Constants.GetTypeSystem.Sys_String;
            }
            catch (Exception ex)
            {
                return Constants.GetTypeSystem.Sys_String;
                throw ex;

            }
        }

        /// <summary>
        /// Returns a semi-colon separated string of email addresses associated with the Dictionary key provided
        /// </summary>
        /// <param name="userEmailAddresses">A Dictionary in the form LpAllPiKey: [emailaddresses] </param>
        /// <param name="key">Returns values associated with this key (LpAllPiKey) in provided Dicionary</param>
        /// <returns></returns>
        public string ExtractFormattedEmailAddressesFromDictionary(Dictionary<int, List<string>> userEmailAddresses, int key)
        {
            var targetDictionaryEntry = userEmailAddresses.SingleOrDefault(x => x.Key == key);
            return string.Join("; ", targetDictionaryEntry.Value.ToArray());
        }
        public void AddDatasetToCustomisableReport(DataTable dataTable, List<RecommendationData> dataSet, List<KeyValuePair<int, string>> userSelectedColumns, bool useLocationNo, int lpAcctKey, string format)
        {

            var refLogic = new ReferenceListLogic();
            var overallRecommendationStatuses = refLogic.GetOverallRecommendationStatus();
            var categories = refLogic.GetRecommendationCategories();
            var types = refLogic.GetRecommendationTypes();
            var implementationStatuses = refLogic.GetRecommendationStatuses();
            var probabilities = refLogic.GetRecommendationProbabilities();
            var intents = refLogic.GetRecommendationClientIntents();
            var sources = refLogic.GetRecommendationSources();
            var recResponseStatuses = refLogic.GetRecommendationResponseStatuses();

            // Stores a list of email addresses associated with each location for assigned/response designees
            Dictionary<int, List<string>> recResponseDesignees = new Dictionary<int, List<string>>();
            Dictionary<int, List<string>> recAssignedDesignees = new Dictionary<int, List<string>>();
            AccountLogic objAcclogic = new AccountLogic();
            var resultCostConfig = objAcclogic.GetAccountCostConfig(lpAcctKey);
            MapLocationsToResponseDesignees(dataSet, ref recResponseDesignees, ref recAssignedDesignees);

            foreach (var item in dataSet)
            {
                List<Object> rowData = new List<object>();

                foreach (KeyValuePair<int, string> kvp in userSelectedColumns)
                {
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_LocationID)
                    {
                        switch (useLocationNo)
                        {
                            case true:
                                rowData.Add(item?.LocationNo);
                                break;
                            case false:
                                rowData.Add(item?.LocationCode);
                                break;
                        }
                    }

                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_ClientLocationID)
                        rowData.Add(item?.ClientLocationNo);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_LocationName)
                        rowData.Add(item?.LocationName);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_Division)
                        rowData.Add(item?.DivisionName);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_SubDivision)
                        rowData.Add(item?.SubDivisionName);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_StreetAddress1)
                        rowData.Add(item?.AddressLine1);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_StreetAddress2)
                        rowData.Add(item?.AddressLine2);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_City)
                        rowData.Add(item?.City);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_State)
                        rowData.Add(item?.State);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_Country)
                        rowData.Add(item?.Country);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_TotalPropertyValue)
                    {
                        if (format == Constants.ExportFormats.Excel)
                            rowData.Add(item?.PDValue);
                        else
                            rowData.Add(FormatHelper.FormatCurrency(item?.PDValue));
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_BusinessInterruptionValue)
                        rowData.Add(item?.BIValue);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_TotalInsurableValue)
                    {
                        if (format == Constants.ExportFormats.Excel)
                            rowData.Add(item?.TotalInsurableValue);
                        else
                            rowData.Add(FormatHelper.FormatCurrency(item?.TotalInsurableValue));
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationID)
                        rowData.Add(item?.RecID);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatus)
                        rowData.Add(overallRecommendationStatuses.SingleOrDefault(y => y.ID == item.OverallRecommendationStatusID)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatusChangeDate)
                    {
                        if (format == Constants.ExportFormats.Excel)
                            rowData.Add(item?.RecommendationStatusChangeDate);
                        else
                            rowData.Add(FormatHelper.FormatDate(item?.RecommendationStatusChangeDate));
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationSummary)
                        rowData.Add(item?.Summary);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_LineofBusiness)
                        rowData.Add(WebPageResources.LineOfBusiness_Property);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_Peril)
                        rowData.Add(MapLpRecSubKeyToPerilType(item.Peril));
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_Category)
                        rowData.Add(categories.SingleOrDefault(y => y.ID == item?.RecommendationCategoryID)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_Type)
                        rowData.Add(types.SingleOrDefault(y => y.ID == item?.RecommendationTypeID)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_SubType)
                        rowData.Add(types.SingleOrDefault(y => y.ID == item?.RecommendationTypeID)?.SubRecName);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_IntentAtTimeOfSurvey)
                        rowData.Add(intents.SingleOrDefault(y => y.ID == item?.RecommendationClientIntentID)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_FacilityComment)
                        rowData.Add(String.IsNullOrEmpty(item.FacilityComment) ? String.Empty : Regex.Replace(item.FacilityComment, "<.*?>", String.Empty));
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_Probability)
                        rowData.Add(probabilities.SingleOrDefault(y => y.ID == item?.RecommendationProbabilityID)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_DateIssued)
                    {
                        if (format == Constants.ExportFormats.Excel)
                        {
                            if (item?.IssuedDate.HasValue == true)
                            {
                                rowData.Add(DateTime.ParseExact(FormatHelper.FormatDateAsUTC(item?.IssuedDate), "dd-MMM-yyyy", CultureInfo.CurrentCulture));
                            }
                            else
                                rowData.Add(item?.IssuedDate);
                        }
                        else
                            rowData.Add(FormatHelper.FormatDate(item?.IssuedDate));
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationSource)
                        rowData.Add(sources.SingleOrDefault(y => y.ID == item.RecommendationSourceID)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_LastSurveyConsultant)
                        rowData.Add((item.LastSurveyConsultant.Contains(",") ? $"{item.LastSurveyConsultant.Split(',')[1]} {item.LastSurveyConsultant.Split(',')[0]}" : item.LastSurveyConsultant));
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_LastSurveyDate)
                    {
                        if (format == Constants.ExportFormats.Excel)
                        {
                            if (item?.LastSurveyDate.HasValue == true)
                            {
                                rowData.Add(DateTime.ParseExact(FormatHelper.FormatDateAsUTC(item?.LastSurveyDate), "dd-MMM-yyyy", CultureInfo.CurrentCulture));
                            }
                            else
                                rowData.Add(item?.LastSurveyDate);

                        }
                        else
                            rowData.Add(FormatHelper.FormatDate(item?.LastSurveyDate));
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_NextSurveyConsultant)
                        rowData.Add((item.NextSurveyConsultant.Contains(",") ? $"{item.NextSurveyConsultant.Split(',')[1]} {item.NextSurveyConsultant.Split(',')[0]}" : item.NextSurveyConsultant));

                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_NextSurveyDate)
                    {
                        if (format == Constants.ExportFormats.Excel)
                        {
                            if (item?.NextSurveyDate.HasValue == true)
                            {
                                rowData.Add(DateTime.ParseExact(FormatHelper.FormatDate(item?.NextSurveyDate), "dd-MMM-yyyy", CultureInfo.CurrentCulture));
                            }
                            else
                                rowData.Add(item?.NextSurveyDate);
                        }
                        else
                            rowData.Add(FormatHelper.FormatDate(item?.NextSurveyDate));
                    }

                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_AssignedPriority)
                        rowData.Add(item?.Priority);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_EstimatedRiskReduction)
                    {
                        if (format == Constants.ExportFormats.Excel)
                            rowData.Add(item.EstimatedRiskReduction);
                        else
                            rowData.Add(FormatHelper.FormatCurrency(item.EstimatedRiskReduction));
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_LossEstimatePriortoImplementation)
                    {
                        if (format == Constants.ExportFormats.Excel)
                            rowData.Add(item.LossEstimatePriorToImplementation);
                        else
                            rowData.Add(FormatHelper.FormatCurrency(item.LossEstimatePriorToImplementation));
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_LossEstimatePriortoImplementationCategory)
                        rowData.Add(MapLEPriorToImplementationToCategory(item.LossEstimatePriorToImplementation, resultCostConfig));
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_LossEstimateAfterImplementation)
                    {
                        if (format == Constants.ExportFormats.Excel)
                            rowData.Add(item.LossEstimateAfterImplementation);
                        else
                            rowData.Add(FormatHelper.FormatCurrency(item.LossEstimateAfterImplementation));
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_EstimatedCosttoComplete)
                    {
                        if (format == Constants.ExportFormats.Excel)
                            rowData.Add(item.EstCostToComplete);
                        else
                            rowData.Add(FormatHelper.FormatCurrency(item.EstCostToComplete));
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_EstimatedCosttoCompleteCategory)
                        rowData.Add(MapEstCostToCompleteToCategory(item.EstCostToComplete, resultCostConfig));
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_CostBenefitRatio)
                        rowData.Add(item.CostBenefitRatio.HasValue ? $"{FormatHelper.FormatCurrency(item.CostBenefitRatio)}:1" : String.Empty);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_LossScenario)
                        rowData.Add(String.IsNullOrEmpty(item.LossScenario) ? String.Empty : Regex.Replace(item.LossScenario, "<.*?>", String.Empty));
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatus)
                        rowData.Add(implementationStatuses.SingleOrDefault(y => y.ID == item?.RecommendationStatusID)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatusChangeDate)
                    {
                        if (format == Constants.ExportFormats.Excel)
                            rowData.Add(item?.ImplementationStatusChangeDate);
                        else
                            rowData.Add(FormatHelper.FormatDateAsUTC(item?.ImplementationStatusChangeDate));

                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatus)
                        rowData.Add(recResponseStatuses.SingleOrDefault(y => y.ID == item.CurrentRecommendationResponseStatusID)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatusChangeDate)
                        rowData.Add(item?.RecommendationResponseStatusChangeDate);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_TargetDate)
                    {
                        if (format == Constants.ExportFormats.Excel)
                            rowData.Add(item?.TargetDate);
                        else
                            rowData.Add(FormatHelper.FormatDateAsUTC(item?.TargetDate));
                    }

                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_Comments)
                    {
                        if (String.IsNullOrEmpty(item.CustomerIntentDescription))
                            rowData.Add(String.Empty);
                        else
                            rowData.Add(Regex.Replace(FormatHelper.FormatDescriptionForHtmlValue(FormatHelper.HtmlDecode(item.CustomerIntentDescription)), "<.*?>", String.Empty));
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_ActualCostToComplete)
                    {
                        if (format == Constants.ExportFormats.Excel)
                            rowData.Add(item.ActualCostToComplete);
                        else
                            rowData.Add(FormatHelper.FormatCurrency(item.ActualCostToComplete));
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_Priority)
                        rowData.Add(item?.Priority);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseDesigneeEmail)
                        rowData.Add(ExtractFormattedEmailAddressesFromDictionary(recResponseDesignees, item.LPAllPiKey));
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationAssignedDesigneeEmail)
                        rowData.Add(ExtractFormattedEmailAddressesFromDictionary(recAssignedDesignees, item.LPAllPiKey));
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_MyComment1)
                        rowData.Add(item?.MyCommentOne);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_MyComment2)
                        rowData.Add(item?.MyCommentTwo);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_MyComment3)
                        rowData.Add(item?.MyCommentThree);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_SharedComment)
                        rowData.Add(item?.SharedComment);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_CurrentRecommendationStatus)
                        rowData.Add(overallRecommendationStatuses.SingleOrDefault(y => y.ID == item.OverallRecommendationStatusID)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatusAsOfDateYearMinusOne)
                        rowData.Add(overallRecommendationStatuses.SingleOrDefault(y => y.ID == item.RecommendationStatusYearMinusOne)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatusAsOfDateYearMinusTwo)
                        rowData.Add(overallRecommendationStatuses.SingleOrDefault(y => y.ID == item.RecommendationStatusYearMinusTwo)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatusAsOfDateYearMinusThree)
                        rowData.Add(overallRecommendationStatuses.SingleOrDefault(y => y.ID == item.RecommendationStatusYearMinusThree)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatusAsOfDateYearMinusFour)
                        rowData.Add(overallRecommendationStatuses.SingleOrDefault(y => y.ID == item.RecommendationStatusYearMinusFour)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationStatusAsOfDateYearMinusFive)
                        rowData.Add(overallRecommendationStatuses.SingleOrDefault(y => y.ID == item.RecommendationStatusYearMinusFive)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_CurrentImplementationStatus)
                        rowData.Add(implementationStatuses.SingleOrDefault(y => y.ID == item.RecommendationStatusID)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatusAsOfDateYearMinusOne)
                        rowData.Add(implementationStatuses.SingleOrDefault(y => y.ID == item.ImplementationStatusYearMinusOne)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatusAsOfDateYearMinusTwo)
                        rowData.Add(implementationStatuses.SingleOrDefault(y => y.ID == item.ImplementationStatusYearMinusTwo)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatusAsOfDateYearMinusThree)
                        rowData.Add(implementationStatuses.SingleOrDefault(y => y.ID == item.ImplementationStatusYearMinusThree)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatusAsOfDateYearMinusFour)
                        rowData.Add(implementationStatuses.SingleOrDefault(y => y.ID == item.ImplementationStatusYearMinusFour)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_ImplementationStatusAsOfDateYearMinusFive)
                        rowData.Add(implementationStatuses.SingleOrDefault(y => y.ID == item.ImplementationStatusYearMinusFive)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_CurrentRecommendationResponseStatus)
                        rowData.Add(recResponseStatuses.SingleOrDefault(y => y.ID == item.CurrentRecommendationResponseStatusID)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatusAsOfDateYearMinusOne)
                        rowData.Add(recResponseStatuses.SingleOrDefault(y => y.ID == item.RecommendationResponseStatusYearMinusOne)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatusAsOfDateYearMinusTwo)
                        rowData.Add(recResponseStatuses.SingleOrDefault(y => y.ID == item.RecommendationResponseStatusYearMinusTwo)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatusAsOfDateYearMinusThree)
                        rowData.Add(recResponseStatuses.SingleOrDefault(y => y.ID == item.RecommendationResponseStatusYearMinusThree)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatusAsOfDateYearMinusFour)
                        rowData.Add(recResponseStatuses.SingleOrDefault(y => y.ID == item.RecommendationResponseStatusYearMinusFour)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_RecommendationResponseStatusAsOfDateYearMinusFive)
                        rowData.Add(recResponseStatuses.SingleOrDefault(y => y.ID == item.RecommendationResponseStatusYearMinusFive)?.Name);
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_DateCompleted)
                    {
                        if (format == Constants.ExportFormats.Excel)
                            rowData.Add(item?.CompletedDate);
                        else
                            rowData.Add(FormatHelper.FormatDateAsUTC(item?.CompletedDate));
                    }
                    if (kvp.Key == Constants.SystemGridFieldRef.RecommendationDetails_DetailedRecommendation)
                    {
                        rowData.Add(item?.DetailedRecommendation);
                    }



                }

                dataTable.Rows.Add(rowData.ToArray());
            }
        }

        public Dictionary<string, string> GetDataForRecommendationDetailReport(Recommendation recommendation, bool useLocationNo)
        {
            var kvp = new Dictionary<string, string>();


            kvp.Add("ReportSubTitle", $"{WebPageResources.Recommendations_Recommendation} - #{recommendation.RecID}");
            kvp.Add("AccountName", recommendation.Account?.Name);
            kvp.Add("LocationName", recommendation.Location?.Name);

            var addressLine1 = recommendation.Location?.AddressLine1;
            var addressLine2 = recommendation.Location?.AddressLine2;
            var addressLine3 = recommendation.Location?.AddressLine3;

            var City = string.Empty;
            var State = string.Empty;
            var Country = string.Empty;
            var PostCode = string.Empty;

            if (!string.IsNullOrEmpty(recommendation.Location.City))
                City = recommendation.Location.City + ", ";

            if (!string.IsNullOrEmpty(recommendation.Location.State))
                State = recommendation.Location.State + ", ";

            if (!string.IsNullOrEmpty(recommendation.Location.Country))
                Country = recommendation.Location.Country + ", ";

            PostCode = recommendation.Location.PostCode;

            var CityCountryCode = City + State + Country + PostCode;
            CityCountryCode = CityCountryCode.Substring(0, CityCountryCode.LastIndexOf(','));

            kvp.Add("LocationAddress", FormatHelper.ConvertLineAddressesToStreetAddressAndCityWithHTMLBreakElements(addressLine1, addressLine2, addressLine3, CityCountryCode, false, true));

            kvp.Add("LabelSurveyDate", WebPageResources.Recommendations_ExpandedView_SurveyDate);
            kvp.Add("LabelSurveyedBy", WebPageResources.Recommendations_ExpandedView_SurveyedBy);
            kvp.Add("LabelGapsLocationID", "Location ID");
            kvp.Add("LabelCustomerID", "Customer ID");
            kvp.Add("SurveyDate", recommendation.Location?.LastSurveyDate?.ToString("dd-M-yyyy"));
            kvp.Add("SurveyedBy", recommendation.Location?.LastSurveyBy);
            kvp.Add("GAPSLocationID", useLocationNo ? recommendation.Location?.LocationNo : recommendation.Location?.LocationCode);
            kvp.Add("CustomerID", recommendation.Location?.ClientLocationNo);
            kvp.Add("RecommendationID", recommendation.RecID);
            kvp.Add("RecommendationDescription", recommendation.Description);
            kvp.Add("Confidential", WebPageResources.RecommendationsDetail_Confidential);
            kvp.Add("Footer", WebPageResources.RecommendationsDetail_Footer);


            return kvp;
        }

        public DataTable GetDataTableForRecommendationsReportByRecommendation(int lPAllPiKey, int lPRecKey)
        {
            var dataTable = new DataTable();

            dataTable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Recommendations_AccountName });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Recommendations_RecTableCol_LocID });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.Recommendations_LocationAddress });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Field4", Caption = WebPageResources.Recommendations_RecTableCol_RecID });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Field5", Caption = WebPageResources.Recommendations_ExpandedView_SurveyDate });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Field6", Caption = WebPageResources.Recommendations_ExpandedView_SurveyedBy });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Field7", Caption = WebPageResources.Dashboard_HighestFireLossEstimates_ClientLocationNo });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Field8", Caption = WebPageResources.Recommendations_ExpandedView_RecommendationDescriptionTitle });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Field9", Caption = WebPageResources.Recommendations_Country });
            dataTable.Columns.Add(new DataColumn { ColumnName = "Field10", Caption = WebPageResources.Recommendations_City });

            var item = GetRecommendationDetails(lPAllPiKey, lPRecKey);

            Object[] rowObject =
            {

                item.Account.Name,
                item.Location.LocationNo,
                FormatHelper.ConvertCharInstancesToCRLFs(item.Location.FullAddress, Constants.LocationAddressSeparatorChar, addCommas: true),
                item.RecID,
                item.Location.LastSurveyDate,
                item.Location.LastSurveyBy,
                item.Location?.ClientLocationNo,
                item.DescriptionSanitised,
                item.Location.Country,
                item.Location.City
            };
            dataTable.Rows.Add(rowObject);

            return dataTable;
        }

        public DataTable GetDataTableForRecommendationsUpdatesReportByRecommendation(int LPRecKey, int LPAllPiKey)
        {
            var datatable = new DataTable();

            var refLogic = new ReferenceListLogic();
            var statuses = refLogic.GetRecommendationStatuses();


            datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.RecommendationHistory_Date });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.RecommendationHistory_UpdatedBy });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.RecommendationHistory_Email });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field4", Caption = WebPageResources.RecommendationHistory_ImplementationStatus });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field5", Caption = WebPageResources.RecommendationHistory_TargetDate });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field6", Caption = WebPageResources.RecommendationHistory_Comments });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field7", Caption = WebPageResources.RecommendationHistory_EstCostToComplete });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field8", Caption = WebPageResources.RecommendationHistory_CompletedDate });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field9", Caption = WebPageResources.RecommendationHistory_ActualCostToComplete });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field10", Caption = WebPageResources.RecommendationHistory_Priority });

            var dataset = LoadRecommendationHistory(LPRecKey, LPAllPiKey);

            // If a Recommendation has changed, print its new property, otherwise just return an empty space
            // in its respective column.
            foreach (var item in dataset)
            {
                Object[] O =
                {
                    FormatHelper.FormatDate(item.Date),
                    item.UpdatedBy,
                    item.Email,
                    item.ImplementationStatus != null ? statuses.SingleOrDefault(s => s.ID == item.ImplementationStatus)?.Name : String.Empty,
                    FormatHelper.FormatDate(item.TargetDate),
                    FormatHelper.FormatDescriptionForHtmlValue(item.Comments),
                    FormatHelper.FormatCurrency(item.EstCostToComplete),
                    FormatHelper.FormatDate(item.CompletedDate),
                    FormatHelper.FormatCurrency(item.ActualCostToComplete),
                    item.Priority

            };
                datatable.Rows.Add(O);
            }

            return datatable;
        }



        #endregion

        #region Save

        public RecommendationResponseBatch CreateRecommendationResponseBatchRecord(UserMerged sender, int notificationType, int notificationOption, string emailSubject)
        {
            var db = new RecommendationDbAccess();
            string senderName = null;

            if (String.IsNullOrEmpty(sender.ForeName) && String.IsNullOrEmpty(sender.Surname))
            {
                senderName = sender.EdsCn;
            }
            else
            {
                senderName = $"{sender.ForeName} {sender.Surname}";
            }

            return db.CreateRecommendationResponseBatchRecord(sender.ID, notificationType, notificationOption, senderName, sender.Email, emailSubject);
        }

        public void CreateRecommendationResponseHistoryRecord(string recipientUser, int responseBatchId, int lpRecKey, int lpAcctKey)
        {
            try
            {

                var db = new RecommendationDbAccess();

                var recommendation = GetRecommendationDetailsByLPRecKey(lpRecKey, lpAcctKey);
                if (recommendation != null)
                    db.CreateRecommendationResponseHistoryRecord(recipientUser, responseBatchId, recommendation.LpRecKey, recommendation.LpAllPiKey);
            }
            catch (Exception e)
            {
                LogHelper.Error($"Could not record recommendation response history for user {recipientUser} , LPRecKey {lpRecKey}, LpAcctKey {lpAcctKey}", e);
            }
        }

        public bool QueueRecommendation(string recommendation)
        {
            var msg = new Message();
            msg.Body = recommendation;
            msg.Label = Constants.MessageQueueTypes.MessageType_RecommendationSingle;
            var messageQueueLocation = ConfigHelper.GetAppSetting("QueueLocation");
            MessageQueue queue = new MessageQueue(messageQueueLocation);

            if (queue.Transactional)
            {
                var trans = new MessageQueueTransaction();
                trans.Begin();
                msg.Formatter = new XmlMessageFormatter(new Type[] { typeof(String) });
                queue.Send(msg, trans);
                trans.Commit();
            }
            else
            {
                queue.Send(msg);
            }
            return true;
        }

        public bool QueueRecommendationBatch(string recommendation)
        {
            var msg = new Message();
            msg.Body = recommendation;
            msg.Label = Constants.MessageQueueTypes.MessageType_RecommendationBulk;
            var messageQueueLocation = ConfigHelper.GetAppSetting("QueueLocation");
            MessageQueue queue = new MessageQueue(messageQueueLocation);

            if (queue.Transactional)
            {
                var trans = new MessageQueueTransaction();
                trans.Begin();
                msg.Formatter = new XmlMessageFormatter(new Type[] { typeof(String) });
                queue.Send(msg, trans);
                trans.Commit();
            }
            else
            {
                queue.Send(msg);
            }
            return true;
        }

        public RecommendationUpdate SaveRecommendationUpdate(RecommendationUpdate recommendationUpdate, bool isSave = false)
        {
            RecommendationDbAccess db = new RecommendationDbAccess();

            if (isSave)
            {
                return db.InsertRecommendationUpdate(recommendationUpdate);
            }
            else
            {
                return recommendationUpdate;
            }
        }

        public RecommendationPermanentData SaveRecommendationUpdate(RecommendationPermanentData recommendationUpdate)
        {
            RecommendationDbAccess db = new RecommendationDbAccess();

            return db.InsertRecommendationUpdate(recommendationUpdate, "");
        }

        public async Task<Recommendation> UpdateRecommendation(Recommendation recommendation)
        {

            RecommendationDbAccess db = new RecommendationDbAccess();

            return await db.UpdateRecommendationAsync(recommendation);

        }

        public Recommendation UpdateRecommendationforExcel(Recommendation recommendation)
        {

            RecommendationDbAccess db = new RecommendationDbAccess();

            return db.UpdateRecommendationforExcel(recommendation);

        }



        /// <summary>
        /// For each user, create a list of Internal Notifications for each of the Location/Recommendation entries passed
        /// </summary>
        /// <param name="recIds"></param>
        /// <param name="createdByUserId"></param>
        /// <param name="locationRecipients"></param>
        /// <param name="notificationType"></param>
        /// <returns></returns>
        public bool RecommendationResponseRequested(List<int> recIds, UserMerged sender, List<KeyValuePair<int, List<SelectRecipientsUser>>> locationRecipients, int notificationType, int lpAcctKey)
        {
            var success = true;

            RecommendationDbAccess db = new RecommendationDbAccess();
            NotificationLogic notificationLogic = new NotificationLogic();
            RecommendationLogic recLogic = new RecommendationLogic();
            List<int> internalNotificationIds = new List<int>();

            RecommendationResponseBatch batch = recLogic.CreateRecommendationResponseBatchRecord(sender, notificationType, Constants.NotificationOption.NotificationOnly, String.Empty); ;


            // Convert our RecIds into Recommendation Entities
            List<Recommendation> recommendations = new List<Recommendation>();
            foreach (var id in recIds)
            {
                var r = db.LoadRecommendationById(id);
                recommendations.Add(r);
            }

            var notificationDescription = new StringBuilder();

            switch (notificationType)
            {
                case Constants.RecommendationRequestResponseNotificationType.InitialNotice:
                    notificationDescription.Append(WebPageResources
                        .Recommendations_RequestResponseDescription_InitialNotice);
                    break;

                case Constants.RecommendationRequestResponseNotificationType.Reminder:
                    notificationDescription.Append(WebPageResources
                        .Recommendations_RequestResponseDescription_Reminder);
                    break;

                case Constants.RecommendationRequestResponseNotificationType.UpdateRequest:
                    notificationDescription.Append(WebPageResources
                        .Recommendations_RequestResponseDescription_UpdatedResponseRequest);
                    break;

                case Constants.RecommendationRequestResponseNotificationType.Other:
                    notificationDescription.Append(WebPageResources
                        .Recommendations_RequestResponseDescription_Other);
                    break;
            }

            try
            {

                foreach (var location in locationRecipients)
                {

                    var targetRecommendations = recommendations.Where(x => x.LpAllPiKey == location.Key);

                    foreach (var rec in targetRecommendations)
                    {

                        InternalNotification internalNotification = new InternalNotification
                        {
                            LpAllPiKey = rec.LpAllPiKey,
                            LpRecKey = rec.LpRecKey,
                            NotificationTypeID = notificationType,
                            Description = notificationDescription.ToString()
                        };


                        internalNotification = notificationLogic.UpsertInternalNotification(internalNotification, sender.ID);
                        internalNotificationIds.Add(internalNotification.ID);

                        List<int> recipientIds = new List<int>();
                        var targetRecipients = location.Value;
                        foreach (var user in targetRecipients)
                        {
                            recipientIds.Add(user.UserId);
                            CreateRecommendationResponseHistoryRecord($"User ID {user.UserId}", batch.ID, rec.ID, lpAcctKey);
                        }
                        // finally generate the individual Notification-User records (based on users prefs)
                        success = true;
                    }

                }



            }
            catch (Exception ex)
            {
                LogHelper.Error("RecommendationLogic.RecommendationResponseRequested", ex);
            }

            return success;
        }

        #endregion

        #region Import Spreadsheet

        private bool RecommendationHasExpired(Recommendation recommendation, DateTime spreadsheetDownloadDate)
        {
            var allUpdates = LoadRecommendationUpdatesByRecommendation(recommendation.LpRecKey, recommendation.LpAllPiKey);

            return allUpdates.Any(x => x.CreatedDate >= spreadsheetDownloadDate);
        }

        private RecommendationSpreadsheetRowData ExtractDataForRow(ExcelWorksheet worksheet, List<SpreadsheetValidationInfo> spreadsheetValidationInfo, int rowIndex, List<RecommendationStatu> recStatuses, List<RecommendationType> recTypes, List<RecommendationClientIntent> recClientIntents, List<Recommendation> availableRecommendations, DateTime spreadsheetDownloadDate, bool useLocationNo, string createdBy)
        {
            // guard
            if (IsBlankRow(worksheet, rowIndex))
                return null;

            string locationGapsOrAxaId = "";

            if (worksheet.Cells[rowIndex, 1].Value != null)
            {
                locationGapsOrAxaId = worksheet.Cells[rowIndex, 1].Value.ToString();
                if (String.IsNullOrEmpty(locationGapsOrAxaId))
                {
                    AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, "Invalid Location Id", false); // TODO: Localise exception
                }
            }
            else
            {
                AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, "Invalid or empty Location Id", false);
            }

            string address = "";
            if (worksheet.Cells[rowIndex, 2].Value != null)
            {
                if (String.IsNullOrEmpty(worksheet.Cells[rowIndex, 2].Value.ToString()))
                {
                    AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, "Invalid or empty Address", false); // TODO: Localise exception
                }
                else
                {
                    address = worksheet.Cells[rowIndex, 2].Value.ToString();
                }
            }

            string city = "";
            if (worksheet.Cells[rowIndex, 3].Value != null)
            {
                if (String.IsNullOrEmpty(worksheet.Cells[rowIndex, 3].Value.ToString()))
                {
                    AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, "Invalid or empty City", false); // TODO: Localise exception
                }
                else
                {
                    city = worksheet.Cells[rowIndex, 3].Value.ToString();
                }
            }

            string country = "";
            if (worksheet.Cells[rowIndex, 4].Value != null)
            {
                if (String.IsNullOrEmpty(worksheet.Cells[rowIndex, 4].Value.ToString()))
                {
                    AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, "Invalid or empty Country", false); // TODO: Localise exception
                }
                else
                {
                    country = worksheet.Cells[rowIndex, 4].Value.ToString();
                }
            }

            string recId = "";
            if (worksheet.Cells[rowIndex, 5].Value == null)
            {
                AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, "Empty Rec ID", false); // TODO: Localise exception                       
            }
            else
            {
                recId = worksheet.Cells[rowIndex, 5].Value.ToString();
            }

            RecommendationStatu recStatus = null;
            string recStatusVal = worksheet.Cells[rowIndex, 7].Value?.ToString();

            if (recStatusVal.ToLower().Contains(Constants.RecommendationStatus.NoPlansOrDisagreeClient.ToLower()))
            {
                recStatusVal = Constants.RecommendationStatus.NoPlansOrDisagreeClient;
            }

            if (string.IsNullOrEmpty(recStatusVal) || recStatuses.All(x => x.Name.ToLower() != recStatusVal.ToLower()))
            {
                AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, "Invalid or empty Rec Status", false); // TODO: Localise exception
                recStatus = recStatuses.SingleOrDefault(x => x.ID == Constants.RecommendationStatus.Unknown);
            }
            else
            {
                recStatus = recStatuses.SingleOrDefault(x => x.Name.ToLower() == recStatusVal.ToLower());
            }

            DateTime? targetDate = null;
            if (!String.IsNullOrEmpty(worksheet.Cells[rowIndex, 8].Value?.ToString()))
            {
                var date = DateTimeHelpers.FromExcelSerialDate(Int32.Parse(worksheet.Cells[rowIndex, 8].Value.ToString()));

                targetDate = date;

            }

            string comment = null;
            if (!String.IsNullOrEmpty(worksheet.Cells[rowIndex, 9].Value?.ToString()))
            {
                comment = worksheet.Cells[rowIndex, 9].Value.ToString();
            }


            long? estCostToComplete = null;
            string estCostToCompleteVal = worksheet.Cells[rowIndex, 10].Value?.ToString();

            if (!string.IsNullOrEmpty(estCostToCompleteVal))
                estCostToCompleteVal = Convert.ToString(Convert.ToInt64(worksheet.Cells[rowIndex, 10].Value));

            if (!String.IsNullOrEmpty(estCostToCompleteVal?.Replace(" ", "")))
            {
                estCostToCompleteVal = Regex.Replace(estCostToCompleteVal, "[^0-9.]", "");
                try
                {
                    estCostToComplete = long.Parse(estCostToCompleteVal);
                }
                catch (Exception e)
                {
                    AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, $"Invalid Est Cost to Complete, {e.Message}", false); // TODO: Localise exception
                }
            }

            DateTime? completedDate = null;
            if (!String.IsNullOrEmpty(worksheet.Cells[rowIndex, 11].Value?.ToString()))
            {
                var date = DateTimeHelpers.FromExcelSerialDate(Int32.Parse(worksheet.Cells[rowIndex, 11].Value.ToString()));

                completedDate = date;

            }


            if (completedDate != null)
            {
                if (recStatus.ID != 5)
                {
                    AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, "Completed Date is mandatory only for 'Completed Client' Status", false); // TODO: Localise exception 
                }
            }

            if (completedDate == null)
            {
                if (recStatus.ID == 5)
                {
                    AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, "Completed Date is mandatory for 'Completed Client' Status", false); // TODO: Localise exception 
                }
            }


            long? actualCostToComplete = null;
            string actualCostToCompleteVal = worksheet.Cells[rowIndex, 12].Value?.ToString();

            if (!String.IsNullOrEmpty(actualCostToCompleteVal) && !actualCostToCompleteVal.Contains("-"))
            {
                actualCostToCompleteVal = Regex.Replace(actualCostToCompleteVal, "[^0-9.]", "");

                try
                {
                    actualCostToComplete = long.Parse(actualCostToCompleteVal);
                }
                catch (Exception e)
                {
                    AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, "Invalid or empty actual Cost to Complete", false); // TODO: Localise exception 
                }
            }

            string priority = null;
            if (!String.IsNullOrEmpty(worksheet.Cells[rowIndex, 13].Value?.ToString()))
            {
                priority = worksheet.Cells[rowIndex, 13].Value.ToString();
            }


            // check for any 'Recommendation IDs' in the uploaded data that do not correspond with records in the database
            if (!availableRecommendations.Select(x => x.RecID).Contains(recId))
            {
                AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, "Invalid Recommendation ID - either does not exist or user does not have permission to update this record", false); // TODO: Localise exception 
            }

            Recommendation recommendation = null;

            try
            {
                if (useLocationNo)
                {
                    recommendation = availableRecommendations.FirstOrDefault(x => x.RecID == recId && x.Location.LocationNo == locationGapsOrAxaId);
                }
                else
                {
                    recommendation = availableRecommendations.FirstOrDefault(x => x.RecID == recId && x.Location.LocationCode == locationGapsOrAxaId);
                }
                if (RecommendationHasExpired(recommendation, spreadsheetDownloadDate))
                {
                    // If a recommendation, which has been included on the downloaded template, has been updated on the system in the meantime,
                    // the system ignores that recommendation from the upload and displays a message to request that the user either downloads that
                    // recommendation again or updates it on the system.
                    AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, $"Recommendation with ID {recommendation.RecID} has since been updated within {WebPageResources.App_Name}, as such the updated data for this record will be ignored. Please either download that Recommendation again, or update it within {WebPageResources.App_Name} ", true);
                    return null;
                }
            }
            catch (Exception e)
            {
                AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, $"Exception thrown in obtaining recommendation record: {e.InnerException} {e.Message}", false); // TODO: Localise exception  
            }

            if (recommendation == null)
            {
                AppendExceptionsTextLine(spreadsheetValidationInfo, rowIndex, $"Could not find matching Recommendation record with LocationGapsOrAxaID {locationGapsOrAxaId} and RecID {recId}, useLocationNo in report {useLocationNo}", false); // TODO: Localise exception  
            }

            return new RecommendationSpreadsheetRowData
            {
                RowIndex = rowIndex,
                LocationGapsOrAxaID = locationGapsOrAxaId,
                Country = country,
                City = city,
                TargetDate = targetDate,
                ClientIntentName = "",
                CompletedDate = completedDate,
                ActualCostToComplete = actualCostToComplete,
                EstCostToComplete = estCostToComplete,
                RecommendationID = recId,
                LpAllPiKey = recommendation?.LpAllPiKey,
                ID = recommendation?.ID,
                LpRecKey = recommendation?.LpRecKey,
                RecommendationStatusId = recStatus.ID,
                CreatedBy = createdBy,
                Priority = priority,
                Comment = FormatHelper.HtmlEncode(comment),
                IsThirdParty = recommendation.IsThirdParty
            };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="worksheet"></param>
        /// <param name="rowIndex"></param>
        /// <returns></returns>
        private bool IsBlankRow(ExcelWorksheet worksheet, int rowIndex)
        {
            for (int i = 1; i <= 13; i++)
            {
                if (worksheet.Cells[rowIndex, i].Value != null)
                    return false;
            }

            return true;
        }

        public List<SpreadsheetValidationInfo> ImportRecommendationSpreadsheetReturnExceptions(byte[] spreadsheetData, bool doValidationOnly, UserMerged user, bool useLocationNo)
        {

            List<SpreadsheetValidationInfo> validationInfo = new List<SpreadsheetValidationInfo>();

            using (var memoryStream = new MemoryStream(spreadsheetData))
            {
                using (var package = new ExcelPackage(memoryStream))
                {
                    var worksheetRiskImprovements = package.Workbook.Worksheets[Constants.RecommendationTemplateSpreadsheet.WorksheetNameRecommendations];

                    var lookupTables = package.Workbook.Worksheets[Constants.RecommendationTemplateSpreadsheet.WorksheetNameLookupTables];
                    var spreadSheetDateTime = double.Parse(lookupTables.GetValue(
                        Constants.RecommendationTemplateSpreadsheet.SpreadsheetDownloadDateRowNumber,
                        Constants.RecommendationTemplateSpreadsheet.SpreadsheetDownloadDateColumnNumber).ToString());
                    var spreadsheetDownloadDate = DateTime.FromOADate(spreadSheetDateTime);

                    var referenceListLogic = new ReferenceListLogic();
                    var recStatuses = referenceListLogic.GetRecommendationStatuses(localeSpecific: false);
                    var recTypes = referenceListLogic.GetRecommendationTypes(localeSpecific: false);
                    var recClientIntents = referenceListLogic.GetRecommendationClientIntents(localeSpecific: false);

                    var spreadsheetImportDataList = new List<RecommendationSpreadsheetRowData>();

                    // Get a list of all the available IDs which the user is authenticated to update
                    var availableRecommendations = GetAvailableRecommendationDataForImport(user.ID);


                    //var CreatedDatetime = DateTime.UtcNow;
                    TimeZoneInfo est = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                    var CreatedDatetime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, est);

                    for (int rowIndex = Constants.RecommendationTemplateSpreadsheet.FirstDataRow; rowIndex <= worksheetRiskImprovements.Dimension.Rows; rowIndex++)
                    {
                        try
                        {
                            var createdBy = $"{user.ForeName} {user.Surname}".Length > 40 ?
                            $"{user.ForeName} {user.Surname}".Substring(0, 40) :
                            $"{user.ForeName} {user.Surname}";

                            var row = ExtractDataForRow(worksheetRiskImprovements, validationInfo, rowIndex, recStatuses, recTypes, recClientIntents, availableRecommendations, spreadsheetDownloadDate, useLocationNo, createdBy);

                            if (row != null)
                            {
                                row.CreatedDatetime = CreatedDatetime;

                                try
                                {

                                    var OldRecdata = GetRecommendationDetails(row.LpAllPiKey ?? 0, row.LpRecKey ?? 0);
                                    if (OldRecdata != null)
                                    {
                                        row.OldComment = OldRecdata.CustomerIntentDescription;
                                        row.OldCompletedDate = OldRecdata.CompletedDate;
                                        row.OldECC = OldRecdata.EstCostToComplete;
                                        row.OldTargetDate = OldRecdata.TargetDate;
                                        row.OldPriority = OldRecdata.Priority;
                                        row.OldImpStatus = OldRecdata.RecommendationStatusID;

                                    }

                                }
                                catch (Exception ex)
                                {
                                    LogHelper.Error("RecUpload old Rec data issue", ex);
                                }

                                spreadsheetImportDataList.Add(row);
                            }
                        }
                        catch (Exception ex)
                        {
                            LogHelper.Error("Error extracting row data", ex);
                        }
                    }


                    // Only queue the recommendations on the "actual" upload function where there are no Spreadsheet Errors
                    if (!doValidationOnly && validationInfo.Count(x => x.AllowFurtherProcessing == false) == 0)
                    {
                        // Add the list of messages to the Queue 
                        QueueRecommendationBatch(JsonConvert.SerializeObject(spreadsheetImportDataList));

                        foreach (var update in spreadsheetImportDataList)
                        {
                            // Find matching Recommendation entity
                            Recommendation recommendation = null;

                            if (useLocationNo)
                            {
                                recommendation = availableRecommendations.FirstOrDefault(x => x.RecID == update.RecommendationID && x.Location.LocationNo == update.LocationGapsOrAxaID);
                            }
                            else
                            {
                                recommendation = availableRecommendations.FirstOrDefault(x => x.RecID == update.RecommendationID && x.Location.LocationCode == update.LocationGapsOrAxaID);
                            }


                            bool isSave;
                            RecommendationUpdate ruFromSpreadsheet = GetRecommendationUpdateFromSpreadsheetRow(update, recommendation, user, out isSave);

                            var recommendationUpdate = SaveRecommendationUpdate(ruFromSpreadsheet, isSave);

                            try
                            {
                                if (recommendationUpdate.ID > 0)
                                {
                                    var target = new RecommendationPermanentData();

                                    if (update.LpRecKey != null)
                                    {
                                        target.LpRecKey = (int)update.LpRecKey;
                                    }
                                    if (update.LpAcctKey != null)
                                    {
                                        target.LpAcctKey = (int)update.LpAcctKey;
                                    }
                                    if (update.LpAllPiKey != null)
                                    {
                                        target.LpAllPiKey = (int)update.LpAllPiKey;
                                    }
                                    target.EstCostToComplete = update.EstCostToComplete;
                                    // target.ActCostToComplete = update.ActualCostToComplete;

                                    var recPermanentdata = LoadRecommendationPermanentData(target.LpRecKey, target.LpAllPiKey);

                                    if (recPermanentdata != null)
                                    {

                                        decimal? recActcost = null;

                                        var recActcostLst = recPermanentdata.Where(x => x.LpRecKey == target.LpRecKey && x.LpAllPiKey == target.LpAllPiKey).OrderByDescending(x => x.CreatedDate).ToList();

                                        if (recActcostLst != null)
                                        {
                                            var ismodifed = recActcostLst.Where(x => x.IsModified == true).ToList();
                                            if (ismodifed != null && ismodifed.Count > 0)
                                            {
                                                recActcost = ismodifed.Select(x => x.ActCostToComplete).FirstOrDefault();
                                            }
                                            else
                                            {
                                                recActcost = recActcostLst.Select(x => x.ActCostToComplete).ToList().FirstOrDefault();
                                            }
                                        }


                                        if (recActcost != update.ActualCostToComplete)
                                        {
                                            target.ActCostToComplete = update.ActualCostToComplete;

                                            target.IsModified = true;
                                        }
                                        else
                                        {
                                            target.ActCostToComplete = null;
                                        }
                                    }

                                    target.CreatedDate = CreatedDatetime;
                                    target.RecommendationUpdateID = recommendationUpdate.ID;
                                    SaveRecommendationUpdate(target);
                                }
                            }
                            catch (Exception ex)
                            {
                                LogHelper.Error("Could not update recommendation permanent data from Excel upload", ex);

                            }

                            try
                            {

                                recommendation.EstCostToComplete = update.EstCostToComplete;
                                recommendation.Priority = update.Priority;
                                recommendation.TargetDate = update.TargetDate;
                                recommendation.CompletedDate = update.CompletedDate;
                                recommendation.CustomerIntentDescription = update.Comment;
                                recommendation.RecommendationStatusID = update.RecommendationStatusId;
                               
                                UpdateRecommendationforExcel(recommendation);
                            }
                            catch (Exception ex)
                            {
                                LogHelper.Error("Error on Recommendation uopdate table from Excel upload", ex);

                            }

                        }
                    }

                    return validationInfo;
                }
            }
        }

        private RecommendationUpdate GetRecommendationUpdateFromSpreadsheetRow(RecommendationSpreadsheetRowData update, Recommendation recommendation, UserMerged user, out bool isSave)
        {

            var completedDateChanged = update.CompletedDate != null && recommendation.CompletedDate != update.CompletedDate;
            var estCostToCompleteChanged = recommendation.EstCostToComplete != update.EstCostToComplete;

            recommendation.Priority = string.IsNullOrEmpty(recommendation.Priority) ? "" : recommendation.Priority;
            update.Priority = string.IsNullOrEmpty(update.Priority) ? "" : update.Priority;

            var priorityChanged = recommendation.Priority != update.Priority;
            var recommendationStatusIdChanged = recommendation.RecommendationStatusID != update.RecommendationStatusId;
            var targetDateChanged = recommendation.TargetDate != update.TargetDate;

            var updatedCompletedDate = recommendation.CompletedDate != update.CompletedDate ? update.CompletedDate : null;
            var updatedEstCostToComplete = recommendation.EstCostToComplete != (long?)update.EstCostToComplete ? (long?)update.EstCostToComplete : null;
            var updatedRecommendationStatusId = recommendation.RecommendationStatusID != update.RecommendationStatusId
                ? update.RecommendationStatusId
                : (int?)null;
            var updatedTargetDate = recommendation.TargetDate != update.TargetDate ? update.TargetDate : null;
            var updatedPriority = recommendation.Priority != update.Priority ? update.Priority : null;

            string updatedComments = "";
            try
            {
                //var updates = LoadRecommendationHistory(recommendation.LpRecKey, recommendation.LpAllPiKey);
                var updates = GetRecommendationUpdate(recommendation.LpAllPiKey, recommendation.LpRecKey);

                var RecommendationStatusID = 1;
                foreach (var x in updates)
                {
                    if (x.ImplementationStatus != null)
                    {
                        RecommendationStatusID = x.ImplementationStatus ?? 1;
                        break;
                    }

                }

                var Impstatus = updates?.OrderByDescending(y => y.Date).FirstOrDefault()?.ImplementationStatus;
                var TargetDate = updates?.OrderByDescending(y => y.Date).FirstOrDefault()?.TargetDate;
                var EstCostToComplete = updates?.OrderByDescending(y => y.Date).FirstOrDefault()?.EstCostToComplete;
                var CompletedDate = updates?.OrderByDescending(y => y.Date).FirstOrDefault()?.CompletedDate;
                var Priority = updates?.OrderByDescending(y => y.Date).FirstOrDefault()?.Priority;
                var ActualCostToComplete = updates?.OrderByDescending(y => y.Date).FirstOrDefault()?.ActualCostToComplete;
                var comments = updates?.OrderByDescending(y => y.Date).FirstOrDefault()?.Comments;

                Priority = string.IsNullOrEmpty(Priority) ? "" : Priority;


                bool isPriorityChanged = update.Priority != Priority;
                bool isTargetDate = update.TargetDate != TargetDate;
                bool isCompletedDate = update.CompletedDate != CompletedDate;
                bool isEstCostToComplete = update.EstCostToComplete != EstCostToComplete;
                bool isRecommendationStatusID = update.RecommendationStatusId != RecommendationStatusID;
                bool isACC = update.ActualCostToComplete != ActualCostToComplete;

                isSave = isPriorityChanged || isTargetDate || isCompletedDate || isEstCostToComplete || isRecommendationStatusID || isACC;

                string updtcomment = updates?.OrderByDescending(y => y.Date).FirstOrDefault()?.Comments;

                updtcomment = !string.IsNullOrEmpty(updtcomment) ? FormatHelper.FormatDescriptionForHtmlValue(FormatHelper.HtmlDecode(updtcomment)) : string.Empty;
                var recupdtComment = !string.IsNullOrEmpty(update.Comment) ? FormatHelper.HtmlDecode(update.Comment) : "";

                if (updtcomment.Replace("/r/n", "") != recupdtComment.Replace("/r/n", ""))
                {
                    isSave = true;
                }


                if (!string.IsNullOrEmpty(recommendation.CustomerIntentDescription))
                {
                    updatedComments = recommendation.CustomerIntentDescription != update.Comment ? update.Comment : null;
                }
                else
                {
                    if (updtcomment.Replace("/r/n", "") == recupdtComment.Replace("/r/n", ""))
                    {
                        updatedComments = null;
                    }
                    else
                    {
                        updatedComments = FormatHelper.HtmlEncode(recupdtComment);
                    }
                }


                updatedRecommendationStatusId = updatedRecommendationStatusId != null && updatedRecommendationStatusId == Impstatus ? null : updatedRecommendationStatusId;
                updatedPriority = !string.IsNullOrEmpty(updatedPriority) && updatedPriority == Priority ? null : updatedPriority;
                updatedCompletedDate = updatedCompletedDate != null && updatedCompletedDate == CompletedDate ? null : updatedCompletedDate;
                updatedTargetDate = updatedTargetDate != null && updatedTargetDate == TargetDate ? null : updatedTargetDate;
                updatedEstCostToComplete = updatedEstCostToComplete != null && updatedEstCostToComplete == EstCostToComplete ? null : updatedEstCostToComplete;
                //updatedComments = updatedComments != null && updatedComments == comments ? null : updatedComments;

                var frmtUpdatedComments = FormatHelper.FormatDescriptionForHtmlValue(FormatHelper.HtmlDecode(updatedComments));
                var frmtcomments = FormatHelper.FormatDescriptionForHtmlValue(FormatHelper.HtmlDecode(comments));

                updatedComments = frmtUpdatedComments != null && frmtUpdatedComments == frmtcomments ? null : updatedComments;

            }
            catch (Exception ex)
            {
                isSave = true;
                LogHelper.Error("exception while compare recupdate against recuplaod", ex);
            }

            var recommendationUpdate = new RecommendationUpdate
            {
                Comment = updatedComments,
                CompletedDateChanged = completedDateChanged,
                CreatedBy = user.ID,
                CreatedDate = update.CreatedDatetime,
                EstCostToCompleteChanged = estCostToCompleteChanged,
                LpRecKey = recommendation.LpRecKey,
                LpAllPiKey = recommendation.LpAllPiKey,
                PriorityChanged = priorityChanged,
                RecommendationStatusIDChanged = recommendationStatusIdChanged,
                TargetDateChanged = targetDateChanged,
                UpdatedByName = $"{user.ForeName} {user.Surname}",
                UpdatedByEmail = user.Email ?? "",
                UpdatedCompletedDate = updatedCompletedDate,
                UpdatedEstCostToComplete = updatedEstCostToComplete,
                UpdatedPriority = updatedPriority,
                UpdatedRecommendationStatusID = updatedRecommendationStatusId,
                UpdatedTargetDate = updatedTargetDate

            };



            return recommendationUpdate;
        }


        private List<Recommendation> GetAvailableRecommendationDataForImport(int userId)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

            if (anyLocationsSelectorDataFilter != null)
            {
                RecommendationDbAccess db = new RecommendationDbAccess();
                using (var ma2DbContext = new MA2DbContext())
                {
                    var qry = db.LoadRecommendationDataForCurrentFilters(anyLocationsSelectorDataFilter, null, ma2DbContext);

                    return qry.ToList();
                }
            }
            return new List<Recommendation>();
        }

        private void AppendExceptionsTextLine(List<SpreadsheetValidationInfo> spreadsheetValidationInfo, int rowIndex, string message, bool allowFurtherProcessing)
        {
            spreadsheetValidationInfo.Add(new SpreadsheetValidationInfo()
            {
                Message = $"{WebPageResources.Recommendation_Import_Row} {rowIndex}\t{message} \n",
                AllowFurtherProcessing = allowFurtherProcessing
            });
        }
        #endregion

        #region FS-09 Type/Status Report

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<RecommendationByTypeStatusData> LoadRecommendationByTypeStatusDataChart(DataFilter dataFilter, int userId)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            var series = new List<object>();

            if (anyLocationsSelectorDataFilter != null)
            {
                RecommendationDbAccess db = new RecommendationDbAccess();
                return db.LoadRecommendationByTypeStatusData(anyLocationsSelectorDataFilter, dataFilter, true);
            }

            return null;
        }

        public List<RecommendationSummaryCategory> LoadRecommendationSummaryCategoryData(DataFilter dataFilter, int userId, RecommendationFilters filters, int accountId, string sortOrder = null)
        {

            var referenceListLogic = new ReferenceListLogic();
            var overallStatuses = referenceListLogic.GetRecommendationCategories();
            List<RecommendationSummaryCategory> results = new List<RecommendationSummaryCategory>();

            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter != null)
            {
                AccountLogic objAcclogic = new AccountLogic();
                var account = objAcclogic.GetAccount(accountId);
                var resultCostConfig = objAcclogic.GetAccountCostConfig(account.LpAcctKey);

                RecommendationDbAccess db = new RecommendationDbAccess();
                {
                    var recommendationCategories = db.LoadRecommendationCategory(anyLocationsSelectorDataFilter, dataFilter, filters, accountId, resultCostConfig);

                    foreach (var category in recommendationCategories)
                    {
                        if (category.RecommendationCategoryID == null)
                            continue;

                        results.Add(new RecommendationSummaryCategory
                        {
                            Name = overallStatuses.SingleOrDefault(x => x.ID == category.RecommendationCategoryID)?.Name,
                            Count = category.Count
                        });
                    }

                    results.RemoveAll(x => x.Count == 0);

                    var total = (double)results.Sum(x => x.Count);

                    foreach (var result in results)
                    {
                        result.Percentage = (result.Count / total) * 100;
                    }

                    if (sortOrder != null)
                    {
                        var sortDescending = !string.IsNullOrEmpty(sortOrder)
                                             && sortOrder.ToLower().Contains("desc");

                        if (sortOrder.Contains("Name"))
                            results = sortDescending
                                ? results.OrderByDescending(x => x.Name).ToList()
                                : results.OrderBy(x => x.Name).ToList();

                        if (sortOrder.Contains("Count"))
                            results = sortDescending
                                ? results.OrderByDescending(x => x.Count).ToList()
                                : results.OrderBy(x => x.Count).ToList();

                        if (sortOrder.Contains("Percentage"))
                            results = sortDescending
                                ? results.OrderByDescending(x => x.Percentage).ToList()
                                : results.OrderBy(x => x.Percentage).ToList();

                        return results;
                    }

                    return results.OrderByDescending(x => x.Count).ToList();
                }
            }

            return new List<RecommendationSummaryCategory>();

        }

        public List<RecommendationSummaryCategory> LoadRecommendationSummaryPhysicalCategoryData(DataFilter dataFilter, RecommendationFilters filters, int userId, int accountId, string sortOrder = null)
        {
            var refLogic = new ReferenceListLogic();

            var recommendationTypes = refLogic.GetRecommendationTypes();
            List<RecommendationSummaryCategory> results = new List<RecommendationSummaryCategory>();

            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter != null)
            {
                AccountLogic objAcclogic = new AccountLogic();
                var account = objAcclogic.GetAccount(accountId);
                var resultCostConfig = objAcclogic.GetAccountCostConfig(account.LpAcctKey);

                var db = new RecommendationDbAccess();

                var recommendationGrouping = db.LoadRecommendationCategoryByType(anyLocationsSelectorDataFilter, dataFilter, filters, accountId, CurrentLcid, resultCostConfig);

                var totalCount = 0;
                foreach (var group in recommendationGrouping)
                {
                    results.Add(new RecommendationSummaryCategory
                    {
                        Name = recommendationTypes.FirstOrDefault(x => x.RecommendationTypeGroup == group.RecommendationTypeGroup)?.Name,
                        Count = group.Count
                    });
                    totalCount += group.Count;
                }

                results.RemoveAll(x => x.Count == 0);

                foreach (var res in results)
                {
                    double percentage = res.Count / (double)totalCount * 100;
                    res.Percentage = percentage;
                }

                if (sortOrder != null)
                {
                    var sortDescending = !string.IsNullOrEmpty(sortOrder)
                                         && sortOrder.ToLower().Contains("desc");

                    if (sortOrder.Contains("Name"))
                        results = sortDescending
                            ? results.OrderByDescending(x => x.Name).ToList()
                            : results.OrderBy(x => x.Name).ToList();

                    if (sortOrder.Contains("Count"))
                        results = sortDescending
                            ? results.OrderByDescending(x => x.Count).ToList()
                            : results.OrderBy(x => x.Count).ToList();

                    if (sortOrder.Contains("Percentage"))
                        results = sortDescending
                            ? results.OrderByDescending(x => x.Percentage).ToList()
                            : results.OrderBy(x => x.Percentage).ToList();

                }
                else
                {
                    results = results.OrderByDescending(x => x.Count).ToList();
                }

                double cumulativePercentCount = 0;

                foreach (var res in results)
                {
                    cumulativePercentCount += res.Percentage;
                    res.CumulativePercentage = cumulativePercentCount;
                }

            }

            return results;
        }
        public List<RecommendationSummaryCategory> LoadRecommendationSummaryHumanElementCategoryData(DataFilter dataFilter, RecommendationFilters filters, int userId, int accountId, string sortOrder = null)
        {
            var refLogic = new ReferenceListLogic();
            var recommendationTypes = refLogic.GetRecommendationTypes();

            List<RecommendationSummaryCategory> results = new List<RecommendationSummaryCategory>();

            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter != null)
            {
                AccountLogic objAcclogic = new AccountLogic();
                var account = objAcclogic.GetAccount(accountId);
                var resultCostConfig = objAcclogic.GetAccountCostConfig(account.LpAcctKey);

                var db = new RecommendationDbAccess();

                var recommendationGrouping = db.LoadRecommendationCategoryBySubType(anyLocationsSelectorDataFilter, dataFilter, filters, accountId, CurrentLcid, resultCostConfig);

                var totalCount = 0;
                foreach (var group in recommendationGrouping)
                {
                    results.Add(new RecommendationSummaryCategory
                    {
                        Name = recommendationTypes.FirstOrDefault(x => x.LpRecSubRecTypKey == group.LPRecSubRecTypKey)?.SubRecName,
                        Count = group.Count
                    });
                    totalCount += group.Count;
                }

                results.RemoveAll(x => x.Count == 0);

                foreach (var res in results)
                {
                    double percentage = res.Count / (double)totalCount * 100;
                    res.Percentage = percentage;
                }

                if (sortOrder != null)
                {
                    var sortDescending = !string.IsNullOrEmpty(sortOrder)
                                         && sortOrder.ToLower().Contains("desc");

                    if (sortOrder.Contains("Name"))
                        results = sortDescending
                            ? results.OrderByDescending(x => x.Name).ToList()
                            : results.OrderBy(x => x.Name).ToList();

                    if (sortOrder.Contains("Count"))
                        results = sortDescending
                            ? results.OrderByDescending(x => x.Count).ToList()
                            : results.OrderBy(x => x.Count).ToList();

                    if (sortOrder.Contains("Percentage"))
                        results = sortDescending
                            ? results.OrderByDescending(x => x.Percentage).ToList()
                            : results.OrderBy(x => x.Percentage).ToList();

                }
                else
                {
                    results = results.OrderByDescending(x => x.Count).ToList();
                }

                double cumulativePercentCount = 0;

                foreach (var res in results)
                {
                    cumulativePercentCount += res.Percentage;
                    res.CumulativePercentage = cumulativePercentCount;
                }

            }

            return results;
        }

        public List<RecommendationSummaryLEBeforeCategory> LoadRecommendationSummaryPhysicalLEBefore(DataFilter dataFilter, RecommendationFilters filters, int userId, int accountId, string sortOrder = null)
        {
            List<RecommendationSummaryLEBeforeCategory> results = new List<RecommendationSummaryLEBeforeCategory>();

            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter != null)
            {


                AccountLogic objAcclogic = new AccountLogic();
                var account = objAcclogic.GetAccount(accountId);
                var resultCostConfig = objAcclogic.GetAccountCostConfig(account.LpAcctKey);

                var db = new RecommendationDbAccess();
                var recommendationGrouping = db.LoadRecommendationPhysicalLEBeforeCategories(anyLocationsSelectorDataFilter, dataFilter, filters, accountId, CurrentLcid, resultCostConfig);

                var totalCount = 0;
                foreach (var group in recommendationGrouping)
                {
                    string groupName = null;
                    switch (group.EstLEPriorGrouping)
                    {
                        case Constants.LEPriorToImplementationCategory.Blank:
                            groupName = WebPageResources.LossEstimatePriorToCompletionCategory_Blank;
                            break;
                        case Constants.LEPriorToImplementationCategory.Low:
                            groupName = WebPageResources.LossEstimatePriorToCompletionCategory_Low;
                            break;
                        case Constants.LEPriorToImplementationCategory.Medium:
                            groupName = WebPageResources.LossEstimatePriorToCompletionCategory_Medium;
                            break;
                        case Constants.LEPriorToImplementationCategory.High:
                            groupName = WebPageResources.LossEstimatePriorToCompletionCategory_High;
                            break;
                        case Constants.LEPriorToImplementationCategory.Critical:
                            groupName = WebPageResources.LossEstimatePriorToCompletionCategory_Critical;
                            break;
                    }

                    results.Add(new RecommendationSummaryLEBeforeCategory
                    {
                        GroupDisplayName = groupName,
                        Count = group.Count,
                        TotalValue = group.TotalValue
                    });
                    totalCount += group.Count;
                }

                foreach (var res in results)
                {
                    double percentage = res.Count / (double)totalCount * 100;
                    res.Percentage = percentage;
                }

                if (sortOrder != null)
                {
                    var sortDescending = !string.IsNullOrEmpty(sortOrder)
                                         && sortOrder.ToLower().Contains("desc");

                    if (sortOrder.Contains("Name"))
                        results = sortDescending
                            ? results.OrderByDescending(x => x.GroupDisplayName).ToList()
                            : results.OrderBy(x => x.GroupDisplayName).ToList();

                    if (sortOrder.Contains("Count"))
                        results = sortDescending
                            ? results.OrderByDescending(x => x.Count).ToList()
                            : results.OrderBy(x => x.Count).ToList();

                    if (sortOrder.Contains("Percentage"))
                        results = sortDescending
                            ? results.OrderByDescending(x => x.Percentage).ToList()
                            : results.OrderBy(x => x.Percentage).ToList();

                }
                else
                {
                    results = results.OrderBy(x => x.EstLEPriorGrouping).ToList();
                }

                double cumulativePercentCount = 0;

                foreach (var res in results)
                {
                    cumulativePercentCount += res.Percentage;
                    res.CumulativePercentage = cumulativePercentCount;
                }

            }

            return results;
        }


        public List<RecommendationSummaryEstCostCategory> LoadRecommendationSummaryPhysicalEstCost(DataFilter dataFilter, RecommendationFilters filters, int userId, int accountId, string sortOrder = null)
        {

            List<RecommendationSummaryEstCostCategory> results = new List<RecommendationSummaryEstCostCategory>();

            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter != null)
            {
                var db = new RecommendationDbAccess();

                AccountLogic objAcclogic = new AccountLogic();
                var account = objAcclogic.GetAccount(accountId);
                var resultCostConfig = objAcclogic.GetAccountCostConfig(account.LpAcctKey);

                var recommendationGrouping = db.LoadRecommendationPhysicalEstCostCategories(anyLocationsSelectorDataFilter, dataFilter, filters, accountId, CurrentLcid, resultCostConfig);

                var totalCount = 0;
                foreach (var group in recommendationGrouping)
                {
                    string groupName = null;
                    switch (group.EstCostToCompleteGrouping)
                    {
                        case Constants.EstimatedCostToCompleteCategory.Blank:
                            groupName = WebPageResources.EstCostToCompleteCategory_Blank;
                            break;
                        case Constants.EstimatedCostToCompleteCategory.Low:
                            groupName = WebPageResources.EstCostToCompleteCategory_Low;
                            break;
                        case Constants.EstimatedCostToCompleteCategory.Medium:
                            groupName = WebPageResources.EstCostToCompleteCategory_Medium;
                            break;
                        case Constants.EstimatedCostToCompleteCategory.High:
                            groupName = WebPageResources.EstCostToCompleteCategory_High;
                            break;
                    }
                    results.Add(new RecommendationSummaryEstCostCategory
                    {
                        GroupDisplayName = groupName,
                        Count = group.Count,
                        TotalValue = group.TotalValue
                    });
                    totalCount += group.Count;
                }

                foreach (var res in results)
                {
                    double percentage = res.Count / (double)totalCount * 100;
                    res.Percentage = percentage;
                }

                if (sortOrder != null)
                {
                    var sortDescending = !string.IsNullOrEmpty(sortOrder)
                                         && sortOrder.ToLower().Contains("desc");

                    if (sortOrder.Contains("Name"))
                        results = sortDescending
                            ? results.OrderByDescending(x => x.GroupDisplayName).ToList()
                            : results.OrderBy(x => x.GroupDisplayName).ToList();

                    if (sortOrder.Contains("Count"))
                        results = sortDescending
                            ? results.OrderByDescending(x => x.Count).ToList()
                            : results.OrderBy(x => x.Count).ToList();

                    if (sortOrder.Contains("Percentage"))
                        results = sortDescending
                            ? results.OrderByDescending(x => x.Percentage).ToList()
                            : results.OrderBy(x => x.Percentage).ToList();

                }
                else
                {
                    results = results.OrderByDescending(x => x.EstCostToCompleteGrouping).ToList();
                }

                double cumulativePercentCount = 0;

                foreach (var res in results)
                {
                    cumulativePercentCount += res.Percentage;
                    res.CumulativePercentage = cumulativePercentCount;
                }

            }

            return results;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public DataTable LoadRecommendationByTypeStatusDataTable(DataFilter dataFilter, int userId)
        {
            var data = LoadRecommendationByTypeStatusDataChart(dataFilter, userId);

            if (data != null)
            {
                var datatable = new DataTable();
                datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Recommendations_RecommendationByTypeStatusDataTable_Header_Status });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Recommendations_RecommendationByTypeStatusDataTable_Header_Physical });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.Recommendations_RecommendationByTypeStatusDataTable_Header_Human });

                var dataSet = (from d in data
                               select new
                               {
                                   d.RecommendationStatusName,
                                   d.RecommendationCategoriesPhysical,
                                   d.RecommendationCategoriesHuman
                               }).ToList();

                foreach (var item in dataSet)
                {
                    datatable.Rows.Add(new object[]
                    {
                        item.RecommendationStatusName, item.RecommendationCategoriesPhysical,
                        item.RecommendationCategoriesHuman
                    });
                }

                return datatable;
            }

            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <param name="dataFilters"></param>
        /// <returns></returns>
        public List<RecommendationByCategoryData> LoadRecommendationByCategoryDataChart(DataFilter dataFilter, int userId, string dataFilters)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

            // retrieve the category the user selected
            int recommendationCategoryId = 0;

            if (!string.IsNullOrEmpty(dataFilters))
            {
                var kvp = JsonConvert.DeserializeObject<Dictionary<string, string>>(dataFilters);

                if (kvp.ContainsKey("selectedRecommendationCategoryId"))
                {
                    if (int.TryParse(kvp["selectedRecommendationCategoryId"], out int parsedRecommendationCategoryId))
                        recommendationCategoryId = parsedRecommendationCategoryId;
                }
            }

            if (anyLocationsSelectorDataFilter != null)
            {
                RecommendationDbAccess db = new RecommendationDbAccess();
                return db.LoadRecommendationByCategoryData(anyLocationsSelectorDataFilter, dataFilter, recommendationCategoryId, true);
            }

            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <param name="dataFilters"></param>
        /// <returns></returns>
        public DataTable LoadRecommendationByCategoryDataTable(DataFilter dataFilter, int userId, string dataFilters)
        {
            var data = LoadRecommendationByCategoryDataChart(dataFilter, userId, dataFilters);

            if (data != null)
            {
                var datatable = new DataTable();
                datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Recommendations_RecommendationByTypeStatusDataTable_Header_Status });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Recommendations_RecommendationByTypeStatusDataTable_Header_Category });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.Recommendations_RecommendationByTypeStatusDataTable_Header_Type });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field4", Caption = WebPageResources.Recommendations_RecommendationByTypeStatusDataTable_Header_Value });

                var dataSet = (from d in data
                               select new
                               {
                                   d.RecommendationStatusName,
                                   d.RecommendationCategoryName,
                                   d.RecommendationByCategoryDataRecommendationTypes,
                               }).ToList();

                foreach (var item in dataSet)
                {
                    foreach (var type in item.RecommendationByCategoryDataRecommendationTypes)
                    {
                        datatable.Rows.Add(new object[]
                        {
                            item.RecommendationStatusName,
                            item.RecommendationCategoryName,
                            type.RecommendationTypeName,
                            type.RecommendationTypeTotal
                        });
                    }
                }

                return datatable;
            }

            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <param name="dataFilters"></param>
        /// <returns></returns>
        public List<RecommendationByStatusData> LoadRecommendationByStatusDataChart(DataFilter dataFilter, int userId, string dataFilters)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

            // retrieve the category the user selected
            int recommendationCategoryId = 0;
            int selectedRecommendationStatusId = 0;

            if (!string.IsNullOrEmpty(dataFilters))
            {
                var kvp = JsonConvert.DeserializeObject<Dictionary<string, string>>(dataFilters);

                if (kvp.ContainsKey("selectedRecommendationCategoryId"))
                {
                    if (int.TryParse(kvp["selectedRecommendationCategoryId"], out int parsedRecommendationCategoryId))
                        recommendationCategoryId = parsedRecommendationCategoryId;
                }

                if (kvp.ContainsKey("selectedRecommendationStatusId"))
                {
                    if (int.TryParse(kvp["selectedRecommendationStatusId"], out int parsedRecommendationStatusId))
                        selectedRecommendationStatusId = parsedRecommendationStatusId;
                }
            }

            if (anyLocationsSelectorDataFilter != null)
            {
                RecommendationDbAccess db = new RecommendationDbAccess();
                return db.LoadRecommendationByStatusData(anyLocationsSelectorDataFilter, dataFilter, recommendationCategoryId, selectedRecommendationStatusId);
            }

            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <param name="dataFilters"></param>
        /// <returns></returns>
        public DataTable LoadRecommendationByStatusDataTable(DataFilter dataFilter, int userId, string dataFilters)
        {
            var data = LoadRecommendationByStatusDataChart(dataFilter, userId, dataFilters);

            if (data != null)
            {
                var datatable = new DataTable();
                datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Recommendations_RecommendationByTypeStatusDataTable_Header_Status });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Recommendations_RecommendationByTypeStatusDataTable_Header_Category });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.Recommendations_RecommendationByTypeStatusDataTable_Header_Type });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field4", Caption = WebPageResources.Recommendations_RecommendationByTypeStatusDataTable_Header_Value });

                var dataSet = (from d in data
                               select new
                               {
                                   d.RecommendationStatusName,
                                   d.RecommendationCategoryName,
                                   d.RecommendationByStatusDataRecommendationTypes,
                               }).ToList();

                foreach (var item in dataSet)
                {
                    foreach (var type in item.RecommendationByStatusDataRecommendationTypes)
                    {
                        datatable.Rows.Add(new object[]
                        {
                            item.RecommendationStatusName,
                            item.RecommendationCategoryName,
                            type.RecommendationTypeName,
                            type.RecommendationTypeTotal
                        });
                    }
                }

                return datatable;
            }

            return null;
        }

        #endregion

        #region Recommendation Export

        public byte[] ExportRecommendationSummaryAsSpreadsheet(List<Recommendation> recommendations, out string filename, bool useLocationNo, bool useAccountNo)
        {
            var template = GetTemplateStream();
            var editibleCells = new string[] { "G", "H", "I", "J", "K", "L", "M" };
            string AccountID = string.Empty;
            var refLogic = new ReferenceListLogic();
            var intents = refLogic.GetRecommendationStatuses();

            using (var memory = new MemoryStream())
            {
                using (var package = new ExcelPackage(memory, template))
                {
                    var recommendationsWorksheet = package.Workbook.Worksheets[Constants.RecommendationTemplateSpreadsheet.WorksheetNameRecommendations];
                    var lookupTables = package.Workbook.Worksheets[Constants.RecommendationTemplateSpreadsheet.WorksheetNameLookupTables];

                    var spreadsheetRowData = recommendations.Select(recommendation => new RecommendationSpreadsheetRowData
                    {
                        LocationGapsOrAxaID = useLocationNo ? recommendation.Location.LocationNo : recommendation.Location.LocationCode,
                        Address = recommendation.Location?.AddressLine1,
                        City = recommendation.Location.City,
                        Country = recommendation.Location.Country,
                        RecommendationID = recommendation.RecID,
                        RecommendationType = recommendation.Summary,
                        RecommendationStatus = intents.SingleOrDefault(y => y.ID == RechistorystatusID(recommendation.LpRecKey, recommendation.LpAllPiKey))?.Name,
                        TargetDate = GetRecommendationUpdate(recommendation.LpAllPiKey, recommendation.LpRecKey).OrderByDescending(x => x.Date).Select(x => x.TargetDate).FirstOrDefault(),
                        //Comment = FormatHelper.FormatDescriptionForHtmlValue(FormatHelper.HtmlDecode(GetRecommendationUpdate(recommendation.LpAllPiKey, recommendation.LpRecKey).OrderByDescending(x => x.Date).Select(x => x.Comments).FirstOrDefault())),
                        Comment = FormatHelper.FormatDescriptionForHtmlValue(FormatHelper.HtmlDecode(recommendation.CustomerIntentDescription)),
                        EstCostToComplete = GetRecommendationUpdate(recommendation.LpAllPiKey, recommendation.LpRecKey).OrderByDescending(x => x.Date).Select(x => x.EstCostToComplete).FirstOrDefault(),
                        CompletedDate = GetRecommendationUpdate(recommendation.LpAllPiKey, recommendation.LpRecKey).OrderByDescending(x => x.Date).Select(x => x.CompletedDate).FirstOrDefault(),
                        ActualCostToComplete = GetRecommendationUpdate(recommendation.LpAllPiKey, recommendation.LpRecKey).OrderByDescending(x => x.Date).Select(x => x.ActualCostToComplete).FirstOrDefault(),
                        Priority = GetRecommendationUpdate(recommendation.LpAllPiKey, recommendation.LpRecKey).OrderByDescending(x => x.Date).Select(x => x.Priority).FirstOrDefault(),


                    }).ToList();


                    if (useAccountNo)
                        AccountID = recommendations.Select(r => r.Account.AccountNo).FirstOrDefault();
                    else
                        AccountID = recommendations.Select(r => r.Account.AccountCode).FirstOrDefault();
                    var AccountName = recommendations.Select(r => r.Account.Name).FirstOrDefault();

                    if (!string.IsNullOrEmpty(AccountName))
                    {
                        recommendationsWorksheet.Cells[1, 1].Value = AccountID + " & " + AccountName;
                    }

                    recommendationsWorksheet.Cells["A1:D1"].Merge = true;

                    recommendationsWorksheet.Cells["A3"].LoadFromCollection(spreadsheetRowData);
                    recommendationsWorksheet.Cells.AutoFitColumns();

                    // Add back in the styles for cells which may have been populated (and thus lost their templated format)
                    var colFromHex = ColorTranslator.FromHtml("#FFCB97");

                    foreach (var editibleCell in editibleCells)
                    {
                        if (recommendations.Count > 0)
                        {
                            recommendationsWorksheet.Cells[$"{editibleCell}3:{editibleCell}{recommendations.Count + 2}"].Style.Fill.PatternType = ExcelFillStyle.Solid;
                            recommendationsWorksheet.Cells[$"{editibleCell}3:{editibleCell}{recommendations.Count + 2}"].Style.Fill.BackgroundColor.SetColor(colFromHex);
                        }
                    }

                    // set the current date when the worksheet was downloaded, to track expiry
                    lookupTables.SetValue(Constants.RecommendationTemplateSpreadsheet.SpreadsheetDownloadDateRowNumber,
                        Constants.RecommendationTemplateSpreadsheet.SpreadsheetDownloadDateColumnNumber, DateTime.UtcNow.ToOADate());

                    // lock the "Lookup Tables" worksheet
                    lookupTables.Protection.SetPassword(ConfigurationManager.AppSettings["ExcelSpreadsheetUnlockKey"]);

                    recommendationsWorksheet.Protection.IsProtected = true;   // Protect whole sheet                  

                    int sRowid = 3;
                    // Estimated Cost to Complete
                    int firstRowId = Constants.RecommendationTemplateSpreadsheet.FirstDataRow;
                    for (int i = 0; i < spreadsheetRowData.Count; i++)
                    {
                        int statusId = spreadsheetRowData[i].RecommendationStatusId;
                        int rowId = firstRowId + i;
                        int estimatedCostToCompleteCol = 9;

                        bool completedClient = statusId == Constants.RecommendationStatus.CompletedClient; // only unlock Estimated Cost to Complete for Recs with status Completed Client
                        recommendationsWorksheet.Cells[rowId, estimatedCostToCompleteCol].Style.Locked = !completedClient;

                        if (completedClient)
                        {
                            recommendationsWorksheet.Cells[rowId, estimatedCostToCompleteCol].Style.Fill.PatternType =
                                ExcelFillStyle.Solid;
                            recommendationsWorksheet.Cells[rowId, estimatedCostToCompleteCol].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(255, 204, 154));
                        }

                        int clearrow = sRowid + i;
                        recommendationsWorksheet.Cells[clearrow, 15].Clear();
                        recommendationsWorksheet.Cells[clearrow, 23].Clear();
                        recommendationsWorksheet.Cells[clearrow, 26].Clear();

                        recommendationsWorksheet.Cells[clearrow, 7].Style.Locked = false;  // Implementaion Status
                        recommendationsWorksheet.Cells[clearrow, 8].Style.Locked = false;  // Target Date
                        recommendationsWorksheet.Cells[clearrow, 9].Style.Locked = false;  // Comments
                        recommendationsWorksheet.Cells[clearrow, 10].Style.Locked = false; // Estimated Cost to Complete
                        recommendationsWorksheet.Cells[clearrow, 11].Style.Locked = false; // Completed Date
                        recommendationsWorksheet.Cells[clearrow, 12].Style.Locked = false; // Actual Cost To Complete
                        recommendationsWorksheet.Cells[clearrow, 13].Style.Locked = false; // Priority              

                    }

                    recommendationsWorksheet.Column(2).Width = 17.20;
                    recommendationsWorksheet.Column(6).Width = 25.75;
                    recommendationsWorksheet.Column(9).Width = 30.75;

                    recommendationsWorksheet.Column(6).Style.WrapText = false;
                    recommendationsWorksheet.Column(9).Style.WrapText = true;
                    recommendationsWorksheet.Select("A1");
                    recommendationsWorksheet.Protection.AllowAutoFilter = true;

                    recommendationsWorksheet.Protection.SetPassword(ConfigurationManager.AppSettings["ExcelSpreadsheetUnlockKey"]);


                    recommendationsWorksheet.Workbook.Worksheets["Lookup Tables"].Hidden = eWorkSheetHidden.Hidden;
                    filename = $"Recommendation_Summary_{DateTime.Now.Day}_{DateTime.Now.Month}_{DateTime.Now.Year}_" +
                               $"{DateTime.Now.Hour}_{DateTime.Now.Minute}_{DateTime.Now.Second}.xlsx";
                    return package.GetAsByteArray();
                }
            }
        }

        private int RechistorystatusID(int lPRecKey, int lPAllPiKey)
        {
            int RecommendationStatusID = 1;

            try
            {
                var recommendationLogic = new RecommendationLogic();

                var updates = recommendationLogic.LoadRecommendationHistory(lPRecKey, lPAllPiKey);


                foreach (var x in updates)
                {
                    if (x.ImplementationStatus != null)
                    {
                        RecommendationStatusID = x.ImplementationStatus ?? 1;
                        break;
                    }

                }

                return RecommendationStatusID;
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error in method  Rechistorystatus", ex);
                return RecommendationStatusID;
            }
        }

        private Stream GetTemplateStream()
        {
            var assembly = Assembly.GetExecutingAssembly();
            const string templateLocation = "XLC.MyAnalysis2.Logic.ExportTemplates.RecommendationSummaryTemplate.xlsm";

            var stream = assembly.GetManifestResourceStream(templateLocation);
            return stream;
        }

        private class RecommendationSpreadsheetRowData
        {

            public string LocationGapsOrAxaID { get; set; }

            public string Address { get; set; }

            public string City { get; set; }

            public string Country { get; set; }

            public string RecommendationID { get; set; }

            public string RecommendationType { get; set; }

            public string RecommendationStatus { get; set; }
            public DateTime? TargetDate { get; set; }

            public string Comment { get; set; }

            public long? EstCostToComplete { get; set; }
            public DateTime? CompletedDate { get; set; }

            public long? ActualCostToComplete { get; set; }
            public string Priority { get; set; }

            public string DetailedRecommendation { get; set; }

            public DateTime IssuedDate { get; set; }

            public String ClientIntentName { get; set; }

            public string RcbaPdBefore { get; set; }

            public string RcbaBiBefore { get; set; }

            public string RcbaPdAfter { get; set; }

            public string RcbaBiAfter { get; set; }

            public string RcbaEeBefore { get; set; }

            public string RcbaEeAfter { get; set; }

            public int RowIndex { get; set; }
            public int? ID { get; set; }
            public string RecSummary { get; set; }

            public int RecommendationStatusId
            {
                get;
                set;
            }
            public int? LpAcctKey { get; set; }
            public int? LpAllPiKey { get; set; }
            public int? LpRecKey { get; set; }
            public string CreatedBy { get; set; }
            public DateTime CreatedDatetime { get; set; }
            public bool IsThirdParty { get; set; } // IsThirdParty


            public long? OldECC { get; set; } // EstCostToComplete
            public System.DateTime? OldTargetDate { get; set; } // TargetDate
            public System.DateTime? OldCompletedDate { get; set; } // CompletedDate
            public string OldPriority { get; set; } // Priority (length: 75)
            public string OldComment { get; set; }
            public int OldImpStatus { get; set; }
        }

        #endregion
    }



}

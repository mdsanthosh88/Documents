﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using XLC.MyAnalysis2.DbAccess;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.DbModels.DbEnums;
using XLC.MyAnalysis2.Logic.DTO;
using XLC.MyAnalysis2.Resources;
using XLC.MyAnalysis2.Shared;
using static XLC.MyAnalysis2.DbModels.DbConstants.Constants;

namespace XLC.MyAnalysis2.Logic
{
    public class DashboardLogic : BaseLogic
    {
        #region Load

        public DivisionSubDivisionLocationKeys LoadDivisionSubDivisionLocationKeysForCurrentFilters(DataFilter dataFilter, int userId)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

            var divisionSubDivisionLocationKeys = new DivisionSubDivisionLocationKeys
            {
                LpAcctWebDivKeys = new List<int>(),
                LpSubDivKeys = new List<int>(),
                LPAcctDivGroupKeyRegions = new List<int>(),
                LPAcctDivGroupKeyClassifications = new List<int>(),
                LPAcctDivGroupKeyOtherProviders = new List<int>(),
                LpAllPiKeys = new List<int>()
            };

            if (anyLocationsSelectorDataFilter != null)
            {
                using (var dbContext = new MA2DbContext())
                {
                    DashboardDbAccess db = new DashboardDbAccess();
                    var locationDataBaseQuery = db.LoadLocationDataForCurrentFiltersBaseQuery(dbContext, anyLocationsSelectorDataFilter, dataFilter);

                    // Division
                    divisionSubDivisionLocationKeys.LpAcctWebDivKeys =
                        locationDataBaseQuery.Where(loc => loc.LpAcctWebDivKey != null)
                            .Select(loc => (int)loc.LpAcctWebDivKey)
                            .Distinct()
                            .ToList();

                    // Sub Division
                    divisionSubDivisionLocationKeys.LpSubDivKeys =
                        locationDataBaseQuery.Where(loc => loc.LPsubDivKey != null)
                            .Select(loc => (int)loc.LPsubDivKey)
                            .Distinct()
                            .ToList();

                    // Region
                    divisionSubDivisionLocationKeys.LPAcctDivGroupKeyRegions =
                        locationDataBaseQuery.Where(loc => loc.LpAcctDivGroupKeyRegion != null)
                            .Select(loc => (int)loc.LpAcctDivGroupKeyRegion)
                            .Distinct()
                            .ToList();

                    // Classification
                    divisionSubDivisionLocationKeys.LPAcctDivGroupKeyClassifications =
                        locationDataBaseQuery.Where(loc => loc.LpAcctDivGroupKeyClassification != null)
                            .Select(loc => (int)loc.LpAcctDivGroupKeyClassification)
                            .Distinct()
                            .ToList();

                    // Other Provider
                    divisionSubDivisionLocationKeys.LPAcctDivGroupKeyOtherProviders =
                        locationDataBaseQuery.Where(loc => loc.LpAcctDivGroupKeyOtherProvider != null)
                            .Select(loc => (int)loc.LpAcctDivGroupKeyOtherProvider)
                            .Distinct()
                            .ToList();

                    // Location
                    divisionSubDivisionLocationKeys.LpAllPiKeys =
                        locationDataBaseQuery.Select(loc => (int)loc.LpAllPiKey)
                            .Distinct()
                            .ToList();
                }
            }

            return divisionSubDivisionLocationKeys;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<DashboardRecommendationByStatusData> LoadTileRecommendationByStatusData(DataFilter dataFilter, int userId, int lpAcctkey)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            var series = new List<object>();

            if (anyLocationsSelectorDataFilter != null)
            {
                DashboardDbAccess db = new DashboardDbAccess();
                return db.LoadTileRecommendationByStatusData(anyLocationsSelectorDataFilter, dataFilter, lpAcctkey);
            }

            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public DataTable LoadTileRecommendationByStatusDataDataTable(DataFilter dataFilter, int userId, int lpAcctkey)
        {
            var data = LoadTileRecommendationByStatusData(dataFilter, userId, lpAcctkey);

            if (data != null)
            {
                var datatable = new DataTable();
                datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Dashboard_RecommendationByStatusDataTable_Header_Status });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Dashboard_RecommendationByStatusDataTable_Header_Total });
                var dataSet = (from d in data
                               select new
                               {
                                   d.RecommendationStatusName,
                                   d.Total
                               }).ToList();

                foreach (var item in dataSet)
                {
                    datatable.Rows.Add(new object[]
                    {
                        item.RecommendationStatusName, item.Total
                    });
                }

                return datatable;
            }

            return null;
        }

        /// <summary>
        /// USER STORY 109973
        /// Gather main data for Dashboard NATCAT tile
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<DashboardNatCatData> LoadTileNaturalCatastropheData(DataFilter dataFilter, int userId)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

            if (anyLocationsSelectorDataFilter != null)
            {
                DashboardDbAccess db = new DashboardDbAccess();
                return db.LoadTileNaturalCatastropheData(anyLocationsSelectorDataFilter, dataFilter);
            }

            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public DataTable LoadTileNaturalCatastropheDataDataTable(DataFilter dataFilter, int userId,bool IsNotEvaluated)
        {
            var data = IsNotEvaluated == false ? LoadTileNaturalCatastropheData(dataFilter, userId).Where(x => x.ExpectationLevel != 5).ToList() : LoadTileNaturalCatastropheData(dataFilter, userId);

            if (data != null)
            {
                var datatable = new DataTable();
                datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Dashboard_NaturalCatastropheData_Header_NatCatType });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Dashboard_NaturalCatastropheData_Header_ExpectationLevel });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.Dashboard_NaturalCatastropheData_Header_LocationCount });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field4", Caption = WebPageResources.Dashboard_NaturalCatastropheData_Header_LocationCountPercentage });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field5", Caption = WebPageResources.Dashboard_NaturalCatastropheData_Header_LocationTIV });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field6", Caption = WebPageResources.Dashboard_NaturalCatastropheData_Header_LocationTIVPercentage });


                var dataSet = (from d in data
                               select new
                               {
                                   d.NatCatTypeNameLocalised,
                                   d.ExpectationLevelNameLocalised,
                                   d.LocationCount,
                                   d.LocationCountPerc,
                                   d.LocationTIV,
                                   d.LocationTIVPerc
                               }).ToList();

                foreach (var item in dataSet)
                {
                    datatable.Rows.Add(new object[]
                    {
                            item.NatCatTypeNameLocalised,
                            item.ExpectationLevelNameLocalised,
                            item.LocationCount,
                            item.LocationCountPerc,
                            FormatHelper.FormatCurrency(item.LocationTIV),
                            item.LocationTIVPerc
                    });
                }

                return datatable;
            }

            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <param name="lPAcctKey"></param>
        /// <param name="filters"></param>
        /// <param name="useLocationNo"></param>
        /// <returns></returns>
        public List<DashboardLoadTileRiskQualityRatingData> LoadTileRiskQualityRatingData(DataFilter dataFilter, int userId, int lPAcctKey, PagedRiskQualityRatingFilters filters, bool useLocationNo)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

            if (anyLocationsSelectorDataFilter != null)
            {
                AccountLogic accountLogic = new AccountLogic();
                LocationLogic locLogic = new LocationLogic(this.UserName);
                RiskQualityLogic riskQualityLogic = new RiskQualityLogic();
                PagingInfo paging = new PagingInfo(0, int.MaxValue);

                RiskQualityFilters level4FiltersAccount = new RiskQualityFilters
                {
                    AsOfFilter = filters.RQR_FromDateFilter,
                    CurrentLocationCategoryRating = new List<int>() { RiskQualityRatingFilters.CurrentLocationCategoryRating.All },
                    TivQuartilesFilter =  new List<int> { Constants.RiskQualityRatingFilters.TivQuartile.All}
                };

                RiskQualityFilters level4FiltersLocation = new RiskQualityFilters
                {
                    AsOfFilter = filters.RQR_FromDateFilter,
                    CurrentLocationCategoryRating = 
                        filters.CurrentRqrRatingsFilter != null && filters.CurrentRqrRatingsFilter.Count > 0 ? 
                            filters.CurrentRqrRatingsFilter : 
                            new List<int>() { RiskQualityRatingFilters.CurrentLocationCategoryRating.All },
                    TivQuartilesFilter = new List<int> { Constants.RiskQualityRatingFilters.TivQuartile.All }
                };

                // Load ALL Locations for Account and Division points
                var account = accountLogic.GetByLpAcctKey(lPAcctKey);
                var lpAllPiKeys = account.Locations.Select(loc => loc.LpAllPiKey).ToList();

                var rqrLevel4Account = riskQualityLogic.LoadRqrLqrLevelFourData(paging, dataFilter, account.ID, lPAcctKey, userId, level4FiltersAccount, "LocationName ASC", false, lpAllPiKeys);
                var rqrLevel4Location = riskQualityLogic.LoadRqrLqrLevelFourData(paging, dataFilter, account.ID, lPAcctKey, userId, level4FiltersLocation, "LocationName ASC", false, lpAllPiKeys);

                // Load selected Locations/Divisions given the users Location Picker
                var divisionSubDivisionLocationKeys = LoadDivisionSubDivisionLocationKeysForCurrentFilters(dataFilter, userId);
                var selectedLocations = divisionSubDivisionLocationKeys.LpAllPiKeys;
                var selectedDivisionLocations = locLogic.GetLocationsByLpAcctKey(lPAcctKey).Where(item => item.LpAcctKey == lPAcctKey && item.LpAcctWebDivKey != null && divisionSubDivisionLocationKeys.LpAcctWebDivKeys.Contains(item.LpAcctWebDivKey.Value)).Select(loc => loc.LpAllPiKey);

                var locations = rqrLevel4Location.Where(item => selectedLocations.Contains(item.LPAllPiKey)).ToList();
                var divisionLocations = rqrLevel4Account.Where(item => selectedDivisionLocations.Contains(item.LPAllPiKey)).ToList();

                // Filter percentile TIV data
                if (filters.CurrentRqrTivFilter != null && filters.CurrentRqrTivFilter.Count > 0)
                {
                    locations = FilterLoadRiskQualityRatingDataPercentiles(locations, filters);
                    divisionLocations = FilterLoadRiskQualityRatingDataPercentiles(divisionLocations, filters);
                }

                var series = new List<DashboardLoadTileRiskQualityRatingData>
                {
                    LoadRiskQualityRatingData(locations, account, useLocationNo, "Locations", WebPageResources.RiskQualityRatings_MyLocations),
                    LoadRiskQualityRatingData(divisionLocations, account, useLocationNo, "Divisions", WebPageResources.RiskQualityRatings_MyDivisions),
                    LoadRiskQualityRatingData(rqrLevel4Account, account, useLocationNo, "Account", @WebPageResources.RiskQualityRatings_AccountAll)
                };

                return series.ToList();
            }

            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="account"></param>
        /// <param name="useLocationNo"></param>
        /// <param name="reference"></param>
        /// <param name="displayName"></param>
        /// <returns></returns>
        private DashboardLoadTileRiskQualityRatingData LoadRiskQualityRatingData(List<RqrLevel4Data> data, Account account, bool useLocationNo, string reference, string displayName)
        {
            DashboardLoadTileRiskQualityRatingData result = new DashboardLoadTileRiskQualityRatingData
            {
                AccountName = account.Name
            };

            data.RemoveAll(x => x.CurrentRiskQualityRating == null);

            if (data == null || data.Count() == 0)
                return result;

            // sort our results by CurrentRiskQualityRating ASC
            data = data.OrderBy(item => item.CurrentRiskQualityRating).ToList();

            // upper
            var skipUpperQuartile = data.Count() * 3 / 4;
            var upperQuartile = data.Skip(skipUpperQuartile).Take(1).FirstOrDefault();

            // lower
            var skipLowerQuartile = data.Count() * 1 / 4;
            var lowerQuartile = data.Skip(skipLowerQuartile).Take(1).FirstOrDefault();

            // median
            var skipVal = (int)Math.Round(data.Count() * 0.5);
            var median = data.Skip(skipVal).Take(1).FirstOrDefault();

            // division
            var distinctDivisions = data.GroupBy(x => x.DivisionName).Select(x => x.FirstOrDefault()).ToList();

            // sub division
            var distinctSubDivisions = data.GroupBy(x => x.SubDivisionName).Select(x => x.FirstOrDefault()).ToList();

            // location
            var distinctLocations = data.GroupBy(x => x.LPAllPiKey).Select(x => x.FirstOrDefault()).ToList();

            result.Name = reference;
            result.DisplayName = displayName;
            result.CurrentTotal = (decimal)data.Average(item => item.CurrentRiskQualityRating.GetValueOrDefault(0));
            result.Average = result.CurrentTotal;
            result.Maximum = (decimal)data.Max(item => item.CurrentRiskQualityRating.GetValueOrDefault(0));
            if (upperQuartile?.CurrentRiskQualityRating != null)
                result.UpperQuartile = (decimal) upperQuartile.CurrentRiskQualityRating;

            if (median?.CurrentRiskQualityRating != null)
                result.Median = (decimal) median.CurrentRiskQualityRating;

            if (lowerQuartile?.CurrentRiskQualityRating != null)
                result.LowerQuartile = (decimal) lowerQuartile.CurrentRiskQualityRating;

            result.Minimum = (decimal)data.Min(item => item.CurrentRiskQualityRating.GetValueOrDefault(0));

            result.AccountName = account.Name;
            result.DivisionName = distinctDivisions.Count() == 1 ? distinctDivisions[0].DivisionName : WebPageResources.Multiple;
            result.SubDivisionName = distinctSubDivisions.Count() == 1 ? distinctSubDivisions[0].SubDivisionName : WebPageResources.Multiple;
            result.LocationName = distinctLocations.Count() == 1 ? distinctLocations[0].LocationName : WebPageResources.Multiple;
            result.LocationCityName = distinctLocations.Count() == 1 ? distinctLocations[0].City : WebPageResources.Multiple;
            result.LocationCountryName = distinctLocations.Count() == 1 ? distinctLocations[0].Country : WebPageResources.Multiple;
            result.LocationID = distinctLocations.Count() == 1 ? (useLocationNo ? distinctLocations[0].LocationNo : distinctLocations[0].LocationCode) : WebPageResources.Multiple;

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="filters"></param>
        /// <returns></returns>
        private List<RqrLevel4Data> FilterLoadRiskQualityRatingDataPercentiles(List<RqrLevel4Data> data, PagedRiskQualityRatingFilters filters)
        {
            data = data.OrderByDescending(item => item.TotalInsurableValue).ToList();
            var result = new List<RqrLevel4Data>();
            int quarter = Convert.ToInt32(Math.Ceiling((decimal)data.Count * 25 / 100));

            if (filters.CurrentRqrTivFilter.Contains(RiskQualityRatingFilters.TivQuartile.Top0to25))
                result.AddRange(data.Skip(0).Take(quarter).ToList());

            if (filters.CurrentRqrTivFilter.Contains(RiskQualityRatingFilters.TivQuartile.Top26to50))
                result.AddRange(data.Skip(quarter).Take(quarter));

            if (filters.CurrentRqrTivFilter.Contains(RiskQualityRatingFilters.TivQuartile.Top51to75))
                result.AddRange(data.Skip(quarter * 2).Take(quarter));

            if (filters.CurrentRqrTivFilter.Contains(RiskQualityRatingFilters.TivQuartile.Top76to100))
                result.AddRange(data.Skip(quarter * 3).Take(quarter));

            if (filters.CurrentRqrTivFilter.Contains(RiskQualityRatingFilters.TivQuartile.All))
            {
                return data;
            }

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <param name="lPAcctKey"></param>
        /// <param name="filters"></param>
        /// <param name="useLocationNo"></param>
        /// <returns></returns>
        public DataTable LoadTileRiskQualityRatingDataDataTable(DataFilter dataFilter, int userId, int lPAcctKey, PagedRiskQualityRatingFilters filters, bool useLocationNo)
        {
            var data = LoadTileRiskQualityRatingData(dataFilter, userId, lPAcctKey, filters, useLocationNo);

            if (data != null)
            {
                var datatable = new DataTable();
                datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Dashboard_RiskQualityRatingDataDataTable_Header_Level });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Dashboard_RiskQualityRatingDataDataTable_Header_CurrentRqr });

                var dataSet = (from d in data
                               select new
                               {
                                   d.Name,
                                   d.CurrentTotal,
                                   d.DisplayName
                               }).ToList();

                foreach (var item in dataSet)
                {
                    if ((item.Name == "Locations" && filters.RqrTileShowLocations) || (item.Name == "Divisions" && filters.RqrTileShowDivisions) || (item.Name == "Account" && filters.RqrTileShowAccount))
                    {
                        datatable.Rows.Add(new object[]
                        {
                        item.DisplayName, FormatHelper.FormatRqr(item.CurrentTotal)
                        });
                    }
                }

                return datatable;
            }

            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<DashboardLoadHighestFireLossEstimatesData> LoadHighestFireLossEstimatesData(DataFilter dataFilter, int userId)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

            if (anyLocationsSelectorDataFilter != null)
            {
                DashboardDbAccess db = new DashboardDbAccess();
                return db.LoadHighestFireLossEstimatesData(anyLocationsSelectorDataFilter, dataFilter);
            }

            return null;
        }

        public List<DashboardCitran> LoadCitranData(DataFilter dataFilter, int userId, int resultsToDisplay, bool useLocationNoInReport)
        {

            var recommendationLogic = new RecommendationLogic();

            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

            if (anyLocationsSelectorDataFilter != null)
            {
                DashboardDbAccess db = new DashboardDbAccess();
                var results = db.LoadCitranData(anyLocationsSelectorDataFilter, dataFilter, resultsToDisplay);

                long totalAccumulatedCost = 0;

                foreach (var citranResult in results)
                {

                    citranResult.AccumulatedCost = totalAccumulatedCost;
                    citranResult.CostBenefitRatio = recommendationLogic.GetRecommendationCostBenefitRatio(citranResult.EstimatedCost, citranResult.LEBefore, citranResult.LEAfter);
                    citranResult.RiskReduction = recommendationLogic.GetRecommendationRiskReduction(citranResult.LEBefore, citranResult.LEAfter);
                    citranResult.LocationId = useLocationNoInReport ? citranResult.LocationNo : citranResult.LocationCode;
                    totalAccumulatedCost += citranResult.EstimatedCost ?? 0;
                }

                return results;
            }

            return null;
        }

        public IList<CopeByConstructionType> LoadCopeTile(DataFilter dataFilter, int userId)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);
            if (anyLocationsSelectorDataFilter != null)
            {
                DashboardDbAccess dashboardDbAccess = new DashboardDbAccess();
                return dashboardDbAccess.LoadCopeTile(anyLocationsSelectorDataFilter, dataFilter);
            }

            return null;
        }

        public DataTable LoadHighestFireLossEstimatesDataDataTable(DataFilter dataFilter, int userId, bool useLocationNo)
        {
            var data = LoadHighestFireLossEstimatesData(dataFilter, userId);

            if (data != null)
            {
                var datatable = new DataTable();
                datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Dashboard_HflEstimates_Table_Heading_Name });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Dashboard_HflEstimates_Table_Heading_Total });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.Dashboard_HflEstimates_Table_Heading_DivisionName });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field3a", Caption = WebPageResources.Documents_LocationID });
                
                datatable.Columns.Add(new DataColumn { ColumnName = "Field4", Caption = WebPageResources.Dashboard_HflEstimates_Table_Heading_LocationName });

                datatable.Columns.Add(new DataColumn { ColumnName = "Field4a", Caption = WebPageResources.CopeSummary_Table_Address });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field6", Caption = WebPageResources.Dashboard_HflEstimates_Table_Heading_SicCode });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field7", Caption = WebPageResources.Dashboard_HflEstimates_Table_Heading_PdAmount });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field8", Caption = WebPageResources.Dashboard_HflEstimates_Table_Heading_PdPercent });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field9", Caption = WebPageResources.Dashboard_HflEstimates_Table_Heading_BiAmount });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field10", Caption = WebPageResources.Dashboard_HflEstimates_Table_Heading_BiPercent });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field11", Caption = WebPageResources.Dashboard_HflEstimates_Table_Heading_TlAmount });
                datatable.Columns.Add(new DataColumn { ColumnName = "Field12", Caption = WebPageResources.Dashboard_HflEstimates_Table_Heading_TlPercent });



                var dataSet = (from d in data
                               select new
                               {
                                   d.Name,
                                   d.Total,
                                   d.DivisionName,
                                   d.LocatioName,
                                  d.LocationNo,
                                   d.LocationCode,
                                   d.SicCode,
                                   d.PdAmount,
                                   d.PdPercent,
                                   d.BiAmount,
                                   d.BiPercent,
                                   d.TlAmount,
                                   d.TlPercent,
                                   d.LocationAddress
                               }).ToList();

                foreach (var item in dataSet)
                {
                    datatable.Rows.Add(new object[]
                    {
                                   item.Name,
                                   FormatHelper.FormatCurrency(item.Total),
                                   item.DivisionName,
                                    useLocationNo ? item.LocationNo : item.LocationCode,
                                   item.LocatioName,
                        item.LocationAddress,
                                   item.SicCode,
                                   item.PdAmount,
                                   item.PdPercent != null ? (int) item.PdPercent.Value : new object(),
                                   item.BiAmount,
                                   item.BiPercent != null ? (int) item.BiPercent.Value : new object(),
                                   item.TlAmount,
                                   item.TlPercent != null ? (int) item.TlPercent.Value : new object()
                    });
                }

                return datatable;
            }

            return null;
        }

        public List<DashboardImpairmentByStatus> LoadImpairmentbyStatusData(DataFilter dataFilter, PagedImpairmentFilters filters, int userId, int lpAcctKey)
        {
            using (var dbContext = new MA2DbContext())
            {
                IQueryable<Impairment> impairments = null;

                var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

                DashboardDbAccess db = new DashboardDbAccess();

                impairments = db.LoadDashboardImpairmentByStatusData(anyLocationsSelectorDataFilter, dataFilter, dbContext, lpAcctKey);

                if (impairments == null)
                    return null;


                // filtering 
                
                if (filters.ExcludeOtherLocations)
                    impairments = impairments.Where(x => filters.LPAllPiKeyFilter.Contains(x.LpAllPiKey.GetValueOrDefault(0)));

                if (filters.ImpairmentStatusesFilterGroup.HasValue)
                    impairments = impairments.Where(x => x.ImpairmentStatusID == filters.ImpairmentStatusesFilterGroup);

                if (filters.ImpairmentTypesFilterGroup.HasValue)
                    impairments = impairments.Where(x => x.ImpairmentTypeID == filters.ImpairmentTypesFilterGroup);

                if (filters.DateFilter.HasValue)
                    impairments = impairments.Where(x => x.OpenedDate >= filters.DateFilter);

                if (filters.ImpairmentSystemType != null && filters.ImpairmentSystemType != 0)
                    impairments = impairments.Where(x => x.ImpairmentSystemType.ID == filters.ImpairmentSystemType);

                if (filters.ImpairmentSeverityFilterGroup != null && filters.ImpairmentSeverityFilterGroup != 0)
                    impairments = impairments.Where(x => x.ImpairmentSeverityID == filters.ImpairmentSeverityFilterGroup);



                var planned = impairments.Where(x => x.ImpairmentStatusID == Constants.ImpairmentStatus.Planned).ToList();
                var open = impairments.Where(x => x.ImpairmentStatusID == Constants.ImpairmentStatus.Open).ToList();
                var closed = impairments.Where(x => x.ImpairmentStatusID == Constants.ImpairmentStatus.Closed).ToList();

                var seriesPlanned = new DashboardImpairmentByStatus
                {
                    Count = planned.Count,
                    ImpairmentStatusId = Constants.ImpairmentStatus.Planned,
                    ImpairmentStatusName = WebPageResources.Impairments_Planned
                };


                var seriesOpen = new DashboardImpairmentByStatus
                {
                    Count = open.Count,
                    ImpairmentStatusId = Constants.ImpairmentStatus.Open,
                    ImpairmentStatusName = WebPageResources.Impairments_Open
                };

                var seriesClosed = new DashboardImpairmentByStatus
                {
                    Count = closed.Count,
                    ImpairmentStatusId = Constants.ImpairmentStatus.Closed,
                    ImpairmentStatusName = WebPageResources.Impairments_Closed
                };

                var series = new List<DashboardImpairmentByStatus>
                {
                    seriesPlanned,
                    seriesOpen,
                    seriesClosed
                };

                return series;
            }
        }

        public List<DashboardImpairmentByStatusTableData> LoadImpairmentsTypeOneTableData(DataFilter dataFilter, PagedImpairmentFilters filters, int userId, int lpAcctKey)
        {

            using (var dbContext = new MA2DbContext())
            {
                IQueryable<Impairment> impairments = null;
                var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

                DashboardDbAccess db = new DashboardDbAccess();
                impairments = db.LoadDashboardImpairmentByStatusTableData(anyLocationsSelectorDataFilter, dataFilter, dbContext, lpAcctKey);

                if (impairments == null)
                    return null;

                if (filters.ExcludeOtherLocations)
                    impairments = impairments.Where(x => filters.LPAllPiKeyFilter.Contains(x.LpAllPiKey.GetValueOrDefault(0)));

                if (filters.ImpairmentStatusesFilterGroup.HasValue)
                    impairments = impairments.Where(x => x.ImpairmentStatusID == filters.ImpairmentStatusesFilterGroup);

                if (filters.ImpairmentTypesFilterGroup.HasValue)
                    impairments = impairments.Where(x => x.ImpairmentTypeID == filters.ImpairmentTypesFilterGroup);

                if (filters.DateFilter.HasValue)
                    impairments = impairments.Where(x => x.OpenedDate >= filters.DateFilter);

                if (filters.ImpairmentSystemType != null && filters.ImpairmentSystemType != 0)
                    impairments = impairments.Where(x => x.ImpairmentSystemType.ID == filters.ImpairmentSystemType);
                
                if (filters.ImpairmentSeverityFilterGroup != null && filters.ImpairmentSeverityFilterGroup != 0)
                    impairments = impairments.Where(x => x.ImpairmentSeverityID == filters.ImpairmentSeverityFilterGroup);

                var planned = impairments.Where(x => x.ImpairmentStatusID == Constants.ImpairmentStatus.Planned).ToList();
                var open = impairments.Where(x => x.ImpairmentStatusID == Constants.ImpairmentStatus.Open).ToList();
                var closed = impairments.Where(x => x.ImpairmentStatusID == Constants.ImpairmentStatus.Closed).ToList();

                var plannedHighestTivSite = planned.OrderByDescending(x => x.Location?.LocationValue).FirstOrDefault()?.Location?.LocationValue;
                var plannedHighestPml = planned.OrderByDescending(x => x.Location?.FirePmlTotal).FirstOrDefault()?.Location?.FirePmlTotal;


                var seriesPlanned = new DashboardImpairmentByStatusTableData
                {
                    ImpairmentStatusGroup = WebPageResources.Impairments_Planned,
                    MajorCount = planned.Count(x => x.ImpairmentSeverity.ID == Constants.ImpairmentSeverity.Major),
                    NormalCount = planned.Count(x => x.ImpairmentSeverity.ID == Constants.ImpairmentSeverity.Normal),
                    TotalCount = planned.Count,
                    HighestTIVSite = plannedHighestTivSite,
                    HighestPML = plannedHighestPml
                };

                var openHighestTivSite = open.OrderByDescending(x => x.Location?.LocationValue).FirstOrDefault()?.Location?.LocationValue;
                var openHighestPml = open.OrderByDescending(x => x.Location?.FirePmlTotal).FirstOrDefault()?.Location?.FirePmlTotal;

                var seriesOpen = new DashboardImpairmentByStatusTableData
                {
                    ImpairmentStatusGroup = WebPageResources.Impairments_Open,
                    MajorCount = open.Count(x => x.ImpairmentSeverity.ID == Constants.ImpairmentSeverity.Major),
                    NormalCount = open.Count(x => x.ImpairmentSeverity.ID == Constants.ImpairmentSeverity.Normal),
                    TotalCount = open.Count,
                    HighestTIVSite = openHighestTivSite,
                    HighestPML = openHighestPml
                };

                var closedHighestTivSite = closed.OrderByDescending(x => x.Location?.LocationValue).FirstOrDefault()?.Location?.LocationValue;
                var closedHighestPml = closed.OrderByDescending(x => x.Location?.FirePmlTotal).FirstOrDefault()?.Location?.FirePmlTotal;


                var seriesClosed = new DashboardImpairmentByStatusTableData
                {
                    ImpairmentStatusGroup = WebPageResources.Impairments_Closed,
                    MajorCount = closed.Count(x => x.ImpairmentSeverity.ID == Constants.ImpairmentSeverity.Major),
                    NormalCount = closed.Count(x => x.ImpairmentSeverity.ID == Constants.ImpairmentSeverity.Normal),
                    TotalCount = closed.Count,
                    HighestTIVSite = closedHighestTivSite,
                    HighestPML = closedHighestPml
                };

                var series = new List<DashboardImpairmentByStatusTableData>
            {
                seriesPlanned,
                seriesOpen,
                seriesClosed
            };

                return series;
            }
        }

        public DataTable LoadImpairmentsTypeOneTableDataExport(List<DashboardImpairmentByStatusTableData> dataset)
        {
            var datatable = new DataTable();

            datatable.Columns.Add(new DataColumn { ColumnName = "Field1", Caption = WebPageResources.Dashboard_ImpairmentsTile_TableCol_Status });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field2", Caption = WebPageResources.Dashboard_ImpairmentsTile_TableCol_Major });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field3", Caption = WebPageResources.Dashboard_ImpairmentsTile_TableCol_Normal });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field4", Caption = WebPageResources.Dashboard_ImpairmentsTile_TableCol_Total });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field6", Caption = WebPageResources.Dashboard_ImpairmentsTile_TableCol_HighestTIVSite });
            datatable.Columns.Add(new DataColumn { ColumnName = "Field8", Caption = WebPageResources.Dashboard_ImpairmentsTile_TableCol_HighestPML });

            foreach (var item in dataset)
            {
                datatable.Rows.Add(new object[]
                {
                   item.ImpairmentStatusGroup,
                    item.MajorCount,
                    item.NormalCount,
                    item.TotalCount,
                    item.HighestTIVSiteFormatted,
                    item.HighestPMLFormatted
                });
            }

            return datatable;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="tileId"></param>
        /// <returns></returns>
        public UserSystemTile LoadUserSystemTile(int userId, int tileId)
        {
            DashboardDbAccess db = new DashboardDbAccess();
            return db.LoadUserSystemTile(userId, tileId);
        }


        //public AccountProfileDashboardAccessConfiguration LoadSystemTile(int userId, int tileId)
        //{
        //    DashboardDbAccess db = new DashboardDbAccess();
        //    return db.LoadSystemTile(userId, tileId);
        //}
        /// <summary>
        /// 
        /// </summary>
        /// <param name="tileId"></param>
        /// <returns></returns>
        public SystemScreen LoadSystemScreenBySystemTileId(int tileId)
        {
            DashboardDbAccess db = new DashboardDbAccess();
            return db.LoadSystemScreenBySystemTileId(tileId);
        }

        /// <summary>
        /// Loads a list of UserSystemTiles given a User's ID. If no tiles exist, then the default set are inserted into the database.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="systemScreenId"></param>
        /// <returns></returns>
        public List<UserSystemTile> LoadUserSystemTilesForUser(int userId, int systemScreenId)
        {
            DashboardDbAccess db = new DashboardDbAccess();
            
            var userSystemTiles = db.LoadUserSystemTilesForUser(userId, systemScreenId);

            if (userSystemTiles == null || userSystemTiles.Count == 0)
                InitialiseSystemTilesForNewUser(userId, SystemScreens.Dashboard);

            return userSystemTiles.OrderBy(item => item.SystemTileID).ToList();
  
        }

        public List<AccountProfileDashboardAccessConfiguration> LoadAccountProfileSystemTilesList(int lpAcctKey, int systemScreenId, int userId)
        {
            DashboardDbAccess db = new DashboardDbAccess();
            var userSystemTiles = db.LoadUserSystemTiles(lpAcctKey, systemScreenId, userId);

            return userSystemTiles.OrderBy(item => item.SystemTileID).ToList();
        }

        // When a new user is set up, the System Tile entries need to be populated so they do not see a blank screen
        public void InitialiseSystemTilesForNewUser(int userId, int systemScreenId)
        {
            DashboardDbAccess db = new DashboardDbAccess();
            var screenTiles = LoadSystemTilesForScreen(systemScreenId);
            var userSystemTiles = db.LoadUserSystemTilesForUser(userId, systemScreenId);
            var missingTiles = screenTiles.Where(left => !userSystemTiles.Any(right => right.SystemTileID == left.ID));

            // add missing tiles
            foreach (var tile in missingTiles)
            {
                var tileUpdate = new UserSystemTile
                {
                    UserID = userId,
                    SystemTileID = tile.ID,
                    GridX = tile.DefaultGridX,
                    GridY = tile.DefaultGridY,
                    GridWidth = tile.DefaultGridWidth,
                    GridHeight = tile.DefaultGridHeight,
                    Visible = tile.DefaultVisible
                };

                UpsertUserSystemTile(tileUpdate, userId);
            }

        }

        public List<UserSystemTile> LoadUserSystemTilesForAdmin(int userId, int systemScreenId)
        {
            DashboardDbAccess db = new DashboardDbAccess();
            var userSystemTiles = db.LoadUserSystemTilesForUser(userId, systemScreenId);

            //var systemTiles = db.LoadSystemTilesForUserAccount(accountId,userId, systemScreenId);
            var screenTiles = LoadSystemTilesForScreen(systemScreenId);

            // identify any tiles for the current screen that the user has no configuration for
            var missingTiles = screenTiles.Where(left => !userSystemTiles.Any(right => right.SystemTileID == left.ID));

            // add missing tiles
            foreach (var tile in missingTiles)
            {
                var tileUpdate = new UserSystemTile
                {
                    UserID = userId,
                    SystemTileID = tile.ID,
                    GridX = tile.DefaultGridX,
                    GridY = tile.DefaultGridY,
                    GridWidth = tile.DefaultGridWidth,
                    GridHeight = tile.DefaultGridHeight,
                    Visible = tile.DefaultVisible
                };

                UpsertUserSystemTile(tileUpdate, userId);
            }

            //reload full user tile list
            if (missingTiles.Count() > 0)
                userSystemTiles = db.LoadUserSystemTilesForUser(userId, systemScreenId);

            return userSystemTiles.OrderBy(item => item.ID).ToList();

        }
            
        /// <summary>
        /// 
        /// </summary>
        /// <param name="systemScreenId"></param>
        /// <returns></returns>
        public List<SystemTile> LoadSystemTilesForScreen(int systemScreenId)
        {
            DashboardDbAccess db = new DashboardDbAccess();
            return db.LoadSystemTilesForScreen(systemScreenId);
        }

        #endregion

        #region Save

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userSystemTile"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public UserSystemTile UpsertUserSystemTile(UserSystemTile userSystemTile, int userId)
        {
            DashboardDbAccess db = new DashboardDbAccess();
            return db.UpsertUserSystemTile(userSystemTile, userId);
        }

        #endregion

        #region Test

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilter"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<ViewDataFilter> GetFilterResults(DataFilter dataFilter, int userId)
        {
            var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser(userId);

            DashboardDbAccess db = new DashboardDbAccess();
            return db.GetFilterResults(anyLocationsSelectorDataFilter, dataFilter);
        }

        #endregion
    }
}

﻿using Serialize.Linq.Serializers;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using XLC.MyAnalysis2.DbAccess;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.DbModels.DbEnums;
using XLC.MyAnalysis2.Logic.DTO;
using System.Transactions;
using static XLC.MyAnalysis2.DbModels.DbConstants.Constants;
using static XLC.MyAnalysis2.Shared.FormatHelper;
using XLC.MyAnalysis2.Shared;

namespace XLC.MyAnalysis2.Logic
{
    public class DataFilterLogic : BaseLogic
    {
        protected DataRepository Repo = new DataRepository();

        #region Load

        /// <summary>
        /// Load all filters
        /// </summary>
        /// <returns></returns>
        public List<DataFilter> LoadDataFilters()
        {
            DataFilterDbAccess db = new DataFilterDbAccess();
            return db.LoadDataFilters();
        }

        /// <summary>
        /// Lo
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<DataFilter> LoadDataFiltersByUserId(int userId, bool isAdministrator)
        {
            DataFilterDbAccess db = new DataFilterDbAccess();
            return db.LoadDataFiltersByUserId(userId, isAdministrator);
        }

        /// <summary>
        /// Load a list of data filters for a given user
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="lpAcctKey"></param>
        /// <returns></returns>
        public List<DataFilter> LoadPermittedDataFilters(int userId, int lpAcctKey, bool isAdministrator)
        {
            DataFilterDbAccess db = new DataFilterDbAccess();
            return db.LoadPermittedDataFilters(userId, lpAcctKey, isAdministrator);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilterId"></param>
        /// <returns></returns>
        public DataFilter LoadDataFilterById(int dataFilterId)
        {
            DataFilterDbAccess db = new DataFilterDbAccess();
            return db.LoadDataFilterById(dataFilterId);
        }

        /// <summary>
        /// Load (any) Data Filter pertaining to the Divisions/Sub-divisions/Locations selector
        /// </summary>
        /// <param name="userId">The current user Id</param>
        /// <returns></returns>
        public DataFilter LoadAnyLocationsSelectorDataFilterByUser(int userId)
        {
            DataFilterDbAccess db = new DataFilterDbAccess();
            return db.LoadAnyLocationsSelectorDataFilterByUser(userId);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="paging"></param>
        /// <param name="filters"></param>
        /// <param name="sortExpression"></param>
        /// <returns></returns>
        public List<DataFilterCriteria> GetDataFilterCriteria(PagingInfo paging, DataFilterCriteriaFilters filters, string sortExpression)
        {
            var results = new List<DataFilterCriteria>();
            DataFilterDbAccess db = new DataFilterDbAccess();

            results = db.GetDataFilterCriteria(filters.DataFilterId);
            paging.TotalRecords = results.Count;

            return results;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilterCriteriaId"></param>
        /// <returns></returns>
        public DataFilterCriteria LoadDataFilterCriteriaById(int dataFilterCriteriaId)
        {
            DataFilterDbAccess db = new DataFilterDbAccess();
            return db.LoadDataFilterCriteriaById(dataFilterCriteriaId);
        }

        /// <summary>
        /// Given a DataFilterField record, load the appropriate data for the multi select
        /// </summary>
        /// <param name="dataFilterField"></param>
        /// <param name="lpAcctKey"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<Tuple<string, string>> LoadDataFilterMultiSelectData(DataFilterField dataFilterField, int lpAcctKey, int userId)
        {
            var logic = new ReferenceListLogic();
            var locLogic = new LocationLogic(this.UserName);
            UserLogic userLogic = new UserLogic();
            var db = new DataFilterDbAccess();

            #region Construction

            // Construction.ConstructionCategory
            if (dataFilterField.ID == Constants.DataFilterFields.ConstructionConstructionCategory || dataFilterField.ID == Constants.DataFilterFields.PredominantConstructionCategory)
            {
                return logic.GetPredominantConstructionTypes().OrderBy(c => c.Rank)
                    .Select(c => new { c.LpPredomConsTypKey, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpPredomConsTypKey.ToString(), c.Name))
                    .ToList();
            }

            #endregion

            #region Location

            // Location.Country
            if (dataFilterField.ID == Constants.DataFilterFields.LocationCountry)
            {
                return logic.GetCountries().OrderBy(c => c.Rank)
                    .Select(c => new { c.ID, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.ID.ToString(), c.Name))
                    .ToList();
            }

            // Location.SICCode2digit - TODO
            if (dataFilterField.ID == Constants.DataFilterFields.LocationSICCode2digit)
                return new List<Tuple<string, string>>();

            // Location.SICCode4digit
            if (dataFilterField.ID == Constants.DataFilterFields.LocationSICCode4digit)
            {
                return logic.GetIndustryClassifications()
                    .Select(c => new { c.ID, c.SicCode })
                    .Distinct()
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.ID.ToString(), c.SicCode))
                    .ToList();
            }

            // Location.WebDivision
            if (dataFilterField.ID == Constants.DataFilterFields.LocationWebDivision)
            {
                return userLogic.GetDivisionPrivileges(userId, lpAcctKey).OrderBy(item => item.Name)
                    .Select(c => new { c.LpAcctWebDivKey, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpAcctWebDivKey.ToString(), c.Name))
                    .ToList();
            }

            // Location.SubDivision
            if (dataFilterField.ID == Constants.DataFilterFields.LocationSubDivision)
            {
                return userLogic.GetSubDivisionPrivileges(userId, lpAcctKey).OrderBy(item => item.Name)
                    .Select(c => new { c.LpSubDivKey, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpSubDivKey.ToString(), c.Name))
                    .ToList();
            }

            #endregion

            #region LossEstimates

            // LossEstimates.LossType
            if (dataFilterField.ID == Constants.DataFilterFields.LossEstimatesLossType)
            {
                return logic.GetLossTypes().OrderBy(c => c.Rank)
                    .Select(c => new { c.LpLossTypKey, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpLossTypKey.ToString(), c.Name))
                    .ToList();
            }

            // LossEstimates.Scenario - TODO
            if (dataFilterField.ID == Constants.DataFilterFields.LossEstimatesScenario)
                return new List<Tuple<string, string>>();

            #endregion

            #region Mgmt Programs

            // MgmtPrograms.Category
            if (dataFilterField.ID == Constants.DataFilterFields.MgmtProgramsCategory)
            {
                return logic.GetManagementPrograms().OrderBy(c => c.Rank)
                    .Select(c => new { c.LpMgtSubPgmTypKey, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpMgtSubPgmTypKey.ToString(), c.Name))
                    .ToList();
            }

            // MgmtPrograms.Rating
            if (dataFilterField.ID == Constants.DataFilterFields.MgmtProgramsRating)
            {
                return Enumerable.Range(1, 10)
                    .Select(c => new Tuple<string, string>(c.ToString(), c.ToString()))
                    .ToList();
            }

            #endregion

            #region Nat Cat

            // NatCat.NatCatType
            if (dataFilterField.ID == Constants.DataFilterFields.NATCATType)
            {
                return logic.GetNatCatTypes().OrderBy(c => c.Rank)
                    .Select(c => new { NatCatTypeID = c.ID, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.NatCatTypeID.ToString(), c.Name))
                    .ToList();
            }

            // NatCat.Rating - TODO
            if (dataFilterField.ID == DataFilterFields.NATCATRating)
            {
                return logic.GetNatCatExposureRating(2).OrderByDescending(c => c.ID).Where(x => x.ExpectationLevel != 1)
                    .Select(c => new { c.ExpectationLevel, HazardRating = c.Zone == "NE" ? "Not Evaluated" : c.Zone })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.ExpectationLevel.ToString(), c.HazardRating))
                    .ToList();
            }
            if (dataFilterField.ID == DataFilterFields.NATCATEarthquakeZones)
            {
                return logic.GetNatCatExposureRating(1).OrderBy(c => c.ID)
                    .Select(c => new { NatCatRating = c.LpCatKey, EarthquakeType = c.Zone == "NE" ? "Not Evaluated" : "Zone " + c.Zone })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.NatCatRating.ToString(), c.EarthquakeType))
                    .ToList();
            }
            if (dataFilterField.ID == DataFilterFields.NATCATFloodZones)
            {
                return logic.GetNatCatExposureRating(3).OrderByDescending(c => c.ExpectationLevel)
                    .Select(c => new { NatCatRating = c.LpCatKey, FloodType = c.Zone == "NE" ? "Not Evaluated" : c.Zone })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.NatCatRating.ToString(), c.FloodType))
                    .ToList();
            }

            if (dataFilterField.ID == DataFilterFields.NATCATWindstormZones)
            {
                return logic.GetNatCatExposureRating(2).OrderBy(c => c.ExpectationLevel)
                    .Select(c => new { c.ExpectationLevel, WindstormType = c.Zone })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.ExpectationLevel.ToString(), c.WindstormType))
                    .ToList();
            }
            #endregion

            #region Protection

            // Protection.PerdomWaterSupply
            if (dataFilterField.ID == Constants.DataFilterFields.ProtectionFireDeptType)
            {
                return logic.GetFireDepartmentTypes().OrderBy(c => c.Rank)
                    .Select(c => new { c.LpFireDeptKey, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpFireDeptKey.ToString(), c.Name))
                    .ToList();
            }

            // Protection.PerdomWaterSupply
            if (dataFilterField.ID == Constants.DataFilterFields.ProtectionPerdomWaterSupply)
            {
                return logic.GetWaterSupplyTypes().OrderBy(c => c.Rank)
                    .Select(c => new { c.LpFireProtWaterSuplTypKey, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpFireProtWaterSuplTypKey.ToString(), c.Name))
                    .ToList();
            }

            // Protection.PerdomSurveillanceType
            if (dataFilterField.ID == Constants.DataFilterFields.ProtectionPerdomSurveillanceType)
            {
                return logic.GetSurveillanceTypes().OrderBy(c => c.Rank)
                    .Select(c => new { c.LpPrdmSrvlTypKey, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpPrdmSrvlTypKey.ToString(), c.Name))
                    .ToList();
            }

            #endregion

            #region Recommendation

            // Recommendation.Category
            if (dataFilterField.ID == Constants.DataFilterFields.RecommendationCategory)
            {
                return logic.GetRecommendationCategories().OrderBy(c => c.Rank)
                    .Select(c => new { c.ID, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.ID.ToString(), c.Name))
                    .ToList();
            }

            // Recommendation.CustomerIntent
            if (dataFilterField.ID == Constants.DataFilterFields.RecommendationCustomerIntent)
            {
                return logic.GetRecommendationClientIntents().OrderBy(c => c.Rank)
                    .Select(c => new { c.LpRecCustIntentKey, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpRecCustIntentKey.ToString(), c.Name))
                    .ToList();
            }

            // Recommendation.Probability
            if (dataFilterField.ID == Constants.DataFilterFields.RecommendationProbability)
            {
                return logic.GetRecommendationProbabilities().OrderBy(c => c.Rank)
                    .Select(c => new { c.LpProbabilityKey, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpProbabilityKey.ToString(), c.Name))
                    .ToList();
            }

            // Recommendation.Type
            if (dataFilterField.ID == Constants.DataFilterFields.RecommendationType)
            {
                return logic.GetRecommendationTypes().OrderBy(c => c.Rank)
                    .Select(c => new { c.LpRecSubRecTypKey, c.SubRecName })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpRecSubRecTypKey.ToString(), c.SubRecName))
                    .ToList();
            }

            // Recommendation.SourceType
            if (dataFilterField.ID == Constants.DataFilterFields.RecommendationSourceType)
            {
                return logic.GetRecommendationSources().OrderBy(c => c.Rank)
                    .Select(c => new { c.ID, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.ID.ToString(), c.Name))
                    .ToList();
            }

            // Recommendation.Recommendation Status
            if (dataFilterField.ID == Constants.DataFilterFields.RecommendationStatus)
            {
                return logic.GetOverallRecommendationStatus().OrderBy(c => c.Rank)
                    .Select(c => new { LpRecStatusKey = c.ID, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpRecStatusKey.ToString(), c.Name))
                    .ToList();
            }
            // Recommendation.Implementation Status
            if (dataFilterField.ID == Constants.DataFilterFields.RecommendationImplementationStatus)
            {
                var ImplementationStatuslist = new List<RecommendationStatu>();
                try
                {
                    foreach (var ImplementationStatus in logic.GetRecImplemendationStatus())
                    {
                        if (ImplementationStatus.ID == RecommendationStatus.AwaitingResponse)
                        {
                            ImplementationStatus.Rank = RecommendationStatus.AwaitingResponse;
                        }
                        else if (ImplementationStatus.ID == RecommendationStatus.CompletedClient)
                        {
                            ImplementationStatus.Rank = RecommendationStatus.VerifiedComplete;
                        }
                        else if (ImplementationStatus.ID == RecommendationStatus.InProgress)
                        {
                            ImplementationStatus.Rank = RecommendationStatus.NoPlansOrDisagree;
                        }
                        else if (ImplementationStatus.ID == RecommendationStatus.NoPlansOrDisagree)
                        {
                            ImplementationStatus.Rank = RecommendationStatus.InProgress;
                        }
                        else if (ImplementationStatus.ID == RecommendationStatus.UnderReview)
                        {
                            ImplementationStatus.Rank = RecommendationStatus.CompletedClient;
                        }
                        else if (ImplementationStatus.ID == RecommendationStatus.VerifiedComplete)
                        {
                            ImplementationStatus.Rank = RecommendationStatus.UnderReview;
                        }

                        ImplementationStatuslist.Add(ImplementationStatus);
                    }
                    return ImplementationStatuslist.OrderBy(c => c.Rank)
                   .Select(c => new { LpStatusCode = c.ID, c.Name })
                   .AsEnumerable()
                   .Select(c => new Tuple<string, string>(c.LpStatusCode.ToString(), c.Name))
                   .ToList();
                }

                catch (Exception ex)
                {
                    return logic.GetRecImplemendationStatus().OrderBy(c => c.Rank)
                    .Select(c => new { LpStatusCode = c.ID, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.LpStatusCode.ToString(), c.Name))
                    .ToList();
                }
            }


            if (dataFilterField.ID.Equals(DataFilterFields.ResponseStatus))
            {
                return logic.GetRecommendationResponseStatuses().Where(x => x.Active.Equals(true)).OrderBy(c => c.Rank)
                    .Select(c => new { c.ID, RecommendationResponseStatusID = c.ID, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.RecommendationResponseStatusID.ToString(), c.Name))
                    .ToList();
            }

            #endregion

            #region RiskQualRatings

            // RiskQualityRatings.Category
            if (dataFilterField.ID == Constants.DataFilterFields.RiskQualityRatingsCategory)
            {
                return logic.GetRiskQualityCategories().OrderBy(c => c.Rank)
                    .Select(c => new { c.ID, c.LpRiskQualRtngKey, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.ID.ToString(), c.Name))
                    .ToList();
            }

            if (dataFilterField.ID == Constants.DataFilterFields.RatingType)
            {
                var list = new List<Tuple<string, string>>();
                list.Add(Tuple.Create(Constants.RiskQualityRatingFilters.CurrentLocationCategoryRating.Poor.ToString(), "Poor"));
                list.Add(Tuple.Create(Constants.RiskQualityRatingFilters.CurrentLocationCategoryRating.Fair.ToString(), "Fair"));
                list.Add(Tuple.Create(Constants.RiskQualityRatingFilters.CurrentLocationCategoryRating.Good.ToString(), "Good"));
                list.Add(Tuple.Create(Constants.RiskQualityRatingFilters.CurrentLocationCategoryRating.Excellent.ToString(), "Excellent"));
                list.Add(Tuple.Create(Constants.RiskQualityRatingFilters.CurrentLocationCategoryRating.NotEvaluated.ToString(), "Not Evaluated"));

                return list;
            }

            // RiskQualityRatings.Rating - TODO
            if (dataFilterField.ID == Constants.DataFilterFields.RiskQualityRatingsRating)
            {
                return Enumerable.Range(1, 10)
                    .Select(c => new Tuple<string, string>((c * 10).ToString(), (c * 10).ToString()))
                    .ToList();
            }


            #endregion

            #region Survey

            // Survey.Frequency - TODO
            if (dataFilterField.ID == Constants.DataFilterFields.SurveyFrequency)
            {
                return db.GetSurveyFrequencyInMonthsList(lpAcctKey)
                    .Select(c => new { Frequency = c })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.Frequency.ToString(), c.Frequency.ToString()))
                    .ToList();
            }

            // Survey.SurveyedBy
            if (dataFilterField.ID == Constants.DataFilterFields.SurveySurveyedBy)
            {
                return db.GetLastSurveyByList(lpAcctKey)
                    .Select(c => new { Name = c })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.Name, c.Name))
                    .ToList();
            }

            // Survey.AssignedTo
            if (dataFilterField.ID == Constants.DataFilterFields.SurveyAssignedTo)
            {
                return db.GetNextSurveyAssignedToList(lpAcctKey)
                    .Select(c => new { Name = c })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.Name, c.Name))
                    .ToList();
            }

            // Survey.DocumentType
            if (dataFilterField.ID == Constants.DataFilterFields.SurveyDocumentType)
            {
                return logic.GetDocumentTypes().OrderBy(c => c.Rank)
                    .Select(c => new { c.ID, c.Name })
                    .AsEnumerable()
                    .Select(c => new Tuple<string, string>(c.ID.ToString(), c.Name))
                    .ToList();
            }

            #endregion

            return new List<Tuple<string, string>>();
        }

        #endregion

        #region Save

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilterCriteria"></param>
        /// <param name="userId"></param>
        /// <param name="isAdministrator"></param>
        /// <param name="lpAcctKey"></param>
        /// <returns></returns>
        public DataFilterCriteria AddCriteriaToDataFilter(DataFilterCriteria dataFilterCriteria, int userId, bool isAdministrator, int lpAcctKey)
        {
            var db = new DataFilterDbAccess();

            // If we are adding criteria to a new Data Filter
            if (dataFilterCriteria.DataFilterID == 0)
            {
                var userHasUnsavedFilter = false;
                var results = LoadDataFiltersByUserId(userId, isAdministrator);

                // https://support.softwaresolved.com/projects/S1164/issues/S1164-6
                // We must also check that parameter 'userId' matches the User ID of any Unsaved filters being brought back,
                // admin roles bring back DataFilters for all users, so no doubt there will be some unsaved records for other users
                // which would cause the "Unsaved Filters" error to be thrown
                userHasUnsavedFilter = results.Any(x => x.Unsaved && x.UserID == userId && x.LpAcctKey == lpAcctKey);

                if (userHasUnsavedFilter)
                {
                    throw new ArgumentException(Resources.WebPageResources.DataFilter_Add_Criteria_Error_Unsaved_Exists);
                }
                else
                {
                    DataFilter dataFilter = CreateUnsavedDataFilter(userId, lpAcctKey);
                    dataFilter = db.UpsertDataFilter(dataFilter, userId);
                    dataFilterCriteria.DataFilterID = dataFilter.ID;
                }
            }

            // assign the fully serialized linq expression to be used in subsequent queries
            dataFilterCriteria.Expression = BuildDataFilterCriteriaExpression(dataFilterCriteria);

            return db.UpsertDataFilterCriteria(dataFilterCriteria, userId);
        }

        public bool UpsertLocationSelectionsForUser(User user, int creatorOrUpdaterId)
        {
            try
            {
                DataFilterDbAccess db = new DataFilterDbAccess();
                DataFilter dataFilterToUpdate = Repo.GetAll<DataFilter>().SingleOrDefault(x => x.UserID == user.ID && x.LocationsSelectorFilter);
                DataFilterCriteria dataFilterCriteriaToUpdate = dataFilterToUpdate?.DataFilterCriterias.SingleOrDefault();

                // Could be a new user who does not currently have any Data Filters with a LocationSelectorFilter set
                if (dataFilterToUpdate == null)
                {

                    var newDataFilter = new DataFilter
                    {
                        UserID = user.ID,
                        Name = $"Locations Picker Data Filter for UserID {user.ID}",
                        LocationsSelectorFilter = true
                    };
                    dataFilterToUpdate = db.UpsertDataFilter(newDataFilter, creatorOrUpdaterId);
                }

                if (dataFilterCriteriaToUpdate == null)
                {
                    dataFilterCriteriaToUpdate = new DataFilterCriteria
                    {
                        CreatedDate = DateTime.UtcNow,
                        UpdatedDate = DateTime.UtcNow,
                        CreatedBy = creatorOrUpdaterId,
                        Operator = "Equal",
                        DataFilterID = dataFilterToUpdate.ID,
                        DataFilterFieldID = Repo.GetAll<DataFilterField>().SingleOrDefault(x => x.DisplayName == "LP Database Location ID")?.ID ?? 0
                    };

                    db.UpsertDataFilterCriteria(dataFilterCriteriaToUpdate, creatorOrUpdaterId);
                }

                // Build the pipe delimited list of LpAllPiKeys
                // check to see if they have a subset of LocationLevelAccess records. 
                //      Has Subset -> Use LocationLevelAccess records
                //      No Subset -> Honor DivisionLevel/SubDivision access records
                StringBuilder newPipeDelimitedLocationSelection = new StringBuilder();

                var userLocationAccess = Repo.GetAll<ViewUserLocationPriviledge>().Where(x => x.UserId == user.ID).Select(x => x.LpAllPiKey).Distinct().ToList();

                if (userLocationAccess.Any())
                {
                    // build the pipe delimited list of LpAllPiKeys
                    foreach (var locationRecord in userLocationAccess)
                        newPipeDelimitedLocationSelection.Append(locationRecord + "|");


                }

                // remove trailing Pipe from the builder when the piped list contains at least one LpAllPiKey
                if (!String.IsNullOrEmpty(newPipeDelimitedLocationSelection.ToString()) && !String.IsNullOrWhiteSpace(newPipeDelimitedLocationSelection.ToString()))
                    newPipeDelimitedLocationSelection.Remove(newPipeDelimitedLocationSelection.ToString().LastIndexOf("|", StringComparison.Ordinal), "|".Length);

                dataFilterCriteriaToUpdate.Value = newPipeDelimitedLocationSelection.ToString();

                db.UpsertDataFilterCriteria(dataFilterCriteriaToUpdate, creatorOrUpdaterId);

                return true;
            }
            catch (Exception e)
            {
                LogHelper.Error($"Could not update LocationSelections for User {user.ID}", e);
                throw;
            }

        }

        public DataFilter UpsertDataFilter(DataFilter dataFilter, int userId)
        {
            DataFilterDbAccess db = new DataFilterDbAccess();
            return db.UpsertDataFilter(dataFilter, userId);
        }

        public DataFilter InsertNewDrillThroughDataFilter(DataFilter dataFilter, int userId)
        {
            DataFilterDbAccess db = new DataFilterDbAccess();
            return db.InsertNewDrillThroughDataFilter(dataFilter, userId);
        }

        public void InsertDataFilterCriteriaForDrillThrough(List<DataFilterCriteria> dataFilterCriteria, int userId)
        {
            DataFilterDbAccess db = new DataFilterDbAccess();

            // First remove any existing DFC for any previous drill throughs
            if (dataFilterCriteria.Count > 0)
                db.DeleteExistingDataFilterCriteriaForDataFilter(dataFilterCriteria.First().DataFilterID);

            // now insert new DFCs
            foreach (var criteria in dataFilterCriteria)
            {
                db.UpsertDataFilterCriteria(criteria, userId);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilterCriteria"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public bool IsDataFilterCriteriaValid(DataFilterCriteria dataFilterCriteria, out string message)
        {
            ReferenceListLogic referenceListLogic = new ReferenceListLogic();
            var dataFilterField = referenceListLogic.GetDataFilterFields().Find(item => item.ID == dataFilterCriteria.DataFilterFieldID);
            Type fieldType = typeof(string);
            message = string.Empty;

            // check criteria is not null
            if (dataFilterCriteria == null)
            {
                message = Resources.WebPageResources.Error_General_Line1;
                return false;
            }

            // check a data filter field has been selected
            if (dataFilterCriteria.DataFilterFieldID == 0)
            {
                message = Resources.WebPageResources.DataFilter_Add_Criteria_Error_Invalid_Data_Field;
                return false;
            }

            // check the data filter field does not exists under this data filter already (if adding to an existing data filter)
            if (CriteriaExistsForDataFilter(dataFilterCriteria.DataFilterID, dataFilterCriteria.DataFilterFieldID))
            {
                message = Resources.WebPageResources.DataFilter_Add_Criteria_Error_Duplicate_Data_Filter_Field;
                return false;
            }

            // check an operator has been set
            if (string.IsNullOrEmpty(dataFilterCriteria.Operator))
            {
                message = Resources.WebPageResources.DataFilter_Add_Criteria_Error_No_Operator_Selected;
                return false;
            }

            // if we have a simple type, let's check the value can be parsed
            if (dataFilterField.DataType != DataFilterDataType.FkLookup)
            {
                // now check the type of the value vs the expected type
                try
                {
                    var param = GetParameterExpression(dataFilterField, out Type domainType, out fieldType);

                    dynamic single = null;
                    dynamic from = null;
                    dynamic to = null;

                    if (dataFilterField.DataType == DataFilterDataType.NvarChar)
                        single = dataFilterCriteria.Value;

                    if (dataFilterField.DataType == DataFilterDataType.Datetime)
                    {
                        single = dataFilterCriteria.DateSingle;
                        from = dataFilterCriteria.DateFrom;
                        to = dataFilterCriteria.DateTo;
                    }

                    if (dataFilterField.DataType == DataFilterDataType.Decimal)
                    {
                        single = dataFilterCriteria.DecimalSingle;
                        from = dataFilterCriteria.DecimalFrom;
                        to = dataFilterCriteria.DecimalTo;
                    }

                    if (dataFilterField.DataType == DataFilterDataType.Bigint)
                    {
                        single = dataFilterCriteria.LongSingle;
                        from = dataFilterCriteria.LongFrom;
                        to = dataFilterCriteria.LongTo;
                    }

                    if (dataFilterField.DataType == DataFilterDataType.Int)
                    {
                        single = dataFilterCriteria.IntSingle;
                        from = dataFilterCriteria.IntFrom;
                        to = dataFilterCriteria.IntTo;
                    }


                    if (dataFilterField.DataType == DataFilterDataType.zerotoonehundred)
                    {
                        if (dataFilterCriteria.Operator == DataFilterCriteriaOperator.Between)
                        {
                            decimal value = decimal.Compare(dataFilterCriteria.ZerotoonehundredTo ?? 0, dataFilterCriteria.ZerotoonehundredFrom ?? 0);

                            if (value < 1)
                            {
                                message = Resources.WebPageResources.DataFilterErrorMessage_CurrentSiteRating;
                                return false;
                            }
                            else if ((dataFilterCriteria.ZerotoonehundredTo > 100) || (dataFilterCriteria.ZerotoonehundredFrom > 100))
                            {
                                message = Resources.WebPageResources.CurrentSiteRating_Validation;
                                return false;
                            }
                        }

                        single = dataFilterCriteria.ZerotoonehundredSingle;
                        from = dataFilterCriteria.ZerotoonehundredFrom;
                        to = dataFilterCriteria.ZerotoonehundredTo;
                    }

                    dynamic singleParsed = null;
                    dynamic fromParsed = null;
                    dynamic toParsed = null;

                    if (dataFilterCriteria.Operator != DataFilterCriteriaOperator.Between)
                    {
                        singleParsed = ParseValueByType(single, fieldType);
                    }
                    else
                    {
                        fromParsed = ParseValueByType(from, fieldType);
                        toParsed = ParseValueByType(to, fieldType);
                    }
                }
                catch
                {
                    var fieldTypeString = GetResourceStringByType(fieldType);
                    message = string.Format(Resources.WebPageResources.DataFilter_Add_Criteria_Error_Data_Type, fieldTypeString);
                    return false;
                }
            }
            else
            {
                if (string.IsNullOrEmpty(dataFilterCriteria.Value))
                {
                    message = Resources.WebPageResources.DataFilter_Add_Criteria_Error_Value1_Missing;
                    return false;
                }
            }

            return true;
        }

        private DataFilter CreateUnsavedDataFilter(int userId, int lpAcctKey)
        {
            return new DataFilter()
            {
                Name = Resources.WebPageResources.DataFilter_Unsaved,
                Shared = false,
                UserID = userId,
                Unsaved = true,
                LpAcctKey = lpAcctKey
            };
        }

        /// <summary>
        /// Persist the current Locations selections in the Divisions/Sub-divisions/Locations picker
        /// as a DataFilter with the LocationsSelectorFilter flag set to true to separate it from the
        /// normal filters.
        /// </summary>
        /// <param name="lpAllPiKeysList"></param>
        /// <param name="userId"></param>
        public void PersistLocationsPickerDataFilter(List<int> lpAllPiKeysList, int userId)
        {
            var db = new DataFilterDbAccess();

            using (var transactionScope = new TransactionScope(TransactionScopeOption.Required,
                                                                new TransactionOptions { IsolationLevel = IsolationLevel.Serializable }))
            {
                DataFilter dataFilter = LoadDataFiltersByUserId(userId, false)
                                        .SingleOrDefault(filter => filter.LocationsSelectorFilter);

                if (lpAllPiKeysList != null)
                {
                    if (dataFilter == null)
                    {
                        dataFilter = CreateLocationsPickerDataFilter(userId);
                        dataFilter = db.UpsertDataFilter(dataFilter, userId);
                    }

                    UpdateLocationsPickerDataFilter(lpAllPiKeysList, dataFilter, userId);
                }
                else if (dataFilter != null)
                {
                    db.DeleteExistingDataFilter(dataFilter.ID);
                }

                transactionScope.Complete();
            }
        }

        private void UpdateLocationsPickerDataFilter(List<int> lpAllPiKeysList, DataFilter dataFilter, int userId)
        {
            if (lpAllPiKeysList == null) throw new ArgumentNullException(nameof(lpAllPiKeysList));
            if (dataFilter == null) throw new ArgumentNullException(nameof(dataFilter));

            var db = new DataFilterDbAccess();

            DataFilterCriteria dataFilterCriteria;
            if (dataFilter.DataFilterCriterias.Count > 0)
            {
                dataFilterCriteria = dataFilter.DataFilterCriterias.First();
            }
            else
            {
                dataFilterCriteria = new DataFilterCriteria
                {
                    DataFilterFieldID = DataFilterFields.LocationLPAllPiKey,
                    Operator = DataFilterCriteriaOperatorEnum.Equal.ToString(),
                    DataFilterID = dataFilter.ID
                };
            };

            // Pipe separated list of location ID will be used for filtering. Expression field is not required
            dataFilterCriteria.Value = string.Join("|", lpAllPiKeysList);
            dataFilterCriteria.Expression = null;       //Expression is not required

            db.UpsertDataFilterCriteria(dataFilterCriteria, userId);
        }

        private DataFilter CreateLocationsPickerDataFilter(int userId)
        {
            return new DataFilter()
            {
                Name = $"Locations Picker Data Filter for UserID {userId}",
                Shared = false,
                UserID = userId,
                LocationsSelectorFilter = true
            };
        }
        #endregion

        #region Delete

        // <summary>
        /// 
        /// </summary>
        /// <param name="dataFilterCriteriaId"></param>
        /// <returns></returns>
        public void RemoveCriteriaFromDataFilter(int dataFilterCriteriaId)
        {
            DataFilterDbAccess db = new DataFilterDbAccess();
            DataFilterCriteria criteria = LoadDataFilterCriteriaById(dataFilterCriteriaId);

            // TODO - check can delete first
            db.DeleteExistingDataFilterCriteria(dataFilterCriteriaId);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilterId"></param>
        /// <param name="userId"></param>
        /// <param name="isAdministrator"></param>
        public bool DeleteExistingDataFilter(int dataFilterId, int userId, bool isAdministrator)
        {
            DataFilterDbAccess db = new DataFilterDbAccess();
            DataFilter filter = LoadDataFilterById(dataFilterId);

            if (filter.UserID != userId && !isAdministrator)
                throw new Exception($"DeleteExistingDataFilter - UserID: {userId}, DataFilter.ID: {dataFilterId}");

            return db.DeleteExistingDataFilter(dataFilterId);
        }

        #endregion

        #region Linq/Query Helpers

        /// <summary>
        /// Helper method used when displaying DataFilterCritera table to the user
        /// </summary>
        /// <param name="dataFilterCriteria"></param>
        /// <param name="dataFilterField"></param>
        /// <param name="lpAcctKey"></param>
        /// <param name="dataFilterEnum"></param>
        /// <param name="userId"></param>
        /// <param name="lPFloorAreaUnitTypeKey"></param>
        /// <returns></returns>
        public string FormatCriterionValueField(DataFilterCriteria dataFilterCriteria, DataFilterField dataFilterField, int lpAcctKey, DataFilterCriteriaTableColumns dataFilterEnum, int userId, int? lPFloorAreaUnitTypeKey)
        {
            // guard
            if (dataFilterCriteria.Operator != DataFilterCriteriaOperator.Between && dataFilterEnum == DataFilterCriteriaTableColumns.Value2)
                return string.Empty;

            if (dataFilterCriteria.Operator != DataFilterCriteriaOperator.Between)
            {
                if (dataFilterField.DataType == DataFilterDataType.NvarChar)
                    return dataFilterCriteria?.Value;

                if (dataFilterField.DataType == DataFilterDataType.Datetime)
                    return dataFilterCriteria.DateSingle.Value.ToString("dd-MMM-yyyy", CurrentCultureInfo);

                if (dataFilterField.DataType == DataFilterDataType.Decimal)
                {
                    if (dataFilterField.IsArea && lPFloorAreaUnitTypeKey.GetValueOrDefault() == FloorAreaUnitTypeRef.UsFt2)
                        return (dataFilterCriteria.DecimalSingle * AreaConversionConstants.MeterSqToFeetSq)?.ToString("#.##");
                    else
                        return dataFilterCriteria.DecimalSingle?.ToString("#.##");
                }

                if (dataFilterField.DataType == DataFilterDataType.Bigint)
                    return dataFilterCriteria.LongSingle?.ToString();

                if (dataFilterField.DataType == DataFilterDataType.Int)
                    return dataFilterCriteria.IntSingle?.ToString();

                if (dataFilterField.DataType == DataFilterDataType.zerotoonehundred)
                    return dataFilterCriteria.ZerotoonehundredSingle?.ToString("#.##");
            }
            else
            {
                if (dataFilterField.DataType == DataFilterDataType.Datetime)
                    return dataFilterEnum == DataFilterCriteriaTableColumns.Value1 ?
                        dataFilterCriteria.DateFrom.Value.ToString("dd-MMM-yyyy", CurrentCultureInfo) :
                        dataFilterCriteria.DateTo.Value.ToString("dd-MMM-yyyy", CurrentCultureInfo);

                if (dataFilterField.DataType == DataFilterDataType.Decimal)
                {
                    if (dataFilterField.IsArea && lPFloorAreaUnitTypeKey.GetValueOrDefault() == FloorAreaUnitTypeRef.UsFt2)
                    {
                        return dataFilterEnum == DataFilterCriteriaTableColumns.Value1 ?
                            (dataFilterCriteria.DecimalFrom * AreaConversionConstants.MeterSqToFeetSq)?.ToString("#.##") :
                            (dataFilterCriteria.DecimalTo * AreaConversionConstants.MeterSqToFeetSq)?.ToString("#.##");
                    }
                    else
                    {
                        return dataFilterEnum == DataFilterCriteriaTableColumns.Value1 ?
                            dataFilterCriteria.DecimalFrom?.ToString("#.##") :
                            dataFilterCriteria.DecimalTo?.ToString("#.##");
                    }
                }

                if (dataFilterField.DataType == DataFilterDataType.Bigint)
                    return dataFilterEnum == DataFilterCriteriaTableColumns.Value1 ?
                        dataFilterCriteria.LongFrom?.ToString() :
                        dataFilterCriteria.LongTo?.ToString();

                if (dataFilterField.DataType == DataFilterDataType.Int)
                    return dataFilterEnum == DataFilterCriteriaTableColumns.Value1 ?
                        dataFilterCriteria.IntFrom?.ToString() :
                        dataFilterCriteria.IntTo?.ToString();

                if (dataFilterField.DataType == DataFilterDataType.zerotoonehundred)
                    return dataFilterEnum == DataFilterCriteriaTableColumns.Value1 ?
                        dataFilterCriteria.ZerotoonehundredFrom?.ToString("#.##") :
                        dataFilterCriteria.ZerotoonehundredTo?.ToString("#.##");
            }

            // convert CSV list of IDs into a displayable format (accounting for the users selected culture)
            if (dataFilterField.DataType == DataFilterDataType.FkLookup)
            {
                var storedOptionsText = new List<string>();

                // all available options in users culture
                var availableOptions = LoadDataFilterMultiSelectData(dataFilterField, lpAcctKey, userId);

                // users stored options
                var storedOptions = dataFilterCriteria.Value.Split('|').ToList();

                if (availableOptions.Count == 0)
                {
                    return string.Join(", ", dataFilterCriteria.Value.Split('|').ToList());
                }

                foreach (var availableOption in availableOptions)
                {
                    storedOptionsText.AddRange(from storedOption in storedOptions
                                               where storedOption == availableOption.Item1
                                               select availableOption.Item2);
                }

                return string.Join(", ", storedOptionsText);
            }

            return string.Empty;
        }

        /// <summary>
        /// Given a DataFilterCriteria object, build up the expression to be applied when the criterion is consumed in a query
        /// </summary>
        /// <param name="dataFilterCriteria"></param>
        /// <returns></returns>
        public string BuildDataFilterCriteriaExpression(DataFilterCriteria dataFilterCriteria)
        {
            var referenceListLogic = new ReferenceListLogic();
            var dataFilterField = referenceListLogic.GetDataFilterField(dataFilterCriteria.DataFilterFieldID);

            // load the ParameterExpression (field type and name)
            GetParameterExpression(dataFilterField, out Type domainType, out Type fieldType);

            // determine the operator to apply
            var operatorEnum = (DataFilterCriteriaOperatorEnum)Enum.Parse(typeof(DataFilterCriteriaOperatorEnum), dataFilterCriteria.Operator);

            // build the expression
            var expressionResult = (dataFilterField.DataType == DataFilterDataType.FkLookup) ?
               GetExpressionDropDown(dataFilterCriteria, domainType, fieldType, operatorEnum, dataFilterField) :
               GetExpression(dataFilterCriteria, domainType, fieldType, operatorEnum, dataFilterField);

            // finally serialize the expression for later use
            var serializer = new ExpressionSerializer(new JsonSerializer());
            var value = serializer.SerializeText(expressionResult);

            return value;
        }

        /// <summary>
        /// Builds up the lambda expression to represent the DataFilterCriteria selected by the user and later used against the ViewDataFilter object
        /// </summary>
        /// <param name="dataFilterCriteria"></param>
        /// <param name="domainType"></param>
        /// <param name="fieldType"></param>
        /// <param name="operatorEnum"></param>
        /// <param name="dataFilterField"></param>
        /// <returns></returns>
        private Expression GetExpression(DataFilterCriteria dataFilterCriteria, Type domainType, Type fieldType, DataFilterCriteriaOperatorEnum operatorEnum, DataFilterField dataFilterField)
        {
            var parameter = Expression.Parameter(domainType);
            var property = Expression.Property(parameter, dataFilterField.ExpressionName);
            var delegateType = typeof(Func<,>).MakeGenericType(domainType, typeof(bool));

            Expression result = null;
            Expression left = Expression.Property(parameter, dataFilterField.ExpressionName);
            Expression right = null; // used for a single value or 'from' where a range has been chosen
            Expression rightTo = null;

            if (operatorEnum != DataFilterCriteriaOperatorEnum.Between)
            {
                if (dataFilterField.DataType == DataFilterDataType.NvarChar)
                    right = BuildValueExpression(dataFilterCriteria.Value.HtmlEncode(), fieldType);

                if (dataFilterField.DataType == DataFilterDataType.Datetime)
                    right = BuildValueExpression(dataFilterCriteria.DateSingle, fieldType);

                if (dataFilterField.DataType == DataFilterDataType.Decimal)
                    right = BuildValueExpression(dataFilterCriteria.DecimalSingle, fieldType);

                if (dataFilterField.DataType == DataFilterDataType.Bigint)
                    right = BuildValueExpression(dataFilterCriteria.LongSingle, fieldType);

                if (dataFilterField.DataType == DataFilterDataType.Int)
                    right = BuildValueExpression(dataFilterCriteria.IntSingle, fieldType);

                if (dataFilterField.DataType == DataFilterDataType.zerotoonehundred)
                    right = BuildValueExpression(dataFilterCriteria.ZerotoonehundredSingle, fieldType);
            }
            else
            {
                if (dataFilterField.DataType == DataFilterDataType.Datetime)
                {
                    right = BuildValueExpression(dataFilterCriteria.DateFrom, fieldType);
                    rightTo = BuildValueExpression(dataFilterCriteria.DateTo, fieldType);
                }

                if (dataFilterField.DataType == DataFilterDataType.Decimal)
                {
                    right = BuildValueExpression(dataFilterCriteria.DecimalFrom, fieldType);
                    rightTo = BuildValueExpression(dataFilterCriteria.DecimalTo, fieldType);
                }

                if (dataFilterField.DataType == DataFilterDataType.Bigint)
                {
                    right = BuildValueExpression(dataFilterCriteria.LongFrom, fieldType);
                    rightTo = BuildValueExpression(dataFilterCriteria.LongTo, fieldType);
                }

                if (dataFilterField.DataType == DataFilterDataType.Int)
                {
                    right = BuildValueExpression(dataFilterCriteria.IntFrom, fieldType);
                    rightTo = BuildValueExpression(dataFilterCriteria.IntTo, fieldType);
                }

                if (dataFilterField.DataType == DataFilterDataType.zerotoonehundred)
                {
                    right = BuildValueExpression(dataFilterCriteria.ZerotoonehundredFrom, fieldType);
                    rightTo = BuildValueExpression(dataFilterCriteria.ZerotoonehundredTo, fieldType);
                }
            }

            // special condition for string contains
            if (fieldType == typeof(string) && operatorEnum == DataFilterCriteriaOperatorEnum.Contains)
                result = Expression.Call(property, "Contains", null, Expression.Constant(dataFilterCriteria.Value.HtmlEncode()));

            // finally apply out operand based on the users choice
            switch (operatorEnum)
            {
                case DataFilterCriteriaOperatorEnum.Equal:
                    result = Expression.Equal(left, right);
                    break;
                case DataFilterCriteriaOperatorEnum.NotEqual:
                    result = Expression.NotEqual(left, right);
                    break;
                case DataFilterCriteriaOperatorEnum.Between:
                    // combine expressions to produce x >= y && x <= z
                    var from = Expression.GreaterThanOrEqual(left, right);
                    var to = Expression.LessThanOrEqual(left, rightTo);
                    result = Expression.AndAlso(from, to);
                    break;
                case DataFilterCriteriaOperatorEnum.LessThan:
                    result = Expression.LessThan(left, right);
                    break;
                case DataFilterCriteriaOperatorEnum.GreaterThan:
                    result = Expression.GreaterThan(left, right);
                    break;
                case DataFilterCriteriaOperatorEnum.Contains:
                    // nothing (string handled above and drop down contains handled by GetExpressionDropDown
                    break;
                default:
                    throw new Exception("GetExpression: unable to build expression");
            }

            dynamic lambda = Expression.Lambda(delegateType, result, parameter);

            return lambda;
        }

        /// <summary>
        /// Builds up the lambda expression to represent a multi select drop down value selected by a user
        /// </summary>
        /// <param name="dataFilterCriteria"></param>
        /// <param name="fieldType"></param>
        /// <param name="operatorEnum"></param>
        /// <param name="left"></param>
        /// <returns></returns>
        private Expression GetExpressionDropDown(DataFilterCriteria dataFilterCriteria, Type domainType, Type fieldType, DataFilterCriteriaOperatorEnum operatorEnum, DataFilterField dataFilterField)
        {
            var parameter = Expression.Parameter(domainType);
            var delegateType = typeof(Func<,>).MakeGenericType(domainType, typeof(bool));

            Expression result = null;
            Expression left = Expression.Property(parameter, dataFilterField.ExpressionName);
            Expression right = null;
            IList Ids = null;

            // could be a list of ints, decimals or strings so lets handle both
            if (fieldType == typeof(int) || fieldType == typeof(int?))
                Ids = new List<int>(dataFilterCriteria.Value.Split('|').Select(int.Parse));

            if (fieldType == typeof(decimal) || fieldType == typeof(decimal?))
                Ids = new List<decimal>(dataFilterCriteria.Value.Split('|').Select(decimal.Parse));

            if (fieldType == typeof(string))
                Ids = new List<string>(dataFilterCriteria.Value.Split('|'));

            // iterate over the list and append to our expression using OrElse
            foreach (var Id in Ids)
            {
                left = Expression.Property(parameter, dataFilterField.ExpressionName);
                left = Expression.Convert(left, Id.GetType());
                right = Expression.Constant(Id);
                Expression equals = Expression.Equal(left, right);
                result = (result == null ? Expression.Equal(left, right) : Expression.OrElse(result, equals));
            }

            return Expression.Lambda(delegateType, result, parameter);
        }

        /// <summary>
        /// Parse the input string based on the target field type
        /// </summary>
        /// <param name="value"></param>
        /// <param name="fieldType"></param>
        /// <returns></returns>
        private dynamic ParseValueByType(dynamic value, Type fieldType)
        {
            if (fieldType == typeof(string))
                return value;

            if (fieldType == typeof(DateTime) || fieldType == typeof(DateTime?))
                return (DateTime)value;

            if (fieldType == typeof(int) || fieldType == typeof(int?))
                return (int)value;

            if (fieldType == typeof(decimal) || fieldType == typeof(decimal?))
                return (decimal)value;

            if (fieldType == typeof(long) || fieldType == typeof(long?))
                return (long)value;

            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <param name="fieldType"></param>
        /// <returns></returns>
        private string GetResourceStringByType(Type fieldType)
        {
            if (fieldType == typeof(string))
                return Resources.WebPageResources.DataFilter_Add_Criteria_Error_Data_Type_String;

            if (fieldType == typeof(DateTime) || fieldType == typeof(DateTime?))
                return Resources.WebPageResources.DataFilter_Add_Criteria_Error_Data_Type_Date;

            if (fieldType == typeof(int) || fieldType == typeof(int?))
                return Resources.WebPageResources.DataFilter_Add_Criteria_Error_Data_Type_Integer;

            if (fieldType == typeof(decimal) || fieldType == typeof(decimal?))
                return Resources.WebPageResources.DataFilter_Add_Criteria_Error_Data_Type_Decimal;

            if (fieldType == typeof(long) || fieldType == typeof(long?))
                return Resources.WebPageResources.DataFilter_Add_Criteria_Error_Data_Type_Long;

            return Resources.WebPageResources.DataFilter_Add_Criteria_Error_Data_Type_String;
        }

        /// <summary>
        /// Given a value and type return a full 'right' expression correctly typed
        /// </summary>
        /// <param name="value"></param>
        /// <param name="fieldType"></param>
        /// <returns></returns>
        private Expression BuildValueExpression(dynamic value, Type fieldType)
        {
            // guard
            if (value == null)
                return null;

            dynamic parsed = ParseValueByType(value, fieldType);
            var expression = Expression.Constant(parsed);
            return Expression.Convert(expression, fieldType);
        }

        /// <summary>
        /// Given a DataFilterCriteria object return a ParameterExpression object
        /// </summary>
        /// <param name="dataFilterField"></param>
        /// <param name="domainType"></param>
        /// <param name="fieldType"></param>
        /// <returns></returns>
        public ParameterExpression GetParameterExpression(DataFilterField dataFilterField, out Type domainType, out Type fieldType)
        {
            domainType = typeof(ViewDataFilter);
            IList<PropertyInfo> props = new List<PropertyInfo>(domainType.GetProperties());
            ParameterExpression parameterExpression = null;

            fieldType = props.SingleOrDefault(prop => prop.Name.ToLower() == dataFilterField.ExpressionName.ToLower())?.PropertyType;
            parameterExpression = Expression.Parameter(domainType, dataFilterField.ExpressionName);

            return parameterExpression;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFilterId"></param>
        /// <param name="dataFilterFieldId"></param>
        /// <returns></returns>
        private bool CriteriaExistsForDataFilter(int dataFilterId, int dataFilterFieldId)
        {
            if (dataFilterId == 0)
                return false;

            var db = new DataFilterDbAccess();
            var criteria = db.GetDataFilterCriteria(dataFilterId);
            return criteria.Any(item => item.DataFilterFieldID == dataFilterFieldId);
        }

        public int DataFilterCriteriaCount(int dataFilterId)
        {
            var db = new DataFilterDbAccess();
            return db.GetDataFilterCriteria(dataFilterId).Count();
        }

        #endregion
    }
}
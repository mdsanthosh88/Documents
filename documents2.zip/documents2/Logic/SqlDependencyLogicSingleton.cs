﻿using System;
using XLC.MyAnalysis2.DbAccess;
using XLC.MyAnalysis2.DbAccess.CustomEventArgs;
using XLC.MyAnalysis2.DbModels.DbEnums;

namespace XLC.MyAnalysis2.Logic
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class SqlDependencyLogicSingleton
    {
        /// <summary>
        /// 
        /// </summary>
        public event SqlDependencyEventhandler DoAlert;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        private void OnDoAlert(SqlDependencyEventArgs args)
        {
            DoAlert?.Invoke(this, args);
        }

        /// <summary>
        /// 
        /// </summary>
        private static readonly SqlDependencyLogicSingleton m_instance = new SqlDependencyLogicSingleton();

        /// <summary>
        /// 
        /// </summary>
        static SqlDependencyLogicSingleton()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        private SqlDependencyLogicSingleton()
        {
            SqlDependencyDataAccessSingleton.Instance.DoAlert += dependency_OnChange;
        }

        /// <summary>
        /// 
        /// </summary>
        public static SqlDependencyLogicSingleton Instance
        {
            get
            {
                return m_instance;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dependency_OnChange(object sender, SqlDependencyEventArgs e)
        {
            OnDoAlert(e);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="start"></param>
        /// <param name="notificationType"></param>
        public void RegisterNotification(DateTime start, NotificationTypeEnum notificationType)
        {
            SqlDependencyDataAccessSingleton.Instance.RegisterNotification(start, notificationType);
        }
    }
}

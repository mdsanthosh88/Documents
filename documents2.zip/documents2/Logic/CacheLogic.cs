﻿using System;
using System.Collections.Generic;
using System.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Caching;
using System.Security.Cryptography;
using System.Text;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.Shared;

namespace XLC.MyAnalysis2.Logic
{
    /// <summary>
    /// Memory Cache for objects in the business logic layer.
    /// https://docs.microsoft.com/en-us/dotnet/api/system.runtime.caching.memorycache?view=dotnet-plat-ext-3.1
    /// </summary>
    public class CacheLogic : BaseLogic
    {
        #region Variables

        private readonly ObjectCache _cache;

        #endregion

        #region Public Methods

        public CacheLogic()
        {
            _cache = MemoryCache.Default;
        }

        /// <summary>
        /// Gets (any) cached object matching the supplied criteria.
        /// A key is built by hashing the serialised criteria.
        /// </summary>
        /// <param name="cacheSource">Text description of cache source</param>
        /// <param name="userId">Current user's Id (for adding Locations Picker location IDs to cache key)</param>
        /// <param name="parameters">Variable set of parameters to be added to cache key</param>
        /// <returns>Object from cache, or null if not found</returns>
        public object GetAnyCachedCopyOfObject(string cacheSource, int? userId, string currentCulture, params object[] parameters)
        {
            if (ConfigHelper.GetAppSettingBool("SuppressMemoryCache"))
            {
                LogHelper.Info("Memory Cache suppressed - call to GetAnyCachedCopyOfObject bypassed");
                return null;
            }

            var parametersList = GetCombinedParametersList(parameters, userId, cacheSource, currentCulture);

            string key = GenerateHashOfObjectSerialised(parametersList);

            object objectFromCache = _cache[key];

            if (objectFromCache != null)
            {
                LogHelper.Debug($"Cache HIT for {cacheSource}{(userId != null ? " and UserId " + userId : String.Empty)}");
                return objectFromCache;
            }
            else
            {
                LogHelper.Debug($"Cache MISS for {cacheSource}{(userId != null ? " and UserId " + userId : String.Empty)}");
                return null;
            }
        }

        /// <summary>
        /// Ensures that the supplied object is in the cache, for the supplied criteria.
        /// MemoryCache.Set: A cache entry is either inserted as a new entry if the specified entry does not exist,
        ///                     or the cache entry is updated with a new value if it already exists.
        /// </summary>
        /// <param name="cacheSource">See documentation for GetAnyCachedCopyOfObject</param>
        /// <param name="data">Data to be stored in cache</param>
        /// <param name="userId">See documentation for GetAnyCachedCopyOfObject</param>
        /// <param name="parameters">See documentation for GetAnyCachedCopyOfObject</param>
        public void EnsureObjectInCache(string cacheSource, object data, int? userId, string currentCulture, params object[] parameters)
        {
            if (ConfigHelper.GetAppSettingBool("SuppressMemoryCache"))
            {
                LogHelper.Info("Memory Cache suppressed - call to EnsureObjectInCache bypassed");
                return;
            }

            var parametersList = GetCombinedParametersList(parameters, userId, cacheSource, currentCulture);

            string key = GenerateHashOfObjectSerialised(parametersList);

            CacheItemPolicy policy = CreateCacheItemPolicy();

            _cache.Set(key, data, policy);  //equivalent of Upsert
        }

        /// <summary>
        /// As EnsureObjectInCache, but also sets additional SqlDependency on dbo.Document table to detect change to records
        /// relating to the supplied accountNo. Used to detect EDMS/Documentum document uploads / deletions.
        /// </summary>
        /// <param name="cacheSource">See documentation for GetAnyCachedCopyOfObject</param>
        /// <param name="accountNo">Account Number for sql dependency</param>
        /// <param name="data">Data to be stored in cache</param>
        /// <param name="userId">See documentation for GetAnyCachedCopyOfObject</param>
        /// <param name="parameters">See documentation for GetAnyCachedCopyOfObject</param>
        public void EnsureObjectInCacheWithDocumentDependency(string cacheSource, string accountNo, object data, int? userId, params object[] parameters)
        {
            if (ConfigHelper.GetAppSettingBool("SuppressMemoryCache"))
            {
                LogHelper.Info("Memory Cache suppressed - call to EnsureObjectInCache bypassed");
                return;
            }

            var parametersList = GetCombinedParametersList(parameters, userId, cacheSource,null);

            string key = GenerateHashOfObjectSerialised(parametersList);

            CacheItemPolicy policy = CreateCacheItemPolicy();

            AddDocumentDependencyToCacheItemPolicy(accountNo, ref policy);

            _cache.Set(key, data, policy);  //equivalent of Upsert
        }

        /// <summary>
        /// Flush the cache
        /// </summary>
        public void Flush()
        {
            List<string> cacheKeys = _cache.Select(kvp => kvp.Key).ToList();
            LogHelper.Debug($"Removing {cacheKeys.Count} Items from the MemoryCache");
            foreach (string cacheKey in cacheKeys)
            {
                _cache.Remove(cacheKey);
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Create CacheItemPolicy with SqlDependency on dbo.ETLProcessingData.
        /// ETLProcessingData updated upon completion of ETL process (via proc_PostEtlBatchProcessing)
        /// This ensures that the cache is cleared upon completion of ETL process.
        /// </summary>
        /// <returns></returns>
        private CacheItemPolicy CreateCacheItemPolicy()
        {
            var policy = new CacheItemPolicy();

            // Create SQL Dependency change monitor
            using (var ma2DbContext = new MA2DbContext())
            {
                string connectionString = EncryptedItemHelper.GetDecryptedValue(EncryptedItemHelper.EncryptedItemEnum.Ma2SqlDependency);

                SqlDependency.Start(connectionString);

                using (var conn = new SqlConnection(connectionString))
                {
                    // ETLProcessingData updated upon completion of ETL process (via proc_PostEtlBatchProcessing)
                    using (var command = new SqlCommand("SELECT LastETLRunDateTime FROM dbo.ETLProcessingData", conn))
                    {
                        command.Notification = null;
                        var dep = new SqlDependency();

                        dep.AddCommandDependency(command);

                        var monitor = new SqlChangeMonitor(dep);
                        policy.ChangeMonitors.Add(monitor);

                        try
                        {
                            conn.Open();

                            command.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            LogHelper.Error("Error executing cache dependency SQL", ex);
                            throw;
                        }
                        finally
                        {
                            if (conn.State == ConnectionState.Open)
                                conn.Close();

                            SqlDependency.Stop(connectionString);
                        }

                        
                    }
                }
            }

            return policy;
        }

        /// <summary>
        /// Add SqlDependency to the specified CacheItemPolicy to monitor the Document table.
        /// The SqlDependency is to be specific to the account number.
        /// </summary>
        /// <returns></returns>
        private void AddDocumentDependencyToCacheItemPolicy(string accountNo, ref CacheItemPolicy policy)
        {
            // Create SQL Dependency change monitor
            using (var ma2DbContext = new MA2DbContext())
            {
                string connectionString = EncryptedItemHelper.GetDecryptedValue(EncryptedItemHelper.EncryptedItemEnum.Ma2SqlDependency);

                SqlDependency.Start(connectionString);

                using (var conn = new SqlConnection(connectionString))
                {
                    // ETLProcessingData updated upon completion of ETL process (via proc_PostEtlBatchProcessing)
                    using (var command = new SqlCommand($"SELECT CHECKSUM(ID) FROM dbo.Document WHERE LPAcctNo = '{accountNo}'", conn))
                    {
                        command.Notification = null;
                        var dep = new SqlDependency();
                        dep.AddCommandDependency(command);

                        var monitor = new SqlChangeMonitor(dep);

                        policy.ChangeMonitors.Add(monitor);
                        try
                        {
                            conn.Open();

                            command.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            LogHelper.Error("Error executing cache dependency SQL", ex);
                            throw;
                        }
                        finally
                        {
                            if (conn.State == ConnectionState.Open)
                                conn.Close();

                            SqlDependency.Stop(connectionString);
                        }

                        
                    }
                }
            }
        }

        private List<object> GetCombinedParametersList(object[] variableParametersList, int? userId, string cacheSource, string currentCulture)
        {
            var combinedParametersList = new List<object>();

            if (variableParametersList != null) combinedParametersList.AddRange(variableParametersList);

            if (userId != null)
            {
                var anyLocationsSelectorDataFilter = base.LoadAnyLocationsSelectorDataFilterByUser((int)userId);
                if (anyLocationsSelectorDataFilter != null
                    && anyLocationsSelectorDataFilter.DataFilterCriterias.Count > 0)
                {
                    string lpAllPiKeys =
                        anyLocationsSelectorDataFilter.DataFilterCriterias.First()
                            .Value; //selected Locations Picker items, | separated list of LPAllPiKeys

                    combinedParametersList.Add(lpAllPiKeys);
                }
            }

            if (!string.IsNullOrEmpty(currentCulture))
            {
                combinedParametersList.Add(currentCulture);
            }

            combinedParametersList.Add(cacheSource);

            return combinedParametersList;
        }

        /// <summary>
        /// Generate SHA256 hash of the object serialised to Json.
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        private string GenerateHashOfObjectSerialised(object obj)
        {
            string jSon = JsonConvert.SerializeObject(obj);
            using (SHA256 sha256Hash = SHA256.Create())
            {
                return GenerateHashOfString(sha256Hash, jSon);
            }
        }

        private string GenerateHashOfString(HashAlgorithm hashAlgorithm, string input)
        {
            // Convert the input string to a byte array and compute the hash.
            byte[] data = hashAlgorithm.ComputeHash(Encoding.UTF8.GetBytes(input));

            // Create a new Stringbuilder to collect the bytes
            // and create a string.
            var sBuilder = new StringBuilder();

            // Loop through each byte of the hashed data
            // and format each one as a hexadecimal string.
            foreach (var t in data)
            {
                sBuilder.Append(t.ToString("x2"));
            }

            // Return the hexadecimal string.
            return sBuilder.ToString();
        }

        #endregion
    }
}
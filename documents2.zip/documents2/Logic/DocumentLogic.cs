﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Messaging;
using System.Web;
using Newtonsoft.Json;
using XLC.MyAnalysis2.DbAccess;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.DbModels.DbEnums;
using XLC.MyAnalysis2.DocumentService;
using XLC.MyAnalysis2.Logic.DTO;
using XLC.MyAnalysis2.Logic.DTO.MessageQueueDTO;
using XLC.MyAnalysis2.Shared;
using XLC.MyAnalysis2.Shared.Documents;
using XLC.MyAnalysis2.Logic.ExtensionMethods;
using System.Data;
using System.Threading;
using XLC.MyAnalysis2.Resources;
using XLC.MyAnalysis2.WebPortal.Helpers;

namespace XLC.MyAnalysis2.Logic
{
    public class DocumentLogic : BaseLogic
    {
        //private string UserName;
        protected DataRepository Repo = new DataRepository();

        private const int DocumentDeleteSleepMicroseconds = 1000;

        private string _userName;

        #region Properties

        /// <summary>
        /// Load the MemoryCompressionLimit setting from the config file
        /// </summary>
        /// <returns></returns>
        private int _memoryCompressionLimit
        {
            get
            {
                if (ConfigurationManager.AppSettings["MemoryCompressionLimit"] == null)
                    return 0;

                if (int.TryParse(ConfigurationManager.AppSettings["MemoryCompressionLimit"], out int memoryCompressionLimit))
                    return memoryCompressionLimit;

                return 0;
            }
        }

        #endregion

        public DocumentLogic()
        {
        }

        public DocumentLogic(string userName)
        {
            this._userName = userName;
        }

        #region Load

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public DocumentType LoadDocumentTypeById(Constants.DocumentType id)
        {
            DocumentDbAccess db = new DocumentDbAccess();
            return db.LoadDocumentTypeById((int)id);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public DocumentType LoadDocumentTypeById(int id)
        {
            DocumentDbAccess db = new DocumentDbAccess();
            return db.LoadDocumentTypeById((int)id);
        }

        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="documentID"></param>
        /// <param name="LPAcctKey"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public MA2Document GetSingleDocument(string documentID, int LPAcctKey, int userId, bool isedit = false)
        {
            DocumentService.DocumentService documentService = new DocumentService.DocumentService();
            var results = new List<MA2Document>();

            var locRecords = Repo.GetAll<ViewLocation>().Where(x => x.LpAcctKey == LPAcctKey).ToList();
            var documentTypes = GetDocumentTypesForUser(userId);

            DocumentInfo doc = documentService.GetSingleDocument(documentID);

            var documentType = documentTypes.Single(map =>
                map.DocumentumDocType == doc.MADocumentType || map.IncludedDocumentumDocType == doc.MADocumentType);

            var combinedResult = new MA2Document
            {
                ClientLocationNo = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.ClientLocationNo,
                LocationNo = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.LocationNo,
                LocationCode = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.LocationCode,
                RepositoryUniqueID = doc.DocumentID,
                LPAcctNo = doc.LPAccountNum,
                LPAcctWebDivKey = locRecords.FirstOrDefault(loc => doc.LPAllPiKey != 0 ? loc.LpAllPiKey == doc.LPAllPiKey : loc.LpAcctWebDivKey == doc.LPAcctWebDivKey)?.LpAcctWebDivKey,
                LPSubDivKey = locRecords.FirstOrDefault(loc => doc.LPAllPiKey != 0 ? loc.LpAllPiKey == doc.LPAllPiKey : loc.LpSubDivKey == doc.LPSubDivKey)?.LpSubDivKey,
                LPAllPiKey = isedit ? doc.DocumentLevel == 3 ? doc.LPAllPiKey ?? 0 : 0 : doc.LPAllPiKey ?? 0,
                DivisionName = locRecords.FirstOrDefault(loc => doc.LPAllPiKey != 0 ? loc.LpAllPiKey == doc.LPAllPiKey : loc.LpAcctWebDivKey == doc.LPAcctWebDivKey)?.DivisionName,
                SubDivisionName = locRecords.FirstOrDefault(loc => doc.LPAllPiKey != 0 ? loc.LpAllPiKey == doc.LPAllPiKey : loc.LpSubDivKey == doc.LPSubDivKey)?.SubDivisionName,
                LocationName = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.LocationName,
                AddressLine1 = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.AddressLine1,
                AddressLine2 = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.AddressLine2,
                AddressLine3 = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.AddressLine3,
                City = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.City,
                State = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.State,
                Country = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.Country,
                TotalPropertyValue = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.PdValue,
                BusinessInterruptionValue = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.BiValue,
                TotalInsurableValue = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.Tiv,
                DocumentTypeID = documentType.ID,
                DocumentTypeName = documentType?.Name,
                DatePosted = doc.DatePosted,
                Subject = doc.Subject,
                FileName = doc.FileName,
                DocumentDate = doc.DocumentDate.HasValue? doc.DocumentDate: DateTime.UtcNow ,
                DocumentLevel = doc.DocumentLevel,
                OrganizationPosted = doc.OrganizationPosted,
                AuthorPosted = doc.AuthorPosted,
                TaskNumber = doc.TaskNumber,
                LCID = doc.LCID,
                FileType = doc.FileType,
                MyComments1 = string.Empty,
                MyComments2 = string.Empty,
                MyComments3 = string.Empty,
                SharedComment1 = string.Empty,
                LossTypeKey= doc.LossTypKey.HasValue? doc.LossTypKey: 0,
                LOBKey=doc.LOBKey
            };

            return combinedResult;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="LPAcctNo"></param>
        /// <param name="userId"></param>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        public List<Document> DocumentsUploadedByUser(string LPAcctNo, int userId, DateTime? from, DateTime? to)
        {
            DateTime? toDateAtEndOfDay = DateTimeHelpers.SetToEndOfDay(to);
            return Repo.GetAll<Document>()
                                .Where(d => d.CreatedBy == userId)
                                .Where(d => d.LpAcctNo == LPAcctNo)
                                .Where(d => !from.HasValue || d.CreatedDate >= from.Value)
                                .Where(d => !to.HasValue || d.CreatedDate <= toDateAtEndOfDay)
                                .ToList();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="RepositoryUniqueID"></param>
        /// <returns></returns>
        public Document GetDocumentByRepositoryUniqueID(string RepositoryUniqueID)
        {
            return Repo.GetAll<Document>()
                                .Where(d => d.RepositoryUniqueID == RepositoryUniqueID)
                                .FirstOrDefault();
        }

        /// <summary>
        /// Checks to see whether a document exists for a specific location and document type
        /// </summary>
        /// <param name="lpAccountNum"></param>
        /// <param name="lpAllPiKey"></param>
        /// <param name="documentType"></param>
        /// <returns></returns>
        public bool DocumentExists(string lpAccountNum, int lpAllPiKey, Constants.DocumentType documentType)
        {
            DocumentDbAccess documentDbAccess = new DocumentDbAccess();
            DocumentService.DocumentService documentService = new DocumentService.DocumentService();
            DocumentType documentDbType = documentDbAccess.LoadDocumentTypeById((int)documentType);
            DocumentSearchRequest request = new DocumentSearchRequest { LPAccountNum = lpAccountNum, LpAllPiKeys = new List<int> { lpAllPiKey }, DocumentType = new List<string> { documentDbType.DocumentumDocType } };

            return documentService.SearchDocuments(request).Where(item => item.LPAllPiKey == lpAllPiKey).Any();
        }

        /// <summary>
        /// Retrieve the latest document for a specific location and document type.
        /// </summary>
        /// <param name="lpAccountNum">Account Number</param>
        /// <param name="lpAllPiKey">LP's location id</param>
        /// <param name="documentType">The type of document to retrieve</param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public MemoryStream GetLatestDocument(string lpAccountNum, int lpAllPiKey, Constants.DocumentType documentType, out string fileName, int userId)
        {
            DocumentDbAccess documentDbAccess = null;
            DocumentService.DocumentService documentService = null;
            DocumentSearchRequest request = null;
            MemoryStream documentStream = null;
            string filePath = null;
            documentService = new DocumentService.DocumentService();
            documentDbAccess = new DocumentDbAccess();

            DocumentType documentDbType = documentDbAccess.LoadDocumentTypeById((int)documentType);

            if (documentDbType == null)
            {
                throw new ArgumentException($"Document with a type id of {documentType} could not be found.");
            }

            request = new DocumentSearchRequest { LPAccountNum = lpAccountNum, LpAllPiKeys = new List<int> { lpAllPiKey }, DocumentType = new List<string> { documentDbType.DocumentumDocType } };
            var response = documentService.SearchDocuments(request);

            IEnumerable<MA2Document> documents = DocumentInfoToMA2Document(response).Where(item => item.LPAllPiKey == lpAllPiKey).OrderByDescending(x => x.DatePosted);

            var responseDoc = documents.FirstOrDefault();

            if (responseDoc != null)
            {
                byte[] documentContent = this.GetDocumentContent(responseDoc.RepositoryUniqueID, true, out filePath, userId);
                documentStream = new MemoryStream(documentContent);
            }

            fileName = filePath;
            return documentStream;
        }

        private IEnumerable<MA2Document> DocumentInfoToMA2Document(IList<DocumentService.DocumentInfo> documentInfos)
        {
            return documentInfos.Select(doc => new MA2Document
            {
                RepositoryUniqueID = doc.DocumentID,
                LPAllPiKey = doc.LPAllPiKey.GetValueOrDefault(),
                DocumentTypeName = doc.MADocumentType,
                DatePosted = doc.DatePosted,
                FileName = doc.FileName
            });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="repositoryUniqueID"></param>
        /// <returns></returns>
        public string LoadDocumentPostedBy(string repositoryUniqueID)
        {
            var result = string.Empty;
            var docLogic = new DocumentLogic();
            var userLogic = new UserLogic();

            if (repositoryUniqueID == null)
                return result;

            try
            {
                var document = docLogic.LoadDocumentByRepositoryUniqueID(repositoryUniqueID);
                var user = userLogic.GetUser(document.CreatedBy);
                var userMerged = userLogic.GetMergedUserByEdsCn(user.EdsCn);

                result = $"{userMerged.ForeName} {userMerged.Surname}";
            }
            catch (Exception ex)
            {
                LogHelper.Error($"LoadDocumentPostedBy : Error PostedBy for repositoryUniqueID: {repositoryUniqueID}", ex);
            }

            return result;
        }

        /// <summary>
        /// Retrieve a list of documents associated with the account
        /// </summary>
        /// <param name="filters"></param>
        /// <returns></returns>
        public List<MA2Document> GetAccountDocuments(PagedDocumentFilters filters, int userId, bool useLocationNo = true, bool isDocTile = false)
        {
            var results = new List<MA2Document>();

            var documentTypes = GetDocumentTypesForUser(userId);
            if (documentTypes.Count == 0)
            {
                LogHelper.Warn($"User ID: {{userId}} does not have permissions to access any document types");
                return results;
            }

            List<ViewLocation> locRecords = null;

            string cacheSource = $"GetAccountDocuments {filters.LPAcctNum}";
            var cacheLogic = new CacheLogic();
            object dataFromCache = cacheLogic.GetAnyCachedCopyOfObject(cacheSource, null, null, filters.LPAcctKey);
            if (dataFromCache != null)
            {
                locRecords = (List<ViewLocation>)dataFromCache;
            }
            else
            {
                locRecords = Repo.GetAll<ViewLocation>().Where(x => x.LpAcctKey == filters.LPAcctKey).ToList();

                // Ensure object is in the Memory Cache
                cacheLogic.EnsureObjectInCache(cacheSource, locRecords, null, null, filters.LPAcctKey);
            }

            var documentsMetaDataFromEdms = GetDocumentsMetaDataFromEDMS(filters, userId);

            var accountLogic = new AccountLogic();
            string accountName = accountLogic.GetAccount(filters.LPAcctKey).AccountName;

            var documentDbAccess = new DocumentDbAccess();
            List<string> documentIDsUploadedBySiteForward =
                documentDbAccess.LoadAccountDocumentRepositoryUniqueIDs(filters.LPAcctNum);

            var combinedResults = documentsMetaDataFromEdms
                .Select(doc => new MA2Document
                {
                    ClientLocationNo = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.ClientLocationNo,
                    LocationNo = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.LocationNo,
                    LocationCode = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.LocationCode,
                    RepositoryUniqueID = doc.DocumentID,
                    LPAcctNo = doc.LPAccountNum,
                    LPAcctWebDivKey = locRecords.FirstOrDefault(loc => doc.LPAllPiKey != 0 ? loc.LpAllPiKey == doc.LPAllPiKey : loc.LpAcctWebDivKey == doc.LPAcctWebDivKey)?.LpAcctWebDivKey,
                    LPSubDivKey = locRecords.FirstOrDefault(loc => doc.LPAllPiKey != 0 ? loc.LpAllPiKey == doc.LPAllPiKey : loc.LpSubDivKey == doc.LPSubDivKey)?.LpSubDivKey,
                    LPAllPiKey = doc.LPAllPiKey ?? 0,
                    DivisionName = locRecords.FirstOrDefault(loc => doc.LPAllPiKey != 0 ? loc.LpAllPiKey == doc.LPAllPiKey : loc.LpAcctWebDivKey == doc.LPAcctWebDivKey)?.DivisionName,
                    SubDivisionName = locRecords.FirstOrDefault(loc => doc.LPAllPiKey != 0 ? loc.LpAllPiKey == doc.LPAllPiKey : loc.LpSubDivKey == doc.LPSubDivKey)?.SubDivisionName,
                    LocationName = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.LocationName,
                    AddressLine1 = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.AddressLine1,
                    AddressLine2 = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.AddressLine2,
                    AddressLine3 = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.AddressLine3,
                    City = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.City,
                    State = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.State,
                    Country = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.Country,
                    TotalPropertyValue = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.PdValue,
                    BusinessInterruptionValue = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.BiValue,
                    TotalInsurableValue = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.Tiv,
                    DocumentTypeName = documentTypes.SingleOrDefault(map => map.DocumentumDocType == doc.MADocumentType || map.IncludedDocumentumDocType == doc.MADocumentType).Name,
                    DatePosted = doc.DatePosted,
                    Subject = doc.Subject,
                    FileName = doc.FileName,
                    DocumentDate = doc.DocumentDate,
                    DocumentLevel = doc.DocumentLevel,
                    OrganizationPosted = doc.OrganizationPosted,
                    AuthorPosted = doc.AuthorPosted,
                    TaskNumber = doc.TaskNumber,
                    TaskCode = doc.TaskCode,
                    LCID = doc.LCID,
                    LOBKey = doc.LOBKey,
                    FileType = doc.FileType,
                    MyComments1 = string.Empty,
                    MyComments2 = string.Empty,
                    MyComments3 = string.Empty,
                    SharedComment1 = string.Empty,
                    WasUploadedBySiteForward = documentIDsUploadedBySiteForward.Contains(doc.DocumentID),
                    AccountName = accountName,
                    LossTypeKey = doc.LossTypKey
                }).ToList();


            filters.Paging.TotalRecords = combinedResults.Count;

            // if we have a sort expression use our extension method to sort appropriately
            if (!string.IsNullOrEmpty(filters.SortExpression))
            {
                // determine whether to sort asc or desc
                var desc = !string.IsNullOrEmpty(filters.SortExpression) &&
                                     filters.SortExpression.ToLower().Contains("desc") && !filters.SortExpression.ToLower().StartsWith("desc");

                // determine our sort expression
                var expr = !desc ? filters.SortExpression.Trim() : filters.SortExpression.Substring(0, filters.SortExpression.LastIndexOf("DESC")).Trim();

                // if the LocationCode should be shown - sort by that instead
                if (expr == nameof(MA2Document.LocationNo) && !useLocationNo)
                    expr = nameof(MA2Document.LocationCode);
                if (expr == nameof(MA2Document.StandardizedFileName) && !useLocationNo)
                    expr = nameof(MA2Document.StandardizedFileNameCode);
                if (expr == "Peril")
                {
                    expr = "LossTypeKey";
                }

                if (isDocTile)
                {
                    if (expr == "LocationName")
                    {
                        expr = "City";
                    }
                }

                if (string.IsNullOrEmpty(expr))
                    expr = "DatePosted";

                // sort the result set
                results = combinedResults.AsQueryable().OrderBy(expr, !desc).ToList();
            }
            else
            {
                results = combinedResults
                    .OrderByDescending(x => x.DatePosted)
                    .ThenBy(x => x.RepositoryUniqueID)
                    .ToList();
            }


            return results
                .Skip(filters.Paging.PageOffset)
                .Take(filters.Paging.PageSize)
                .ToList();
        }

        public List<DocumentInfo> GetDocumentsMetaDataFromEDMS(DocumentFiltersBase filters, int userId, bool fromDateSearchGreaterOrEqual = true)
        {
            var docRepo = new DocumentService.DocumentService();

            List<DocumentType> documentTypesForUser = GetDocumentTypesForUser(userId);

            // If we have no doc types in the list of the Document Types the user wants to view - load them all.
            documentTypesForUser = (filters.TypeFilter == null || filters.TypeFilter.Count == 0) ?
                documentTypesForUser.ToList() :
                documentTypesForUser.Where(x => filters.TypeFilter.Contains(x.ID)).ToList();

            List<string> documentTypes = documentTypesForUser
                    .Select(x => x.DocumentumDocType)
                    .Union(
                        documentTypesForUser
                        .Where(x => !string.IsNullOrEmpty(x.IncludedDocumentumDocType))
                        .Select(x => x.IncludedDocumentumDocType)
                    ).ToList();

            DocumentSearchRequest request = new DocumentSearchRequest
            {
                LPAccountNum = filters.LPAcctNum,
                LPAcctWebDivKeys = filters.LPAcctWebDivKeyFilter,
                LPSubDivKeys = filters.LPSubDivKeyFilter,
                LpAllPiKeys = filters.LPAllPiKeyFilter.OrderBy(x => x).ToList(),
                LPAcctDivGroupKeyRegion = filters.LPAcctDivGroupKeyRegions,
                LPAcctDivGroupKeyClassification = filters.LPAcctDivGroupKeyClassifications,
                LPAcctDivGroupKeyOtherProvider = filters.LPAcctDivGroupKeyOtherProviders,
                DocumentType = documentTypes,
                LOBFilter = filters.LOBFilter,
                PerilFilter = filters.PerilFilter,
                OrganizationPostedFilter = filters.OrganizationPostedFilter,
                DocAccessFilter = filters.DocAccessFilter
            };

            List<DocumentInfo> result = null;
            LogHelper.Info($"GetDocumentsMetaDataFromEDMS {filters.LPAcctNum}- {request}- {filters}");
            // Try to get data from the Memory Cache (instead of call to EDMS/Documentum web service)
            string cacheSource = $"GetDocumentsMetaDataFromEDMS {filters.LPAcctNum}";
            var cacheLogic = new CacheLogic();
            object dataFromCache = cacheLogic.GetAnyCachedCopyOfObject(cacheSource, null, null,request, filters);
           
            if (dataFromCache != null)
            {               
                result = (List<DocumentInfo>)dataFromCache;              
            }
            else
            {              
                var docRecords = docRepo.SearchDocuments(request);              

                ////filter set of documents inline with Division, Sub-division and Location filters (plus Document Type)
                var baseRecords = docRecords.Where(x =>
                    (x.LPAcctWebDivKey == null || x.LPAcctWebDivKey == 0 ||
                     filters.LPAcctWebDivKeyFilter.Contains((int)x.LPAcctWebDivKey))
                    && (x.LPSubDivKey == null || x.LPSubDivKey == 0 ||
                        filters.LPSubDivKeyFilter.Contains((int)x.LPSubDivKey))
                    && (x.LPAllPiKey == null || x.LPAllPiKey == 0 ||
                        filters.LPAllPiKeyFilter.Contains((int)x.LPAllPiKey))
                    && (x.LPAcctDivGroupKeyRegion == null || x.LPAcctDivGroupKeyRegion == 0 ||
                        filters.LPAcctDivGroupKeyRegions.Contains((int)x.LPAcctDivGroupKeyRegion))
                    && (x.LPAcctDivGroupKeyClassification == null || x.LPAcctDivGroupKeyClassification == 0 ||
                        filters.LPAcctDivGroupKeyClassifications.Contains((int)x.LPAcctDivGroupKeyClassification))
                    && (x.LPAcctDivGroupKeyOtherProvider == null || x.LPAcctDivGroupKeyOtherProvider == 0 ||
                        filters.LPAcctDivGroupKeyOtherProviders.Contains((int)x.LPAcctDivGroupKeyOtherProvider))
                );

                // 142923 - ensure document retention policy is ALWAYS applied if configured
                if (AccountHasDocumentNonDisplay(filters.LPAcctKey, out var retentionLimit))
                    baseRecords = baseRecords.Where(x =>
                        x.DatePosted == null || x.DatePosted.Value.Date >= retentionLimit.Value.Date);

                if (filters.DateMode == Constants.DocumentDateDisplayMode.DatePosted)
                {
                    if (filters.FromDateFilter != null)
                    {
                        // If we use  Documents posted with ‘DatePosted’ >= Run Date – 1 day we run the risk of sending out duplicate emails.
                        if (fromDateSearchGreaterOrEqual)
                        {
                            baseRecords = baseRecords.Where(x =>
                            x.DatePosted == null || x.DatePosted.Value.Date >= filters.FromDateFilter.Value.Date);
                        }
                        else
                        {
                            baseRecords = baseRecords.Where(x =>
                            x.DatePosted == null || x.DatePosted.Value.Date == filters.FromDateFilter.Value.Date);
                        }
                    }
                        

                    if (filters.ToDateFilter != null)
                    {
                        
                        if (filters.ToDateFilter.Value.ToString("dd/M/yyyy").Equals(DateTime.UtcNow.ToString("dd/M/yyyy")))
                        {                            
                            baseRecords = baseRecords.Where(x =>
                              x.DatePosted == null || x.DatePosted.Value.Date <= filters.ToDateFilter.Value.Date.AddDays(1));

                            LogHelper.Info($"ToDateFilter-CurrentTimeStamp {filters.ToDateFilter.Value.ToString("dd/M/yyyy")}-{DateTime.UtcNow.ToString("dd/M/yyyy")}");
                        }
                        else
                        {
                            baseRecords = baseRecords.Where(x =>
                                x.DatePosted == null || x.DatePosted.Value.Date <= filters.ToDateFilter.Value.Date);

                            LogHelper.Info($"ToDateFilter {filters.ToDateFilter.Value.ToString("dd/M/yyyy")}-{DateTime.UtcNow.ToString("dd/M/yyyy")}");
                        }

                    }
                }

                // If document has no DocumentDate then it should be excluded
                if (filters.DateMode == Constants.DocumentDateDisplayMode.DocumentDate)
                {
                    if (filters.FromDateFilter != null)
                        baseRecords = baseRecords.Where(x =>
                            x.DocumentDate == null || x.DocumentDate.Value.Date >= filters.FromDateFilter.Value.Date);

                    if (filters.ToDateFilter != null)
                        if (filters.ToDateFilter.Value.ToString("dd/M/yyyy").Equals(DateTime.UtcNow.ToString("dd/M/yyyy")))
                        {
                            baseRecords = baseRecords.Where(x =>
                              x.DocumentDate == null || x.DocumentDate.Value.Date <= filters.ToDateFilter.Value.Date.AddDays(1));
                        }
                        else
                        {
                            baseRecords = baseRecords.Where(x =>
                                x.DocumentDate == null || x.DocumentDate.Value.Date <= filters.ToDateFilter.Value.Date);
                        }
                }

                // Most Recent - given the applied filters, show the most recent doc per Division, Location & Doc Type
                // We may have two MADocumentType which have been merged into a single SF Doc Type which is why we have join criteria in the where clause 
                if (filters.MostRecent)
                {
                    baseRecords = from doc in baseRecords
                                  from type in documentTypesForUser
                                  where doc.MADocumentType == type.DocumentumDocType ||
                                        doc.MADocumentType == type.IncludedDocumentumDocType
                                  group doc by (doc.LPAcctWebDivKey, doc.LPSubDivKey, doc.LPAllPiKey, type.Name)

                    into grouping
                                  select grouping.OrderByDescending(x => x.DatePosted).FirstOrDefault();


                }

                result = baseRecords.ToList();

                // Ensure object is in the Memory Cache
                cacheLogic.EnsureObjectInCacheWithDocumentDependency(cacheSource, filters.LPAcctNum, result, null,
                                                            request, filters);               

            }

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="repositoryUniqueID"></param>
        /// <param name="download"></param>
        /// <param name="fileName"></param>
        /// <param name="userId">Inserts an audit record for the user having viewed this document</param>
        /// <returns></returns>
        public byte[] GetDocumentContent(string repositoryUniqueID, bool download, out string fileName, int userId)
        {
            var docRepo = new DocumentService.DocumentService();
            var bytes = docRepo.GetDocumentContent(repositoryUniqueID, out fileName);
            var memoryCompressionLimit = _memoryCompressionLimit;

            // insert audit record
            InsertDocumentAuditRecord(userId, repositoryUniqueID);

            // if downloading - compress first
            return bytes;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="docContent"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public bool UpsertDocument(MA2Document doc, byte[] docContent, int userId)
        {
            var success = false;
            DocumentDbAccess db = new DocumentDbAccess();

            DocumentInfo docInfo = new DocumentInfo()
            {
                DocumentID = doc.RepositoryUniqueID,
                DatePosted = doc.DatePosted,
                MADocumentType = doc.DocumentTypeName,
                LPAccountNum = doc.LPAcctNo,
                LPAcctWebDivKey = doc.LPAcctWebDivKey,
                LPSubDivKey = doc.LPSubDivKey,
                LPAllPiKey = doc.LPAllPiKey,
                LPAcctDivGroupKeyRegion = doc.LPAcctDivGroupKeyRegion,
                LPAcctDivGroupKeyClassification = doc.LPAcctDivGroupKeyClassification,
                LPAcctDivGroupKeyOtherProvider = doc.LPAcctDivGroupKeyOtherProvider,
                Subject = doc.Subject,
                FileName = doc.FileName,
                LCID = doc.LCID,
                DocumentDate = doc.DocumentDate,
                LOBKey = doc.LOBKey,
                LossTypKey = doc.LossTypeKey,
                OrganizationPosted = doc.OrganizationPosted,
                IsEdit = doc.IsEdit,
                DocumentLevel = doc.DocumentLevel,
                AuthorPosted = doc.AuthorPosted,
                Location = doc.Location
            };

            var docRepo = new DocumentService.DocumentService();
            success = docRepo.UpsertDocument(docInfo, docContent, out string repositoryUniqueID);

            if (success)
            {
                Document document = Repo.GetAll<Document>()
                    .FirstOrDefault(d => d.RepositoryUniqueID == repositoryUniqueID);

                if (document == null)
                {
                    document = new Document
                    {
                        RepositoryUniqueID = repositoryUniqueID
                    };
                }

                document.Filename = doc.FileName;
                document.DocumentTypeID = doc.DocumentTypeID;
                document.LpAcctNo = doc.LPAcctNo;
                document.LpAcctWebDivKey = doc.LPAcctWebDivKey;
                document.LpSubDivKey = doc.LPSubDivKey;
                document.LpAllPiKey = doc.LPAllPiKey;
                document.LpRecKey = doc.LPRecKey;

                db.UpsertDocument(document, userId);
            }

            return success;
        }

        /// <summary>
        /// Delete document from EDMS (and MA2Data Document table, if present)
        /// </summary>
        /// <param name="repositoryUniqueID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public bool DeleteDocument(string repositoryUniqueID, int userID)
        {
            var documentDbAccess = new DocumentDbAccess();
            var docRepo = new DocumentService.DocumentService();
            var result = docRepo.DeleteDocument(repositoryUniqueID);

            if (result)
            {
                Document document = Repo
                    .GetAll<Document>()
                    .FirstOrDefault(d => d.RepositoryUniqueID == repositoryUniqueID);

                if (document != null)
                {
                    documentDbAccess.DeleteDocument(document.ID);
                }
                else
                {
                    // Make a change to the Document table to trigger the SqlCacheDependency 
                    // In order to clear the MemoryCache
                    var newDocument = documentDbAccess.UpsertDocument(new Document
                    {
                        RepositoryUniqueID = repositoryUniqueID
                    }, userID);

                    documentDbAccess.DeleteDocument(newDocument.ID);
                }

                // Give the MemoryCache time to be cleared.
                Thread.Sleep(DocumentDeleteSleepMicroseconds);
            }

            return result;
        }

        #region Security

        /// <summary>
        /// Given a User ID, load a list of permitted DocumentTypes
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<DocumentType> GetDocumentTypesForUser(int userId)
        {
            ReferenceListLogic refLogic = new ReferenceListLogic();
            DocumentDbAccess db = new DocumentDbAccess();

            var documentTypes = refLogic.GetDocumentTypes();
            var userAccess = db.LoadUserDocumentAccess(userId);

            return documentTypes.Where(x => userAccess.Select(y => y.DocumentTypeID).Contains(x.ID)).ToList();
        }

        public List<DocumentType> GetDocumentTypes()
        {
            var refLogic = new ReferenceListLogic();

            return refLogic.GetDocumentTypes();
        }

        public List<DocumentType> GetOnlyEnglish(bool isEnglishOnly = true)
        {
            var refLogic = new ReferenceListLogic();

            return refLogic.GetDocumentTypes(isEnglishOnly);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="repositoryUniqueID"></param>
        /// <returns></returns>
        public Document LoadDocumentByRepositoryUniqueID(string repositoryUniqueID)
        {
            DocumentDbAccess db = new DocumentDbAccess();
            return db.LoadDocumentByRepositoryUniqueID(repositoryUniqueID);
        }

        public int InsertDocumentAuditRecord(int userId, string documentId)
        {
            DocumentDbAccess db = new DocumentDbAccess();
            return db.InsertDocumentAuditRecord(userId, documentId);
        }

        public bool UserHasPreviouslyAccessedDocument(int userId, string documentId)
        {
            DocumentDbAccess db = new DocumentDbAccess();
            return db.UserHasPreviouslyAccessedDocument(userId, documentId);
        }

        #endregion

        #region Helpers

        /// <summary>
        /// FS-07 - Given a byte array (representing a single file), compress in memory and return with the correct name.
        /// This will be replaced in a later phase to use a 'fire and forget' mechanism which will run in the background
        /// and support multiple documents (notifying the user when complete). This will ideally be to disk (rather than in mem)
        /// </summary>
        /// <param name="bytes"></param>
        /// <param name="fileName"></param>
        /// <param name="zipFileName"></param>
        /// <returns></returns>
        private byte[] CompressDocument(byte[] bytes, string fileName, out string zipFileName)
        {
            using (var compressedFileStream = new MemoryStream())
            {
                using (var zipArchive = new ZipArchive(compressedFileStream, ZipArchiveMode.Create, false))
                {
                    var zipEntry = zipArchive.CreateEntry(fileName);

                    using (var originalFileStream = new MemoryStream(bytes))
                    {
                        using (var zipEntryStream = zipEntry.Open())
                        {
                            originalFileStream.CopyTo(zipEntryStream);
                        }
                    }
                }

                zipFileName = $"{Path.GetFileNameWithoutExtension(fileName)}.zip";
                return compressedFileStream.ToArray();
            }
        }

        /// <summary>
        /// Given a file upload, determine whether it is allowed in the current context based on its extension
        /// This could be improved in future to inspect the file contents (to prevent a malicious user altering the extension)
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="acceptedTypes"></param>
        /// <returns></returns>
        public bool IsFileTypeValid(string filename, string[] acceptedTypes)
        {
            bool isValid = false;

            var fileExt = Path.GetExtension(filename).Substring(1);
            isValid = acceptedTypes.Contains(fileExt);

            return isValid;
        }

        /// <summary>
        /// Given a filename, ensure the mime type matches the one passed in (will handle type and sub type)
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="type"></param>
        /// <param name="subType"></param>
        /// <returns></returns>
        public bool IsValidMimeType(string fileName, string type, string subType)
        {
            var mimeType = MimeMapping.GetMimeMapping(fileName);

            // match whole mime type
            if (!string.IsNullOrEmpty(subType))
                return mimeType == $"{type}/{subType}";

            // match only type
            return mimeType.StartsWith(type);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lpAcctKey"></param>
        /// <param name="retentionLimit"></param>
        /// <returns></returns>
        private bool AccountHasDocumentNonDisplay(int lpAcctKey, out DateTime? retentionLimit)
        {
            AccountLogic accountLogic = new AccountLogic();
            var account = accountLogic.GetAccount(lpAcctKey);
            retentionLimit = null;

            var hasDocumentNonDisplay = account.ActivateAutomaticDocumentNonDisplay.GetValueOrDefault(false);

            // use configured value or default if not set
            if (hasDocumentNonDisplay)
                retentionLimit = DateTime.UtcNow.AddYears((account.DocumentNonDisplayYears ?? Constants.DocumentNonDisplayYearsOptions.Default) * -1);

            return hasDocumentNonDisplay;
        }

        #endregion

        #region Bulk Download

        /// <summary>
        /// Place a message on the MSMQ for later processing. Requests download
        /// of related documents from EDMS into a .ZIP file.
        /// </summary>
        /// <returns></returns>
        public bool QueueBulkDocumentDownloadRequest(BulkDocumentExportMSMQ bulkDocumentExportMsmq)
        {
            var msg = new Message
            {
                Body = JsonConvert.SerializeObject(bulkDocumentExportMsmq),
                Label = Constants.MessageQueueTypes.MessageType_BulkDocumentDownloadRequest
            };
            var messageQueueLocation = ConfigHelper.GetAppSetting("QueueLocation");
            MessageQueue queue = new MessageQueue(messageQueueLocation);

            if (queue.Transactional)
            {
                var trans = new MessageQueueTransaction();
                trans.Begin();
                msg.Formatter = new XmlMessageFormatter(new Type[] { typeof(String) });
                queue.Send(msg, trans);
                trans.Commit();
            }
            else
            {
                queue.Send(msg);
            }
            return true;

        }

        /// <summary>
        /// Initiate the processing of the document bulk download request.
        /// 1) Retrieve metadata for each applicable document from the filter criteria in the message
        /// 2) Download each document and compress into .ZIP
        /// 3) Write the .ZIP to the temp folder
        /// 4) Write a UserDocumentExport record (to make the new download available in the UI)
        /// </summary>
        /// <param name="bulkDocumentExportMsmq"></param>
        /// <param name="messageId"></param>
        /// <returns></returns>
        public bool InitiateBulkDocumentDownloadRequestForMessage(BulkDocumentExportMSMQ bulkDocumentExportMsmq, string messageId)
        {
            // guard
            if (bulkDocumentExportMsmq.LimitToSelectedDocumentsOnly
                && (bulkDocumentExportMsmq.RecordsSelected == null || bulkDocumentExportMsmq.RecordsSelected.Count == 0))
                throw new ArgumentNullException("BulkDocumentExportMSMQ.RecordsSelected is null or empty");

            int userId = bulkDocumentExportMsmq.UserID;
            string zipFileName = null;
            int? userDocumentExportId = null;

            var documentDbAccess = new DocumentDbAccess();

            try
            {
                userDocumentExportId =
                    documentDbAccess.UpsertUserDocumentExportRecord(null, UserDocumentExportStatusEnum.New, userId,
                        null, null);

                zipFileName = $"{Guid.NewGuid()}.ZIP";
                var zipFilePath = Path.Combine(ConfigHelper.GetAppSetting("TempDocumentDownloadFolderPath"),
                    zipFileName);

                documentDbAccess.UpsertUserDocumentExportRecord(zipFileName, UserDocumentExportStatusEnum.Downloading,
                    userId, userDocumentExportId, null);

                var documentsMetaDataFromEdms = GetDocumentsMetaDataFromEDMS(bulkDocumentExportMsmq, userId);

                if (documentsMetaDataFromEdms.Count == 0)
                {
                    LogHelper.Error(
                        $"Unexpected error attempting to initiate bulk document download request - no documents found to export. MessageId = {messageId}");
                    documentDbAccess.UpsertUserDocumentExportRecord(zipFileName, UserDocumentExportStatusEnum.Error,
                        userId, userDocumentExportId, $"No documents found to export. MessageId = {messageId}");
                    return false;
                }

                var locRecords = Repo.GetAll<ViewLocation>().Where(x => x.LpAcctKey == bulkDocumentExportMsmq.LPAcctKey)
                    .ToList();

                var accountLogic = new AccountLogic();
                string accountName = accountLogic.GetAccount(bulkDocumentExportMsmq.LPAcctKey).AccountName;

                List<DocumentType> documentTypes = GetDocumentTypesForUser(userId);

                var combinedResults = documentsMetaDataFromEdms
                    .Select(doc => new MA2Document
                    {
                        LocationNo = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.LocationNo,
                        LocationCode =
                            locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.LocationCode,
                        RepositoryUniqueID = doc.DocumentID,
                        LPAcctNo = doc.LPAccountNum,
                        LPAcctWebDivKey = locRecords.FirstOrDefault(loc =>
                            doc.LPAllPiKey != 0
                                ? loc.LpAllPiKey == doc.LPAllPiKey
                                : loc.LpAcctWebDivKey == doc.LPAcctWebDivKey)?.LpAcctWebDivKey,
                        LPSubDivKey = locRecords.FirstOrDefault(loc =>
                                doc.LPAllPiKey != 0
                                    ? loc.LpAllPiKey == doc.LPAllPiKey
                                    : loc.LpSubDivKey == doc.LPSubDivKey)
                            ?.LpSubDivKey,
                        LPAllPiKey = doc.LPAllPiKey ?? 0,
                        DivisionName = locRecords.FirstOrDefault(loc =>
                            doc.LPAllPiKey != 0
                                ? loc.LpAllPiKey == doc.LPAllPiKey
                                : loc.LpAcctWebDivKey == doc.LPAcctWebDivKey)?.DivisionName,
                        SubDivisionName = locRecords.FirstOrDefault(loc =>
                                doc.LPAllPiKey != 0
                                    ? loc.LpAllPiKey == doc.LPAllPiKey
                                    : loc.LpSubDivKey == doc.LPSubDivKey)
                            ?.SubDivisionName,
                        LocationName =
                            locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.LocationName,
                        City = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.City,
                        State = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.State,
                        Country = locRecords.SingleOrDefault(loc => loc.LpAllPiKey == doc.LPAllPiKey)?.Country,
                        DocumentTypeName = documentTypes.SingleOrDefault(map =>
                            map.DocumentumDocType == doc.MADocumentType ||
                            map.IncludedDocumentumDocType == doc.MADocumentType)?.Name,
                        DatePosted = doc.DatePosted,
                        FileName = doc.FileName,
                        DocumentDate = doc.DocumentDate,
                        AccountName = accountName
                    }).ToList();

                documentDbAccess.UpsertUserDocumentExportRecord(zipFileName, UserDocumentExportStatusEnum.Packaging,
                    userId, userDocumentExportId, null);

                ExtractDocumentsToZIPFile(zipFilePath, combinedResults, userId, bulkDocumentExportMsmq.RecordsSelected,
                    bulkDocumentExportMsmq.StandardizedFilename, bulkDocumentExportMsmq.UseLocationNoInReport,
                    bulkDocumentExportMsmq.LimitToSelectedDocumentsOnly);

                documentDbAccess.UpsertUserDocumentExportRecord(zipFileName, UserDocumentExportStatusEnum.Ready, userId,
                    userDocumentExportId, null);

                return true;
            }
            catch (Exception exception)
            {
                LogHelper.Error(
                    $"Unexpected error attempting to initiate bulk document download request. MessageId = {messageId}",
                    exception);
                documentDbAccess.UpsertUserDocumentExportRecord(zipFileName, UserDocumentExportStatusEnum.Error, userId,
                    userDocumentExportId, $"Exception: '{exception.Message}' MessageId: {messageId}");
                return false;
            }
            finally
            {
                var cacheLogic = new CacheLogic();
                cacheLogic.Flush();
            }
        }

        /// <summary>
        /// Extract the set of documents in documentsMetaDataFromEdms to a .ZIP file. Save the .ZIP file to zipFilePath.
        /// </summary>
        /// <param name="zipFilePath"></param>
        /// <param name="ma2DocumentsList"></param>
        /// <param name="userId"></param>
        /// <param name="recordsSelected"></param>
        /// <param name="standardizedFilename"></param>
        /// <param name="useLocationNoInReport"></param>
        /// <param name="limitToSelectedDocumentsOnly"></param>
        private void ExtractDocumentsToZIPFile(string zipFilePath, List<MA2Document> ma2DocumentsList,
                                                int userId, List<string> recordsSelected,
                                                bool standardizedFilename, bool useLocationNoInReport,
                                                bool limitToSelectedDocumentsOnly)
        {
            LogHelper.Info($"Processing Bulk Download request for User ID {userId}. Number of documents to be ZIPed: {ma2DocumentsList.Count} Creating ZIP file with path '{zipFilePath}'...");

            var docServ = new DocumentService.DocumentService();

            using (var fileStream = new FileStream(zipFilePath, FileMode.Create))
            {
                using (var archive = new ZipArchive(fileStream, ZipArchiveMode.Create))
                {
                    foreach (MA2Document ma2Document in ma2DocumentsList)
                    {
                        if (!limitToSelectedDocumentsOnly || recordsSelected.Contains(ma2Document.RepositoryUniqueID))
                        {
                            LogHelper.Info($"Downloading file '{ma2Document.FileName}' Document ID {ma2Document.RepositoryUniqueID} from EDMS");
                            byte[] docContent = docServ.GetDocumentContent(ma2Document.RepositoryUniqueID, out string fileName);
                            LogHelper.Info($"File {ma2Document.FileName} Document ID {ma2Document.RepositoryUniqueID} downloaded from EDMS. Add to .ZIP file...");

                            // Set filename as standardized filename IF a value is set otherwise rollback to DocumentName
                            if (standardizedFilename)
                            {
                                if (useLocationNoInReport && !string.IsNullOrEmpty(ma2Document.StandardizedFileName))
                                    fileName = ma2Document.StandardizedFileName;
                                else if (!useLocationNoInReport && !string.IsNullOrEmpty(ma2Document.StandardizedFileNameCode))
                                    fileName = ma2Document.StandardizedFileNameCode;
                            }

                            if (!String.IsNullOrEmpty(fileName) && docContent != null)
                            {
                                ZipArchiveEntry entry = archive.CreateEntry(FormatHelper.CleanFilename(fileName, string.Empty));
                                using (var memoryStream = new MemoryStream(docContent))
                                {
                                    using (Stream zipStream = entry.Open())
                                    {
                                        memoryStream.CopyTo(zipStream);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            LogHelper.Info($"ZIP file successfully created with path '{zipFilePath}'");
        }

        /// <summary>
        /// Get the .ZIP file related to the UserDocumentExport record userDocumentExportId as a byte[]
        /// </summary>
        /// <param name="userDocumentExportId"></param>
        /// <returns></returns>
        public byte[] GetBulkDocumentExportZIPFile(int userDocumentExportId, int userId)
        {
            var documentDbAccess = new DocumentDbAccess();
            var userDocumentExport = documentDbAccess.LoadUserDocumentExport(userDocumentExportId);

            if (userDocumentExport.UserID != userId)
            {
                LogHelper.Warn($"Attempt to download .ZIP file belonging to UserID {userDocumentExport.UserID} by {userId}");

                return new byte[] { };
            }

            string zipFileName = userDocumentExport.ExportFilePath;
            string zipFilePath = Path.Combine(ConfigHelper.GetAppSetting("TempDocumentDownloadFolderPath"), zipFileName);
            LogHelper.Info(
                $"Extracting .ZIP file from path {zipFilePath} for UserDocumentExport Id={userDocumentExportId}");

            Byte[] byteArray = null;
            using (FileStream fileStream = new FileStream(zipFilePath, FileMode.Open, FileAccess.Read))
            {
                byteArray = new byte[fileStream.Length];

                fileStream.Read(byteArray, 0, Convert.ToInt32(fileStream.Length));
            }

            LogHelper.Info(
                $"Extracted .ZIP file from path {zipFilePath} for UserDocumentExport Id={userDocumentExportId}. {byteArray.Length} bytes read.");

            return byteArray;
        }

        /// <summary>
        /// Purge bulk download .ZIP files older than retention days
        /// </summary>
        public void PurgeOldBulkDownloadFiles()
        {
            int retentionDays = Convert.ToInt32(ConfigHelper.GetAppSetting("TempDocumentDownloadRetentionDays"));

            var userExportsToBePurged = GetUserDocumentsOlderThanRetentionDays(retentionDays);

            LogHelper.Info($"PurgeOldBulkDownloadFiles: Found {userExportsToBePurged.Count} .ZIP files to be purged. Retention days = {retentionDays}");

            userExportsToBePurged.ForEach(ude =>
            {
                if (ude.Status == Enum.GetName(typeof(UserDocumentExportStatusEnum), UserDocumentExportStatusEnum.Ready))
                {
                    string zipFilePath = Path.Combine(ConfigHelper.GetAppSetting("TempDocumentDownloadFolderPath"), ude.ExportFilePath);
                    LogHelper.Info($"PurgeOldBulkDownloadFiles: Deleting .ZIP file at path {zipFilePath} for UserDocumentExport Id={ude.ID}");
                    File.Delete(zipFilePath);
                }

                LogHelper.Info($"PurgeOldBulkDownloadFiles: Removing UserDocumentExport record Id={ude.ID}, Status = {ude.Status}");
                Repo.Delete(ude);
            });

            if (userExportsToBePurged.Count > 0)
            {
                Repo.SaveChanges();

                LogHelper.Info("PurgeOldBulkDownloadFiles: Successfully purged old .ZIP files");
            }
        }

        private List<UserDocumentExport> GetUserDocumentsOlderThanRetentionDays(int retentionDays)
        {
            DateTime fromDate = DateTime.Today.AddDays(retentionDays * -1);
            return Repo.GetAll<UserDocumentExport>()
                                .Where(ude => ude.CreatedDate < fromDate)
                                .ToList();
        }

        /// <summary>
        /// Get the name of the language for the specified LCID.
        /// </summary>
        /// <param name="lcid"></param>
        /// <param name="localeSpecific"></param>
        public string GetLanguageNameByLcid(int lcid, bool localeSpecific = true)
        {
            var result = string.Empty;

            if (lcid == Constants.LanguageLCID.English)
                result = localeSpecific ? Resources.WebPageResources.Language_Localized_English : Resources.WebPageResources.Language_English;
            if (lcid == Constants.LanguageLCID.German)
                result = localeSpecific ? Resources.WebPageResources.Language_Localized_German : Resources.WebPageResources.Language_German;
            if (lcid == Constants.LanguageLCID.French)
                result = localeSpecific ? Resources.WebPageResources.Language_Localized_French : Resources.WebPageResources.Language_French;
            if (lcid == Constants.LanguageLCID.Spanish)
                result = localeSpecific ? Resources.WebPageResources.Language_Localized_Spanish : Resources.WebPageResources.Language_Spanish;
            if (lcid == Constants.LanguageLCID.Italian)
                result = localeSpecific ? Resources.WebPageResources.Language_Localized_Italian : Resources.WebPageResources.Language_Italy;
            if (lcid == Constants.LanguageLCID.Portuguese)
                result = localeSpecific ? Resources.WebPageResources.Language_Localized_Portuguese : Resources.WebPageResources.Language_Portuguese;
            if (lcid == Constants.LanguageLCID.Other)
                result = Resources.WebPageResources.Language_Localized_Other;

            return result;
        }

        /// <summary>
        /// Get the name of the language for the specified LCID.
        /// </summary>
        /// <param name="lcid"></param>
        /// <param name="localeSpecific"></param>
        public string GetLanguageNameById(int Id, bool localeSpecific = true)
        {
            var result = string.Empty;

            if (Id == Constants.DocLanguageID.English || Id == Constants.LanguageLCID.English)
                result = localeSpecific ? Resources.WebPageResources.Language_Localized_English : Resources.WebPageResources.Language_English;
            if (Id == Constants.DocLanguageID.German || Id == Constants.LanguageLCID.German)
                result = localeSpecific ? Resources.WebPageResources.Language_Localized_German : Resources.WebPageResources.Language_German;
            if (Id == Constants.DocLanguageID.French || Id == Constants.LanguageLCID.French)
                result = localeSpecific ? Resources.WebPageResources.Language_Localized_French : Resources.WebPageResources.Language_French;
            if (Id == Constants.DocLanguageID.Spanish || Id == Constants.LanguageLCID.Spanish)
                result = localeSpecific ? Resources.WebPageResources.Language_Localized_Spanish : Resources.WebPageResources.Language_Spanish;
            if (Id == Constants.DocLanguageID.Italian || Id == Constants.LanguageLCID.Italian)
                result = localeSpecific ? Resources.WebPageResources.Language_Localized_Italian : Resources.WebPageResources.Language_Italy;
            if (Id == Constants.DocLanguageID.Portuguese || Id == Constants.LanguageLCID.Portuguese)
                result = localeSpecific ? Resources.WebPageResources.Language_Localized_Portuguese : Resources.WebPageResources.Language_Portuguese;
            if (Id == Constants.DocLanguageID.Other)
                result = Resources.WebPageResources.Language_Localized_Other;

            return result;
        }

        /// <summary>
        /// Get the Organization name for the given Id.
        /// </summary>
        /// <param name="organizationPostedId"></param>
        /// <returns></returns>
        public string GetOrganizationPostedById(int organizationPostedId)
        {
            var result = string.Empty;

            if (organizationPostedId == Constants.DocumentFilterOrganizationPosted.AXAXL)
                result = WebPageResources.Documents_Table_Organization_Posted_AXA_XL;
            if (organizationPostedId == Constants.DocumentFilterOrganizationPosted.NonAXAXL)
                result = WebPageResources.Documents_Table_Organization_Posted_Non_AXA_XL;

            return result;
        }

        /// <summary>
        /// Get description of Document Level
        /// </summary>
        /// <param name="level"></param>
        /// <returns></returns>
        public string GetDocumentLevelDescription(int level)
        {
            if (level == Constants.DocumentFilterDocumentLevel.Blank)
                return Resources.WebPageResources.Documents_TableCol_Blank;
            if (level == Constants.DocumentFilterDocumentLevel.Location)
                return Resources.WebPageResources.Documents_TableCol_Location;
            if (level == Constants.DocumentFilterDocumentLevel.Division)
                return Resources.WebPageResources.Documents_Table_Division;
            if (level == Constants.DocumentFilterDocumentLevel.Account)
                return Resources.WebPageResources.Documents_Table_Account;

            return string.Empty;
        }

        public string GetDocumentLevelLineOfBusinessOptions(int level)
        {
            if (level == Constants.DocumentFilterLineOfBusiness.Property)
                return WebPageResources.LineOfBusiness_Property;
            if (level == Constants.DocumentFilterLineOfBusiness.Casualty)
                return Resources.WebPageResources.LineOfBusiness_Casualty;
            if (level == Constants.DocumentFilterLineOfBusiness.Environment)
                return Resources.WebPageResources.LineOfBusiness_Environment;
            if (level == Constants.DocumentFilterLineOfBusiness.Marine)
                return Resources.WebPageResources.LineOfBusiness_Marine;
            if (level == Constants.DocumentFilterLineOfBusiness.Motor)
                return Resources.WebPageResources.LineOfBusiness_Motor;
            if (level == Constants.DocumentFilterLineOfBusiness.Blank)
                return string.Empty;


            return string.Empty;
        }
        public string GetDocumentLevelSubject(int level, string Subject)
        {
            if (level == Constants.DocumentFilterPeril.General_Property)
                return WebPageResources.Task_Domain_General_Property;
            if (level == Constants.DocumentFilterPeril.Machinery_Breakdown_Standalone)
                return Resources.WebPageResources.Task_Domain_Machinery_Breakdown_Standalone;
            if (level == Constants.DocumentFilterPeril.Fire_and_MachineryBreakdown)
                return Resources.WebPageResources.Task_Domain_Fire_and_Machinery_Breakdown;

            if (level == 0)
                return Subject;

            return string.Empty;
        }
        public string GetDocumentLevelPeril(int level)
        {
            if (level == Constants.DocumentFilterPeril.General_Property)
                return WebPageResources.Peril_Fire;
            if (level == Constants.DocumentFilterPeril.Machinery_Breakdown_Standalone)
                return Resources.WebPageResources.Peril_MachineryBreakdown;
            if (level == Constants.DocumentFilterPeril.Fire_and_MachineryBreakdown)
                return Resources.WebPageResources.Peril_FireMachinery;

            if (level == Constants.DocumentFilterPeril.Fire)
                return WebPageResources.Peril_Fire;
            if (level == Constants.DocumentFilterPeril.NaturalCatastrophe)
                return WebPageResources.Peril_NaturalCatastrophe;
            if (level == Constants.DocumentFilterPeril.MachineryBreakdown)
                return WebPageResources.Peril_MachineryBreakdown;

            return string.Empty;
        }


        #endregion

        #region Export

        /// <summary>
        /// 
        /// </summary>
        /// <param name="paging"></param>
        /// <param name="dataFilter"></param>
        /// <param name="lpAcctKey"></param>
        /// <param name="userId"></param>
        /// <param name="useLocationNo"></param>
        /// <param name="sortExpression"></param>
        /// <param name="filters"></param>
        /// <param name="records"></param>
        /// <returns></returns>
        public DataTable GetDataTableForDocumentsReport(PagingInfo paging, DataFilter dataFilter, int lpAcctKey, int userId,
                                                            bool useLocationNo, PagedDocumentFilters filters, List<string> records)
        {
            var dataTable = new DataTable();
            var systemGridLogic = new SystemGridLogic();

            var documentSystemGridFields = systemGridLogic.LoadSystemGridForUser(Constants.SystemGridRef.Documents, userId, false, lpAcctKey);

            var userSelectedColumns = GetUserReportExportColumnOptions(userId, Constants.SystemGridRef.Documents, null, null, lpAcctKey);

            if (userSelectedColumns != null)
            {
                var counter = 1;
                foreach (KeyValuePair<int, string> kvp in userSelectedColumns)
                {
                    // Don't print the Actions column
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_Actions)
                        continue;

                    var gridGroup = documentSystemGridFields.Groups.First(g => g.Fields.Any(f => f.SystemGridFieldSystemGridFieldRef == kvp.Key));
                    var gridFieldsCount = gridGroup.Fields.Count(f => f.UserSystemGridFieldVisible);

                    dataTable.Columns.Add(
                 new DataColumn
                 {
                     ColumnName = $"Field{counter}",
                     Caption = $"{gridGroup.SystemGridGroupName.TrimEnd()}-{gridFieldsCount}|{kvp.Value.TrimEnd().Replace("'", "").Replace("ä", "").Replace("%", "").Replace("&", "").Replace("-", "").Replace("°", "").Replace(" ", "").Replace("Ü", "").Trim()}"
                 });

                    counter++;
                }
            }

            var dataSet = GetAccountDocuments(filters, userId, useLocationNo);
            dataSet = dataSet.Where(d => records.Contains(d.RepositoryUniqueID)).ToList();

            AddDatasetToCustomisableReport(dataTable, dataSet, userSelectedColumns, useLocationNo);

            return dataTable;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataTable"></param>
        /// <param name="dataSet"></param>
        /// <param name="userSelectedColumns"></param>
        /// <param name="useLocationNo"></param>
        public void AddDatasetToCustomisableReport(DataTable dataTable, List<MA2Document> dataSet, List<KeyValuePair<int, string>> userSelectedColumns, bool useLocationNo)
        {

            var refLogic = new ReferenceListLogic();
            var languages = refLogic.GetDocumentLanguageOptions();

            foreach (var item in dataSet)
            {
                List<Object> rowData = new List<object>();

                foreach (KeyValuePair<int, string> kvp in userSelectedColumns)
                {
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_LocationID)
                        rowData.Add(useLocationNo ? item?.LocationNo : item?.LocationCode);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_CustomerLocationID)
                        rowData.Add(item?.ClientLocationNo);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_LocationName)
                        rowData.Add(item?.LocationName);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_Division)
                        rowData.Add(item?.DivisionName);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_SubDivision)
                        rowData.Add(item?.SubDivisionName);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_StreetAddress1)
                        rowData.Add(item?.AddressLine1);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_StreetAddress2)
                        rowData.Add(item?.AddressLine2);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_City)
                        rowData.Add(item?.City);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_State)
                        rowData.Add(item?.State);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_Country)
                        rowData.Add(item?.Country);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_TotalPropertyValue)
                        rowData.Add(item?.TotalPropertyValue);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_BusinessInterruptionValue)
                        rowData.Add(item?.BusinessInterruptionValue);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_TotalInsurableValue)
                        rowData.Add(item?.TotalInsurableValue);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_FileName)
                        rowData.Add(item?.FileName);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_StandardizedFileName)
                        rowData.Add(useLocationNo ? item?.StandardizedFileName : item?.StandardizedFileNameCode);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_DocumentType)
                        rowData.Add(item?.DocumentTypeName);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_DocumentDate)
                        rowData.Add(FormatHelper.FormatDate(item?.DocumentDate));
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_DatePosted)
                        rowData.Add(FormatHelper.FormatDate(item?.DatePosted));
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_DocumentLevel)
                        rowData.Add(item == null ? null : GetDocumentLevelDescription(item.DocumentLevel));
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_OrganizationPosted)
                        rowData.Add(item == null ? null : GetOrganizationPostedById(item.OrganizationPosted));
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_AuthorPosted)
                        rowData.Add(item?.AuthorPosted);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_TaskNumber)
                        rowData.Add(item?.TaskCode);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_Language)
                        rowData.Add(item == null ? null : GetLanguageNameByLcid(item.LCID, false));
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_FileType)
                        rowData.Add(item?.FileType);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_MyComments1)
                        rowData.Add(item?.MyComments1);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_MyComments2)
                        rowData.Add(item?.MyComments2);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_MyComments3)
                        rowData.Add(item?.MyComments3);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_SharedComment1)
                        rowData.Add(item?.SharedComment1);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_Subject)
                        rowData.Add(item?.Subject);
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_LOB)
                        rowData.Add(GetDocumentLevelLineOfBusinessOptions(item.LOBKey));
                    if (kvp.Key == Constants.SystemGridFieldRef.Documents_Peril)
                        rowData.Add(GetDocumentLevelPeril(item.LossTypeKey ?? 0));
                }

                dataTable.Rows.Add(rowData.ToArray());
            }
        }

        #endregion

    }
}
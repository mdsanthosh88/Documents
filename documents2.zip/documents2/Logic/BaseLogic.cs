﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using XLC.MyAnalysis2.DbAccess;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.DbModels.DbEnums;
using XLC.MyAnalysis2.Logic.DTO;
using XLC.MyAnalysis2.Shared;

namespace XLC.MyAnalysis2.Logic
{
    public abstract class BaseLogic
    {
        protected int CurrentLcid { get; set; }

        protected CultureInfo CurrentCultureInfo { get; set; }

        protected string UserName { get; private set; }

        protected BaseLogic()
        {
            CurrentCultureInfo = Thread.CurrentThread.CurrentUICulture;
            CurrentLcid = Thread.CurrentThread.CurrentUICulture.LCID;
        }
        protected BaseLogic(string userName)
        {
            CurrentCultureInfo = Thread.CurrentThread.CurrentUICulture;
            CurrentLcid = Thread.CurrentThread.CurrentUICulture.LCID;
            this.UserName = userName;
        }

        #region Helper Methods

        /// <summary>
        /// Load (any) Data Filter pertaining to the Divisions/Sub-divisions/Locations selector
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        protected DataFilter LoadAnyLocationsSelectorDataFilterByUser(int userId)
        {
            var dataFilterLogic = new DataFilterLogic();

            return dataFilterLogic.LoadAnyLocationsSelectorDataFilterByUser(userId);
        }

        public static string GetMimeTypeFromBase64(string base64String)
        {
            var data = base64String.Substring(0, 5);

            switch (data.ToUpper())
            {
                case "R0lGO":
                    return "image/gif";
                case "IVBOR":
                    return "image/png";
                case "/9J/2":
                case "/9J/4":
                    return "image/jpg";
                case "AAAAF":
                    return "video/mp4";
                case "JVBER":
                    return "application/pdf";
                case "AAABA":
                    return "image/x-icon";
                case "UMFYI":
                    return "application/x-rar-compressed";
                case "E1XYD":
                    return "application/rtf";
                case "U1PKC":
                    return "text/plain";
                default:
                    return "image/png";
            }
        }

        public byte[] GetImageThumbnail(byte[] originalImage, int maxWidth, int maxHeight, string accountName)
        {
            byte[] result;
            Image img;
            try
            {
                ImageConverter ic = new ImageConverter();
                img = (Image)ic.ConvertFrom(originalImage);               
            }
            catch (ArgumentException e)
            {
                // Invalid byte arrays stored against a ViewAccount can throw the ArgumentException at runtime
                LogHelper.Error($"Could not load account thumbnail for account {accountName}", e);
                return new byte[0];
            }


            using (Bitmap loBmp = new Bitmap(img ?? throw new InvalidOperationException()))
            {
                decimal lnRatio;
                int lnNewWidth = 0;
                int lnNewHeight = 0;

                //*** If the image is smaller than a thumbnail just return it
                if (loBmp.Width < maxWidth && loBmp.Height < maxHeight)
                    return originalImage;

                if (loBmp.Width > loBmp.Height)
                {
                    lnRatio = (decimal)maxWidth / loBmp.Width;
                    lnNewWidth = maxWidth;
                    decimal lnTemp = loBmp.Height * lnRatio;
                    lnNewHeight = (int)lnTemp;
                }
                else
                {
                    lnRatio = (decimal)maxHeight / loBmp.Height;
                    lnNewHeight = maxHeight;
                    decimal lnTemp = loBmp.Width * lnRatio;
                    lnNewWidth = (int)lnTemp;
                }

                // *** This code creates cleaner (though bigger) thumbnails and properly
                // *** and handles GIF files better by generating a white background for
                // *** transparent images (as opposed to black)
                Bitmap bmpOut = new Bitmap(lnNewWidth, lnNewHeight);
                Graphics g = Graphics.FromImage(bmpOut);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.FillRectangle(Brushes.White, 0, 0, lnNewWidth, lnNewHeight);
                g.DrawImage(loBmp, 0, 0, lnNewWidth, lnNewHeight);

                result = BitmapToByteArray(bmpOut);

                loBmp.Dispose();
            }

            return result;
        }

        private byte[] BitmapToByteArray(Bitmap img)
        {
            using (var ms = new MemoryStream())
            {
                img.Save(ms, ImageFormat.Jpeg);

                // read to end
                var output = ms.GetBuffer();
                ms.Close();

                return output;
            }
        }

        /// <summary>
        /// https://stackoverflow.com/questions/20137562/round-decimals-and-convert-to-in-c-sharp
        /// </summary>
        /// <param name="values"></param>
        /// <returns></returns>
        public void CalculateIntPercents(List<BaseChartData> values)
        {
            // this should distribute any error evenly across the resultset
            double error = 0;
            for (int i = 0; i < values.Count; i++)
            {
                double val = (double)values[i].PercentageDecimal * 100;
                int percent = (int)Math.Round(val + error, 0, MidpointRounding.AwayFromZero);
                error += val - percent;
                if (Math.Abs(error) >= 0.5)
                {
                    int sign = Math.Sign(error);
                    percent += sign;
                    error -= sign;
                }
                values[i].PercentageInt = percent;
            }
        }
        public static void OverrideSystemGridHeaderName(ref UserSystemGridDTO gridConfig, string systemGridGroupName, string overridenHeaderName)
        {
            UserSystemGridGroupDTO targetHeader = gridConfig.Groups?.FirstOrDefault(x => x.SystemGridGroupName == systemGridGroupName);
            if (targetHeader != null)
                targetHeader.SystemGridGroupName = overridenHeaderName;
        }

        public static void OverrideSystemGridFieldName(ref UserSystemGridDTO gridConfig, string systemGridGroupName, string targetSystemGridFieldName, string overridenFieldName)
        {
            UserSystemGridFieldDTO targetField = gridConfig.Groups?.FirstOrDefault(x => x.SystemGridGroupName == systemGridGroupName)?.Fields?.FirstOrDefault(x => x.SystemGridFieldName == targetSystemGridFieldName);
            if (targetField != null)
                targetField.SystemGridFieldName = overridenFieldName;
        }
        /// <summary>
        /// Given a System Grid ID (i.e. Documents report, Impairments report), return a list of KeyValuePairs (SystemGridFieldRef, Name) which
        /// help build the export which takes into account the column groups and column fields which are currently shown/hidden
        /// within the UI, and the order in which they are presented.
        /// </summary>
        /// <param name="systemGridId"></param>
        /// <returns></returns>
        public List<KeyValuePair<int, string>> GetUserReportExportColumnOptions(int userId, int systemGridId, List<Dictionary<string, string>> replacementHeaders = null, Dictionary<string, Dictionary<string, string>> replacementFields = null, int accountId = 0)
        {
            SystemGridDbAccess db = new SystemGridDbAccess();
            
            var userLogic = new UserLogic();
            var isInternalUser = userLogic.GetUser(userId).UserRoles.Any(x => Constants.Roles.InternalRoles.Contains(x.RoleID));

            UserSystemGridDTO results = db.LoadSystemGridForUser(systemGridId, userId, false, isInternalUser, true, accountId);
            var userGridGroups = results.Groups.ToList();

            List<KeyValuePair<int, string>> userFields = new List<KeyValuePair<int, string>>();

            if (systemGridId == Constants.SystemGridRef.RiskQualityRatings || systemGridId == Constants.SystemGridRef.RecommendationSummary )
            {
                if (replacementFields != null)
                {
                    foreach (KeyValuePair<string, Dictionary<string, string>> kvp in replacementFields)
                    {
                        foreach (KeyValuePair<string, string> overrideField in kvp.Value)
                        {
                            OverrideSystemGridFieldName(ref results, kvp.Key, overrideField.Key, overrideField.Value);
                        }

                    }
                }
            }

            foreach (var group in userGridGroups)
            {
                var fieldsInGroup = group.Fields.Where(o => o.UserSystemGridFieldVisible).Select(x => new {x.SystemGridFieldSystemGridFieldRef, x.SystemGridFieldName})
                    .AsEnumerable().Select(x =>
                        new KeyValuePair<int, string>(x.SystemGridFieldSystemGridFieldRef, x.SystemGridFieldName))
                    .ToList();

                foreach (var field in fieldsInGroup)
                {
                    userFields.Add(field);
                }
               
            }

            return userFields;

        }

        /// <summary>
        /// Get the Rating Type configured against the Account Profile
        /// </summary>
        /// <param name="lpAcctKey"></param>
        /// <returns></returns>
        public RatingTypesEnum GetAccountRatingType(int lpAcctKey)
        {
            var accountDbAccess = new AccountProfileDbAccess();
            var accountProfile = accountDbAccess.GetAccountProfileByAcctKey(lpAcctKey);
            return (RatingTypesEnum)(accountProfile.RatingTypeID ?? (int)RatingTypesEnum.Rating_per_Contract);
        }
        public static bool AccessToAccountIsValid(ViewUserAccountPriviledge userAccountPrivilege)
        {
            bool usersAccountAccessIsValid = true;
            if (userAccountPrivilege != null)
            {
                if (userAccountPrivilege.UserAccountAccessStartDate != null)
                {
                    if (DateTime.UtcNow < userAccountPrivilege.UserAccountAccessStartDate.Value.ToUniversalTime())
                        usersAccountAccessIsValid = false;
                }

                if (userAccountPrivilege.UserAccountAccessExpiryDate != null)
                {
                    if (DateTime.UtcNow > userAccountPrivilege.UserAccountAccessExpiryDate.Value.ToUniversalTime())
                        usersAccountAccessIsValid = false;
                }
            }
            return usersAccountAccessIsValid;
        }
        #endregion
    }
}

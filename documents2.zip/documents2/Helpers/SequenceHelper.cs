﻿using System.Collections.Generic;
using System.Linq;

namespace XLC.MyAnalysis2.WebPortal.Helpers
{
    public static class SequenceHelper
    {
        /// <summary>
        /// Obtain a hash code given a sequence of elements
        ///
        /// Adapted from https://stackoverflow.com/a/30758270
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sequence"></param>
        /// <returns></returns>
        public static int GetSequenceHashCode<T>(IList<T> sequence)
        {
            const int seed = 487;
            const int modifier = 31;

            unchecked
            {
                return sequence.Aggregate(seed, (current, item) => (current * modifier) + item.GetHashCode());
            }
        }
    }
}
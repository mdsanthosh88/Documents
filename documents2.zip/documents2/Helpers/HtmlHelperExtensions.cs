﻿using Microsoft.Ajax.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.Logic;
using XLC.MyAnalysis2.Resources;

namespace XLC.MyAnalysis2.WebPortal.Helpers
{
    public static class HtmlHelperExtensions
    {
        public static MvcHtmlString MenuItem(this HtmlHelper html, string actionName, string controller, string displayName, string className, string style)
        {
            var helper = new UrlHelper(html.ViewContext.RequestContext);

            var li = new TagBuilder("li");

            li.GenerateId($"listitem{controller}{actionName}");

            var a = new TagBuilder("a");
            a.MergeAttribute("href", helper.Action(actionName, controller));
            a.GenerateId($"menu{controller}{actionName}");

            var i = new TagBuilder("i");
            i.AddCssClass(className);

            if (!style.IsNullOrWhiteSpace())
            {
                i.MergeAttribute("style", style);
            }

            var span = new TagBuilder("span");
            span.InnerHtml = displayName;

            a.InnerHtml = i.ToString(TagRenderMode.Normal) + span.ToString(TagRenderMode.Normal);
            li.InnerHtml = a.ToString(TagRenderMode.Normal);

            return MvcHtmlString.Create(li.ToString(TagRenderMode.Normal));
        }

        public static MvcHtmlString RadioButtonFor<TModel, TValue>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TValue>> expression, object value, object htmlAttributes, bool checkedState)
        {
            var htmlAttributeDictionary = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            if (checkedState)
            {
                htmlAttributeDictionary.Add("checked", "checked");
            }

            return htmlHelper.RadioButtonFor(expression, value, htmlAttributeDictionary);
        }

        public static MvcHtmlString GetMainMenuItems(this HtmlHelper html)
        {
            var controllerContext = new ControllerContext(
                html.ViewContext.HttpContext, html.ViewContext.RouteData, html.ViewContext.Controller);

            var clientOrIntermediaryOrFieldEngineerOrUnderwriterOrXLCManager = false;
            var mainmenu = new StringBuilder();
            var mainmenuItems = new List<MenuItem>();

            bool defaultToFirstAccount = true;
            var userLogic = new UserLogic();
            var accountLogic = new AccountLogic();
            var user = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: false);
            MA2CookieData ma2Cookie = null;


            if (MA2CookieHelper.CookieExists(controllerContext))
            {

                ma2Cookie = MA2CookieHelper.GetData(controllerContext, UIHelper.EncryptCookie);

                if (ma2Cookie != null)
                {
                    // check the Account in the cookie still exists...
                    var accLogic = new AccountLogic();
                    var restoreAccount = accLogic.GetAccount(ma2Cookie.LPAcctKey);

                    if (restoreAccount != null)
                        defaultToFirstAccount = false;

                }
            }

            if (defaultToFirstAccount)
            {
                // set cookie to first account user has permission for
                var accounts = userLogic.GetAccountPrivileges(user.ID);

                if (accounts.Count > 0)
                {
                    var firstAccount = accounts.First();
                    var accountNoDisplayTypeId = accountLogic.GetAccountNumberDisplayType(firstAccount.AccountNumberDisplayTypeID);
                    var lpAcctNumDisTypeKey = (accountNoDisplayTypeId != null) ? accountNoDisplayTypeId.LpAcctNumDispTypeKey : Constants.AccountNumberDisplayType.Unknown;

                    ma2Cookie = new MA2CookieData
                    {
                        LPAcctKey = firstAccount.LpAcctKey,
                        LPAcctNum = firstAccount.AccountNo,
                        LpAcctNumDispTypeKey = lpAcctNumDisTypeKey,
                        ClientTypeId = firstAccount.ClientTypeID
                    };

                    MA2CookieHelper.CreateCookie(controllerContext, ma2Cookie, UIHelper.EncryptCookie);
                }
            }

            var logic = new AccountLogic();
            var entity = logic.GetAccountProfile(ma2Cookie.LPAcctKey);
            var referenceListLogic = new ReferenceListLogic();

            foreach (var role in UserHelper.GetCurrentUsersRoles())
            {
                if (Equals(role, Constants.RoleNames.Client) || Equals(role, Constants.RoleNames.Intermediary)
                    || Equals(role, Constants.RoleNames.FieldEngineer) || Equals(role, Constants.RoleNames.Underwriter)
                    || Equals(role, Constants.RoleNames.XLCManager))
                    clientOrIntermediaryOrFieldEngineerOrUnderwriterOrXLCManager = true;
            }

            var reports = logic.GetSummaryReportAccess(ma2Cookie.LPAcctKey, referenceListLogic.GetSummaryReports().Where(x => x.Active).ToList());

            foreach (var reportType in reports)
            {
                // Restrict Client and Intermediary Users from viewing reports
                // outside those which have been enabled for the account they have selected
                if (clientOrIntermediaryOrFieldEngineerOrUnderwriterOrXLCManager && !reportType.ExternalUserHasAccess)
                    continue;

                var item = new MenuItem();

                switch (reportType.ID)
                {
                    case Constants.SummaryReport.Maps:
                        //item.DisplayName = WebPageResources.Menu_Map;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "Map";
                        item.IconClass = "fa fa-sidebar fa-map-marker fa-lg";
                        break;

                    case Constants.SummaryReport.Documents:
                        //item.DisplayName = WebPageResources.Menu_Docs;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "Documents";
                        item.IconClass = "fa fa-sidebar fa-files-o fa-lg";
                        break;

                    case Constants.SummaryReport.WhatIfAnalysis:
                        if (entity.RatingTypeID.Equals(Constants.RatingType.RQRCalculated) || entity.RatingTypeID.Equals(Constants.RatingType.RQRValidated))
                        {
                            //item.DisplayName = WebPageResources.Menu_WhatIfBeta;
                            item.DisplayName = reportType.Name;
                            item.Action = "Index";
                            item.Controller = "WhatIf";
                            item.IconClass = "fa fa-sidebar fa-question-circle fa-lg";
                        }
                        break;

                }
                if (item.DisplayName != null && item.Action != null && item.Controller != null)
                    mainmenuItems.Add(item);
            }


            foreach (var x in mainmenuItems.OrderBy(x => x.DisplayName))
            {
                mainmenu.Append(MenuItem(html, x.Action, x.Controller, x.DisplayName, x.IconClass, x.Style));
            }

            return MvcHtmlString.Create(mainmenu.ToString());
        }



        public static MvcHtmlString GetMenuItems(this HtmlHelper html)
        {
            var controllerContext = new ControllerContext(
                html.ViewContext.HttpContext, html.ViewContext.RouteData, html.ViewContext.Controller);

            var clientOrIntermediaryOrFieldEngineerOrUnderwriterOrXLCManager = false;
            var menu = new StringBuilder();
            var menuItems = new List<MenuItem>();
            bool defaultToFirstAccount = true;
            var userLogic = new UserLogic();
            var accountLogic = new AccountLogic();
            var user = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: false);
            MA2CookieData ma2Cookie = null;


            if (MA2CookieHelper.CookieExists(controllerContext))
            {

                ma2Cookie = MA2CookieHelper.GetData(controllerContext, UIHelper.EncryptCookie);

                if (ma2Cookie != null)
                {
                    // check the Account in the cookie still exists...
                    var accLogic = new AccountLogic();
                    var restoreAccount = accLogic.GetAccount(ma2Cookie.LPAcctKey);

                    if (restoreAccount != null)
                        defaultToFirstAccount = false;

                }
            }

            if (defaultToFirstAccount)
            {
                // set cookie to first account user has permission for
                var accounts = userLogic.GetAccountPrivileges(user.ID);

                if (accounts.Count > 0)
                {
                    var firstAccount = accounts.First();
                    var accountNoDisplayTypeId = accountLogic.GetAccountNumberDisplayType(firstAccount.AccountNumberDisplayTypeID);
                    var lpAcctNumDisTypeKey = (accountNoDisplayTypeId != null) ? accountNoDisplayTypeId.LpAcctNumDispTypeKey : Constants.AccountNumberDisplayType.Unknown;

                    ma2Cookie = new MA2CookieData
                    {
                        LPAcctKey = firstAccount.LpAcctKey,
                        LPAcctNum = firstAccount.AccountNo,
                        LpAcctNumDispTypeKey = lpAcctNumDisTypeKey,
                        ClientTypeId = firstAccount.ClientTypeID
                    };

                    MA2CookieHelper.CreateCookie(controllerContext, ma2Cookie, UIHelper.EncryptCookie);
                }
            }

            var logic = new AccountLogic();
            var referenceListLogic = new ReferenceListLogic();

            foreach (var role in UserHelper.GetCurrentUsersRoles())
            {
                if (Equals(role, Constants.RoleNames.Client) || Equals(role, Constants.RoleNames.Intermediary)
                    || Equals(role, Constants.RoleNames.FieldEngineer) || Equals(role, Constants.RoleNames.Underwriter)
                    || Equals(role, Constants.RoleNames.XLCManager))
                    clientOrIntermediaryOrFieldEngineerOrUnderwriterOrXLCManager = true;
            }

            var reports = logic.GetSummaryReportAccess(ma2Cookie.LPAcctKey, referenceListLogic.GetSummaryReports().Where(x => x.Active).ToList());

            foreach (var reportType in reports.Where(rep => rep.ID != Constants.SummaryReport.Maps
                                                    && rep.ID != Constants.SummaryReport.WhatIfAnalysis))   //suppress Map and What If Analysis from menu
            {
                // Restrict Client and Intermediary Users from viewing reports
                // outside those which have been enabled for the account they have selected
                if (clientOrIntermediaryOrFieldEngineerOrUnderwriterOrXLCManager && !reportType.ExternalUserHasAccess)
                    continue;

                var item = new MenuItem();
                switch (reportType.ID)
                {

                    case Constants.SummaryReport.RecommendationsSummary:
                        //item.DisplayName = @WebPageResources.Menu_RecsByTypeStatus;
                        item.DisplayName = reportType.Name;
                        item.Action = "RecommendationsSummary";
                        item.Controller = "Recommendation";
                        item.IconClass = "fa fa-sidebar fa-bar-chart fa-lg";
                        break;

                    case Constants.SummaryReport.CopeSummary:
                        //item.DisplayName = @WebPageResources.Menu_CopeSummary;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "Cope";
                        item.IconClass = "fa fa-sidebar fa-building-o fa-lg";
                        break;
                    case Constants.SummaryReport.ImpairmentsSummary:
                        //item.DisplayName = @WebPageResources.Menu_Impairments_Type3;
                        item.DisplayName = reportType.Name;
                        item.Action = "MidLevel";
                        item.Controller = "Impairment";
                        item.IconClass = "fa fa-sidebar fa-wrench fa-lg";
                        break;
                    case Constants.SummaryReport.ImpairmentsDetails:
                        //item.DisplayName = @WebPageResources.Menu_Impairments_Type4;
                        item.DisplayName = reportType.Name;
                        item.Action = "DetailLevel";
                        item.Controller = "Impairment";
                        item.IconClass = "fa fa-sidebar fa-table fa-lg";
                        break;
                    case Constants.SummaryReport.ProjectsDetails:
                        //item.DisplayName = @WebPageResources.Menu_Projects_Details;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "ProjectsDetails";
                        item.IconClass = "fa fa-sidebar fa fa-tasks fa-lg";
                        break;
                    case Constants.SummaryReport.HazardsDetails:
                        //item.DisplayName = @WebPageResources.Menu_HazardsDetails;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "HazardsDetails";
                        item.IconClass = "fa fa-sidebar fa fa-warning fa-lg";
                        break;
                    case Constants.SummaryReport.LossEstimatesSummary:
                        //item.DisplayName = @WebPageResources.Menu_LossEstimates;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "LossEstimate";
                        item.IconClass = "fa fa-sidebar fa-area-chart fa-lg";
                        break;

                    case Constants.SummaryReport.LossEstimatesSummaryL4:
                        //item.DisplayName = @WebPageResources.Menu_LossEstimatesSummary;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "LossEstimateDetails";
                        item.IconClass = "fa fa-sidebar fa-sort-amount-asc fa-lg";
                        break;
                    case Constants.SummaryReport.ManagementProgramSummary:
                        //item.DisplayName = @WebPageResources.Menu_ManagementProgram;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "ManagementProgram";
                        item.IconClass = "fa fa-sidebar fa-check-circle fa-lg";
                        break;
                    case Constants.SummaryReport.NatcatSummary:
                        //item.DisplayName = @WebPageResources.Menu_NatcatSummary;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "Natcat";
                        item.IconClass = "fa fa-sidebar fa-bolt";
                        break;
                    case Constants.SummaryReport.RecommendationDetails:
                        //item.DisplayName = @WebPageResources.Menu_RecDetails;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "Recommendation";
                        item.IconClass = "fa fa-sidebar fa-list fa-lg";
                        break;
                    case Constants.SummaryReport.RiskQualityBenchmarking:
                        //item.DisplayName = @WebPageResources.Menu_RiskQualityBench;
                        item.DisplayName = reportType.Name;
                        item.Action = "Benchmarking";
                        item.Controller = "RiskQuality";
                        item.IconClass = "fa fa-sidebar fa-line-chart fa-lg";
                        break;
                    case Constants.SummaryReport.RiskQualityRatings:
                        //item.DisplayName = @WebPageResources.Menu_RQR;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "RiskQuality";
                        item.IconClass = "fa fa-sidebar fa-pie-chart fa-lg";
                        break;
                    case Constants.SummaryReport.Maps:
                        //item.DisplayName = WebPageResources.Menu_Map;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "Map";
                        item.IconClass = "fa fa-sidebar fa-map-marker fa-lg";
                        break;
                    case Constants.SummaryReport.WhatIfAnalysis:
                        //item.DisplayName = WebPageResources.Menu_WhatIf;
                        item.DisplayName = reportType.Name;
                        item.Action = "Index";
                        item.Controller = "WhatIf";
                        item.IconClass = "fa fa-sidebar fa-question-circle fa-lg";
                        break;
                    case Constants.SummaryReport.IsoRisk:
                        item.DisplayName = WebPageResources.IoRisk_Title;
                        item.Action = "Index";
                        item.Controller = "IsoRisk";
                        item.IconClass = "fa fa-sidebar fa-braille fa-lg";
                        break;
                }

                // we may have some menu items which are not implemented yet, so only add the item
                // to our list if we have defined the menu item above.
                if (item.DisplayName != null && item.Action != null && item.Controller != null)
                    menuItems.Add(item);
            }

            foreach (var x in menuItems.OrderBy(x => x.DisplayName))
            {
                menu.Append(MenuItem(html, x.Action, x.Controller, x.DisplayName, x.IconClass, x.Style));
            }

            return MvcHtmlString.Create(menu.ToString());
        }
    }
}



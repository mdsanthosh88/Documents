﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Claims;
using System.Web;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.Logic;
using XLC.MyAnalysis2.Logic.DTO;
using XLC.MyAnalysis2.Shared;
using Constants = XLC.MyAnalysis2.DbModels.DbConstants.Constants;

namespace XLC.MyAnalysis2.WebPortal.Helpers
{
    public static class UserHelper
    {
        public static UserMerged GetCurrentlyAuthenticatedUser(bool localDataOnly = false)
        {
            string commonName = ExtractCommonNameFromClaims();

            var userLogic = new UserLogic();
            return (localDataOnly 
                        ? userLogic.GetLocalUserByEdsCn(commonName)
                        : userLogic.GetMergedUserByEdsCn(commonName));
        }

        /// <summary>
        /// Does the current authenticated user have permissions to a location
        /// </summary>
        /// <param name="lpAllPiKey">LP's location Id</param>
        public static void UserHasAccessToLocation(int lpAllPiKey)
        {
            var userLogic = new UserLogic();
            UserMerged authenticatedUser = GetCurrentlyAuthenticatedUser(localDataOnly: true);
            bool hasAccess = userLogic.GetUserLocationPrivilegesIdsOnly(authenticatedUser.ID, lpAllPiKey).Any();
            if (!authenticatedUser.AccountAccessAll && !hasAccess)
            {
                throw new UnauthorizedAccessException(
                    $"User with Id {authenticatedUser.ID} does not have permissions to access location lpAllPiKey={lpAllPiKey}");
            }
        }

        /// <summary>
        /// Attempt to extract the CommonName (CN) e.g. X121852 from the supplied claims
        /// When claims supplied by EDS special logic is required to derive from claims:
        /// 1) Internal users, derive from nameidentifier
        /// 2) External users, derive from x500distinguishedname
        /// </summary>
        /// <returns></returns>
        private static string ExtractCommonNameFromClaims()
        {
            string commonName = null;

            bool doSpecialClaimsProcessing =
                Boolean.Parse(ConfigHelper.GetAppSetting("EDS_EnableSpecialClaimsProcessing"));

            // we don't know if the user is 'external' or 'internal' so will use brute force to extract the CN

            string identifierForExternalUser =
                TryGetClaimValue(ConfigHelper.GetAppSetting("EDS_UniqueClaimTypeIdentifier_External"));
            if (identifierForExternalUser != null)
            {
                if (doSpecialClaimsProcessing)
                {
                    LogHelper.Info($"Extracting CN from {identifierForExternalUser}");
                    commonName = ExtractCommonNameFromDistinguishedName(identifierForExternalUser);
                }
                else
                {
                    commonName = identifierForExternalUser;
                }

                LogHelper.Info($"CN = {commonName}");

                return commonName;
            }

            string identifierForInternalUser =
                TryGetClaimValue(ConfigHelper.GetAppSetting("EDS_UniqueClaimTypeIdentifier_Internal"));
            if (identifierForInternalUser != null)
            {
                if (doSpecialClaimsProcessing)
                {
                    LogHelper.Info($"Extracting CN from {identifierForInternalUser}");
                    commonName = ExtractCommonNameFromDomainWithUserName(identifierForInternalUser);
                }
                else
                {
                    commonName = identifierForInternalUser;
                }

                LogHelper.Info($"CN = {commonName}");

                return commonName;
            }

            LogHelper.Error("Unable to extract Common Name (CN) from claims");
            throw new Exception("Unable to extract Common Name (CN) from claims");
        }

        /// <summary>
        /// Extract the common name from a value which contains the domain and user name.
        /// E.g. R02\X12152 returns X12152
        /// </summary>
        /// <param name="domainWithUserName"></param>
        /// <returns></returns>
        private static string ExtractCommonNameFromDomainWithUserName(string domainWithUserName)
        {
            char delimiter = (char)92;      //delimiter is '\' as in "R02\X12152"
            if (domainWithUserName.Contains(delimiter))
            {
                return domainWithUserName.Split(delimiter)[1];
            }
            else
            {
                return domainWithUserName;
            }
        }

        /// <summary>
        /// Extract the common name from the X500 Distinguished Name,
        /// E.g. CN=EX0000003122,OU=people,OU=external,DC=xl,DC=com
        /// becomes EX0000003122
        /// </summary>
        /// <param name="distinguishedName"></param>
        /// <returns></returns>
        private static string ExtractCommonNameFromDistinguishedName(string distinguishedName)
        {
            char delimiter = ',';      //delimiter comma
            if (distinguishedName.Contains(delimiter))
            {
                return distinguishedName.Split(delimiter)[0].Remove(0, 3);
            }
            else
            {
                return distinguishedName;
            }
        }

        private static string TryGetClaimValue(string claimType)
        {
            var currentUser = HttpContext.Current.User.Identity;
            return ((ClaimsIdentity)currentUser).Claims.SingleOrDefault(cl => cl.Type == claimType)?.Value;
        }

        public static IEnumerable<string> GetCurrentUsersRoles()
        {
            var userLogic = new UserLogic();
            IList<string> result = new List<string>();
            var user = HttpContext.Current.User.Identity;

            var mergedUser = GetCurrentlyAuthenticatedUser(localDataOnly: true);
            if (mergedUser != null)
            {
                var userRoles = mergedUser.UserRoles;

                if (user.IsAuthenticated)
                {
                    result = (from ur in userRoles
                              join userRole in userLogic.GetAllRoles() on ur.RoleID equals userRole.ID
                              select userRole.Name
                        ).ToList();
                }
            }

            return result;
        }

        public static bool CurrentUserIsInternalUser()
        {
            var internalRoles = GetInternalRoleNames();
            return GetCurrentUsersRoles().Any(role => internalRoles.Contains(role));
        }

        public static bool SpecifiedUserIsInternalUser(UserMerged userData)
        {
            var internalRoles = GetInternalRoleNames();
            return userData.UserRoles.Any(ur => internalRoles.Contains(ur.Role.Name));
        }

        private static List<string> GetInternalRoleNames()
        {
            return new List<string>
            {
                Constants.RoleNames.FieldEngineer,
                Constants.RoleNames.RiskConsultant,
                Constants.RoleNames.SystemAdministrator,
                Constants.RoleNames.XLCManager,
                Constants.RoleNames.Underwriter
            };
        }

        /// <summary>
        /// Raise the MA2 User and UserRole data for the initial 'sysadmin' user if necessary
        /// </summary>
        public static void EnsureInitialAdminUser()
        {
            var userLogic = new UserLogic();

            string sysadminEDSCN = ConfigHelper.GetAppSetting("Initial_SysAdmin_UserName");

            if (userLogic.GetByEDSCN(sysadminEDSCN) == null)
            {
                var user = new User
                {
                    EdsCn = sysadminEDSCN,
                    AccountAccessAll = true,
                    LanguageID = DbModels.DbConstants.Constants.Language.English,
                    UserStatusID = DbModels.DbConstants.Constants.UserStatus.Active,
                    LastActivityDate = DateTime.Now
                };

                user.UserRoles.Add(new UserRole
                {
                    User = user,
                    RoleID = DbModels.DbConstants.Constants.Roles.SystemAdministrator,
                    CreatedDate = DateTime.Now,
                    CreatedBy = -1,
                    UpdatedDate = DateTime.Now,
                    UpdatedBy = -1
                });

                // userId set to zero as we have no authenticated user this early on in the pipeline
                user.UserStatusID = Constants.UserStatus.Active;  //ensure that status is not Pending when user saved
                User result = userLogic.UpsertUser(user, 0);

                if (result == null)
                {
                    throw new Exception($"Error attempting to create MA2 data for '{sysadminEDSCN}' user");
                }

                LogHelper.Info($"Created MA2 data for '{sysadminEDSCN}' user");
            }
            else
            {
                LogHelper.Info($"MA2 data for '{sysadminEDSCN}' user detected - no action taken");
            }
        }

        public static bool GetTranslatorMenuAcess()
        {
            var userLogic = new UserLogic();

            bool isAccess = false;
            var mergedUser = GetCurrentlyAuthenticatedUser(localDataOnly: true);
            if (mergedUser != null)
            {
                isAccess = mergedUser.Translator;
            }
            return isAccess;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="roleName"></param>
        /// <returns></returns>
        public static bool IsUserInRole(string roleName)
        {
            var userRoles = GetCurrentUsersRoles();
            return (from role in userRoles where role.ToLower() == roleName.ToLower() select role).Any();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static bool ReferralFromAdfsLogin()
        {
            bool result = false;

            if (HttpContext.Current.Request.UrlReferrer == null)
                return result;

            var actual = HttpContext.Current.Request.UrlReferrer;
            var expected = new Uri(ConfigurationManager.AppSettings["ida:Issuer"]);

            // check the referrer against our own web.config value
            result = actual.Scheme == expected.Scheme && actual.Authority == expected.Authority && actual.AbsolutePath == expected.AbsolutePath;

            return result;
        }

    }
}

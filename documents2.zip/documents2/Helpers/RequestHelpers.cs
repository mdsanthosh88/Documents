﻿using System;
using System.Web;

namespace XLC.MyAnalysis2.WebPortal.Helpers
{
    public static class RequestHelpers
    {
        public static string GetRequestInfo(HttpContextBase httpContext)
        {
            if (httpContext == null) throw new ArgumentNullException(nameof(httpContext));

            string controllerName = "<unknown>";
            string actionName = "<unknown>";

            var routeValues = httpContext.Request.RequestContext.RouteData.Values;

            if (routeValues.ContainsKey("controller"))
                controllerName = (string)routeValues["controller"];

            if (routeValues.ContainsKey("action"))
                actionName = (string)routeValues["action"];

            return $"{controllerName}Controller.{actionName}";
        }
    }
}
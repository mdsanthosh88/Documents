﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using XLC.MyAnalysis2.DbModels.DbConstants;

namespace XLC.MyAnalysis2.WebPortal.Helpers
{
    public static class CultureHelper
    {
        public const string LanguageCookieName = "_ma2culture";

        // Include ONLY cultures you are implementing
        private static readonly List<string> _cultures = new List<string> {
            "en-GB", // first culture is the DEFAULT
            "de-DE", // German
            "es-ES", // Spanish culture
            "fr-FR", // French culture
            "it-IT", // Italian culture
            "pt-PT"  // Portuguese culture
        };
        /// <summary>
        /// Returns a valid culture name based on "name" parameter. If "name" is not valid, it returns the default culture "en-GB"
        /// </summary>
        /// <param name="name" />Culture's name (e.g. en-US)</param>
        public static string GetImplementedCulture(string name)
        {
            // make sure it's not null
            if (string.IsNullOrEmpty(name))
                return GetDefaultCulture(); // return Default culture
            if (_cultures.Where(c => c.Equals(name, StringComparison.InvariantCultureIgnoreCase)).Count() > 0)
                return name; // accept it
                             // Find a close match. For example, if you have "en-US" defined and the user requests "en-GB",
                             // the function will return closes match that is "en-US" because at least the language is the same (ie English)
            var n = GetNeutralCulture(name);
            foreach (var c in _cultures)
                if (c.StartsWith(n))
                    return c;
            // else
            // It is not implemented
            return GetDefaultCulture(); // return Default culture as no match found
        }
        /// <summary>
        /// Returns default culture name which is the first name decalared (e.g. en-US)
        /// </summary>
        /// <returns></returns>
        public static string GetDefaultCulture()
        {
            return _cultures[0]; // return Default culture
        }
        public static string GetCurrentCulture()
        {
            return Thread.CurrentThread.CurrentCulture.Name;
        }

        public static string GetNeutralCulture(string name)
        {
            if (!name.Contains("-")) return name;
            return name.Split('-')[0]; // Read first part only. E.g. "en", "es"
        }

        public static string GetCurrentCultureLanguageCode()
        {
            return Thread.CurrentThread.CurrentCulture.TwoLetterISOLanguageName;
        }

        public static int GetLanguageIDFromCulture(string culture)
        {
            switch (culture)
            {
                case Constants.Culture.English:
                    return Constants.Language.English;
                case Constants.Culture.German:
                    return Constants.Language.German;
                case Constants.Culture.Spanish:
                    return Constants.Language.Spanish;
                case Constants.Culture.French:
                    return Constants.Language.French;
                case Constants.Culture.Italian:
                    return Constants.Language.Italian;
                case Constants.Culture.Portuguese:
                    return Constants.Language.Portuguese;
                default:
                    return Constants.Language.English;
            }
        }
    }
}
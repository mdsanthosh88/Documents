﻿using AutoMapper;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.Logic.DTO;
using XLC.MyAnalysis2.WebPortal.Models;

namespace XLC.MyAnalysis2.WebPortal.Helpers
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<User, UserViewModel>();
            CreateMap<UserMerged, UserViewModel>();
            CreateMap<UserViewModel, User>();
            CreateMap<UserNotificationType, UserNotificationTypeModel>();
            CreateMap<NotificationType, NotificationTypeModel>();
            CreateMap<WhatIfScenario, WhatIfFiltersViewModel>();
            CreateMap<UserNotificationTypeModel, UserNotificationType>();

            CreateMap<ViewAccount, AccountProfileViewModel>();
            CreateMap<ViewReportAccess, ReportAccess>();

            CreateMap<ViewReportAccess, ReportAccess>();
        }
    }

    public static class MappingExpressionExtensions
    {
        public static IMappingExpression<TSource, TDest> IgnoreAllUnmapped<TSource, TDest>(this IMappingExpression<TSource, TDest> expression)
        {
            expression.ForAllMembers(opt => opt.Ignore());
            return expression;
        }
    }

    public static class AutoMapperConfig
    {
        private static MapperConfiguration _mapperConfiguration { get; set; }

        public static void Configure(Profile profile)
        {
            _mapperConfiguration = new MapperConfiguration(cfg => cfg.AddProfile(profile));
        }

        public static IMapper Mapper
        {
            get { return _mapperConfiguration.CreateMapper(); }
        }
    }
}
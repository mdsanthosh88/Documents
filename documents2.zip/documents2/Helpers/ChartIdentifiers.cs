﻿namespace XLC.MyAnalysis2.WebPortal.Helpers
{
    public enum ChartIdentifierEnum
    {
        Dashboard_RecommendationByStatus = 1,
        Dashboard_NaturalCatastrophe = 2,
        Dashboard_RiskQualityRating = 3,
        Dashboard_HighestFireLossEstimates = 4,
        Dashboard_Map = 5,
        Dashboard_Documents = 6,
        Recommendation_TypeStatus = 7,
        Recommendation_Type = 8,
        Recommendation_Status = 9,
        RiskQualityRating_Benchmarking = 10,
        RiskQualityRatings_BreakdownByLocation = 11,
        RiskQualityRatings_BreakdownByAccountPercentage = 12,
        Dashboard_Cope = 13,
        Dashboard_RQROverTime = 14,
        RiskQualityRatingsOverTime_FromDate = 15,
        RiskQualityRatingsOverTime_ToDate = 16,
        Dashboard_RiskQualityRatingsOverTime_FromDate = 17,
        Dashboard_RiskQualityRatingsOverTime_ToDate = 18,
        Impairments_Type3_Location = 19,
        Impairments_Type3_SystemType = 20,
        Dashboard_Impairments_Type1 = 21,
        Dashboard_Citran = 22,
        RiskQualityRatingsOverTimeTileTwo = 23,
        IsoRisk = 24,
        RecommendationSummary_Category = 25,
        RecommendationSummary_Category_Physical = 26,
        RecommendationSummary_Category_HumanElement = 27,
        RecommendationSummary_Physical_EstCost = 28,
        RecommendationSummary_Physical_LEPrior = 29,
        Dashboard_RecommendationStatusSummary_FromDate = 30,
        Dashboard_RecommendationStatusSummary_ToDate = 31
    }

    public enum ExportFormat
    {
        PDF,
        Excel,
        Word,
        PowerPoint
    }
}
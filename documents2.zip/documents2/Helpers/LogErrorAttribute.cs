﻿using System.Web.Mvc;
using XLC.MyAnalysis2.Shared;

namespace XLC.MyAnalysis2.WebPortal.Helpers
{
    public class LogErrorAttribute : HandleErrorAttribute
    {
        public override void OnException(ExceptionContext filterContext)
        {
            LogHelper.Error(filterContext.Exception.Message, filterContext.Exception);
        }
    }
}
﻿using System;
using System.Configuration;
using System.IO;
using System.Reflection;
using System.Web;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.Logic;
using XLC.MyAnalysis2.Shared;

namespace XLC.MyAnalysis2.WebPortal.Helpers
{
    public static class UIHelper
    {
        public static string SystemVersion
        {
            get
            {
                var version = HttpContext.Current.Application["SystemVersion"];

                if (version == null)
                    version = Assembly.GetExecutingAssembly().GetName().Version.ToString(3);

                return version.ToString();
            }
        }

        public static string FullSystemVersion
        {
            get
            {
                var version = HttpContext.Current.Application["FullSystemVersion"];

                if (version == null)
                    version = Assembly.GetExecutingAssembly().GetName().Version.ToString(4);

                return version.ToString();
            }
        }

        public static string EnvironmentName
        {
            get
            {
                var result = string.Empty;
                var value = ConfigurationManager.AppSettings["EnvironmentName"];

                if (!string.IsNullOrEmpty(value))
                    result = value;

                return result;
            }
        }

        public static bool EncryptCookie
        {
            get
            {
                var result = true;
                var value = ConfigurationManager.AppSettings["EncryptCookie"];

                try
                {
                    if (!string.IsNullOrEmpty(value))
                        result = bool.Parse(value);
                }
                catch (Exception ex)
                {
                    result = true;
                }

                return result;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="replaceChar"></param>
        /// <returns></returns>
        public static string CleanFilename(string filename, string replaceChar)
        {
            return FormatHelper.CleanFilename(filename, replaceChar);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="score"></param>
        /// <param name="ratingType"></param>
        /// <returns></returns>
        public static string GetRiskQualityCategoryColourForScore(decimal? score, DbModels.DbEnums.RatingTypesEnum ratingType)
        {
            if (ratingType == DbModels.DbEnums.RatingTypesEnum.LQR || ratingType == DbModels.DbEnums.RatingTypesEnum.LQI)
            {
                return (score >= 15  ? Constants.RQRColours.RQRColour_Excellent
                        : score >= 12 && score <= 14 ? Constants.RQRColours.RQRColour_Good
                        : score >= 9 && score <= 11 ? Constants.RQRColours.RQRColour_Fair
                        : score >= 0 && score <= 8 ? Constants.RQRColours.RQRColour_Poor
                        : Constants.RQRColours.RQRColour_Unspecified);
            }
            else
            {
                return (score >= 75 && score <= 100 ? Constants.RQRColours.RQRColour_Excellent
                        : score >= 60 && score <= 74 ? Constants.RQRColours.RQRColour_Good
                        : score >= 45 && score <= 59 ? Constants.RQRColours.RQRColour_Fair
                        : score >= 1 && score <= 44 ? Constants.RQRColours.RQRColour_Poor
                        : Constants.RQRColours.RQRColour_Unspecified);
            }
        }

        /// <summary>
        /// Get the name of the language for the specified LCID.
        /// </summary>
        /// <param name="lcid"></param>
        /// <param name="localeSpecific"></param>
        public static string GetLanguageNameByLcid(int lcid, bool localeSpecific = true)
        {
            var documentLogic = new DocumentLogic();
            return documentLogic.GetLanguageNameByLcid(lcid, localeSpecific);
        }


        /// <summary>
        /// Get the name of the language for the specified LCID.
        /// </summary>
        /// <param name="lcid"></param>
        /// <param name="localeSpecific"></param>
        public static string GetLanguageNameById(int id, bool localeSpecific = true)
        {
            var documentLogic = new DocumentLogic();
            return documentLogic.GetLanguageNameById(id, localeSpecific);
        }

        /// <summary>
        /// Get the Organization name for the given Id.
        /// </summary>
        /// <param name="organizationPostedId"></param>
        /// <returns></returns>
        public static string GetOrganizationPostedById(int organizationPostedId)
        {
            var documentLogic = new DocumentLogic();
            return documentLogic.GetOrganizationPostedById(organizationPostedId);
        }

        /// <summary>
        /// Get description of Document Level
        /// </summary>
        /// <param name="level"></param>
        /// <returns></returns>
        public static string GetDocumentLevelDescription(int level)
        {
            var documentLogic = new DocumentLogic();
            return documentLogic.GetDocumentLevelDescription(level);
        }
        public static string GetDocumentLevelLineOfBusinessOptions(int level)
        {
            var documentLogic = new DocumentLogic();
            return documentLogic.GetDocumentLevelLineOfBusinessOptions(level);
        }
        public static string GetDocumentLevelPeril(int level)
        {
            var documentLogic = new DocumentLogic();
            return documentLogic.GetDocumentLevelPeril(level);
        }
        public static string GetDocumentLevelSubject(int level,string Subject)
        {
            var documentLogic = new DocumentLogic();
            return documentLogic.GetDocumentLevelSubject(level, Subject);
        }
        
    }
}
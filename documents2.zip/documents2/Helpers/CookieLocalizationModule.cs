﻿using System;
using System.Threading;
using System.Web;

namespace XLC.MyAnalysis2.WebPortal.Helpers
{

    /// <summary>
    /// Check the _culture cookie on each request
    /// http://www.manas.com.ar/smedina/2008/12/17/internationalization-in-aspnet-mvc/
    /// </summary>
    public class CookieLocalizationModule : IHttpModule
    {
        public void Dispose()
        {
        }

        public void Init(HttpApplication context)
        {
            context.BeginRequest += context_BeginRequest;
        }

        void context_BeginRequest(object sender, EventArgs e)
        {
            string cultureName = null;

            // Attempt to read the culture cookie from Request
            HttpCookie cultureCookie = HttpContext.Current.Request.Cookies[CultureHelper.LanguageCookieName];
            if (cultureCookie != null)
                cultureName = cultureCookie.Value;
            else
                cultureName = HttpContext.Current.Request.UserLanguages != null && HttpContext.Current.Request.UserLanguages.Length > 0 ?
                    HttpContext.Current.Request.UserLanguages[0] :  // obtain it from HTTP header AcceptLanguages
                    null;

            // Validate culture name
            cultureName = CultureHelper.GetImplementedCulture(cultureName); // This is safe

            // Modify current thread's cultures            
            Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(cultureName);
            Thread.CurrentThread.CurrentUICulture = Thread.CurrentThread.CurrentCulture;
        }
    }
}
﻿using System;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Newtonsoft.Json;
using XLC.MyAnalysis2.Shared;

namespace XLC.MyAnalysis2.WebPortal.Helpers
{
    public class MA2CookieData
    {
        public int LPAcctKey { get; set; }
        public string LPAcctNum { get; set; }
        public int DataFilterId { get; set; }
        public DateTime? AlertsAcknowledged { get; set; }

        // Used to determine Account-Location No/Code Preference, based on AccountNumerDisplayType table
        public int? LpAcctNumDispTypeKey { get; set; }
        public int? ClientTypeId { get; set; }
    }

    public class MA2CookieHelper
    {
        public const string SessionCacheCookieName = "MA2_SessionCache";
        const string MachineKeyPurpose = "MA2";

        public static void CreateCookie(ControllerContext context, MA2CookieData data, bool encrypt)
        {
            UpdateCookie(context, data, encrypt);
        }

        public static bool CookieExists(ControllerContext context)
        {
            HttpCookie httpCookie = context.HttpContext.Request.Cookies[SessionCacheCookieName];
            return httpCookie != null;
        }

        /// <summary>
        /// Unprotect and deserialize the cookie - we may have a cookie but it may not deserialize correctly between major versions of the system. 
        /// To combat this we log the failure and return null so the cookie can subsequently be recreated at the new standard.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="encrypt"></param>
        /// <returns></returns>
        public static MA2CookieData GetData(ControllerContext context, bool encrypt)
        {
            MA2CookieData result = null;
            HttpCookie httpCookie = context.HttpContext.Request.Cookies[SessionCacheCookieName];
            return GetData(httpCookie, encrypt);
        }

        /// <summary>
        /// Refactored to accept cookie object which may have been passed from any number of HttpContext objects (ControllerContext or SignalR Hub Context)
        /// </summary>
        /// <param name="httpCookie"></param>
        /// <param name="encrypt"></param>
        /// <returns></returns>
        public static MA2CookieData GetData(HttpCookie httpCookie, bool encrypt)
        {
            MA2CookieData result = null;

            if (httpCookie == null)
                throw new Exception("Cookie not found");

            try
            {
                var data = encrypt ? Unprotect(httpCookie.Value) : httpCookie.Value;
                result = JsonConvert.DeserializeObject<MA2CookieData>(data);
            }
            catch (Exception ex)
            {
                if (ex is JsonReaderException)
                    LogHelper.Error("Unable to Deserialize Cookie", ex);
                else
                    LogHelper.Error("Unable to GetData from Cookie", ex);
            }

            return result;
        }

        /// <summary>
        /// Update or Create cookie as required
        /// </summary>
        /// <param name="context"></param>
        /// <param name="data"></param>
        /// <param name="encrypt"></param>
        public static void UpdateCookie(ControllerContext context, MA2CookieData data, bool encrypt)
        {
            var json = JsonConvert.SerializeObject(data);

            HttpCookie httpCookie = context.HttpContext.Request.Cookies[SessionCacheCookieName] ?? new HttpCookie(SessionCacheCookieName);

            httpCookie.Value = encrypt ? Protect(json) : json;
            httpCookie.HttpOnly = true;
            httpCookie.Secure = true;
            httpCookie.Expires = DateTime.Today.AddYears(1);

            context.HttpContext.Response.Cookies.Add(httpCookie);
        }

        /// <summary>
        /// Removes the cookie
        /// </summary>
        /// <param name="context">Controller context</param>
        public static void RemoveCookie(ControllerContext context)
        {
            if (CookieExists(context))
            {
                HttpCookie cookie = new HttpCookie(SessionCacheCookieName);
                cookie.Expires = DateTime.Now.AddDays(-1);

                context.HttpContext.Request.Cookies.Remove(SessionCacheCookieName);
                context.HttpContext.Response.Cookies.Remove(SessionCacheCookieName);
                context.HttpContext.Request.Cookies.Add(cookie);
                context.HttpContext.Response.Cookies.Add(cookie);
            }
        }

        private static string Protect(string data)
        {
            if (string.IsNullOrEmpty(data)) return null;

            var raw = Encoding.UTF8.GetBytes(data);
            var value = MachineKey.Protect(raw, MachineKeyPurpose);
            return Convert.ToBase64String(value);
        }

        private static string Unprotect(string value)
        {
            if (String.IsNullOrWhiteSpace(value)) return null;
            var bytes = Convert.FromBase64String(value);
            var raw = MachineKey.Unprotect(bytes, MachineKeyPurpose);

            return Encoding.UTF8.GetString(raw);
        }
    }
}
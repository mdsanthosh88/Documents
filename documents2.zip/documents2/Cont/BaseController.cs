﻿using DataTables.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.DbModels.DbEnums;
using XLC.MyAnalysis2.Logic;
using XLC.MyAnalysis2.Logic.DTO;
using XLC.MyAnalysis2.Resources;
using XLC.MyAnalysis2.Shared;
using XLC.MyAnalysis2.WebPortal.Helpers;
using XLC.MyAnalysis2.WebPortal.Hubs;
using XLC.MyAnalysis2.WebPortal.Models;
using static XLC.MyAnalysis2.DbModels.DbConstants.Constants;


namespace XLC.MyAnalysis2.WebPortal.Controllers
{
    public class BaseController : Controller
    {
        private string _userName;

        /// <summary>
        /// Return the ID of the current authenticated user
        /// </summary>
        public int UserId
        {
            get
            {
                var user = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true);
                return user != null ? user.ID : 0;
            }
        }

        public string UserName
        {
            get
            {
                if (string.IsNullOrWhiteSpace(this._userName))
                {
                    this._userName = UserHelper.GetCurrentlyAuthenticatedUser()?.EdsCn;
                }

                return this._userName;
            }
        }

        #region Pipleine Overrides

        protected override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            base.OnActionExecuted(filterContext);

            var model = filterContext.Controller.ViewData.Model as BaseModel;

            if (model != null)
            {
                LoadBaseModel(model);
            }
        }

        #endregion

        [HttpGet]
        public JsonResult GetLocationsPickerNodes()
        {
            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            var useLocationNo = UseLocationNoInReport();

            try
            {
                var logic = new UserLogic(this.UserName);
                var locationLogic = new LocationLogic(this.UserName);
                int userId = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true).ID;

                int idSeed = 1;

                var divisions = (from div in logic.GetDivisionPrivileges(userId, cookieData.LPAcctKey)
                                 select new LocationsPickerNode
                                 {
                                     Id = idSeed++,
                                     LPAcctWebDivKey = div.LpAcctWebDivKey,
                                     Name = div.Name,
                                     Type = LocationsPickerNode.LocationsPickerNodeTypesEnum.DivisionNode,
                                     ParentIds = null //parent not relevant for Division
                                 }).ToList();

                var subDivisions = (from sdiv in logic.GetSubDivisionPrivileges(userId, cookieData.LPAcctKey)
                                    select new LocationsPickerNode
                                    {
                                        Id = idSeed++,
                                        LPsubDivKey = sdiv.LpSubDivKey,
                                        Name = sdiv.Name,
                                        Type = LocationsPickerNode.LocationsPickerNodeTypesEnum.SubDivisionNode,
                                        ParentIds = new List<int?> { divisions.Single(div => div.LPAcctWebDivKey == sdiv.LpDivKey).Id }        //parent division
                                    }).ToList();


                var regions = (from reg in logic.GetRegionPrivileges(userId, cookieData.LPAcctKey)
                               select new LocationsPickerNode
                               {
                                   Id = idSeed++,
                                   LPAcctDivGroupKeyRegion = reg.LpAcctDivGroupKey,
                                   Name = reg.Name,
                                   Type = LocationsPickerNode.LocationsPickerNodeTypesEnum.RegionNode,
                                   ParentIds = null //parent not relevant for Region
                               }).ToList();

                var classifications = (from clas in logic.GetClassificationPrivileges(userId, cookieData.LPAcctKey)
                                       select new LocationsPickerNode
                                       {
                                           Id = idSeed++,
                                           LPAcctDivGroupKeyClassification = clas.LpAcctDivGroupKey,
                                           Name = clas.Name,
                                           Type = LocationsPickerNode.LocationsPickerNodeTypesEnum.ClassificationNode,
                                           ParentIds = null //parent not relevant for Classification
                                       }).ToList();

                var otherProviders = (from op in logic.GetOtherProviderPrivileges(userId, cookieData.LPAcctKey)
                                      select new LocationsPickerNode
                                      {
                                          Id = idSeed++,
                                          LPAcctDivGroupKeyOtherProvider = op.LpAcctDivGroupKey,
                                          Name = op.Name,
                                          Type = LocationsPickerNode.LocationsPickerNodeTypesEnum.OtherProviderNode,
                                          ParentIds = null //parent not relevant for Other Provider
                                      }).ToList();

                var filtered = locationLogic.LoadLocationAccountGroupTypesForAccount(cookieData.LPAcctKey).ToList();

                var locationLpAllPiKeys = logic.GetLocationPrivilegesReturnLpAllPiKeys(userId, cookieData.LPAcctKey);
                locationLpAllPiKeys.Sort();


                var locations = (from loc in logic.GetLocationsFromLpAllPiKeys(locationLpAllPiKeys)
                                 select new LocationsPickerNode
                                 {
                                     Id = idSeed++,
                                     LPAcctWebDivKey = loc.LpAcctWebDivKey,
                                     LPsubDivKey = loc.LPsubDivKey,
                                     LPAcctDivGroupKeyRegion = (from grp in filtered where grp.LpAllPiKey == loc.LpAllPiKey && grp.AccountGroupType.LpDivGroupTypeKey == (int)AccountGroupTypeKeyEnum.Region select grp.LpAcctDivGroupKey).FirstOrDefault(),
                                     LPAcctDivGroupKeyClassification = (from grp in filtered where grp.LpAllPiKey == loc.LpAllPiKey && grp.AccountGroupType.LpDivGroupTypeKey == (int)AccountGroupTypeKeyEnum.Classification select grp.LpAcctDivGroupKey).FirstOrDefault(),
                                     LPAcctDivGroupKeyOtherProvider = (from grp in filtered where grp.LpAllPiKey == loc.LpAllPiKey && grp.AccountGroupType.LpDivGroupTypeKey == (int)AccountGroupTypeKeyEnum.OtherProvider select grp.LpAcctDivGroupKey).FirstOrDefault(),
                                     LPAllPiKey = loc.LpAllPiKey,
                                     Name = loc.Name,
                                     LocationNo = useLocationNo ? loc.LocationNo : loc.LocationCode,
                                     ClientLocationNo = loc.ClientLocationNo,
                                     LocationFullAddressWithLocationNo = FormatHelper.FormatFullAddressToIncludeLocationNumber(
                                         loc.FullAddress,
                                         useLocationNo ? loc.LocationNo : loc.LocationCode),
                                     StreetAddress = FormatHelper.ConvertLineAddressesToStreetAddressWithHTMLBreakElements(loc.AddressLine1, loc.AddressLine2, loc.AddressLine3, false),
                                     City = loc.City,
                                     State = loc.State,
                                     Country = loc.Country,
                                     Type = LocationsPickerNode.LocationsPickerNodeTypesEnum.LocationNode,
                                     ParentIds = new List<int?> { }
                                 }).ToList();

                // assign all parents of this locations
                foreach (var loc in locations)
                {
                    if (divisions.Any(x => x.LPAcctWebDivKey == loc.LPAcctWebDivKey))
                        loc.ParentIds.Add(divisions.SingleOrDefault(x => x.LPAcctWebDivKey == loc.LPAcctWebDivKey)?.Id);

                    if (subDivisions.Any(x => x.LPsubDivKey == loc.LPsubDivKey))
                        loc.ParentIds.Add(subDivisions.SingleOrDefault(x => x.LPsubDivKey == loc.LPsubDivKey)?.Id);

                    if (regions.Any(x => x.LPAcctDivGroupKeyRegion == loc.LPAcctDivGroupKeyRegion))
                        loc.ParentIds.Add(regions.SingleOrDefault(x => x.LPAcctDivGroupKeyRegion == loc.LPAcctDivGroupKeyRegion)?.Id);

                    if (classifications.Any(x => x.LPAcctDivGroupKeyClassification == loc.LPAcctDivGroupKeyClassification))
                        loc.ParentIds.Add(classifications.SingleOrDefault(x => x.LPAcctDivGroupKeyClassification == loc.LPAcctDivGroupKeyClassification)?.Id);

                    if (otherProviders.Any(x => x.LPAcctDivGroupKeyOtherProvider == loc.LPAcctDivGroupKeyOtherProvider))
                        loc.ParentIds.Add(otherProviders.SingleOrDefault(x => x.LPAcctDivGroupKeyOtherProvider == loc.LPAcctDivGroupKeyOtherProvider)?.Id);
                }

                var results = divisions
                                .Union(subDivisions)
                                .Union(locations)
                                .Union(regions)
                                .Union(classifications)
                                .Union(otherProviders)
                                .OrderBy(x => x.Name);

               

                var locationsHash = SequenceHelper.GetSequenceHashCode(locationLpAllPiKeys);
                
                var result = new LocationsPickerNodeModel
                {
                    UseLocationNo = useLocationNo,
                    LocationsPickerNodes = results,
                    CurrentCulture = LoadCurrentCulture(),
                    LocationsHash = locationsHash
                };


                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error loading Divisions for Account {cookieData.LPAcctKey}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Given the current Account - return a JSON list of Contacts
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetAccountContacts()
        {
            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);

            try
            {
                var accountLogic = new AccountLogic();
                var account = accountLogic.GetByLpAcctKey(cookieData.LPAcctKey);

                var data = new { contacts = new List<object>() };

                data.contacts.Add(new { Role = WebPageResources.AccountProfile_RiskConsultant, Name = account.RiskConsultantFormatted, Phone = account.RiskConsultantTelephone, Email = account.RiskConsultantEmail });
                data.contacts.Add(new { Role = WebPageResources.AccountProfile_RiskEngineeringLeader, Name = account.RiskEngineeringLeaderFormatted, Phone = account.RiskEngineeringTelephone, Email = account.RiskEngineeringLeaderEmail });

                if (account.Unbundled)
                {
                    data.contacts.Add(new { Role = WebPageResources.AccountProfile_PortfolioLeader, Name = account.PortfolioLeaderFormatted, Phone = account.PortfolioLeaderTelephone, Email = account.PortfolioLeaderEmail });
                }
                else
                {
                    data.contacts.Add(new { Role = WebPageResources.AccountProfile_Underwriter, Name = account.UnderwriterFormatted, Phone = account.UnderwriterTelephone, Email = account.UnderwriterEmail });
                    data.contacts.Add(new { Role = WebPageResources.AccountProfile_UnderwritingOffice, Name = account.UnderwritingOffice, Phone = account.UnderwritingOfficeTelephone, Email = account.UnderwritingOfficeEmail });
                }

                return Json(data, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error retrieving contacts for Account: {cookieData.LPAcctKey}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tileModel"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SaveTileConfiguration(IEnumerable<TileConfigurationModel> tileModel)
        {
            int userId = UserHelper.GetCurrentlyAuthenticatedUser().ID;

            try
            {
                if (tileModel != null)
                {
                    var tileConfigurationModels = tileModel.ToList();

                    if (!SaveTileConfigurationToDb(tileConfigurationModels))
                        throw new Exception();

                    return Json(tileConfigurationModels.OrderBy(item => item.name), JsonRequestBehavior.AllowGet);
                }

                return Json(null);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error saving tiles for User: {userId}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult PersistLocationsPickerNodes(List<int> lpAllPiKeysList)
        {
            int userId = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true).ID;

            try
            {
                var logic = new DataFilterLogic();
                logic.PersistLocationsPickerDataFilter(lpAllPiKeysList, userId);

                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error persisting selected locations for user {userId}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        private void LoadBaseModel(BaseModel model)
        {
            var currentUser = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true);
            var userId = currentUser.ID;
            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            var useLocationNo = UseLocationNoInReport();

            // 85102 - record users last activity
            var userLogic = new UserLogic();
            userLogic.RecordUserLastActivityDate(userId);

            if (cookieData != null)
            {
                var logic = new AccountLogic();
                var refLogic = new ReferenceListLogic();
                var filterLogic = new DataFilterLogic();
                var notificationLogic = new NotificationLogic();

                var isAdministrator = UserHelper.IsUserInRole(Constants.RoleNames.SystemAdministrator);
                var account = logic.GetAccount(cookieData.LPAcctKey);
                var ratingTypeId = logic.GetAccountProfile(cookieData.LPAcctKey)?.RatingTypeID;
                var ratingTypeName = refLogic.GetRatingTypes(true).Where(item => item.ID == ratingTypeId).SingleOrDefault();

                model.AccountContextID = account.LpAcctKey;
                model.IsSystemAdminUser = isAdministrator;

                model.AccountCurrencyCode = account.CurrencyCode;
                model.AccountFloorAreaUnitType = account.FloorAreaUnitTypeName;

                model.AccountName = account.AccountName;

                // add in the context account so it displays by default
                model.AccountOptions = new List<Select2Option>
                {
                    new Select2Option { id = account.LpAcctKey.ToString(), text = account.AccountName }
                };

                // load data filter groups
                model.DataFilterGroups = refLogic.GetDataFilterGroups()
                    .Where(x => !x.IsLocationsPickerGroup)
                    .OrderBy(x => x.Rank)
                    .Select(x => new Select2Option
                    {
                        id = x.ID.ToString(),
                        text = x.Name
                    })
                    .ToList();

                // load data filters for user -- System Administrators to be classed as owners of all Shared filters
                var dataFilters = filterLogic.LoadPermittedDataFilters(userId, cookieData.LPAcctKey, isAdministrator)
                    .OrderBy(x => x.Name)
                    .Select(x => new Select2Option
                    {
                        id = x.ID.ToString(),
                        text = x.Unsaved ? WebPageResources.DataFilter_Unsaved : x.Shared ? x.Name + WebPageResources.DataFilter_Shared : x.Name,
                        isUnsaved = x.Unsaved,
                        isShared = x.Shared,
                        isOwner = (x.UserID == userId || (isAdministrator && x.Shared))
                    }).Where(x=>x.isOwner || x.isShared)
                    .ToList();

                dataFilters.Insert(0, new Select2Option { id = null, text = WebPageResources.SelectOption_None });
                model.DataFilters = dataFilters;

                model.DataFilterSelectSingle = new List<Select2Option>();
                model.DataFilterId = cookieData.DataFilterId;

                var selectedDataFilter = filterLogic.LoadDataFilterById(model.DataFilterId);
                model.DataFilterIsDrillThrough = selectedDataFilter?.IsDrillThrough ?? false;
                model.OverrideQuickFilters = model.DataFilterIsDrillThrough;

                // load account logo
                model.HasLogo = account.Logo != null;

                model.CurrentCulture = LoadCurrentCulture();
                model.UseLocationNo = useLocationNo;
                model.RatingTypeName =FormatHelper.HtmlDecode(ratingTypeName.Name);
                model.RatingTypeId = ratingTypeName.ID;
                // load User's last login date
                model.UserLastUpdatedDate = UserHelper.GetCurrentlyAuthenticatedUser(false).UpdatedDate;

                // Load report permissions
                model.AllowedReportAccessIDs = LoadAllowedReportAccessIDs(cookieData.LPAcctKey);

                // Load unread alerts/notifications and new alerts since last login
                model.DashboardAlertsEnabled = ConfigHelper.GetAppSettingBool("DashboardAlertsEnabled");
                model.EnableAlertsandNotification = ConfigHelper.GetAppSettingBool("EnableAlertsandNotification");

                if (model.DashboardAlertsEnabled)
                {
                    model.Notification_AlertsSinceLastLogin = notificationLogic.CountUnreadAlertsSinceLastLogin(userId, true, null, cookieData.AlertsAcknowledged, account.LpAcctKey);
                    model.Notification_UnreadAlerts = notificationLogic.CountUnreadAlerts(userId, true, null, account.LpAcctKey);
                    model.Notification_UnreadNotifications = notificationLogic.CountUnreadNotifications(userId, true, null, account.LpAcctKey);
                }

                model.HashOfAllPermittedLocations = GetHashOfAvailableLocationsForUser();

                AssessUserAccountValidity(model);

                try
                {
                    logic.InsertAccountCostConfigforNewAccount(cookieData.LPAcctKey);
                }
                catch (Exception ex)
                {
                    LogHelper.Error($"Error inserting Accountcost config {userId}", ex);
                }
            }
            
        }
        
        public void AssessUserAccountValidity(BaseModel model)
        {
            var currentUser = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true);
            var userId = currentUser.ID;
            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);

            var userLogic = new UserLogic();
            userLogic.RecordUserLastActivityDate(userId);

            if (cookieData != null)
            {
                var logic = new AccountLogic();

                var account = logic.GetAccount(cookieData.LPAcctKey);
                var userAccountPrivilege = userLogic.GetUserAccountPrivilege(userId, account.LpAcctKey);
                
                model.UserAccountValid = new UserAccountValid();

                if (!BaseLogic.AccessToAccountIsValid(userAccountPrivilege))
                {
                    // User's access to the currently selected account is invalid. If they have permission to only one account, then they should have 
                    // their entire permissions revoked by setting their account status to pending.
                    //
                    // If the user has multiple accounts, then we must check to see if they have access to any valid accounts. If they do have access to an alternative
                    // account, then switch over on their behalf.

                    var allAccountAccessesForUser = userLogic.GetUserAccountPrivileges(userId);

                    if (allAccountAccessesForUser.Count == 1)
                    {
                        LogHelper.Info($"User {currentUser.EdsCn} has access to only one account, and their access is not valid (Start Date: {userAccountPrivilege.UserAccountAccessStartDate}, End Date: {userAccountPrivilege.UserAccountAccessExpiryDate}");
                        userLogic.UpdateUserStatus(currentUser, UserStatus.Pending, currentUser.EdsCn);

                        model.UserAccountValid.GrantAccess = false;
                        model.UserAccountValid.RedirectToLpAcctKey = null;
                        return;
                    }

                    else
                    {
                        foreach (var accountUserAccess in allAccountAccessesForUser.OrderBy(x => x.Name))
                        {
                            if (BaseLogic.AccessToAccountIsValid(accountUserAccess))
                            {
                                model.UserAccountValid.GrantAccess = false;
                                model.UserAccountValid.RedirectToLpAcctKey = accountUserAccess.LpAcctKey;
                                return;
                            }
                        }
                        // if we have reached here then the user doesn't have valid access to any accounts - so set their status as Pending
                        LogHelper.Info($"User {currentUser.EdsCn} has access to multiple accounts, and their access is not valid for any of them (Selected Account - Start Date: {userAccountPrivilege.UserAccountAccessStartDate}, End Date: {userAccountPrivilege.UserAccountAccessExpiryDate}");
                        userLogic.UpdateUserStatus(currentUser, UserStatus.Pending, currentUser.EdsCn);

                        model.UserAccountValid.GrantAccess = false;
                        model.UserAccountValid.RedirectToLpAcctKey = null;
                        return;
                    }
                }
            }

            model.UserAccountValid.GrantAccess = true;
            model.UserAccountValid.RedirectToLpAcctKey = null; 
        }

        private int GetHashOfAvailableLocationsForUser()
        {
            var userLogic = new UserLogic();
            var cookie = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            var currentUser = UserHelper.GetCurrentlyAuthenticatedUser().ID;

            var availableLocations = userLogic.GetLocationPrivilegesReturnLpAllPiKeys(currentUser, cookie.LPAcctKey);
            availableLocations.Sort();

            return SequenceHelper.GetSequenceHashCode(availableLocations);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected DataFilter LoadCurrentDataFilter()
        {
            var dfLogic = new DataFilterLogic();
            var cookie = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            var dataFilterId = cookie.DataFilterId;
            var dataFilter = dfLogic.LoadDataFilterById(dataFilterId);
            return dataFilter;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lPAcctKey"></param>
        /// <returns></returns>
        private List<int> LoadAllowedReportAccessIDs(int lPAcctKey)
        {
            List<int> result = null;

            var acclogic = new AccountLogic();
            var referenceListLogic = new ReferenceListLogic();

            var isAdminOrRiskConsultant =
                UserHelper.IsUserInRole(Constants.RoleNames.SystemAdministrator) ||
                UserHelper.IsUserInRole(Constants.RoleNames.RiskConsultant);

            if (isAdminOrRiskConsultant)
            {
                var adminReportAccess = acclogic.GetSummaryReportAccess(lPAcctKey, referenceListLogic.GetSummaryReports().Where(x => x.Active).ToList());
                result = adminReportAccess.Select(arid => arid.ID).ToList();
            }
            else
            {
                var userReportAccess = acclogic.GetUserReportIdsWithAccessList(lPAcctKey).ToList();
                result = userReportAccess.Select(urid => urid.SummaryReportType.ID).ToList();
            }

            return result;
        }

        /// <summary>
        /// Returns the value to use in the html lang tah
        /// </summary>
        /// <returns></returns>
        protected string LoadCurrentCulture()
        {
            var result = "en";
            HttpCookie langCookie = Request.Cookies[CultureHelper.LanguageCookieName];

            if (langCookie != null)
                result = langCookie.Value;

            return result;
        }

        #region Helpers
        /// <summary>
        /// Removes any integers and replaces any commas with a space from a DataTables sort expression
        /// </summary>
        /// <param name="sortExpression"></param>
        /// <returns></returns>
        protected string SanitiseSortExpression(string sortExpression)
        {
            sortExpression = Regex.Replace(sortExpression, @"\d", "").Replace(",", " ");
            return sortExpression;
        }

        #endregion
        #region Tiles (FS-02/FR-3.2/FR-3.3)

        /// <summary>
        /// Load default tile configuration details for the specified screen.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult LoadDefaultTileConfiguration(int id)
        {
            try
            {
                var userId = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true).ID;
                var cookie = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);

                var systemTilesList = LoadTileConfigurationModelsList(userId, cookie.LPAcctKey, true);

                SaveTileConfigurationToDb(systemTilesList);

                return Json(systemTilesList, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error loading default tile configuration for screen: {id}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Load system tiles configuration models
        /// If user is a 'super user' (Risk Consultant or System Admin roles) then load all tiles in system,
        /// For all others (esp Client or Intermediary) load only those tiles that they are permitted to access for the account profile 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="lpAcctKey"></param>
        /// <param name="reset"></param>
        /// <returns></returns>
        protected List<TileConfigurationModel> LoadTileConfigurationModelsList(int userId, int lpAcctKey, bool reset)
        {
            var logic = new DashboardLogic();

            var isAdminOrRiskConsultant =
                UserHelper.IsUserInRole(Constants.RoleNames.SystemAdministrator) ||
                UserHelper.IsUserInRole(Constants.RoleNames.RiskConsultant);

            if (isAdminOrRiskConsultant)
            {
                return logic.LoadUserSystemTilesForAdmin(userId, Constants.SystemScreens.Dashboard)
                                                   .Select(item => new TileConfigurationModel
                                                   {
                                                       id = item.SystemTileID,
                                                       x = !reset ? item.GridX : item.SystemTile.DefaultGridX,
                                                       y = !reset ? item.GridY : item.SystemTile.DefaultGridY,
                                                       width = !reset ? item.GridWidth : item.SystemTile.DefaultGridWidth,
                                                       height = !reset ? item.GridHeight : item.SystemTile.DefaultGridHeight,
                                                       visible = !reset ? item.Visible : item.SystemTile.DefaultVisible,
                                                       name = item.SystemTile.Name                                                      
                                                   })
                                                   .OrderBy(item => item.x)
                                                   .ThenBy(item => item.y)
                                                   .ToList();
            }
            else
            {
                var systemTilesForUserList = logic.LoadUserSystemTilesForUser(userId, Constants.SystemScreens.Dashboard).ToList();
                return logic.LoadAccountProfileSystemTilesList(lpAcctKey, Constants.SystemScreens.Dashboard, userId)
                                                .Select(item =>
                                                {
                                                    var systemTile = systemTilesForUserList.Single(stfu =>
                                                        stfu.SystemTileID == item.SystemTileID);
                                                    return new TileConfigurationModel
                                                    {
                                                        id = item.SystemTileID ?? default(int),
                                                        x = !reset ? systemTile.GridX : systemTile.SystemTile.DefaultGridX,
                                                        y = !reset ? systemTile.GridY : systemTile.SystemTile.DefaultGridY,
                                                        width = !reset ? systemTile.GridWidth : systemTile.SystemTile.DefaultGridWidth,
                                                        height = !reset ? systemTile.GridHeight : systemTile.SystemTile.DefaultGridHeight,
                                                        visible = !reset ? systemTile.Visible : systemTile.SystemTile.DefaultVisible,

                                                        name = item.SystemTile.Name                                                      
                                                    };
                                                })
                                                .OrderBy(item => item.x)
                                                .ThenBy(item => item.y)
                                                .ToList();
            }
        }

        private bool SaveTileConfigurationToDb(IEnumerable<TileConfigurationModel> tileModel)
        {
            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            int userId = UserHelper.GetCurrentlyAuthenticatedUser().ID;
            var logic = new DashboardLogic();

            try
            {
                foreach (var tile in tileModel)
                {
                    var tileUpdate = logic.LoadUserSystemTile(userId, tile.id) ?? new UserSystemTile();
                    tileUpdate.UserID = userId;
                    tileUpdate.SystemTileID = tile.id;
                    tileUpdate.GridX = tile.x;
                    tileUpdate.GridY = tile.y;
                    tileUpdate.GridWidth = tile.width;
                    tileUpdate.GridHeight = tile.height;
                    tileUpdate.Visible = tile.visible;

                    logic.UpsertUserSystemTile(tileUpdate, userId);
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        #endregion

        #region Notifications (FS-02.2/FR-3.11)

        /// <summary>
        /// 
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult TableHandler_Notifications(DTParameters param)
        {
            try
            {
                var cookie = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
                var filters = GetTableFilters(param);
                var logic = new NotificationLogic();
                var refLogic = new ReferenceListLogic();
                var useLocationNo = UseLocationNoInReport();

                var data = logic.LoadUserNotifications(filters.Paging, filters, filters.SortExpression, useLocationNo, cookie.LPAcctKey);
                var types = refLogic.GetNotificationTypes();
                var response = new DTResult<NotificationsTableModel>
                {
                    draw = param.Draw,
                    recordsFiltered = filters.Paging.TotalRecords,
                    recordsTotal = filters.Paging.TotalRecords,
                    data = data.Select(notification => new NotificationsTableModel
                    {
                        UserNotificationId = notification.UserNotificationID,
                        Date = FormatHelper.FormatDate(notification.CreatedDate),
                        Type = types.Find(item => item.ID == notification.NotificationTypeID).Description,
                        Details = notification.NotificationDescription,
                        Viewed = notification.Viewed,
                        LocationGapsOrAxaID = useLocationNo ? notification.LocationNo : notification.LocationCode,
                        RecID = notification.RecID,
                        LPAlertKey = notification.LPAlertKey,
                        InternalNotificationID = notification.InternalNotificationID,
                        FullAddress = notification.FullAddress
                    }).ToList()
                };

                return Json(response);
            }
            catch (Exception ex)
            {
                LogHelper.Error("TableHandler_Notifications : Error loading table data", ex);
                return Json(new { error = ex.Message });
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="notificationsUpdateModel"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult UpdateNotifications(NotificationsUpdateModel notificationsUpdateModel)
        {
            var cookie = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            int userId = UserHelper.GetCurrentlyAuthenticatedUser().ID;
            var logic = new NotificationLogic();

            try
            {
                var notifications = (from item in notificationsUpdateModel.UserNotificationIds
                                    select new NotificationsUpdateData
                                    {
                                        LPAlertKey = item.LPAlertKey,
                                        InternalNotificationID = item.InternalNotificationID,
                                        UserNotificationId = item.UserNotificationId
                                    }).ToList();


                var success = logic.UpdateNotifications(userId, (NotificationActionEnum)notificationsUpdateModel.NotificationAction, notifications);

                var result = new
                {
                    Notification_UnreadAlerts = logic.CountUnreadAlerts(userId, true, null, cookie.LPAcctKey),
                    Notification_UnreadNotifications = logic.CountUnreadNotifications(userId, true, null, cookie.LPAcctKey)
                };


                return Json(result);
            }
            catch (Exception ex)
            {
                LogHelper.Error("UpdateNotifications : Error persisting notifications action", ex);
                return Json(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Update the AlertsAcknowledged value in the cookie when the user acknowledges the alerts added since the previous value
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult UpdateAlertsAcknowledged()
        {
            try
            {
                var data = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
                data.AlertsAcknowledged = DateTime.UtcNow;
                MA2CookieHelper.UpdateCookie(ControllerContext, data, UIHelper.EncryptCookie);

                return Json(true);
            }
            catch (Exception ex)
            {
                LogHelper.Error("UpdateAlertsAcknowledged : Error persisting AlertsAcknowledged value", ex);
                return Json(new { error = ex.Message });
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetNotificationsForUser()
        {
            var cookie = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            int userId = UserHelper.GetCurrentlyAuthenticatedUser().ID;
            var logic = new NotificationLogic();

            try
            {
                var result = new
                {
                    Notification_UnreadAlerts = logic.CountUnreadAlerts(userId, true, null, cookie.LPAcctKey),
                    Notification_UnreadNotifications = logic.CountUnreadNotifications(userId, true, null, cookie.LPAcctKey)
                };

                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("GetNotificationsForUser : Error loading notifications", ex);
                return Json(new { error = ex.Message });
            }
        }

        public List<Select2Option> GetMonthsOfTheYear()
        {
            var months = new List<Select2Option>
            {
                new Select2Option
                {
                    id = "1",
                    text = WebPageResources.Month_January
                },
                new Select2Option
                {
                    id = "2",
                    text =  WebPageResources.Month_February
                },
                new Select2Option
                {
                    id = "3",
                    text =  WebPageResources.Month_March
                },
                new Select2Option
                {
                    id = "4",
                    text =  WebPageResources.Month_April
                },
                new Select2Option
                {
                    id = "5",
                    text =  WebPageResources.Month_May
                },
                new Select2Option
                {
                    id = "6",
                    text =  WebPageResources.Month_June
                },
                new Select2Option
                {
                    id = "7",
                    text =  WebPageResources.Month_July
                },
                new Select2Option
                {
                    id = "8",
                    text =  WebPageResources.Month_August
                },
                new Select2Option
                {
                    id = "9",
                    text =  WebPageResources.Month_September
                },
                new Select2Option
                {
                    id = "10",
                    text =  WebPageResources.Month_October
                },
                new Select2Option
                {
                    id = "11",
                    text =  WebPageResources.Month_November
                },
                new Select2Option
                {
                    id = "12",
                    text =  WebPageResources.Month_December
                }
            };

            return months;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        private NotificationFilters GetTableFilters(DTParameters param)
        {
            DTFilter[] filters = param.CustomFilters;
            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);

            var paging = new PagingInfo(param.Start, param.Length);
            var result = new NotificationFilters();

            result.UserId = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true).ID;
            result.Paging = paging;
            result.SortExpression = param.SortOrder;

            if (filters.Any(f => f.Key == "Archived"))
            {
                var val = filters.First(item => item.Key == "Archived").Value;
                if (val != null && bool.TryParse(val, out bool archived))
                    result.Archived = archived;
            }

            if (filters.Any(f => f.Key == "IsAlert"))
            {
                var val = filters.First(item => item.Key == "IsAlert").Value;
                if (val != null && bool.TryParse(val, out bool isAlert))
                    result.IsAlert = isAlert;
            }

            if (filters.Any(f => f.Key == "NotifyByDashboard"))
            {
                var val = filters.First(item => item.Key == "NotifyByDashboard").Value;
                if (val != null && bool.TryParse(val, out bool notifyByDashboard))
                    result.NotifyByDashboard = notifyByDashboard;
            }

            return result;
        }

        /// <summary>
        /// When a user switches Account or changes the Location Picker this logic is invoked. The Dahboard Hub will identify all the connections/tabs the user has open (excluding 
        /// the one which triggered this action) and notify them of a change to their configuration - to continue the user must refresh the page to pick up the changes
        /// </summary>
        /// <param name="connection">The SignalR ConnectionID of the tab triggering this action</param>
        /// <param name="accountContextID"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult NotifyAccountChange(string connection, int accountContextID)
        {
            int userId = UserHelper.GetCurrentlyAuthenticatedUser().ID;

            try
            {
                DashboardHub hub = new DashboardHub();
                hub.NotifyAccountChange(userId, Guid.Parse(connection), accountContextID);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("NotifyAccountChange : Error notifying user of Account or Location change", ex);
                return Json(new { error = ex.Message });
            }
        }

        #endregion

        #region Column Options

        /// <summary>
        /// 
        /// </summary>
        /// <param name="systemGridId"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult EditColumnOptions(int systemGridRef, bool restore)
        {
            int userId = UserHelper.GetCurrentlyAuthenticatedUser().ID;
            SystemGridLogic logic = new SystemGridLogic();
            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            try
            {
                var results = logic.LoadSystemGridForUser(systemGridRef, userId, restore, cookieData.LPAcctKey);

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error editing grid: {systemGridRef} for user: {userId}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="loadSystemGridModel"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SaveColumnOptions(UserSystemGridDTO userSystemGrid)
        {
            int userId = UserHelper.GetCurrentlyAuthenticatedUser().ID;
            SystemGridLogic logic = new SystemGridLogic();
            var result = false;
            var accountLogic = new AccountLogic();
            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            var accountId = accountLogic.GetByLpAcctKey(cookieData.LPAcctKey).ID;
            try
            {
                var groupRank = 1;
                foreach (var group in userSystemGrid.Groups)
                {
                    var objGroup = group;
                    group.UserSystemGridGroupVisible = (from item in objGroup.Fields where item.UserSystemGridFieldVisible select item).Any();

                    result = logic.SaveSystemGridGroupForUser(userSystemGrid.SystemGridSystemGridRef, group, groupRank, userId, cookieData.LPAcctKey);

                    var fieldRank = 1;
                    foreach (var field in group.Fields)
                    {
                        result = logic.SaveSystemGridFieldForUser(userSystemGrid.SystemGridSystemGridRef, field, fieldRank, userId, cookieData.LPAcctKey);
                        fieldRank++;
                    }

                    groupRank++;
                }

                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error editing grid for user: {userId}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public bool UseLocationNoInReport()
        {
            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            
            if (cookieData.LpAcctNumDispTypeKey != null && cookieData.LpAcctNumDispTypeKey != Constants.AccountNumberDisplayType.Unknown)
            {
                return cookieData.LpAcctNumDispTypeKey == Constants.AccountNumberDisplayType.UseNumber;
            }

            // If there is no preference set - look at the Client Type and follow these rules:
            //
            // 0 = AXA XL(default all new accounts to 0)
            // 1 = AXA CS Corporate Solutions
            // 2 = Legacy XL
            // 3 = AXA GI General Insurance
            // 4 = Legacy Matrix(historic, not assigned to new clients)
            //
            // Where 0, 1, 3 or 4 then Legacy AXA 
            // Else where 2 then Legacy GAPS / Newly secured GAPS

            if (cookieData?.ClientTypeId != null)
            {
                switch (cookieData.ClientTypeId)
                {
                    case Constants.ClientType.AXA_XL:
                    case Constants.ClientType.AXA_CS:
                    case Constants.ClientType.AXA_GI:
                    case Constants.ClientType.Legacy_Matrix:
                        // Don't use Location No, use Location Code instead
                        return false;
                    case Constants.ClientType.Legacy_XL:
                        // Use Location No
                        return true;
                }
            }

            // as a last resort - with No Preference set and No Client Type then we do not have any information to go on,
            // in which case return the AccountNo (GAPS Legacy ID)
            return true;
        }

        public bool UseAccountNoInReport()
        {
            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);

            if (cookieData.LpAcctNumDispTypeKey != null && cookieData.LpAcctNumDispTypeKey != Constants.AccountNumberDisplayType.Unknown)
            {
                return cookieData.LpAcctNumDispTypeKey == Constants.AccountNumberDisplayType.UseNumber;
            }

            // If there is no preference set - look at the Client Type and follow these rules:
            //
            // 0 = AXA XL(default all new accounts to 0)
            // 1 = AXA CS Corporate Solutions
            // 2 = Legacy XL
            // 3 = AXA GI General Insurance
            // 4 = Legacy Matrix(historic, not assigned to new clients)
            //
            // Where 0, 1, 3 or 4 then Legacy AXA 
            // Else where 2 then Legacy GAPS / Newly secured GAPS

            if (cookieData.ClientTypeId != null)
            {
                switch (cookieData.ClientTypeId)
                {
                    case Constants.ClientType.AXA_XL:
                    case Constants.ClientType.AXA_CS:
                    case Constants.ClientType.AXA_GI:
                    case Constants.ClientType.Legacy_Matrix:
                        // Don't use Location No, use Location Code instead
                        return false;
                    case Constants.ClientType.Legacy_XL:
                        // Use Location No
                        return true;
                }
            }

            // as a last resort - with No Preference set and No Client Type then we do not have any information to go on,
            // in which case return the AccountNo (GAPS Legacy ID)
            return true;
        }

        #endregion

        #region Partial Views (Shared)

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public PartialViewResult Contacts()
        {
            return PartialView(@"~/Views/Shared/Contacts.cshtml");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public PartialViewResult NotifyAccountChangeView()
        {
            return PartialView(@"~/Views/Shared/NotifyAccountChange.cshtml");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public PartialViewResult NotificationsModal()
        {
            return PartialView(@"~/Views/Shared/Notifications.cshtml");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public PartialViewResult DataFilterConfigWidget()
        {
            return PartialView(@"~/Views/Shared/DataFilterConfigWidget.cshtml");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public PartialViewResult GridColumnOptionsModal()
        {
            return PartialView(@"~/Views/Shared/GridColumnOptions.cshtml");
        }

        #endregion
    }
}
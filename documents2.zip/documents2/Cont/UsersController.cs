﻿using DataTables.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using System.Web.WebPages;
using Microsoft.Ajax.Utilities;
using Newtonsoft.Json;
using XLC.MyAnalysis2.DbModels;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.Logic;
using XLC.MyAnalysis2.Logic.DTO;
using XLC.MyAnalysis2.Logic.DTO.MessageQueueDTO;
using XLC.MyAnalysis2.Resources;
using XLC.MyAnalysis2.Shared;
using XLC.MyAnalysis2.Shared.ReportExport;
using XLC.MyAnalysis2.WebPortal.Helpers;
using XLC.MyAnalysis2.WebPortal.Models;
using static XLC.MyAnalysis2.DbModels.DbConstants.Constants;

namespace XLC.MyAnalysis2.WebPortal.Controllers
{
    using AutoMapper;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;
    using XLC.MyAnalysis2.WebPortal.Hubs;

    public class UsersController : BaseController
    {
        private string UserName;

        private DashboardHub _dashboardHub;

        public UsersController()
        {
            this.UserName = UserHelper.GetCurrentlyAuthenticatedUser()?.EdsCn;
            _dashboardHub = new DashboardHub();
        }
        // GET: Users
        [Authorize(Roles = "System Administrator,Risk Consultant")]
        public ActionResult Index(string EdsCn)
        {
            var model = new UsersFiltersViewModel();

            LoadReferenceLists(model);

            return View(model);
        }

        // GET: Users
        public ActionResult UserProfile()
        {
            var logic = new UserLogic();
            var accountLogic = new AccountLogic();
            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);

            ViewAccount currentSelectedAccount = accountLogic.GetAccount(cookieData.LPAcctKey);
            var notificationLogic = new UserNotificationTypeLogic();



            var data = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: false);

            bool isAdminOrRiskConsultant = UserHelper.IsUserInRole(Constants.RoleNames.SystemAdministrator) || UserHelper.IsUserInRole(Constants.RoleNames.RiskConsultant);

            var userNotificationTypes = notificationLogic.GetUserNotificationTypesById(data.ID, isAdmin: isAdminOrRiskConsultant);
            var userNotificationTypeModels = UserNotificationTypeDbModelToModel(userNotificationTypes);
            var alerts = SortAlertsAndNotifications(userNotificationTypeModels);

            var userAccountProfile = logic.GetUserAccountProfileRecordForUser(userId: data.ID, lpAcctKey: cookieData.LPAcctKey);

            userNotificationTypeModels = userNotificationTypeModels.Except(alerts).ToList();

            var model = new UsersProfileViewModel
            {
                Email = data.Email,
                Language = data.Language.Name,
                Title = (data.UserTitle != null) ? data.UserTitle.Name : "",
                FirstName = data.ForeName,
                MiddleName = data.MiddleName,
                LastName = data.Surname,
                JobTitle = data.JobTitle,
                TelephoneNo = data.PhoneNumber,
                MobileNo = data.Mobile,
                EdsCn = data.EdsCn,
                LanguageId = data.LanguageID,
                UserNotificationPreferences = userNotificationTypeModels,
                UserAlertPreferences = alerts,
                InternalUser = data.InternalUser,
                IsAdminOrRiskConsultant = isAdminOrRiskConsultant,
                UserAccountClientTypeID = currentSelectedAccount.ClientTypeID,
                UseAccountNo = userAccountProfile.UseAccountNo,
                UseLocationNo = userAccountProfile.UseLocationNo,
                GlobalAsAtDateDay = userAccountProfile.GlobalAsAtDateDay,
                GlobalAsAtDateMonth = userAccountProfile.GlobalAsAtDateMonth,
                GlobalAsAtDateYear = userAccountProfile.GlobalAsAtDateYear
            };

            LoadProfileReferenceLists(model);

            return View(model);
        }

        [Authorize(Roles = "System Administrator,Risk Consultant")]
        public ActionResult Edit(string EDS_CN)
        {
            var userLogic = new UserLogic();
            var refLogic = new ReferenceListLogic();

            var data = userLogic.GetMergedUserByEdsCn(EDS_CN);

            if (data == null)
                throw new Exception($"User {EDS_CN} does not exist.");

            var model = DbModelToViewModel(data);

            string MapDocumentTypeToolTip(int documentTypeId, string documentTypeName)
            {
                switch (documentTypeId)
                {
                    case (int)Constants.DocumentType.AccountOther:
                        return WebPageResources.Documents_Tooltip_AccountOther;
                    case (int)Constants.DocumentType.DivisionOther:
                        return WebPageResources.Documents_Tooltip_DivisionOther;
                    case (int)Constants.DocumentType.LocationOther:
                        return WebPageResources.Documents_Tooltip_LocationOther;
                    case (int)Constants.DocumentType.Internal:
                        return WebPageResources.Documents_Tooltip_Internal;
                    default:
                        return documentTypeName;
                }
            }

            bool GetInitialDocumentAccessForUser(UserMerged user, DbModels.DocumentType dt, UserDocumentAccess uda)
            {
                // for new members, set up access to only Basic Documents Package documents by default
                if (user.UserStatusID == UserStatus.Pending)
                    return dt.IsMemberOfBasicPackage;

                return uda != null;
            }

            model.DocumentPermissions = (from d in userLogic.GetAllDocuments()
                                         join up in data.UserDocumentAccesses on d.ID equals up.DocumentTypeID into ps
                                         from up in ps.DefaultIfEmpty()
                                         where d.Active
                                         select new UserViewModel.DocumentPermissionModel
                                         {
                                             ID = d.ID,
                                             DocumentName = d.Name,
                                             HasAccess = GetInitialDocumentAccessForUser(data, d, up),
                                             AllowUserAccess = (!d.InternalOnly || UserHelper.SpecifiedUserIsInternalUser(data)),
                                             IsMemberOfBasicPackage = d.IsMemberOfBasicPackage,
                                             DocumentTypeID = d.ID,
                                             DocumentTypeGroupID = d.DocumentTypeGroupID,
                                             Rank = d.Rank,
                                             Tooltip = MapDocumentTypeToolTip(d.ID, d.Name),
                                             InternalOnly = d.InternalOnly
                                         }).ToList();

            var documentGroupTypes = refLogic.GetDocumentTypeGroups();

            model.AvailableDocumentTypeGroups = new List<UserViewModel.DocumentTypeGroupPermissionModel>();

            foreach (var dgt in documentGroupTypes)
            {
                model.AvailableDocumentTypeGroups.Add(new UserViewModel.DocumentTypeGroupPermissionModel
                {
                    ID = dgt.ID,
                    Name = dgt.Name,
                    DocumentTypePermissions = model.DocumentPermissions.Where(x => x.DocumentTypeGroupID == dgt.ID).OrderBy(y => y.Rank).ToList()
                });
            }

            var accountLogic = new AccountLogic();
            var allAccountsList = accountLogic.GetAccounts();
            var standardAccount = new List<UserPermissionNode> {  new UserPermissionNode {  Id = 0,
                                        IsIP = false,
                                        IsNAP = false,
                                        LpAcctKey = 0,
                                        Name = "Standard Account",
                                        AccountNameWithCode = "Standard Account ( " + accountLogic.GetAccounts().Where(x=>x.IsRestrict==false).Count() + " ) ",
                                        Modified = false,
                                        InclusionStatus = InclusionStatus.StandardAccount,
                                       UserAccountAccessStartDate = DateTime.Now,
                                       UserAccountAccessExpiryDate = DateTime.Now.AddYears(2) } };

            if (data.AccountAccessAll)
            {
                HashSet<int> diffids = new HashSet<int>(allAccountsList.Where(x => x.IsRestrict == false).Select(x => x.LpAcctKey));
                data.UserAccountLevelAccesses = data.UserAccountLevelAccesses.Where(m => !diffids.Contains(m.LpAcctKey)).ToList();
            }
            else
            {
                data.UserAccountLevelAccesses = data.UserAccountLevelAccesses.Where(m => !m.StandardAccess).ToList();

            }

            model.AccountDivisionLocationSelectionModel = new AccountDivisionLocationSelectionModel
            {
                UserIsInternalUser = UserHelper.SpecifiedUserIsInternalUser(data),
                AllAccountsToBeIncluded = data.AccountAccessAll,
                AllIPAccountsToBeIncluded = data.AccountAccessIp,
                AllNAPAccountsToBeIncluded = data.AccountAccessNap,
                StandardAccount = standardAccount.ToList(),

                AccountNodes = allAccountsList
                                    .Where(acc => (data.UserAccountLevelAccesses.Any(uala => uala.LpAcctKey == acc.LpAcctKey)))
                                    .Select(acc => new UserPermissionNode
                                    {
                                        Id = acc.ID,
                                        IsIP = acc.Ip,
                                        IsNAP = acc.Nap,
                                        LpAcctKey = acc.LpAcctKey,
                                        Name = acc.Name,
                                        AccountNameWithCode = acc.Name + " ( " + acc.AccountNo + " , " + acc.AccountCode + " ) ",
                                        Modified = false,
                                        InclusionStatus = data.AccountAccessAll ? InclusionStatus.StandardAccount : data.UserAccountLevelAccesses.Single(x => x.LpAcctKey == acc.LpAcctKey).ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded : InclusionStatus.PartiallyIncluded,
                                        UserAccountAccessStartDate = DateTime.SpecifyKind(data.UserAccountLevelAccesses.Single(x => x.LpAcctKey == acc.LpAcctKey).UserAccountAccessStartDate ?? DateTime.MinValue, DateTimeKind.Utc),
                                        UserAccountAccessExpiryDate = DateTime.SpecifyKind(data.UserAccountLevelAccesses.Single(x => x.LpAcctKey == acc.LpAcctKey).UserAccountAccessExpiryDate ?? DateTime.MinValue, DateTimeKind.Utc)
                                    }).ToList()
            };

            if (model.AccountDivisionLocationSelectionModel.AllAccountsToBeIncluded)
            {
                model.AccountDivisionLocationSelectionModel.StandardAccount.AddRange(model.AccountDivisionLocationSelectionModel.AccountNodes);
                model.AccountDivisionLocationSelectionModel.AccountNodes.AddRange(standardAccount);
            }
            bool isAdminRecord = data.UserRoles.Any(x => x.Role.Name == RoleNames.SystemAdministrator);
            bool canEditRecord = false;

            if (isAdminRecord && UserHelper.IsUserInRole(RoleNames.SystemAdministrator))
            {
                canEditRecord = true;
            }
            else if (!isAdminRecord)
            {
                canEditRecord = true;
            }

            model.isAdminUser = canEditRecord;
            model.UserIsAdmin = UserHelper.IsUserInRole(RoleNames.SystemAdministrator);
            model.Translator = data.Translator;


            model.SelfAccess = false;
            if (this.UserName == EDS_CN)
            {
                model.SelfAccess = true;
            }
            return View(model);
        }


        [HttpPost]
        public JsonResult LoadAllChildNodesForAccount(UserPermissionNode selectedAccountNode)
        {

            var accountLogic = new AccountLogic();
            var locationLogic = new LocationLogic("");
            var userLogic = new UserLogic();
            var selectedAccount = accountLogic.GetByLpAcctKey(selectedAccountNode.LpAcctKey);

            var targetUser = userLogic.GetMergedUserByEdsCn(selectedAccountNode.UserEdsCn);



            var useLocationNo = UseLocationNoInReport();

            var selectedAccountPermission = userLogic.GetAccountLevelAccessForUser(targetUser.ID, selectedAccount.LpAcctKey);

            // 1. Load Division Child Records
            // The Inclusion Status logic looks more intricate than it actually is - pseudo logic below:
            //
            //   IF EXISTS UserAccountLevelAccessRecord 
            //
            //           IF UserAccountLevelAccessRecord.ForceAllChildrenIncluded 
            //
            //               InclusionStatus = FullyIncluded
            //
            //           ELSE
            //
            //               IF EXISTS UserDivisionLevelAccessRecord 
            //
            //                   IF UserDivisionLevelAccessRecord.ForceAllChildrenIncluded
            //                       InclusionStatus = FullyIncluded
            //                   ELSE
            //                       InclusionStatus = PartiallyIncluded
            //
            //               ELSE
            //                   InclusionStatus = Excluded
            //    ELSE
            //             InclusionStatus = Excluded
            //
            List<UserPermissionNode> allDivisionsForAccount = userLogic
                .GetDivisionsForAccount(selectedAccount.ID).Select(
                    div => new UserPermissionNode
                    {
                        Id = div.ID,
                        Name = div.Name,
                        LpAcctKey = selectedAccount.LpAcctKey,
                        LpAcctWebDivKey = div.LpAcctWebDivKey,
                        AccountNameWithCode = selectedAccount.Name + "( " + selectedAccount.AccountNo + " , " + selectedAccount.AccountCode + " )",
                        NodeType = NodeType.Division,
                        InclusionStatus = //selectedAccountNode.InclusionStatus == InclusionStatus.FullyIncluded ? InclusionStatus.FullyIncluded :
                            selectedAccountPermission != null ?
                                selectedAccountPermission.ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded :
                                userLogic.GetDivisionLevelAccessForUser(targetUser.ID, div.LpAcctWebDivKey) != null ?
                                    userLogic.GetDivisionLevelAccessForUser(targetUser.ID, div.LpAcctWebDivKey).ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded : InclusionStatus.PartiallyIncluded
                                    : InclusionStatus.Excluded :
                                InclusionStatus.Excluded
                    }).ToList();


            foreach (var divisionNode in allDivisionsForAccount)
            {
                if (divisionNode.LpAcctWebDivKey != null)
                {
                    var divisionLocations =
                        locationLogic
                            .GetLocationsByDivisionId(divisionNode.LpAcctWebDivKey.Value).Select(
                                loc =>
                                    new UserPermissionNode
                                    {
                                        Id = loc.ID,
                                        Name = loc.Name,
                                        AccountNameWithCode = selectedAccount.Name + " ( " + selectedAccount.AccountNo + " , " + selectedAccount.AccountCode + " ) ",
                                        LocationNo = useLocationNo ? loc.LocationNo : loc.LocationCode,
                                        ClientLocationNo = loc.ClientLocationNo,
                                        City = loc.City,
                                        State = loc.State,
                                        Country = loc.Country,
                                        NodeType = NodeType.Location,
                                        LpAcctKey = loc.LpAcctKey,
                                        LpAllPiKey = loc.LpAllPiKey,
                                        ExtendedNodeDescription = FormatHelper.ConvertLineAddressesToStreetAddressWithHTMLBreakElements(loc.AddressLine1, loc.AddressLine2, loc.AddressLine3, false),
                                        ParentDescription = divisionNode.Name,
                                        InclusionStatus = //selectedAccountNode.InclusionStatus == InclusionStatus.FullyIncluded ? InclusionStatus.FullyIncluded :
                                            selectedAccountPermission != null ? selectedAccountPermission.ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded :
                                            divisionNode.InclusionStatus == InclusionStatus.FullyIncluded ? InclusionStatus.FullyIncluded :
                                                (userLogic.UserHasAccessToLocationThroughParentDivision(loc.LpAllPiKey, targetUser.ID, divisionNode.LpAcctWebDivKey.Value) ? InclusionStatus.FullyIncluded : InclusionStatus.Excluded) : InclusionStatus.Excluded
                                    }).ToList();

                    var divisionSubDivisions = locationLogic.GetSubDivisionsByDivisionId(divisionNode.Id).Select(
                        sub => new UserPermissionNode
                        {
                            Id = sub.ID,
                            Name = sub.Name,
                            AccountNameWithCode = selectedAccount.Name + " ( " + selectedAccount.AccountNo + " , " + selectedAccount.AccountCode + " ) ",
                            LpAcctKey = sub.LpAcctKey,
                            NodeType = NodeType.SubDivision,
                            LpSubDivKey = sub.LpSubDivKey,
                            LpAcctWebDivKey = sub.LpDivKey,
                            InclusionStatus =
                                selectedAccountPermission != null ? //selectedAccountPermission.ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded :
                                    divisionNode.InclusionStatus == InclusionStatus.FullyIncluded ? InclusionStatus.FullyIncluded :
                                        userLogic.GetSubDivisionLevelAccessesForUser(targetUser.ID) != null ?
                                            userLogic.GetSubDivisionLevelAccessForUser(targetUser.ID, sub.LpSubDivKey) != null ?
                                            userLogic.GetSubDivisionLevelAccessForUser(targetUser.ID, sub.LpSubDivKey).ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded : InclusionStatus.PartiallyIncluded
                                                : InclusionStatus.Excluded : InclusionStatus.Excluded :
                                    InclusionStatus.Excluded
                        }).ToList();

                    foreach (var subDivisionNode in divisionSubDivisions)
                    {
                        if (subDivisionNode.LpSubDivKey != null)
                        {
                            var subDivisionLocations = locationLogic.GetLocationsBySubDivisionLp(subDivisionNode.LpSubDivKey.Value).Select(loc => new UserPermissionNode
                            {
                                Id = loc.ID,
                                Name = loc.Name,
                                AccountNameWithCode = selectedAccount.Name + " ( " + selectedAccount.AccountNo + " , " + selectedAccount.AccountCode + " ) ",
                                LocationNo = UseLocationNoInReport() ? loc.LocationNo : loc.LocationCode,
                                ClientLocationNo = loc.ClientLocationNo,
                                City = loc.City,
                                State = loc.State,
                                Country = loc.Country,
                                NodeType = NodeType.Location,
                                LpAcctKey = loc.LpAcctKey,
                                LpAllPiKey = loc.LpAllPiKey,
                                ExtendedNodeDescription = FormatHelper.ConvertLineAddressesToStreetAddressWithHTMLBreakElements(loc.AddressLine1, loc.AddressLine2, loc.AddressLine3, false),
                                ParentDescription = $"{divisionNode.Name} - {subDivisionNode.Name}",
                                InclusionStatus =
                                    selectedAccountPermission != null ? selectedAccountPermission.ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded :
                                        divisionNode.InclusionStatus == InclusionStatus.FullyIncluded ? InclusionStatus.FullyIncluded :
                                        (userLogic.UserHasAccessToLocationThroughParentSubDivision(loc.LpAllPiKey, targetUser.ID, subDivisionNode.LpSubDivKey.Value) ? InclusionStatus.FullyIncluded : InclusionStatus.Excluded) : InclusionStatus.Excluded

                            }).ToList();


                            subDivisionNode.Children = subDivisionLocations;
                        }

                    }

                    divisionNode.Children = divisionLocations.Concat(divisionSubDivisions).ToList();
                    //divisionNode.Children = divisionNode.Children;
                }
            }


            List<UserPermissionNode> allRegionsForAccount = userLogic.GetRegionsForAccount(selectedAccount.ID).Select(
                x => new UserPermissionNode
                {
                    Id = x.ID,
                    Name = x.Name,
                    AccountNameWithCode = selectedAccount.Name + " ( " + selectedAccount.AccountNo + " , " + selectedAccount.AccountCode + " ) ",
                    LpAcctKey = selectedAccount.LpAcctKey,
                    LpAcctDivGroupKey = x.LpAcctDivGroupKey,
                    NodeType = NodeType.Region,
                    InclusionStatus =
                        selectedAccountPermission != null ?
                            selectedAccountPermission.ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded :
                                userLogic.GetRegionLevelAccessForUser(targetUser.ID, x.LpAcctDivGroupKey) != null ?
                                    userLogic.GetRegionLevelAccessForUser(targetUser.ID, x.LpAcctDivGroupKey).ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded : InclusionStatus.PartiallyIncluded
                                    : InclusionStatus.Excluded :
                            InclusionStatus.Excluded
                }).ToList();

            foreach (var regionNode in allRegionsForAccount)
            {
                if (regionNode.LpAcctDivGroupKey != null)
                {
                    var regionLocations = locationLogic
                        .GetLocationsByLpAcctDivGroupKey(regionNode.LpAcctDivGroupKey.Value).Select(
                            loc => new UserPermissionNode
                            {
                                Id = loc.ID,
                                Name = loc.Location.Name,
                                AccountNameWithCode = selectedAccount.Name + " ( " + selectedAccount.AccountNo + " , " + selectedAccount.AccountCode + " ) ",
                                LocationNo = useLocationNo ? loc.Location.LocationNo : loc.Location.LocationCode,
                                ClientLocationNo = loc.Location.ClientLocationNo,
                                City = loc.Location.City,
                                State = loc.Location.State,
                                Country = loc.Location.Country,
                                NodeType = NodeType.Location,
                                LpAcctKey = loc.Location.LpAcctKey,
                                LpAllPiKey = loc.LpAllPiKey,
                                ExtendedNodeDescription = FormatHelper.ConvertLineAddressesToStreetAddressWithHTMLBreakElements(loc.Location?.AddressLine1, loc.Location?.AddressLine2, loc.Location?.AddressLine3, false),
                                ParentDescription = regionNode.Name,
                                InclusionStatus =
                                    regionNode.InclusionStatus == InclusionStatus.FullyIncluded ? InclusionStatus.FullyIncluded :
                                           (userLogic.UserHasAccessToLocationThroughParentRegion(loc.LpAllPiKey, targetUser.ID, regionNode.LpAcctDivGroupKey.Value) ? InclusionStatus.FullyIncluded : InclusionStatus.Excluded)
                            }).ToList();
                    regionNode.Children = regionLocations;
                }
            }



            List<UserPermissionNode> allClassificationsForAccount = userLogic.GetClassificationsForAccount(selectedAccount.ID).Select(
                x => new UserPermissionNode
                {
                    Id = x.ID,
                    Name = x.Name,
                    AccountNameWithCode = selectedAccount.Name + " ( " + selectedAccount.AccountNo + " , " + selectedAccount.AccountCode + " ) ",
                    LpAcctKey = selectedAccount.LpAcctKey,
                    LpAcctDivGroupKey = x.LpAcctDivGroupKey,
                    NodeType = NodeType.Classification,
                    InclusionStatus =
                        selectedAccountPermission != null ?
                            selectedAccountPermission.ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded :
                                userLogic.GetClassificationLevelAccessForUser(targetUser.ID, x.LpAcctDivGroupKey) != null ?
                                    userLogic.GetClassificationLevelAccessForUser(targetUser.ID, x.LpAcctDivGroupKey).ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded : InclusionStatus.PartiallyIncluded
                                    : InclusionStatus.Excluded :
                            InclusionStatus.Excluded
                }).ToList();

            foreach (var userPermissionNode in allClassificationsForAccount)
            {
                if (userPermissionNode.LpAcctDivGroupKey != null)
                {
                    var classificationLocations = locationLogic
                        .GetLocationsByLpAcctDivGroupKey(userPermissionNode.LpAcctDivGroupKey.Value).Select(
                            loc => new UserPermissionNode
                            {
                                Id = loc.ID,
                                Name = loc.Location.Name,
                                AccountNameWithCode = selectedAccount.Name + " ( " + selectedAccount.AccountNo + " ,  " + selectedAccount.AccountCode + " ) ",
                                LocationNo = useLocationNo ? loc.Location.LocationNo : loc.Location.LocationCode,
                                ClientLocationNo = loc.Location.ClientLocationNo,
                                City = loc.Location.City,
                                State = loc.Location.State,
                                Country = loc.Location.Country,
                                NodeType = NodeType.Location,
                                LpAcctKey = loc.Location.LpAcctKey,
                                LpAllPiKey = loc.LpAllPiKey,
                                ExtendedNodeDescription = FormatHelper.ConvertLineAddressesToStreetAddressWithHTMLBreakElements(loc.Location?.AddressLine1, loc.Location?.AddressLine2, loc.Location?.AddressLine3, false),
                                ParentDescription = userPermissionNode.Name,
                                InclusionStatus =
                                    userPermissionNode.InclusionStatus == InclusionStatus.FullyIncluded ? InclusionStatus.FullyIncluded :
                                        (userLogic.UserHasAccessToLocationThroughParentClassification(loc.LpAllPiKey, targetUser.ID, userPermissionNode.LpAcctDivGroupKey.Value) ? InclusionStatus.FullyIncluded : InclusionStatus.Excluded)

                            }).ToList();
                    userPermissionNode.Children = classificationLocations;
                }
            }


            List<UserPermissionNode> allOtherProvidersForAccount = userLogic.GetOtherProvidersForAccount(selectedAccount.ID).Select(
                x => new UserPermissionNode
                {
                    Id = x.ID,
                    Name = x.Name,
                    AccountNameWithCode = selectedAccount.Name + " ( " + selectedAccount.AccountNo + " , " + selectedAccount.AccountCode + " ) ",
                    LpAcctKey = selectedAccount.LpAcctKey,
                    LpAcctDivGroupKey = x.LpAcctDivGroupKey,
                    NodeType = NodeType.OtherProvider,
                    InclusionStatus =
                        selectedAccountPermission != null ?
                            selectedAccountPermission.ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded :
                                userLogic.GetOtherProviderLevelAccessForUser(targetUser.ID, x.LpAcctDivGroupKey) != null ?
                                    userLogic.GetOtherProviderLevelAccessForUser(targetUser.ID, x.LpAcctDivGroupKey).ForceAllChildrenIncluded ? InclusionStatus.FullyIncluded : InclusionStatus.PartiallyIncluded
                                    : InclusionStatus.Excluded :
                            InclusionStatus.Excluded
                }).ToList();

            foreach (var userPermissionNode in allOtherProvidersForAccount)
            {
                if (userPermissionNode.LpAcctDivGroupKey != null)
                {
                    var otherProviderLocations = locationLogic
                        .GetLocationsByLpAcctDivGroupKey(userPermissionNode.LpAcctDivGroupKey.Value).Select(
                            loc => new UserPermissionNode
                            {
                                Id = loc.ID,
                                Name = loc.Location.Name,
                                AccountNameWithCode = selectedAccount.Name + " ( " + selectedAccount.AccountNo + " , " + selectedAccount.AccountCode + " ) ",
                                LocationNo = useLocationNo ? loc.Location.LocationNo : loc.Location.LocationCode,
                                ClientLocationNo = loc.Location.ClientLocationNo,
                                City = loc.Location.City,
                                State = loc.Location.State,
                                Country = loc.Location.Country,
                                NodeType = NodeType.Location,
                                LpAcctKey = loc.Location.LpAcctKey,
                                LpAllPiKey = loc.LpAllPiKey,
                                ExtendedNodeDescription = FormatHelper.ConvertLineAddressesToStreetAddressWithHTMLBreakElements(loc.Location?.AddressLine1, loc.Location?.AddressLine2, loc.Location?.AddressLine3, false)
                                                          + $" {WebPageResources.UserPermissions_Parent} : {userPermissionNode.Name}",
                                ParentDescription = userPermissionNode.Name,
                                InclusionStatus =
                                    userPermissionNode.InclusionStatus == InclusionStatus.FullyIncluded ? InclusionStatus.FullyIncluded :
                                        (userLogic.UserHasAccessToLocationThroughParentOtherProvider(loc.LpAllPiKey, targetUser.ID, userPermissionNode.LpAcctDivGroupKey.Value) ? InclusionStatus.FullyIncluded : InclusionStatus.Excluded)

                            }).ToList();
                    userPermissionNode.Children = otherProviderLocations;
                }
            }


            var allChildrenAndGrandChildren = allDivisionsForAccount.Concat(allRegionsForAccount).Concat(allClassificationsForAccount).Concat(allOtherProvidersForAccount);

            var list = JsonConvert.SerializeObject(allChildrenAndGrandChildren.ToList(), Formatting.None, new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore });
            return Json(list, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetAccountsList()
        {
            try
            {
                var accountLogic = new AccountLogic();

                var results = accountLogic.GetAccounts()
                    .Select(acc => new UserPermissionNode
                    {
                        Id = acc.ID,
                        Name = acc.Name,
                        AccountNameWithCode = acc.Name + " ( " + acc.AccountNo + " , " + acc.AccountCode + " ) ",
                        IsIP = acc.Ip,
                        IsNAP = acc.Nap,
                        LpAcctKey = acc.LpAcctKey,
                        InclusionStatus = InclusionStatus.FullyIncluded,
                        Children = new List<UserPermissionNode>()

                    }).ToList();

                //return Json(results, JsonRequestBehavior.AllowGet);

                var jsonResult = Json(results, JsonRequestBehavior.AllowGet);
                jsonResult.MaxJsonLength = int.MaxValue;
                return jsonResult;

            }
            catch (Exception ex)
            {
                LogHelper.Error("Error loading Accounts", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetDivisionsForAccount(int accountId)
        {
            try
            {
                var logic = new UserLogic();

                var results = logic.GetDivisionsForAccount(accountId)
                    .Select(div => new UserPermissionNode
                    {
                        Id = div.ID,
                        Name = div.Name,
                        LpAcctWebDivKey = div.LpAcctWebDivKey
                    }).ToList();

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error loading Divisions for Account {accountId}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetRegionsForAccount(int accountId)
        {
            try
            {
                var logic = new UserLogic();

                var results = logic.GetRegionsForAccount(accountId)
                    .Select(x => new UserPermissionNode
                    {
                        Id = x.ID,
                        Name = x.Name,
                        LpAcctDivGroupKey = x.LpAcctDivGroupKey,
                        LpAcctKey = x.LpAcctKey
                    }).ToList();

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error loading Regions for Account {accountId}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetClassificationsForAccount(int accountId)
        {
            try
            {
                var logic = new UserLogic();

                var results = logic.GetClassificationsForAccount(accountId)
                    .Select(x => new UserPermissionNode
                    {
                        Id = x.ID,
                        Name = x.Name,
                        LpAcctDivGroupKey = x.LpAcctDivGroupKey
                    }).ToList();

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error loading Regions for Account {accountId}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetOtherProvidersForAccount(int accountId)
        {
            try
            {
                var logic = new UserLogic();

                var results = logic.GetOtherProvidersForAccount(accountId)
                    .Select(x => new UserPermissionNode
                    {
                        Id = x.ID,
                        Name = x.Name,
                        LpAcctDivGroupKey = x.LpAcctDivGroupKey
                    }).ToList();

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error loading Regions for Account {accountId}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Used when adding a new Account via the Users Edit admin panel
        /// Returns an array of one Account object
        /// </summary>
        /// <param name="LpAcctKey"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetAccountByLpAcctKey(int LpAcctKey, int userId, bool type)
        {
            try
            {
                var logic = new AccountLogic();
                var userLogic = new UserLogic();

                var account = logic.GetAccount(LpAcctKey);
                var selectedAccountPermission = userLogic.GetAccountLevelAccessForUser(userId, LpAcctKey);

                if (type)
                {
                    if (logic.GetByLpAcctKey(LpAcctKey).IsRestrict == false)
                        return Json(new { error = "User already has access to this account  " + account.AccountName + " ( " + account.LpAcctNum + " , " + account.LpAcctCode + " )" }, JsonRequestBehavior.AllowGet);

                }
                var result = new List<UserPermissionNode>
                {
                    new UserPermissionNode
                    {
                        Id = account.AccountID,
                        Name = account.AccountName,
                        LpAcctKey = account.LpAcctKey,
                        Modified = true,
                        NewlyAdded = true,
                        InclusionStatus = type? InclusionStatus.StandardAccount: InclusionStatus.FullyIncluded,
                        UserAccountAccessStartDate = selectedAccountPermission?.UserAccountAccessStartDate ??  DateTime.Now,
                        UserAccountAccessExpiryDate = selectedAccountPermission?.UserAccountAccessExpiryDate ?? DateTime.Now.AddYears(2),
                        AccountNameWithCode = account.AccountName + " ( " + account.LpAcctNum + " , " + account.LpAcctCode + " ) ",
                    }
                }.ToList();

                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error loading details for Account with LpAcctKey {LpAcctKey}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetSubDivisionsForDivision(int divisionId)
        {
            try
            {
                var logic = new UserLogic();

                var results = logic.GetSubDivisionsForDivision(divisionId)
                    .Select(subdiv => new UserPermissionNode
                    {
                        Id = subdiv.ID,
                        Name = subdiv.Name,
                        //AccountNameWithCode = subdiv.Account.Name + " ( " + subdiv.Account.AccountNo + " , " + subdiv.Account.AccountCode + " ) ",
                        LpSubDivKey = subdiv.LpSubDivKey
                    }).ToList();

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Error loading SubDivisions for Division {divisionId}", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "System Administrator,Risk Consultant")]
        public ActionResult UtilizationReport(UserReportCriteriaModel criteria)
        {
            var model = new UtilizationReportViewModel();
            model.FilterCriteria = criteria;
            return View(model);
        }

        [Authorize(Roles = "System Administrator,Risk Consultant")]
        public ActionResult SecurityReport(UserReportCriteriaModel criteria)
        {
            var model = new SecurityReportViewModel();
            model.FilterCriteria = criteria;
            return View(model);
        }

        private static UsersFilters MapUsersFilters(UserReportCriteriaModel criteria)
        {
            return new UsersFilters
            {
                AccountsFilter = (criteria.AccountIDs != null) ? criteria.AccountIDs.ToList() : new List<int>(),
                DivisionsFilter = (criteria.DivisionIDs != null) ? criteria.DivisionIDs.ToList() : new List<int>(),
                SubDivisionsFilter = (criteria.SubDivisionIDs != null) ? criteria.SubDivisionIDs.ToList() : new List<int>(),
                LocationsFilter = (criteria.LocationIDs != null) ? criteria.LocationIDs.ToList() : new List<int>(),
                RoleIDFilter = (criteria.RoleID) != null ? criteria.RoleID.ToList() : new List<int>(),
                LastNameFilter = (criteria.LocationIDs != null) ? criteria.LastName : String.Empty
            };
        }
        [Authorize(Roles = "System Administrator,Risk Consultant")]
        [HttpPost]
        public JsonResult Save(UserViewModel model)
        {
            try
            {
                var initPreferences = (model.UserStatusID == UserStatus.Pending);

                var logic = new UserLogic(this.UserName);
                var userModel = ViewModelToDbModel(model);

                var updater = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true);
                bool isAdminRecord = updater.UserRoles.Any(x => x.Role.Name == RoleNames.SystemAdministrator);

                bool roleUnchanged = updater.UserRoles.Any(x => x.RoleID == model.SelectedRoleID);

                if (this.UserName == model.EdsCn || model.SelectedRoleID == Constants.Roles.Client || model.SelectedRoleID == Constants.Roles.Intermediary)
                    userModel.Translator = false;

                // do not allow a user to promote/demote their own role
                if (updater.ID == model.Id && !roleUnchanged)
                    return Json(model);

                // do not allow non-sysadmins to promote any accounts to a sysadmin role
                // (i.e. only sysadmins can promote others to sysadmin)
                if (!isAdminRecord && model.SelectedRoleID == Constants.Roles.SystemAdministrator)
                    return Json(model);

                if (!userModel.AccountAccessAll)
                {
                    userModel.UserAccountLevelAccesses = userModel.UserAccountLevelAccesses.Where(m => !m.StandardAccess).ToList();
                }
                else
                {
                    userModel.UserAccountLevelAccesses = userModel.UserAccountLevelAccesses.Where(m => m.StandardAccess).ToList();
                }

                userModel.UserStatusID = Constants.UserStatus.Active;  //ensure that status is not Pending when user saved
                User updatedEntity = logic.UpsertUser(userModel, updater.ID);

                UserMerged data = logic.GetMergedUserByEdsCn(updatedEntity.EdsCn);
                if (data == null)
                    throw new Exception($"User {updatedEntity.EdsCn} does not exist.");

                var updatedModel = DbModelToViewModel(data);

                //create User Notification/Alert preferences, and UserSystemTile records once a role is assigned.
                if (initPreferences)
                {
                    var userNotificationLogic = new UserNotificationTypeLogic();
                    if (updatedModel.SelectedRoleID != null)
                    {
                        var roleId = updatedModel.SelectedRoleID.GetValueOrDefault();

                        userNotificationLogic.InitialiseUserNotificationPreferences(updatedModel.Id, roleId);
                    }

                    var dashboardLogic = new DashboardLogic();

                    dashboardLogic.InitialiseSystemTilesForNewUser(updatedEntity.ID, SystemScreens.Dashboard);
                }

                // notify users of change
                _dashboardHub.UserSaveChange(updatedEntity.ID);

                return Json(updatedModel);
            }
            catch (Exception ex)
            {
                LogHelper.Error(RequestHelpers.GetRequestInfo(HttpContext), ex);
                return Json(new { error = ex.Message, JsonRequestBehavior.AllowGet });
            }
        }


        [HttpPost]
        public JsonResult SaveNotificationPreferences(UsersProfileViewModel model)
        {
            var logic = new UserNotificationTypeLogic();

            //set new FrequencyID based on the users selection.
            foreach (var notification in model.UserNotificationPreferences)
            {
                notification.FrequencyId = notification.SelectedFrequency;
            }

            if (model.UserAlertPreferences != null)
            {
                var updatedUserAlerts = UserNotificationTypeModelToDbModel(model.UserAlertPreferences);

                logic.UpsertUserNotifications(updatedUserAlerts, updatedUserAlerts.First().UserID);
                model.UserAlertPreferences = UserNotificationTypeDbModelToModel(updatedUserAlerts);
            }

            if (model.UserNotificationPreferences != null)
            {
                var updatedUserNotifications = UserNotificationTypeModelToDbModel(model.UserNotificationPreferences);

                logic.UpsertUserNotifications(updatedUserNotifications, updatedUserNotifications.First().UserID);
                model.UserNotificationPreferences = UserNotificationTypeDbModelToModel(updatedUserNotifications);
            }

            return Json(model);
        }

        [HttpPost]
        public async Task<JsonResult> SaveUserAccountProfile(UsersProfileViewModel model)
        {
            var logic = new UserLogic();

            var entity = UsersProfileViewModelToModel(model);

            var upsertedEntity = await logic.UpsertUserAccountProfileAsync(entity);

            return Json(model);
        }

        [HttpPost]
        public JsonResult TableHandler_SecurityExport(DTParameters param)
        {
            try
            {
                var userLogic = new UserLogic();
                var user = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true);

                var userExports = userLogic.GetUserSecurityExports(user.ID);

                var response = new DTResult<MyExportsTableModel>
                {
                    draw = param.Draw,
                    recordsFiltered = userExports.Count,
                    recordsTotal = userExports.Count,
                    data = userExports.Select(ude => new MyExportsTableModel
                    {
                        ID = ude.ID,
                        CreatedDate = ude.CreatedDate,
                        Status = ude.Status
                    }).ToList()
                };

                return Json(response);
            }
            catch (Exception ex)
            {
                LogHelper.Error("TableHandler_MyExports : Error loading table data", ex);
                return Json(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Download Bulk Document Download .ZIP file
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public FileContentResult MyExportsDownload(int id)
        {
            var logic = new UserLogic();

            var user = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true);

            byte[] content = logic.GetSecurityExportZIPFile(id, user.ID);
            const string mimeType = "application/zip, application/octet-stream, application/x-zip-compressed, multipart/x-zip";

            string fileName = $"Security_Extract_{id}.ZIP";
            Response.AppendHeader("Content-Disposition", $"attachment; filename={fileName}");

            return File(content, mimeType);
        }

        /// <summary>
        /// Record the bulk document download request (for later processing).
        /// </summary>
        /// <returns>True for success, else false</returns>
        /// <param name="documentType"></param>
        /// <param name="recordsSelected"></param>
        [HttpPost]
        public JsonResult RecordSecurityExtractRequest(string filters)
        {
            try
            {
                var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);

                var dataFilterId = cookieData.DataFilterId;
                var dfLogic = new DataFilterLogic();
                var dataFilter = dfLogic.LoadDataFilterById(dataFilterId);

                // load division, sub-division and location keys in current Data Filter (and Locations selection)
                var dashboardLogic = new DashboardLogic();
                var userId = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true).ID;
                var criteria = JsonConvert.DeserializeObject<List<KeyValuePair<string, string>>>(filters);

                var edsCnFilter = criteria.FirstOrDefault(x => x.Key == "EdsCnList").Value?.Split(',').ToList();

                var accountFilter = criteria.FirstOrDefault(x => x.Key == "LPAcctKey").Value;

                var securityExtractMSMQ = new SecurityExtractMSMQ
                {
                    CreatedBy = userId,
                    LpAcctKey = String.IsNullOrEmpty(accountFilter) ? (int?)null : int.Parse(accountFilter),
                    ExtractedUsers = edsCnFilter
                };

                var userLogic = new UserLogic();
                var countExports = userLogic.GetUserSecurityExports(userId).Count;

                bool success = userLogic.QueueSecurityExtractRequest(securityExtractMSMQ);

                if (success)
                    countExports += 1; // the queue will not have had time to have processed the extract, so we'll add one to the current successful extracts

                return Json(
                   new
                   {
                       successFlag = success,
                       count = countExports
                   }
                       , JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                LogHelper.Error("Error recording bulk document download request", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new
                {
                    error = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult TableHandler_Users(DTParameters param)
        {
            try
            {
                var logic = new UserLogic();
                var paging = new PagingInfo(param.Start, param.Length);
                UsersFilters filters = GetTableFilters(param.CustomFilters);

                var data = logic.GetUsers(paging, filters, param.SortOrder);

                var response = new DTResult<UsersTableModel>
                {
                    draw = param.Draw,
                    recordsFiltered = paging.TotalRecords,
                    recordsTotal = paging.TotalRecords,
                    data = data.Select(x => new UsersTableModel
                    {

                        FullName = x.FullName,
                        Status = x.Status,
                        RoleName = (x.RoleID != -1
                                        ? UserResourceHelper.GetLocalisedRoleName(x.RoleName)
                                        : String.Empty),
                        Client = x.Client,
                        UserID = x.UserID,
                        EDS_CN = x.EdsCn,
                        FirstName = x.Forename,
                        LastName = x.Surname,
                        Email = x.Email,
                        AllowActions = (x.RoleID == Roles.Intermediary || x.RoleID == Roles.Client), // see 94700: only Client/Intermediary users are allow to be selected within "Actions" menu
                        HasBeenSelected = filters.SelectedUsers.Contains(x.EdsCn)
                    }).ToList()
                };

                return Json(response);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error loading table data", ex);
                return Json(new { error = ex.Message });
            }
        }

        [HttpGet]
        public JsonResult GetUserEdsCnForCurrentFilters(string filters)
        {
            try
            {
                var logic = new UserLogic();

                var criteria = JsonConvert.DeserializeObject<List<KeyValuePair<string, string>>>(filters);

                var paging = new PagingInfo(0, Int32.MaxValue);

                UsersFilters userFilters = new UsersFilters
                {
                    AccountsFilter = criteria.FirstOrDefault(x => x.Key == "AccountIDs").Value?.Split(',').Select(int.Parse).ToList(),
                    DivisionsFilter = criteria.FirstOrDefault(x => x.Key == "DivisionIDs").Value?.Split(',').Select(int.Parse).ToList(),
                    SubDivisionsFilter = criteria.FirstOrDefault(x => x.Key == "SubDivisionIDs").Value?.Split(',').Select(int.Parse).ToList(),
                    LocationsFilter = criteria.FirstOrDefault(x => x.Key == "LocationIDs").Value?.Split(',').Select(int.Parse).ToList(),
                    RegionsFilter = criteria.FirstOrDefault(x => x.Key == "RegionIDs").Value?.Split(',').Select(int.Parse).ToList(),
                    ClassificationsFilter = criteria.FirstOrDefault(x => x.Key == "ClassificationIDs").Value?.Split(',').Select(int.Parse).ToList(),
                    OtherProvidersFilter = criteria.FirstOrDefault(x => x.Key == "OtherProviderIDs").Value?.Split(',').Select(int.Parse).ToList(),
                    RoleIDFilter = criteria.FirstOrDefault(x => x.Key == "Role").Value?.Split(',').Select(int.Parse).ToList(),
                    EmailFilter = criteria.FirstOrDefault(x => x.Key == "Email").Value,
                    LastNameFilter = criteria.FirstOrDefault(x => x.Key == "LastName").Value
                };

                var data = logic.GetUsers(paging, userFilters, null);

                // return a list of client/intermediary users given current filters
                return Json(data.Where(u => u.RoleID == Roles.Client || u.RoleID == Roles.Intermediary).Select(x => new { edsCn = x.EdsCn }).ToList(), JsonRequestBehavior.AllowGet);
            }
            catch (Exception e)
            {
                LogHelper.Error("Error loading user edscn data", e);
                return Json(new { error = e.Message });
            }

        }


        [HttpPost]
        public JsonResult TableHandler_SelectRecipients(DTParameters param)
        {
            try
            {
                var logic = new UserLogic();
                var paging = new PagingInfo(param.Start, param.Length);
                UsersFilters filters = GetTableFilters(param.CustomFilters);

                var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
                var data = logic.GetUsersForSelectedAccount(paging, cookieData.LPAcctKey, param.SortOrder);

                var response = new DTResult<UsersTableModel>
                {
                    draw = param.Draw,
                    recordsFiltered = paging.TotalRecords,
                    recordsTotal = paging.TotalRecords,
                    data = data.Select(x => new UsersTableModel
                    {

                        FullName = x.FullName,
                        Status = x.Status,
                        RoleName = (x.RoleID != -1
                            ? UserResourceHelper.GetLocalisedRoleName(x.RoleName)
                            : String.Empty),
                        Client = x.Client,
                        UserID = x.UserID,
                        EDS_CN = x.EdsCn,
                        FirstName = x.Forename,
                        LastName = x.Surname,
                        JobTitle = "",
                        Email = x.Email,
                        GapsLocationID = "",
                        StreetAddress1 = "",
                        Country = "",
                        City = "",
                        HasBeenSelected = false
                    }).ToList()
                };

                return Json(response);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error loading table data", ex);
                return Json(new { error = ex.Message });
            }
        }

        [HttpPost]
        public JsonResult TableHandler_SelectRecipientsForLocation(DTParameters param)
        {
            try
            {
                var logic = new UserLogic();
                var paging = new PagingInfo(param.Start, Int32.MaxValue);

                var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
                var acctKey = cookieData.LPAcctKey;


                int? selectedLpAllPiKey = param?.CustomFilters?.FirstOrDefault(x => x.Key == SelectRecipientsParameters.SelectedLocation)?.Value.Split(',').Select(int.Parse).FirstOrDefault();

                List<KeyValuePair<int, List<SelectRecipientsUser>>> multiSelectRecipients = new List<KeyValuePair<int, List<SelectRecipientsUser>>>();
                if (param?.CustomFilters?.FirstOrDefault(x => x.Key == SelectRecipientsParameters.SelectedUsers)?.Value != null)
                {
                    multiSelectRecipients = JsonConvert.DeserializeObject<List<KeyValuePair<int, List<SelectRecipientsUser>>>>(param.CustomFilters?.FirstOrDefault(x => x.Key == SelectRecipientsParameters.SelectedUsers)?.Value);
                }

                var selectedLocationRecipients = multiSelectRecipients.SingleOrDefault(x => x.Key == selectedLpAllPiKey).Value;

                var filters = new SelectRecipientsFilters
                {
                    LpAcctKey = acctKey,
                    SearchTerm = param?.CustomFilters?.FirstOrDefault(x => x.Key == SelectRecipientsParameters.SearchTerm)?.Value?.Replace(",", "") ?? String.Empty,
                    LpAllPiKey = selectedLpAllPiKey
                };

                var data = logic.GetUsersForSelectedAccount(acctKey, filters.LpAllPiKey);

                var response = new DTResult<UsersTableModel>
                {
                    draw = param.Draw,
                    recordsFiltered = paging.TotalRecords,
                    recordsTotal = paging.TotalRecords,
                    data = data.Select(x => new UsersTableModel
                    {

                        FullName = x.FullName,
                        Status = x.Status,
                        RoleName = (x.RoleID != -1
                            ? UserResourceHelper.GetLocalisedRoleName(x.RoleName)
                            : String.Empty),
                        Client = x.Client,
                        UserID = x.UserID,
                        EDS_CN = x.EdsCn,
                        FirstName = x.Forename,
                        LastName = x.Surname,
                        JobTitle = x.JobTitle,
                        Email = x.Email,
                        SiteSurveyContact = x.SiteSurveyContact,
                        SiteRecommendationResponseDesignee = x.SiteRecommendationResponseDesignee,
                        SiteRecommendationAssignedDesignee = x.SiteRecommendationAssignedDesignee,
                        LocationLevel = x.LocationLevel,
                        DivisionLevel = x.DivisionLevel,
                        AccountLevel = x.AccountLevel,
                        HasBeenSelected = selectedLocationRecipients.Any(y => y.UserId == x.UserID),
                        LpAllPiKey = selectedLpAllPiKey,
                        Translator = x.Translator,
                    }).ToList()
                };

                return Json(response);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error loading table data", ex);
                return Json(new { error = ex.Message });
            }
        }




        [Authorize(Roles = "System Administrator,Risk Consultant")]
        [HttpPost]
        public JsonResult TableHandler_UtilisationReport(DTParameters param)
        {
            try
            {
                var filters = new UsersFilters();

                if (param.CustomFilters != null)
                {
                    BuildFilter(param, filters);
                }

                var logic = new UserLogic();
                var allHeaderViewRecords = logic.GetUtilizationHeaderData();
                var allDetailViewRecords = logic.GetUtilizationDetailData();

                var edsUsers = logic.GetFilteredReportUsers(filters);
                var filteredList = new List<ViewUtilizationReportAggregated>();


                var paging = new PagingInfo(param.Start, param.Length);

                var mergedData = filteredList.Concat(from m in edsUsers
                                                     join e in allHeaderViewRecords on m.EdsCn equals e.EdsCn into ps
                                                     from e in ps.DefaultIfEmpty()
                                                     select new ViewUtilizationReportAggregated
                                                     {
                                                         C0To30 = e?.C0To30 ?? 0,
                                                         C31To45 = e?.C31To45 ?? 0,
                                                         C46To90 = e?.C46To90 ?? 0,
                                                         Name = m.FullName,
                                                         C90To365 = e?.C90To365 ?? 0,
                                                         UserID = e?.UserID ?? -1
                                                     });
                var recordsForReportTable =
                mergedData.Select(vr => new UtilizationReportViewModel.ViewUtilizationReportAggregatedModel
                {
                    UserID = vr.UserID,
                    Name = vr.Name,
                    C0To30 = vr.C0To30,
                    C31To45 = vr.C31To45,
                    C46To90 = vr.C46To90,
                    C90To365 = vr.C90To365,

                    DetailRows = (allDetailViewRecords.Select(dr => new UtilizationReportViewModel.UtilizationDetailModel
                    {
                        UserID = dr.UserID,
                        Hits = dr.Hits,
                        Report = dr.Name
                    }).Where(vn => vn.UserID == vr.UserID).ToList())

                });


                var data = SortUserUtlisisationData(param.SortOrder, recordsForReportTable).ToList();
                var response = new DTResult<UtilizationReportViewModel.ViewUtilizationReportAggregatedModel>
                {
                    draw = param.Draw,
                    data = data.Skip(paging.PageOffset).Take(paging.PageSize).ToList(),
                    recordsFiltered = data.Count,
                    recordsTotal = data.Count

                };

                return Json(response);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error loading table data", ex);
                return Json(new
                {
                    error = ex.Message
                });
            }
        }

        public IEnumerable<UtilizationReportViewModel.ViewUtilizationReportAggregatedModel> SortUserUtlisisationData(string sortExpression, IEnumerable<UtilizationReportViewModel.ViewUtilizationReportAggregatedModel> qry)
        {

            if (!string.IsNullOrEmpty(sortExpression))
            {
                var sortDescending = !string.IsNullOrEmpty(sortExpression) &&
                                     sortExpression.ToLower().Contains("desc");

                if (sortExpression.Contains("Name"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Name)
                        : qry.OrderBy(x => x.Name);

                if (sortExpression.Contains("C0To30"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.C0To30)
                        : qry.OrderBy(x => x.C0To30);

                if (sortExpression.Contains("C31To45"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.C31To45)
                        : qry.OrderBy(x => x.C31To45);

                if (sortExpression.Contains("C46To90"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.C46To90)
                        : qry.OrderBy(x => x.C46To90);

                if (sortExpression.Contains("C90To365"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.C90To365)
                        : qry.OrderBy(x => x.C90To365);
            }
            else
            {
                qry = qry.OrderByDescending(x => x.Name);
            }

            return qry;
        }

        public IEnumerable<SecurityReportViewModel.SecurityReportHeaderRowsModel> SortUserSecurityReportData(string sortExpression, IEnumerable<SecurityReportViewModel.SecurityReportHeaderRowsModel> qry, PagingInfo paging)
        {

            if (!string.IsNullOrEmpty(sortExpression))
            {
                var sortDescending = !string.IsNullOrEmpty(sortExpression) &&
                                     sortExpression.ToLower().Contains("desc");

                if (sortExpression.Contains("Name"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Name)
                        : qry.OrderBy(x => x.Name);

                if (sortExpression.Contains("Client"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Client)
                        : qry.OrderBy(x => x.Client);

                if (sortExpression.Contains("Division"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Division)
                        : qry.OrderBy(x => x.Division);

                if (sortExpression.Contains("SubDivision"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.SubDivision)
                        : qry.OrderBy(x => x.SubDivision);

                if (sortExpression.Contains("Location"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Location)
                        : qry.OrderBy(x => x.Location);

                if (sortExpression.Contains("ReportAccess"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.ReportAccess)
                        : qry.OrderBy(x => x.ReportAccess);

                if (sortExpression.Contains("Role"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Role)
                        : qry.OrderBy(x => x.Role);

                if (sortExpression.Contains("Email"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Email)
                        : qry.OrderBy(x => x.Email);

                if (sortExpression.Contains("Documents"))
                    qry = sortDescending
                        ? qry.OrderByDescending(x => x.Documents)
                        : qry.OrderBy(x => x.Documents);

            }
            else
            {
                qry = qry.OrderByDescending(x => x.Name);
            }

            paging.TotalRecords = qry.Count();

            return qry.Skip(paging.PageOffset)
                .Take(paging.PageSize)
                .ToList();
        }

        [Authorize(Roles = "System Administrator,Risk Consultant")]
        [HttpGet]
        public JsonResult LoadRowDetails(int userId)
        {
            try
            {

                var userLogic = new UserLogic();

                var rowDetailsRecords = userLogic.GetDetailDataForSecurityReport(false).Where(x => x.UserID == userId).OrderBy(x => x.Client).ThenBy(x => x.DivisionName).ThenBy(x => x.SubDivisionName).ToList();

                var rowRegionDetailRecords = userLogic.GetRegionDetailDataForSecurityReport().Where(x => x.UserID == userId).OrderBy(x => x.Client).ThenBy(x => x.Region).ToList();
                var rowClassificationDetailRecords = userLogic.GetClassificationDetailDataForSecurityReport().Where(x => x.UserID == userId).OrderBy(x => x.Client).ThenBy(x => x.Classification).ToList();
                var rowOtherProviderDetailRecords = userLogic.GetOtherProviderDetailDataForSecurityReport().Where(x => x.UserID == userId).OrderBy(x => x.Client).ThenBy(x => x.OtherProvider).ToList();

                var userDetails = rowDetailsRecords.Select(x => new UsersSecurityReportDetailTableModel
                {
                    Client = x.Client,
                    DivisionName = x.DivisionName,
                    SubDivisionName = x.SubDivisionName
                });

                var userRegionDetails = rowRegionDetailRecords.Select(x => new UsersSecurityReportDetailTableModel
                {
                    Client = x.Client,
                    Region = x.Region
                });

                var userClassificationDetails = rowClassificationDetailRecords.Select(x => new UsersSecurityReportDetailTableModel
                {
                    Client = x.Client,
                    Classification = x.Classification
                });

                var userOtherProviderDetails = rowOtherProviderDetailRecords.Select(x => new UsersSecurityReportDetailTableModel
                {
                    Client = x.Client,
                    OtherProvider = x.OtherProvider
                });

                return Json(new { userDetails, userRegionDetails, userClassificationDetails, userOtherProviderDetails }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception e)
            {
                LogHelper.Error("Error loading row details data", e);
                return Json(new
                {
                    error = e.Message
                });
            }

        }

        [Authorize(Roles = "System Administrator,Risk Consultant")]
        [HttpPost]
        public JsonResult TableHandler_SecurityReport(DTParameters param)
        {
            try
            {
                var filters = new UsersFilters();

                var paging = new PagingInfo(param.Start, param.Length);
                var pagingAll = new PagingInfo(0, int.MaxValue); // mock paging info to force all user records back

                if (param.CustomFilters != null)
                {
                    BuildFilter(param, filters);
                }

                var logic = new UserLogic();
                var allHeaderViewRecords = logic.GetHeaderDataForSecurityReport();
                var edsUsers = logic.GetUsers(pagingAll, null, param.SortOrder);
                var filteredList = new List<ViewSecurityReportAggregated>();

                var mergedData = filteredList.Concat(from m in edsUsers
                                                     join e in allHeaderViewRecords on m.EdsCn equals e.EdsCn into ps
                                                     from e in ps.DefaultIfEmpty()
                                                     select new ViewSecurityReportAggregated
                                                     {
                                                         Name = m.FullName,
                                                         Client = e?.Client,
                                                         Division = e?.Division,
                                                         SubDivision = e?.SubDivision,
                                                         Location = e?.Location,
                                                         UserID = e?.UserID ?? m.UserID,
                                                         Documents = e?.Documents,
                                                         Email = e?.Email,
                                                         ReportAccess = e?.ReportAccess ?? 0,
                                                         Region = e?.Region,
                                                         Classification = e?.Classification,
                                                         OtherProvider = e?.OtherProvider
                                                     });


                var recordsForReportTable =
                mergedData.Select(vr => new SecurityReportViewModel.SecurityReportHeaderRowsModel
                {
                    UserID = vr.UserID,
                    Name = vr.Name,
                    Client = vr.Client,
                    Location = vr.Location,
                    Division = vr.Division,
                    SubDivision = vr.SubDivision,
                    Email = vr.Email,
                    Documents = vr.Documents,
                    Role = logic.GetUser(vr.UserID)?.UserRoles?.FirstOrDefault()?.Role?.Name,
                    ReportAccess = vr.ReportAccess == 1 ? WebPageResources.Yes : WebPageResources.No,
                    Region = vr.Region,
                    Classification = vr.Classification,
                    OtherProvider = vr.OtherProvider
                });

                IEnumerable<SecurityReportViewModel.SecurityReportHeaderRowsModel> data = SortUserSecurityReportData(param.SortOrder, recordsForReportTable, paging);


                var response = new DTResult<SecurityReportViewModel.SecurityReportHeaderRowsModel>
                {
                    draw = param.Draw,
                    data = data.ToList(),
                    recordsFiltered = paging.TotalRecords,
                    recordsTotal = paging.TotalRecords
                };

                return Json(response, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error loading table data", ex);
                return Json(new
                {
                    error = ex.Message
                });
            }
        }

        private JsonResult LoadUserSecurityReportRowDetails(int userId)
        {
            return Json("");
        }

        private static void BuildFilter(DTParameters param, UsersFilters filters)
        {
            var filtersCount = param.CustomFilters.Count();

            var lastName = param.CustomFilters[0].Value ?? String.Empty;
            List<int> roleID = (param.CustomFilters[1].Value != null) & filtersCount == 2 ? (param.CustomFilters[1].Value.Split(',').Select(int.Parse).ToList()) : new List<int>();
            var accountParamFilters = filtersCount == 3 ? param.CustomFilters[2].Value ?? String.Empty : String.Empty;
            var divisionParamFilters = filtersCount == 4 ? ((param.CustomFilters[3].Value != null) ? param.CustomFilters[2].Value : String.Empty) : String.Empty;
            var locationParamFilters = filtersCount == 5 ? ((param.CustomFilters[4].Value != null) ? param.CustomFilters[2].Value : String.Empty) : String.Empty;
            var subDivisionParamFilters = filtersCount == 6 ? ((param.CustomFilters[5].Value != null) ? param.CustomFilters[2].Value : String.Empty) : String.Empty;

            filters.LastNameFilter = lastName ?? String.Empty;
            filters.RoleIDFilter = roleID;
            filters.AccountsFilter = accountParamFilters.IsEmpty()
                ? new List<int>()
                : accountParamFilters.Split(',').Select(Int32.Parse).ToList();
            filters.DivisionsFilter = divisionParamFilters.IsEmpty()
                ? new List<int>()
                : divisionParamFilters.Split(',').Select(Int32.Parse).ToList();
            filters.LocationsFilter = locationParamFilters.IsEmpty()
                ? new List<int>()
                : locationParamFilters.Split(',').Select(Int32.Parse).ToList();
            filters.SubDivisionsFilter = subDivisionParamFilters.IsEmpty()
                ? new List<int>()
                : subDivisionParamFilters.Split(',').Select(Int32.Parse).ToList();
        }

        [HttpPost]
        public JsonResult ConvertUserIdsToEmailAddresses(Dictionary<string, string> criteria)
        {
            try
            {
                var userLogic = new UserLogic();

                var userIds = new List<int>();

                List<KeyValuePair<int, List<SelectRecipientsUser>>> multiSelectRecipientsByLocation = new List<KeyValuePair<int, List<SelectRecipientsUser>>>();

                if (criteria.FirstOrDefault(x => x.Key == SelectRecipientsParameters.SelectedUsers).Value != null)
                {
                    multiSelectRecipientsByLocation = JsonConvert.DeserializeObject<List<KeyValuePair<int, List<SelectRecipientsUser>>>>(criteria.FirstOrDefault(x => x.Key == SelectRecipientsParameters.SelectedUsers).Value);
                }

                foreach (var location in multiSelectRecipientsByLocation)
                {
                    foreach (var selectRecipientsUser in location.Value)
                    {
                        if (!userIds.Contains(selectRecipientsUser.UserId))
                        {
                            userIds.Add(selectRecipientsUser.UserId);
                        }
                    }
                }

                var recipients = userLogic.GetUserEmailAddressesFromIds(userIds);

                return Json(recipients, JsonRequestBehavior.AllowGet);
            }
            catch (Exception e)
            {
                LogHelper.Error("Could not get recipient email addresses from User Ids provided");
                throw;
            }
        }

        [HttpGet]
        public JsonResult AutoCompleteLastName(string term)
        {
            try
            {
                var logic = new UserLogic();

                if (!Regex.IsMatch(term, "^[a-zA-Z]+$"))
                {
                    return Json("Invalid input for email search at AutoCompleteLastName ", JsonRequestBehavior.DenyGet);
                }

                var results = logic.SearchByLastName(term)
                    .GroupBy(x => x.Surname)
                    .Select(x => new
                    {
                        id = x.Key,
                        text = x.Key
                    });

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error searching by last name", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult AutoCompleteEmail(string term)
        {
            try
            {
                var logic = new UserLogic();

                if (!Regex.IsMatch(term, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$"))
                {
                    return Json("Invalid input for email search at AutoCompleteEmail", JsonRequestBehavior.DenyGet);
                }

                var results = logic.SearchByEmail(term)
                    .GroupBy(x => x.Email)
                    .Select(x => new
                    {
                        id = x.Key,
                        text = x.Key
                    });

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error searching by last name", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult AutoCompleteAccountName(string term)
        {
            try
            {
                var logic = new AccountLogic();

                var results = logic.GetAccountsByName(term)
                    .Select(x => new
                    {
                        x.LpAcctKey,
                        x.Name,
                        Rank = x.Name.StartsWith(term) ? 1 : 2
                    })
                    .OrderBy(x => x.Rank)
                    .ThenBy(x => x.Name)
                    .Select(x => new
                    {
                        id = x.LpAcctKey,
                        text = x.Name
                    });

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error searching by last name", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult AutoCompleteDivisionName(string term)
        {
            try
            {
                var logic = new AccountLogic();

                var results = logic.GetDivisionsByName(term)
                    .Select(x => new
                    {
                        x.LpAcctWebDivKey,
                        x.Name,
                        Rank = x.Name.StartsWith(term) ? 1 : 2
                    })
                    .OrderBy(x => x.Rank)
                    .ThenBy(x => x.Name)
                    .Select(x => new
                    {
                        id = x.LpAcctWebDivKey,
                        text = x.Name
                    });

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error searching by last name", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult AutoCompleteSubDivisionName(string term)
        {
            try
            {
                var logic = new AccountLogic();

                var results = logic.GetSubDivisionsByName(term)
                    .Select(x => new
                    {
                        x.LpSubDivKey,
                        x.Name,
                        Rank = x.Name.StartsWith(term) ? 1 : 2
                    })
                    .OrderBy(x => x.Rank)
                    .ThenBy(x => x.Name)
                    .Select(x => new
                    {
                        id = x.LpSubDivKey,
                        text = x.Name
                    });

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error searching by last name", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult AutoCompleteLocationName(string term)
        {
            try
            {
                var logic = new AccountLogic();

                var results = logic.GetLocationsByName(term)
                    .Select(x => new
                    {
                        x.LpAllPiKey,
                        x.Name,
                        Rank = x.Name.StartsWith(term) ? 1 : 2
                    })
                    .OrderBy(x => x.Rank)
                    .ThenBy(x => x.Name)
                    .Select(x => new
                    {
                        id = x.LpAllPiKey,
                        text = x.Name
                    });

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error searching by last name", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult AutoCompleteRegionName(string term)
        {
            try
            {
                var logic = new AccountLogic();

                var results = logic.GetRegionsByName(term)
                    .Select(x => new
                    {
                        x.LpAcctDivGroupKey,
                        x.Name,
                        Rank = x.Name.StartsWith(term) ? 1 : 2
                    })
                    .OrderBy(x => x.Rank)
                    .ThenBy(x => x.Name)
                    .Select(x => new
                    {
                        id = x.LpAcctDivGroupKey,
                        text = x.Name
                    });

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error searching by region name", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpGet]
        public JsonResult AutoCompleteClassificationName(string term)
        {
            try
            {
                var logic = new AccountLogic();

                var results = logic.GetClassificationsByName(term)
                    .Select(x => new
                    {
                        x.LpAcctDivGroupKey,
                        x.Name,
                        Rank = x.Name.StartsWith(term) ? 1 : 2
                    })
                    .OrderBy(x => x.Rank)
                    .ThenBy(x => x.Name)
                    .Select(x => new
                    {
                        id = x.LpAcctDivGroupKey,
                        text = x.Name
                    });

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error searching by Classification name", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpGet]
        public JsonResult AutoCompleteOtherProviderName(string term)
        {
            try
            {
                var logic = new AccountLogic();

                var results = logic.GetOtherProvidersByName(term)
                    .Select(x => new
                    {
                        x.LpAcctDivGroupKey,
                        x.Name,
                        Rank = x.Name.StartsWith(term) ? 1 : 2
                    })
                    .OrderBy(x => x.Rank)
                    .ThenBy(x => x.Name)
                    .Select(x => new
                    {
                        id = x.LpAcctDivGroupKey,
                        text = x.Name
                    });

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error searching by OtherProvider name", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize(Roles = "System Administrator,Risk Consultant")]
        public ActionResult ExportUtilizationReport(UtilizationReportExportViewModel criteria)
        {
            IExportHelper reportHelper = new GenericExportHelper();
            var logic = new UserLogic();

            List<DataTable> dataTables = new List<DataTable>
            {
                logic.GetDataTableForUtilizationReport(MapUsersFilters(criteria))
            };

            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            var acclogic = new AccountLogic();
            var selectedAccount = acclogic.GetByLpAcctKey(cookieData.LPAcctKey);
            var accountName = selectedAccount.Name;

            List<string[]> columnWidths = new List<string[]>
                                              { new string[]{  "6cm", "2cm", "2cm", "2cm", "2cm", "2cm", "2cm" }
                                              };

            var fileName = WebPageResources.Users_UtilizationReport_Filename;
            var content = reportHelper.RenderChartExportReport(WebPageResources.Users_UtilizationReport_Title, accountName,
                 null, dataTables, columnWidths, reportHelper.GetExportFormat(criteria.Format), fileName, false, out string mimeType, out string fullFilename, WebPageResources.Export_NoDataMessage, false);

            try
            {
                Response.AppendHeader("Content-Disposition", $"attachment; filename={fullFilename}");
                return File(content, mimeType);
            }
            catch (Exception ex)
            {
                content.Dispose();
                throw ex;
            }

        }

        [Authorize(Roles = "System Administrator,Risk Consultant")]
        public ActionResult ExportSecurityReport(SecurityReportExportViewModel criteria)
        {
            IExportHelper reportHelper = new SecurityReportExportHelper();
            var logic = new UserLogic();

            List<DataTable> dataTables = logic.GetDataTableForSecurityReport(MapUsersFilters(criteria));

            List<string[]> columnWidths = new List<string[]>
            {
                new string[]{ "4cm", "4cm", "4cm", "4cm" }
            };

            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            var acclogic = new AccountLogic();
            var selectedAccount = acclogic.GetByLpAcctKey(cookieData.LPAcctKey);
            var accountName = selectedAccount.Name;

            var fileName = WebPageResources.Users_SecurityReport_Filename;

            var content = reportHelper.RenderChartExportReport(WebPageResources.Users_Security_Report_Title, accountName,
                 null, dataTables, columnWidths, reportHelper.GetExportFormat(criteria.Format), fileName, false, out string mimeType, out string fullFilename, WebPageResources.Export_NoDataMessage, false);

            try
            {
                Response.AppendHeader("Content-Disposition", $"attachment; filename={fullFilename}");
                return File(content, mimeType);
            }
            catch (Exception ex)
            {
                content.Dispose();
                throw ex;
            }

        }


        [HttpPost]
        public JsonResult GetClientUsersOfType(Dictionary<string, string> criteria)
        {
            var userLogic = new UserLogic();
            List<int> recIds = new List<int>();
            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);

            var locationLogic = new LocationLogic(this.UserName);

            if (criteria != null && criteria.ContainsKey(SelectRecipientsParameters.SelectedRecommendations) && criteria.FirstOrDefault(x => x.Key == SelectRecipientsParameters.SelectedRecommendations).Value != null)
            {
                recIds = criteria.FirstOrDefault(x => x.Key == SelectRecipientsParameters.SelectedRecommendations).Value.Split(',').Select(int.Parse).ToList();
            }
            var lpAllPiKeys = locationLogic.GetLocationLpAllPiKeysFromRecommendations(recIds, cookieData.LPAcctKey);

            var lpAcctKey = cookieData.LPAcctKey;

            var filters = new SelectRecipientsFilters
            {
                LpAcctKey = lpAcctKey,
                SearchTerm = criteria?.FirstOrDefault(x => x.Key == SelectRecipientsParameters.SearchTerm).Value.Replace(",", "")
            };

            var userType = criteria?.FirstOrDefault(x => x.Key == SelectRecipientsParameters.UserType).Value;

            var clientUsers = userLogic.GetUsersForSelectedAccount(lpAcctKey);


            var userIds = new List<ViewUserMerged>();

            switch (userType)
            {
                case SelectRecipientsParameters.UserType_LocationLevel_RecommendationResponse:
                    userIds = clientUsers.Where(x => x.SiteRecommendationResponseDesignee && x.LocationLevel).ToList();
                    break;

                case SelectRecipientsParameters.UserType_LocationLevel_AllAssignedDesignees:
                    userIds = clientUsers.Where(x => x.SiteRecommendationAssignedDesignee && x.LocationLevel).ToList();
                    break;

                case SelectRecipientsParameters.UserType_LocationLevel_SiteSurveyContacts:
                    userIds = clientUsers.Where(x => x.SiteSurveyContact && x.LocationLevel).ToList();
                    break;

                case SelectRecipientsParameters.UserType_LocationLevel_Others:
                    userIds = clientUsers.Where(x => !x.SiteRecommendationResponseDesignee && !x.SiteRecommendationAssignedDesignee && !x.SiteSurveyContact && x.LocationLevel).ToList();
                    break;

                case SelectRecipientsParameters.UserType_DivisionLevel_RecommendationResponse:
                    userIds = clientUsers.Where(x => x.SiteRecommendationResponseDesignee && x.DivisionLevel).ToList();
                    break;

                case SelectRecipientsParameters.UserType_DivisionLevel_Others:
                    userIds = clientUsers.Where(x => !x.SiteRecommendationResponseDesignee && x.DivisionLevel).ToList();
                    break;

                case SelectRecipientsParameters.UserType_AccountLevel_RecommendationResponse:
                    userIds = clientUsers.Where(x => x.SiteRecommendationResponseDesignee && x.AccountLevel).ToList();
                    break;

                case SelectRecipientsParameters.UserType_AccountLevel_Others:
                    userIds = clientUsers.Where(x => !x.SiteRecommendationResponseDesignee && x.AccountLevel).ToList();
                    break;

            }

            var sru = new List<SelectRecipientsUser>();
            foreach (var location in lpAllPiKeys)
            {
                foreach (var user in userIds)
                    if (userLogic.UserHasAccessToViewLocation(location, user.UserID))
                    {
                        sru.Add(new SelectRecipientsUser
                        {
                            UserId = user.UserID,
                            AccountLevelUser = user.AccountLevel,
                            DivisionLevelUser = user.DivisionLevel,
                            LocationLevelUser = user.LocationLevel,
                            LpAllPiKey = location,
                            RecAssignedDesignee = user.SiteRecommendationAssignedDesignee,
                            RecResponseDesignee = user.SiteRecommendationResponseDesignee,
                            SiteSurveyContact = user.SiteSurveyContact
                        });
                    }
            }

            return Json(sru, JsonRequestBehavior.AllowGet);
        }

        public UserViewModel DbModelToViewModel(UserMerged entity)
        {

            var target = AutoMapperConfig.Mapper.Map<UserMerged, UserViewModel>(entity);

            if (entity.UserRoles.Count > 0)
                target.SelectedRoleID = entity.UserRoles.First().RoleID;

            target.UserStatusName = entity.UserStatu.Name;
            target.SiteRecommendationResponseDesignee = entity.SiteRecResponseDesignee;
            target.SiteRecommendationAssignedDesignee = entity.SiteRecAssignedDesignee;
            target.Translator = entity.Translator;

            return target;
        }

        public UserAccountProfile UsersProfileViewModelToModel(UsersProfileViewModel vm)
        {

            var cookieData = MA2CookieHelper.GetData(ControllerContext, UIHelper.EncryptCookie);
            var data = UserHelper.GetCurrentlyAuthenticatedUser();

            UserAccountProfile model = new UserAccountProfile
            {
                GlobalAsAtDateDay = vm.GlobalAsAtDateDay,
                GlobalAsAtDateMonth = vm.GlobalAsAtDateMonth,
                GlobalAsAtDateYear = vm.GlobalAsAtDateYear,
                UseAccountNo = vm.UseAccountNo,
                UseLocationNo = vm.UseLocationNo,
                LpAcctKey = cookieData.LPAcctKey,
                UserID = data.ID
            };

            return model;
        }
        public User ViewModelToDbModel(UserViewModel model)
        {
            var userLogic = new UserLogic();
            var mapperConfig = new MapperConfiguration(
                cfg =>
                    {
                        cfg.CreateMap<UserViewModel, User>().ForMember(dest => dest.DataFilters, opt => opt.Ignore());
                    });

            var target = mapperConfig.CreateMapper().Map<UserViewModel, User>(model);

            var currentUserId = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true).ID;
            if (model.SelectedRoleID != null)
                target.UserRoles.Add(new UserRole
                {
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = currentUserId,
                    UpdatedDate = DateTime.UtcNow,
                    UpdatedBy = currentUserId,
                    RoleID = (int)model.SelectedRoleID,
                    UserID = model.Id
                });

            var documentTypeGroups = model.AvailableDocumentTypeGroups;
            List<UserDocumentAccess> userDocumentAccesses = new List<UserDocumentAccess>();

            foreach (var group in documentTypeGroups)
            {

                var x = group.DocumentTypePermissions;
                var docPermissions = (from d in x.Where(idv => idv.HasAccess)
                                      select new UserDocumentAccess
                                      {
                                          DocumentTypeID = d.ID,
                                          CreatedBy = currentUserId,
                                          CreatedDate = DateTime.UtcNow,
                                          UpdatedBy = currentUserId,
                                          UpdatedDate = DateTime.UtcNow,
                                          UserID = model.Id
                                      }).ToList();

                userDocumentAccesses = userDocumentAccesses.Concat(docPermissions).ToList();
            }


            target.UserDocumentAccesses = userDocumentAccesses;
            target.SiteRecAssignedDesignee = model.SiteRecommendationAssignedDesignee;
            target.SiteRecResponseDesignee = model.SiteRecommendationResponseDesignee;
            target.AccountAccessAll = model.AccountDivisionLocationSelectionModel.AllAccountsToBeIncluded;

            var serializer = new JavaScriptSerializer();
            var userPermissionsNodesDataList = new List<UserPermissionsNodeData>();

            if (model.AccountDivisionLocationSelectionModel?.NodesDataToBeSavedJson != null)
            {
                var NodesDataToBeSavedJson = serializer.Deserialize<List<UserPermissionsNodeData>>(model.AccountDivisionLocationSelectionModel?.NodesDataToBeSavedJson);
                userPermissionsNodesDataList.AddRange(NodesDataToBeSavedJson);
            }

            if (model.AccountDivisionLocationSelectionModel.AllAccountsToBeIncluded)
            {

                target.AccountAccessStandard = true;
                target.AccountAccessIp = false;
                target.AccountAccessNap = false;

                if (userPermissionsNodesDataList.Count == 0)
                {
                    userPermissionsNodesDataList = new List<UserPermissionsNodeData>();
                    target.UserAccountLevelAccesses = new List<UserAccountLevelAccess>();
                    target.UserDivisionLevelAccesses = new List<UserDivisionLevelAccess>();
                    target.UserSubDivisionLevelAccesses = new List<UserSubDivisionLevelAccess>();
                    target.UserRegionLevelAccesses = new List<UserRegionLevelAccess>();
                    target.UserClassificationLevelAccesses = new List<UserClassificationLevelAccess>();
                    target.UserOtherProviderLevelAccesses = new List<UserOtherProviderLevelAccess>();
                    target.UserLocationLevelAccesses = new List<UserLocationLevelAccess>();
                }
                else
                {
                    var regionsList = userLogic.GetAllRegions();
                    var classificationsList = userLogic.GetAllClassifications();
                    var otherProvidersList = userLogic.GetAllOtherProviders();

                    if (userPermissionsNodesDataList != null && userPermissionsNodesDataList.Count != 0)
                    {
                        if (userPermissionsNodesDataList != null && userPermissionsNodesDataList.Count != 0)
                        {
                            ProcessUserPermissionsJson(userPermissionsNodesDataList, model, currentUserId, target, regionsList, classificationsList, otherProvidersList);
                        }

                        var excludedAccounts = GetExcludedAccounts(userPermissionsNodesDataList, currentUserId, model.Id);
                        var excludedDivisions = GetExcludedDivisions(userPermissionsNodesDataList, currentUserId, model.Id);
                        var excludedSubDivisions = GetExcludedSubDivisions(userPermissionsNodesDataList, currentUserId, model.Id);
                        var excludedRegions = GetExcludedRegions(userPermissionsNodesDataList, currentUserId, model.Id, regionsList);
                        var excludedOtherProviders = GetExcludedOtherProviders(userPermissionsNodesDataList, currentUserId, model.Id, otherProvidersList);
                        var excludedClassifications = GetExcludedClassifications(userPermissionsNodesDataList, currentUserId, model.Id, classificationsList);
                        var excludedLocations = GetExcludedLocations(userPermissionsNodesDataList, currentUserId, model.Id);

                        AppendUntouchedUserPermissionRules(target, excludedAccounts, excludedDivisions, excludedSubDivisions, excludedRegions, excludedClassifications, excludedOtherProviders, excludedLocations);

                    }

                    // at this point here we need to load any other User_____LevelAccess records which were not set from the JSON objects
                    // stored within session storage

                }

            }
            else
            {
                target.AccountAccessStandard = false;
                userPermissionsNodesDataList = userPermissionsNodesDataList.Where(x => x.InclusionStatus != InclusionStatus.StandardAccount).ToList();

                target.AccountAccessIp = model.AccountDivisionLocationSelectionModel.AllIPAccountsToBeIncluded;
                target.AccountAccessNap = model.AccountDivisionLocationSelectionModel.AllNAPAccountsToBeIncluded;


                var regionsList = userLogic.GetAllRegions();
                var classificationsList = userLogic.GetAllClassifications();
                var otherProvidersList = userLogic.GetAllOtherProviders();

                if (userPermissionsNodesDataList != null && userPermissionsNodesDataList.Count != 0)
                {
                    if (userPermissionsNodesDataList != null && userPermissionsNodesDataList.Count != 0)
                    {
                        ProcessUserPermissionsJson(userPermissionsNodesDataList, model, currentUserId, target, regionsList, classificationsList, otherProvidersList);
                    }

                    // at this point here we need to load any other User_____LevelAccess records which were not set from the JSON objects
                    // stored within session storage

                    var excludedAccounts = GetExcludedAccounts(userPermissionsNodesDataList, currentUserId, model.Id);
                    var excludedDivisions = GetExcludedDivisions(userPermissionsNodesDataList, currentUserId, model.Id);
                    var excludedSubDivisions = GetExcludedSubDivisions(userPermissionsNodesDataList, currentUserId, model.Id);
                    var excludedRegions = GetExcludedRegions(userPermissionsNodesDataList, currentUserId, model.Id, regionsList);
                    var excludedOtherProviders = GetExcludedOtherProviders(userPermissionsNodesDataList, currentUserId, model.Id, otherProvidersList);
                    var excludedClassifications = GetExcludedClassifications(userPermissionsNodesDataList, currentUserId, model.Id, classificationsList);
                    var excludedLocations = GetExcludedLocations(userPermissionsNodesDataList, currentUserId, model.Id);

                    AppendUntouchedUserPermissionRules(target, excludedAccounts, excludedDivisions, excludedSubDivisions, excludedRegions, excludedClassifications, excludedOtherProviders, excludedLocations);

                }
                else
                {
                    target.UserAccountLevelAccesses = userLogic.GetAccountLevelAccessesForUser(target.ID);
                    target.UserDivisionLevelAccesses = userLogic.GetDivisionLevelAccessesForUser(target.ID);
                    target.UserSubDivisionLevelAccesses = userLogic.GetSubDivisionLevelAccessesForUser(target.ID);
                    target.UserRegionLevelAccesses = userLogic.GetRegionLevelAccessesForUser(target.ID);
                    target.UserClassificationLevelAccesses = userLogic.GetClassificationLevelAccessesForUser(target.ID);
                    target.UserOtherProviderLevelAccesses = userLogic.GetOtherProviderLevelAccessesForUser(target.ID);
                    target.UserLocationLevelAccesses = userLogic.GetLocationLevelAccessesForUser(target.ID);
                }
            }


            return target;
        }

        public List<UserNotificationTypeModel> UserNotificationTypeDbModelToModel(List<UserNotificationType> entity)
        {
            var referenceLogic = new ReferenceListLogic();

            bool isAdminOrRiskConsultant = UserHelper.IsUserInRole(Constants.RoleNames.SystemAdministrator) || UserHelper.IsUserInRole(Constants.RoleNames.RiskConsultant);

            var notificationTypes = referenceLogic.GetNotificationTypes();
            var notificationTypeModels = NotificationTypeDbModelToModel(notificationTypes);

            var refLogic = new ReferenceListLogic();
            var frequencies = refLogic.GetFrequencies()
                .OrderBy(x => x.FrequencyString).Select(x => new FrequencyModel()
                {
                    id = x.ID,
                    text = x.FrequencyString

                }).ToList();

            var target = new List<UserNotificationTypeModel>();

            foreach (var userNotification in entity)
            {
                target.Add(AutoMapperConfig.Mapper.Map<UserNotificationType, UserNotificationTypeModel>(userNotification));

            }

            foreach (var notificationType in notificationTypeModels)
            {
                foreach (var userNotification in target)
                {

                    userNotification.Frequencies = frequencies;

                    var currentFrequency = frequencies.FirstOrDefault(fr => fr.id == userNotification.FrequencyId);

                    //set selected frequency to the persisted value
                    if (currentFrequency != null)
                    {
                        userNotification.SelectedFrequency = currentFrequency.id;
                    }

                    if (userNotification.NotificationTypeId == Constants.NotificationType.Documents)
                    {
                        var frequency = frequencies.FirstOrDefault(fr => fr.id == 2);
                        userNotification.SelectedFrequency = userNotification.FrequencyId == null ? frequency.id : userNotification.FrequencyId ?? 2;
                    }

                    if (notificationType.Id != userNotification.NotificationTypeId) continue;
                    userNotification.Description = notificationType.Description;
                    userNotification.isAlert = notificationType.IsAlert;

                    userNotification.UserCanModify = notificationType.Active == false ? false : true;

                    if (userNotification.NotificationTypeId == Constants.NotificationType.Documents)
                    {
                        userNotification.UserCanModifyEmail = true;
                    }
                    else
                    {
                        userNotification.UserCanModifyEmail = false;
                    }

                }
            }

            var result = target.Where(x => (x.NotificationTypeId != Constants.NotificationType.AdministrationDocument &&
            x.NotificationTypeId != Constants.NotificationType.RecommendationResponseResponserequested &&
            x.NotificationTypeId != Constants.NotificationType.RecommendationResponseUpdateRequested &&
            x.NotificationTypeId != Constants.NotificationType.RecommendationResponseReminder &&
            x.NotificationTypeId != Constants.NotificationType.RecommendationResponseOther &&
            x.NotificationTypeId != Constants.NotificationType.RecommendationResponseTargetDateExpired &&
            x.NotificationTypeId != Constants.NotificationType.RecommendationResponseInitialnotice)).ToList();
            return result;
        }

        public List<UserNotificationType> UserNotificationTypeModelToDbModel(
            List<UserNotificationTypeModel> models)
        {
            var target = new List<UserNotificationType>();

            foreach (var userNotification in models)
            {
                target.Add(AutoMapperConfig.Mapper.Map<UserNotificationTypeModel, UserNotificationType>(userNotification));
            }

            foreach (var updatedNotification in target)
            {
                updatedNotification.UpdatedDate = DateTime.Now;
                updatedNotification.UpdatedBy = updatedNotification.UserID;
            }
            return target;
        }

        public List<NotificationTypeModel> NotificationTypeDbModelToModel(List<DbModels.NotificationType> entity)
        {
            var target = new List<NotificationTypeModel>();

            foreach (var notificationType in entity)
            {
                target.Add(AutoMapperConfig.Mapper.Map<DbModels.NotificationType, NotificationTypeModel>(notificationType));
            }

            return target;
        }

        public List<UserNotificationTypeModel> SortAlertsAndNotifications(List<UserNotificationTypeModel> userPreferences)
        {
            var alerts = new List<UserNotificationTypeModel>();

            foreach (var preference in userPreferences)
            {
                if (!preference.isAlert) continue;
                alerts.Add(preference);
            }

            return alerts;
        }

        #region Private Methods

        private void LoadReferenceLists(UsersFiltersViewModel model)
        {
            var refLogic = new ReferenceListLogic();
            var userLogic = new UserLogic();
            var roles = refLogic.GetRoles()
                .OrderBy(x => x.Name)
                .Select(x => new Select2Option
                {
                    id = x.ID.ToString(),
                    text = x.Name
                })
                .ToList();

            //  roles.Insert(0, new Select2Option { id = null, text = "<all>" });
            var user = UserHelper.GetCurrentlyAuthenticatedUser();
            model.RoleOptions = roles;

            model.SecurityExportCount = userLogic.GetUserSecurityExports(user.ID, readyExportsOnly: true).Count;
        }

        private void LoadProfileReferenceLists(UsersProfileViewModel model)
        {

            var refLogic = new ReferenceListLogic();
            var frequencies = refLogic.GetFrequencies()
                .OrderBy(x => x.FrequencyString).Select(x => new FrequencyModel
                {
                    id = x.ID,
                    text = x.FrequencyString

                }).ToList();

            model.Frequencies = frequencies;

            model.MonthOptions = GetMonthsOfTheYear();
            model.MonthOptions.Add(new Select2Option { });

            var monthWithThirtyDays = new List<int> { 4, 6, 9, 11 };

            var endDate = 31;
            if (model.GlobalAsAtDateMonth.HasValue)
            {
                if (model.GlobalAsAtDateMonth.Value == 2)
                {
                    endDate = 28;

                }
                else if (monthWithThirtyDays.Any(x => x == model.GlobalAsAtDateMonth.Value))
                {
                    endDate = 30;
                }
            }

            model.DayOptions = Enumerable.Range(1, endDate).Select(x => x.ToString()).ToList();
            model.DayOptions.Add(null);


        }

        private UsersFilters GetTableFilters(DTFilter[] filters)
        {
            var result = new UsersFilters();
            result.SelectedUsers = new List<string>();

            if (filters != null && filters.Length > 0)
            {
                if (filters.Any(f => f.Key == "LastName"))
                {
                    var val = filters.First(item => item.Key == "LastName").Value;
                    if (val != null)
                        result.LastNameFilter = val;
                }

                if (filters.Any(f => f.Key == "Email"))
                {
                    var val = filters.First(item => item.Key == "Email").Value;
                    if (val != null)
                        result.EmailFilter = val;
                }

                if (filters.Any(f => f.Key == "Role"))
                {
                    var val = filters.First(item => item.Key == "Role").Value;
                    if (val != null)
                        result.RoleIDFilter = val.Split(',').Select(int.Parse).ToList();
                }

                if (filters.Any(f => f.Key == "AccountIDs"))
                {
                    var csv = filters.First(item => item.Key == "AccountIDs").Value;
                    if (!string.IsNullOrEmpty(csv))
                        result.AccountsFilter = csv.Split(',').Select(int.Parse).ToList();
                }

                if (filters.Any(f => f.Key == "DivisionIDs"))
                {
                    var csv = filters.First(item => item.Key == "DivisionIDs").Value;
                    if (!string.IsNullOrEmpty(csv))
                        result.DivisionsFilter = csv.Split(',').Select(int.Parse).ToList();
                }

                if (filters.Any(f => f.Key == "SubDivisionIDs"))
                {
                    var csv = filters.First(item => item.Key == "SubDivisionIDs").Value;
                    if (!string.IsNullOrEmpty(csv))
                        result.SubDivisionsFilter = csv.Split(',').Select(int.Parse).ToList();
                }

                if (filters.Any(f => f.Key == "LocationIDs"))
                {
                    var csv = filters.First(item => item.Key == "LocationIDs").Value;
                    if (!string.IsNullOrEmpty(csv))
                        result.LocationsFilter = csv.Split(',').Select(int.Parse).ToList();
                }

                if (filters.Any(f => f.Key == "RegionIDs"))
                {
                    var csv = filters.First(item => item.Key == "RegionIDs").Value;
                    if (!string.IsNullOrEmpty(csv))
                        result.RegionsFilter = csv.Split(',').Select(int.Parse).ToList();
                }

                if (filters.Any(f => f.Key == "ClassificationIDs"))
                {
                    var csv = filters.First(item => item.Key == "ClassificationIDs").Value;
                    if (!string.IsNullOrEmpty(csv))
                        result.ClassificationsFilter = csv.Split(',').Select(int.Parse).ToList();
                }

                if (filters.Any(f => f.Key == "OtherProviderIDs"))
                {
                    var csv = filters.First(item => item.Key == "OtherProviderIDs").Value;
                    if (!string.IsNullOrEmpty(csv))
                        result.OtherProvidersFilter = csv.Split(',').Select(int.Parse).ToList();
                }

                if (filters.Any(f => f.Key == "SelectedUsers"))
                {
                    var csv = filters.First(item => item.Key == "SelectedUsers").Value;

                    if (!string.IsNullOrEmpty(csv))
                        result.SelectedUsers = csv.Split(',').Select(y => y.Trim()).ToList();
                }
            }

            return result;
        }

        /// <summary>
        /// Process the NodesDataToBeSavedJson in the model and populate the UserAccountLevelAccess, UserDivisionLevelAccess (etc) collections.
        /// </summary>
        /// <param name="model"></param>
        /// <param name="currentUserId"></param>
        /// <param name="target"></param>
        private void ProcessUserPermissionsJson(IList<UserPermissionsNodeData> userPermissionsNodesDataList, UserViewModel model, int currentUserId, User target, List<AccountGroupType> regionsList, List<AccountGroupType> classificationsList, List<AccountGroupType> otherProvidersList)
        {
            if (model == null) throw new ArgumentNullException(nameof(model), "Cannot be null");
            if (target == null) throw new ArgumentNullException(nameof(target), "Cannot be null");
            // if (String.IsNullOrWhiteSpace(userPermissionsNodesDataList)) throw new Exception("model.AccountDivisionLocationSelectionModel.NodesDataToBeSavedJson must be populated");


            target.UserAccountLevelAccesses = userPermissionsNodesDataList.Where(node => node.InclusionStatus != InclusionStatus.Excluded
                                                                                    && node.Key.LpAcctKey != null
                                                                                    && node.Key.LpAcctWebDivKey == null
                                                                                    && node.Key.LpSubDivKey == null
                                                                                    && node.Key.LpAcctDivGroupKey == null
                                                                                    && node.Key.LpAllPiKey == null)
                                                                                .Select(node =>
                                                                                new UserAccountLevelAccess
                                                                                {
                                                                                    CreatedDate = DateTime.UtcNow,
                                                                                    CreatedBy = currentUserId,
                                                                                    UpdatedDate = DateTime.UtcNow,
                                                                                    UpdatedBy = currentUserId,
                                                                                    LpAcctKey = (int)node.Key.LpAcctKey,
                                                                                    UserID = model.Id,
                                                                                    StandardAccess = (model.AccountDivisionLocationSelectionModel.AllAccountsToBeIncluded),
                                                                                    ForceAllChildrenIncluded = (node.InclusionStatus == InclusionStatus.FullyIncluded),
                                                                                    UserAccountAccessStartDate = node.UserAccountAccessStartDate != null ? new DateTime(node.UserAccountAccessStartDate.Value.Year, node.UserAccountAccessStartDate.Value.Month, node.UserAccountAccessStartDate.Value.Day, 0, 0, 0) : DateTime.Today,
                                                                                    UserAccountAccessExpiryDate = node.UserAccountAccessExpiryDate != null ? new DateTime(node.UserAccountAccessExpiryDate.Value.Year, node.UserAccountAccessExpiryDate.Value.Month, node.UserAccountAccessExpiryDate.Value.Day, 23, 59, 59) : DateTime.MaxValue,
                                                                                }).ToList();

            target.UserDivisionLevelAccesses = userPermissionsNodesDataList.Where(node => node.InclusionStatus != InclusionStatus.Excluded
                                                                                    && node.Key.LpAcctWebDivKey != null
                                                                                    && node.Key.LpSubDivKey == null
                                                                                    && node.Key.LpAcctDivGroupKey == null
                                                                                    && node.Key.LpAllPiKey == null)
                                                                                .Select(node => new UserDivisionLevelAccess
                                                                                {
                                                                                    CreatedDate = DateTime.UtcNow,
                                                                                    CreatedBy = currentUserId,
                                                                                    UpdatedDate = DateTime.UtcNow,
                                                                                    UpdatedBy = currentUserId,
                                                                                    LpAcctWebDivKey = (int)node.Key.LpAcctWebDivKey,
                                                                                    UserID = model.Id,
                                                                                    ForceAllChildrenIncluded = (node.InclusionStatus == InclusionStatus.FullyIncluded)
                                                                                }).ToList();

            target.UserSubDivisionLevelAccesses = userPermissionsNodesDataList.Where(node => node.InclusionStatus != InclusionStatus.Excluded
                                                                                        && node.Key.LpSubDivKey != null
                                                                                        && node.Key.LpAcctDivGroupKey == null
                                                                                        && node.Key.LpAllPiKey == null)
                                                                                    .Select(node => new UserSubDivisionLevelAccess
                                                                                    {
                                                                                        CreatedDate = DateTime.UtcNow,
                                                                                        CreatedBy = currentUserId,
                                                                                        UpdatedDate = DateTime.UtcNow,
                                                                                        UpdatedBy = currentUserId,
                                                                                        LpSubDivKey = (int)node.Key.LpSubDivKey,
                                                                                        UserID = model.Id,
                                                                                        ForceAllChildrenIncluded = (node.InclusionStatus == InclusionStatus.FullyIncluded)
                                                                                    }).ToList();

            target.UserRegionLevelAccesses = userPermissionsNodesDataList.Where(node => node.InclusionStatus != InclusionStatus.Excluded
                                                                                        && node.Key.LpAcctDivGroupKey != null
                                                                                        && node.Key.LpAllPiKey == null
                                                                                        && regionsList.Any(reg => reg.LpAcctDivGroupKey == node.Key.LpAcctDivGroupKey))
                                                                                    .Select(node => new UserRegionLevelAccess
                                                                                    {
                                                                                        CreatedDate = DateTime.UtcNow,
                                                                                        CreatedBy = currentUserId,
                                                                                        UpdatedDate = DateTime.UtcNow,
                                                                                        UpdatedBy = currentUserId,
                                                                                        LpAcctDivGroupKey = (int)node.Key.LpAcctDivGroupKey,
                                                                                        UserID = model.Id,
                                                                                        ForceAllChildrenIncluded = (node.InclusionStatus == InclusionStatus.FullyIncluded)
                                                                                    }).ToList();

            target.UserOtherProviderLevelAccesses = userPermissionsNodesDataList.Where(node => node.InclusionStatus != InclusionStatus.Excluded
                                                                                        && node.Key.LpAcctDivGroupKey != null
                                                                                        && node.Key.LpAllPiKey == null
                                                                                        && otherProvidersList.Any(op => op.LpAcctDivGroupKey == node.Key.LpAcctDivGroupKey))
                                                                                    .Select(node => new UserOtherProviderLevelAccess
                                                                                    {
                                                                                        CreatedDate = DateTime.UtcNow,
                                                                                        CreatedBy = currentUserId,
                                                                                        UpdatedDate = DateTime.UtcNow,
                                                                                        UpdatedBy = currentUserId,
                                                                                        LpAcctDivGroupKey = (int)node.Key.LpAcctDivGroupKey,
                                                                                        UserID = model.Id,
                                                                                        ForceAllChildrenIncluded = (node.InclusionStatus == InclusionStatus.FullyIncluded)
                                                                                    }).ToList();

            target.UserClassificationLevelAccesses = userPermissionsNodesDataList.Where(node => node.InclusionStatus != InclusionStatus.Excluded
                                                                                                && node.Key.LpAcctDivGroupKey != null
                                                                                               && node.Key.LpAllPiKey == null
                                                                                               && classificationsList.Any(cls => cls.LpAcctDivGroupKey == node.Key.LpAcctDivGroupKey))
                                                                                        .Select(node => new UserClassificationLevelAccess
                                                                                        {
                                                                                            CreatedDate = DateTime.UtcNow,
                                                                                            CreatedBy = currentUserId,
                                                                                            UpdatedDate = DateTime.UtcNow,
                                                                                            UpdatedBy = currentUserId,
                                                                                            LpAcctDivGroupKey = (int)node.Key.LpAcctDivGroupKey,
                                                                                            UserID = model.Id,
                                                                                            ForceAllChildrenIncluded = (node.InclusionStatus == InclusionStatus.FullyIncluded)
                                                                                        }).ToList();

            target.UserLocationLevelAccesses = userPermissionsNodesDataList.Where(node => node.InclusionStatus != InclusionStatus.Excluded
                                                                                        && node.Key.LpAllPiKey != null)
                                                                                    .Select(node => new UserLocationLevelAccess
                                                                                    {
                                                                                        CreatedDate = DateTime.UtcNow,
                                                                                        CreatedBy = currentUserId,
                                                                                        UpdatedDate = DateTime.UtcNow,
                                                                                        UpdatedBy = currentUserId,
                                                                                        LpAllPiKey = (int)node.Key.LpAllPiKey,
                                                                                        UserID = model.Id
                                                                                    }).ToList();
        }

        /// <summary>
        /// Persists any "untouched" locations - i.e. those which have been neither added nor excluded through session storage by adding them to
        /// the target's collection of these entities
        /// </summary>

        private void AppendUntouchedUserPermissionRules(User target,
            List<UserAccountLevelAccess> excludedAccounts, List<UserDivisionLevelAccess> excludedDivisions, List<UserSubDivisionLevelAccess> excludedSubDivisions, List<UserRegionLevelAccess> excludedRegions,
            List<UserClassificationLevelAccess> excludedClassifications, List<UserOtherProviderLevelAccess> excludedOtherProviders, List<UserLocationLevelAccess> excludedLocations)
        {
            var userLogic = new UserLogic();
            var locationLogic = new LocationLogic("");

            var existingUserAccountLevelAccessRecords = userLogic.GetAccountLevelAccessesForUser(target.ID);
            var existingUserDivisionLevelAccessRecords = userLogic.GetDivisionLevelAccessesForUser(target.ID);
            var existingUserSubDivisionLevelAccessRecords = userLogic.GetSubDivisionLevelAccessesForUser(target.ID);
            var existingUserRegionLevelAccessRecords = userLogic.GetRegionLevelAccessesForUser(target.ID);
            var existingUserClassificationLevelAccessRecords = userLogic.GetClassificationLevelAccessesForUser(target.ID);
            var existingUserOtherProviderLevelAccessRecords = userLogic.GetOtherProviderLevelAccessesForUser(target.ID);
            var existingUserLocationLevelAccessRecords = userLogic.GetLocationLevelAccessesForUser(target.ID);


            // Remove any possible orphaned records
            existingUserAccountLevelAccessRecords.RemoveAll(o => excludedAccounts.Select(s => s.LpAcctKey).ToList().Contains(o.LpAcctKey));
            existingUserDivisionLevelAccessRecords.RemoveAll(o => excludedDivisions.Select(s => s.LpAcctWebDivKey).ToList().Contains(o.LpAcctWebDivKey));
            existingUserSubDivisionLevelAccessRecords.RemoveAll(o => excludedSubDivisions.Select(s => s.LpSubDivKey).ToList().Contains(o.LpSubDivKey));
            existingUserRegionLevelAccessRecords.RemoveAll(o => excludedRegions.Select(s => s.LpAcctDivGroupKey).ToList().Contains(o.LpAcctDivGroupKey));
            existingUserClassificationLevelAccessRecords.RemoveAll(o => excludedClassifications.Select(s => s.LpAcctDivGroupKey).ToList().Contains(o.LpAcctDivGroupKey));
            existingUserOtherProviderLevelAccessRecords.RemoveAll(o => excludedOtherProviders.Select(s => s.LpAcctDivGroupKey).ToList().Contains(o.LpAcctDivGroupKey));
            existingUserLocationLevelAccessRecords.RemoveAll(o => excludedLocations.Select(s => s.LpAllPiKey).ToList().Contains(o.LpAllPiKey));

            List<int> lpAcctWebDivKeysBelongingToRevokedAccounts = new List<int>();
            List<int> lpSubDivKeysBelongingToRevokedAccounts = new List<int>();
            List<int> lpAllPiKeysBelongingToRevokedAccounts = new List<int>();
            List<int> lpAcctDivGroupKeyBelongingToRevokedAccounts = new List<int>();

            foreach (var excludedAccount in excludedAccounts)
            {
                var orphanedLocations = locationLogic.GetLocationsByLpAcctKey(excludedAccount.LpAcctKey);
                foreach (var orphanedLocation in orphanedLocations)
                {
                    lpAllPiKeysBelongingToRevokedAccounts.Add(orphanedLocation.LpAllPiKey);
                }

                var orphanedDivisions = locationLogic.LoadDivisionsByLPAcctKey(excludedAccount.LpAcctKey);
                foreach (var orphanedDivision in orphanedDivisions)
                {
                    lpAcctWebDivKeysBelongingToRevokedAccounts.Add(orphanedDivision.LpAcctWebDivKey);
                }

                var orphanedSubDivisions = locationLogic.LoadSubDivisionsByLPAcctKey(excludedAccount.LpAcctKey);
                {
                    foreach (var orphanedSubDivision in orphanedSubDivisions)
                    {
                        lpSubDivKeysBelongingToRevokedAccounts.Add(orphanedSubDivision.LpSubDivKey);
                    }
                }

                var orphanedRegionClassificationsOtherProviders = locationLogic.LoadAccountGroupTypeByLpAcctKey(excludedAccount.LpAcctKey);

                foreach (var accountGroupType in orphanedRegionClassificationsOtherProviders)
                {
                    lpAcctDivGroupKeyBelongingToRevokedAccounts.Add(accountGroupType.LpAcctDivGroupKey);
                }
            }

            existingUserDivisionLevelAccessRecords.RemoveAll(o => lpAcctWebDivKeysBelongingToRevokedAccounts.Contains(o.LpAcctWebDivKey));
            existingUserSubDivisionLevelAccessRecords.RemoveAll(o => lpSubDivKeysBelongingToRevokedAccounts.Contains(o.LpSubDivKey));
            existingUserRegionLevelAccessRecords.RemoveAll(o => lpAcctDivGroupKeyBelongingToRevokedAccounts.Contains(o.LpAcctDivGroupKey));
            existingUserClassificationLevelAccessRecords.RemoveAll(o => lpAcctDivGroupKeyBelongingToRevokedAccounts.Contains(o.LpAcctDivGroupKey));
            existingUserOtherProviderLevelAccessRecords.RemoveAll(o => lpAcctDivGroupKeyBelongingToRevokedAccounts.Contains(o.LpAcctDivGroupKey));
            existingUserLocationLevelAccessRecords.RemoveAll(o => lpAllPiKeysBelongingToRevokedAccounts.Contains(o.LpAllPiKey));

            foreach (var accountLevelAccess in existingUserAccountLevelAccessRecords)
            {
                if (!target.UserAccountLevelAccesses.Any(x => accountLevelAccess != null && x.LpAcctKey == accountLevelAccess.LpAcctKey) && !excludedAccounts.Any(x => x.LpAcctKey == accountLevelAccess.LpAcctKey))
                {
                    target.UserAccountLevelAccesses.Add(accountLevelAccess);
                }
            }

            foreach (var divisionLevelAccess in existingUserDivisionLevelAccessRecords)
            {
                if (!target.UserDivisionLevelAccesses.Any(x => divisionLevelAccess != null && x.LpAcctWebDivKey == divisionLevelAccess.LpAcctWebDivKey) && !excludedDivisions.Any(x => x.LpAcctWebDivKey == divisionLevelAccess.LpAcctWebDivKey))
                {
                    target.UserDivisionLevelAccesses.Add(divisionLevelAccess);
                }
            }

            foreach (var SubDivisionLevelAccess in existingUserSubDivisionLevelAccessRecords)
            {
                if (!target.UserSubDivisionLevelAccesses.Any(x => SubDivisionLevelAccess != null && x.LpSubDivKey == SubDivisionLevelAccess.LpSubDivKey) && !excludedSubDivisions.Any(x => x.LpSubDivKey == SubDivisionLevelAccess.LpSubDivKey))
                {
                    target.UserSubDivisionLevelAccesses.Add(SubDivisionLevelAccess);
                }
            }

            foreach (var regionLevelAccess in existingUserRegionLevelAccessRecords)
            {
                if (!target.UserRegionLevelAccesses.Any(x => regionLevelAccess != null && x.LpAcctDivGroupKey == regionLevelAccess.LpAcctDivGroupKey) && !excludedRegions.Any(x => x.LpAcctDivGroupKey == regionLevelAccess.LpAcctDivGroupKey))
                {
                    target.UserRegionLevelAccesses.Add(regionLevelAccess);
                }
            }

            foreach (var classificationLevelAccess in existingUserClassificationLevelAccessRecords)
            {
                if (!target.UserClassificationLevelAccesses.Any(x => classificationLevelAccess != null && x.LpAcctDivGroupKey == classificationLevelAccess.LpAcctDivGroupKey) && !excludedClassifications.Any(x => x.LpAcctDivGroupKey == classificationLevelAccess.LpAcctDivGroupKey))
                {
                    target.UserClassificationLevelAccesses.Add(classificationLevelAccess);
                }
            }

            foreach (var otherProviderLevelAccess in existingUserOtherProviderLevelAccessRecords)
            {
                if (!target.UserOtherProviderLevelAccesses.Any(x => otherProviderLevelAccess != null && x.LpAcctDivGroupKey == otherProviderLevelAccess.LpAcctDivGroupKey) && !excludedOtherProviders.Any(x => x.LpAcctDivGroupKey == otherProviderLevelAccess.LpAcctDivGroupKey))
                {
                    target.UserOtherProviderLevelAccesses.Add(otherProviderLevelAccess);
                }
            }

            foreach (var locationLevelAccess in existingUserLocationLevelAccessRecords)
            {
                if (!target.UserLocationLevelAccesses.Any(x => locationLevelAccess != null && x.LpAllPiKey == locationLevelAccess.LpAllPiKey) && !excludedLocations.Any(x => x.LpAllPiKey == locationLevelAccess.LpAllPiKey))
                {
                    target.UserLocationLevelAccesses.Add(locationLevelAccess);
                }
            }
        }

        private List<UserAccountLevelAccess> GetExcludedAccounts(IList<UserPermissionsNodeData> userPermissionsNodesDataList, int currentUserId, int modelId)
        {
            return userPermissionsNodesDataList.Where(node => node.InclusionStatus == InclusionStatus.Excluded
                                                              && node.Key.LpAcctKey != null
                                                              && node.Key.LpAcctWebDivKey == null
                                                              && node.Key.LpSubDivKey == null
                                                              && node.Key.LpAcctDivGroupKey == null
                                                              && node.Key.LpAllPiKey == null)
                .Select(node => new UserAccountLevelAccess
                {
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = currentUserId,
                    UpdatedDate = DateTime.UtcNow,
                    UpdatedBy = currentUserId,
                    LpAcctKey = (int)node.Key.LpAcctKey,
                    UserID = modelId,
                    ForceAllChildrenIncluded = (node.InclusionStatus == Constants.InclusionStatus.FullyIncluded)
                }).ToList();
        }

        private List<UserDivisionLevelAccess> GetExcludedDivisions(IList<UserPermissionsNodeData> userPermissionsNodesDataList, int currentUserId, int modelId)
        {
            return userPermissionsNodesDataList.Where(node => node.InclusionStatus == InclusionStatus.Excluded
                                                                                    && node.Key.LpAcctWebDivKey != null
                                                                                    && node.Key.LpSubDivKey == null
                                                                                    && node.Key.LpAcctDivGroupKey == null
                                                                                    && node.Key.LpAllPiKey == null)
                                                                                .Select(node => new UserDivisionLevelAccess
                                                                                {
                                                                                    CreatedDate = DateTime.UtcNow,
                                                                                    CreatedBy = currentUserId,
                                                                                    UpdatedDate = DateTime.UtcNow,
                                                                                    UpdatedBy = currentUserId,
                                                                                    LpAcctWebDivKey = (int)node.Key.LpAcctWebDivKey,
                                                                                    UserID = modelId,
                                                                                    ForceAllChildrenIncluded = (node.InclusionStatus == Constants.InclusionStatus.FullyIncluded)
                                                                                }).ToList();
        }

        private List<UserRegionLevelAccess> GetExcludedRegions(IList<UserPermissionsNodeData> userPermissionsNodesDataList, int currentUserId, int modelId, List<AccountGroupType> regionsList)
        {
            return userPermissionsNodesDataList.Where(node => node.InclusionStatus == InclusionStatus.Excluded
                                                                                        && node.Key.LpAcctDivGroupKey != null
                                                                                        && node.Key.LpAllPiKey == null
                                                                                        && regionsList.Any(reg => reg.LpAcctDivGroupKey == node.Key.LpAcctDivGroupKey))
                                                                                    .Select(node => new UserRegionLevelAccess
                                                                                    {
                                                                                        CreatedDate = DateTime.UtcNow,
                                                                                        CreatedBy = currentUserId,
                                                                                        UpdatedDate = DateTime.UtcNow,
                                                                                        UpdatedBy = currentUserId,
                                                                                        LpAcctDivGroupKey = (int)node.Key.LpAcctDivGroupKey,
                                                                                        UserID = modelId,
                                                                                        ForceAllChildrenIncluded = (node.InclusionStatus == InclusionStatus.FullyIncluded)
                                                                                    }).ToList();
        }

        private List<UserClassificationLevelAccess> GetExcludedClassifications(IList<UserPermissionsNodeData> userPermissionsNodesDataList, int currentUserId, int modelId, List<AccountGroupType> classificationsList)
        {
            return userPermissionsNodesDataList.Where(node => node.InclusionStatus == InclusionStatus.Excluded
                                                              && node.Key.LpAcctDivGroupKey != null
                                                              && node.Key.LpAllPiKey == null
                                                              && classificationsList.Any(cls => cls.LpAcctDivGroupKey == node.Key.LpAcctDivGroupKey))
                .Select(node => new UserClassificationLevelAccess
                {
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = currentUserId,
                    UpdatedDate = DateTime.UtcNow,
                    UpdatedBy = currentUserId,
                    LpAcctDivGroupKey = (int)node.Key.LpAcctDivGroupKey,
                    UserID = modelId,
                    ForceAllChildrenIncluded = (node.InclusionStatus == InclusionStatus.FullyIncluded)
                }).ToList();
        }

        private List<UserOtherProviderLevelAccess> GetExcludedOtherProviders(IList<UserPermissionsNodeData> userPermissionsNodesDataList, int currentUserId, int modelId, List<AccountGroupType> otherProvidersList)
        {
            return userPermissionsNodesDataList.Where(node => node.InclusionStatus == InclusionStatus.Excluded
                                                              && node.Key.LpAcctDivGroupKey != null
                                                              && node.Key.LpAllPiKey == null
                                                              && otherProvidersList.Any(op => op.LpAcctDivGroupKey == node.Key.LpAcctDivGroupKey))
                .Select(node => new UserOtherProviderLevelAccess
                {
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = currentUserId,
                    UpdatedDate = DateTime.UtcNow,
                    UpdatedBy = currentUserId,
                    LpAcctDivGroupKey = (int)node.Key.LpAcctDivGroupKey,
                    UserID = modelId,
                    ForceAllChildrenIncluded = (node.InclusionStatus == InclusionStatus.FullyIncluded)
                }).ToList();
        }

        private List<UserLocationLevelAccess> GetExcludedLocations(IList<UserPermissionsNodeData> userPermissionsNodesDataList, int currentUserId, int modelId)
        {
            return userPermissionsNodesDataList.Where(node => node.InclusionStatus == InclusionStatus.Excluded
                                                              && node.Key.LpAllPiKey != null)
                .Select(node => new UserLocationLevelAccess
                {
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = currentUserId,
                    UpdatedDate = DateTime.UtcNow,
                    UpdatedBy = currentUserId,
                    LpAllPiKey = (int)node.Key.LpAllPiKey,
                    UserID = modelId
                }).ToList();
        }

        private List<UserSubDivisionLevelAccess> GetExcludedSubDivisions(IList<UserPermissionsNodeData> userPermissionsNodesDataList, int currentUserId, int modelId)
        {
            return userPermissionsNodesDataList.Where(node => node.InclusionStatus == InclusionStatus.Excluded
                                                              && node.Key.LpSubDivKey != null
                                                              && node.Key.LpAcctDivGroupKey == null
                                                              && node.Key.LpAllPiKey == null)
                .Select(node => new UserSubDivisionLevelAccess
                {
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = currentUserId,
                    UpdatedDate = DateTime.UtcNow,
                    UpdatedBy = currentUserId,
                    LpSubDivKey = (int)node.Key.LpSubDivKey,
                    UserID = modelId,
                    ForceAllChildrenIncluded = (node.InclusionStatus == Constants.InclusionStatus.FullyIncluded)
                }).ToList();
        }
        #endregion

        [HttpGet]
        public JsonResult AccountSelect(string term)
        {
            try
            {
                var logic = new AccountLogic();
                var userId = UserHelper.GetCurrentlyAuthenticatedUser(localDataOnly: true).ID;

                var results = logic.GetAccountsBySearchTermForUser(term.Trim(), userId)
                    .Where(x => x.UserAccountAccessStartDate <= DateTime.UtcNow && x.UserAccountAccessExpiryDate >= DateTime.UtcNow)
                    .Select(x => new
                    {
                        x.LpAcctKey,
                        Name = x.Name + " ( " + x.AccountNo + " , " + x.AccountCode + " ) ",
                        Rank = x.Name.StartsWith(term) ? 1 : 2
                    })
                    .OrderBy(x => x.Rank)
                    .ThenBy(x => x.Name)
                    .Select(x => new
                    {
                        id = x.LpAcctKey,
                        text = x.Name
                    });

                return Json(results, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error searching by last name", ex);
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

    }
}

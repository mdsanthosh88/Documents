﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using XLC.MyAnalysis2.DbAccess.DTO;
using XLC.MyAnalysis2.DbModels.DbConstants;
using XLC.MyAnalysis2.Logic;
using XLC.MyAnalysis2.Resources;
using XLC.MyAnalysis2.Shared;
using XLC.MyAnalysis2.WebPortal.Helpers;
using XLC.MyAnalysis2.WebPortal.Models;

namespace XLC.MyAnalysis2.WebPortal.Controllers
{
    /// <summary>
    /// Controller class to handle loss estimate reporting
    /// </summary>
    public class TranslationController : BaseController
    {
        /// <summary>
        /// DB Language Trasnlation Home Page
        /// </summary>
        /// <returns>View with model containing reference data</returns>
        [NonAction]
        public ActionResult Index()
        {
            UserLogic userLogic = new UserLogic();
            var x = userLogic.GetByEDSCN(this.UserName);

            if (x.Translator == true)
            {
                DBLanguageTransModel model = new DBLanguageTransModel();
                LoadReferenceLists(model);
                return View(model);
            }
            else
            {
                return View("NotAuthorised");
            }
        }

        /// <summary>
        /// Handles call to retrieve Language Table details
        /// </summary>
        /// <param name="param">results filter</param>
        /// <returns>JSON result of loss estimates</returns>
        [SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1126:PrefixCallsCorrectly", Justification = "Reviewed. Suppression is OK here.")]
        [HttpPost]
        public JsonResult TableHandler_GetLanguageRecords(int paramValue)
        {
            try
            {

                DBLanguageTransLogic dbTransLogic = new DBLanguageTransLogic(this.UserName);

                var dbTablelist = dbTransLogic.LoadLanguageTables().Where(x => x.ID == paramValue).ToList();

                if (dbTablelist != null && dbTablelist.Count > 0)
                {
                    int i = -1;
                    var result = dbTransLogic.LoadTranslationforTable(dbTablelist[0].SrcTableName, dbTablelist[0].DstTableName,
                        dbTablelist[0].SourceKey, dbTablelist[0].DestKey, dbTablelist[0].SrcColumnName, dbTablelist[0].DstColumnName).ToList();

                    var data = result.OrderBy(x => x.objEndata.LanguageName)
                        .Select(x => new LanguageResult
                        {
                            objEndata = new LanguageData { LanguageName = x.objEndata.LanguageName == null ? string.Empty : x.objEndata.LanguageName, LCID = x.objEndata.LCID, SourceKey = x.objEndata.SourceKey ?? i--, SourceKey1 = x.objEndata.Sourcekey1, RowVersion = ConvertByteToString(x.objEndata.RowVersion) },
                            objGedata = new LanguageData { LanguageName = x.objGedata.LanguageName == null ? string.Empty : x.objGedata.LanguageName, LCID = x.objGedata.LCID, SourceKey = x.objGedata.SourceKey ?? i--, SourceKey1 = x.objGedata.Sourcekey1, RowVersion = ConvertByteToString(x.objGedata.RowVersion) },
                            objSpdata = new LanguageData { LanguageName = x.objSpdata.LanguageName == null ? string.Empty : x.objSpdata.LanguageName, LCID = x.objSpdata.LCID, SourceKey = x.objSpdata.SourceKey ?? i--, SourceKey1 = x.objSpdata.Sourcekey1, RowVersion = ConvertByteToString(x.objSpdata.RowVersion) },
                            objfrdata = new LanguageData { LanguageName = x.objfrdata.LanguageName == null ? string.Empty : x.objfrdata.LanguageName, LCID = x.objfrdata.LCID, SourceKey = x.objfrdata.SourceKey ?? i--, SourceKey1 = x.objfrdata.Sourcekey1, RowVersion = ConvertByteToString(x.objfrdata.RowVersion) },
                            objItdata = new LanguageData { LanguageName = x.objItdata.LanguageName == null ? string.Empty : x.objItdata.LanguageName, LCID = x.objItdata.LCID, SourceKey = x.objItdata.SourceKey ?? i--, SourceKey1 = x.objItdata.Sourcekey1, RowVersion = ConvertByteToString(x.objItdata.RowVersion) },
                            objPedata = new LanguageData { LanguageName = x.objPedata.LanguageName == null ? string.Empty : x.objPedata.LanguageName, LCID = x.objPedata.LCID, SourceKey = x.objPedata.SourceKey ?? i--, SourceKey1 = x.objPedata.Sourcekey1, RowVersion = ConvertByteToString(x.objPedata.RowVersion) }

                        }).ToList();

                    return Json(data);

                }

                return Json("");
            }
            catch (Exception ex)
            {
                LogHelper.Error("Error loading table data", ex);
                return Json(new
                {
                    error = ex.Message
                });
            }
        }


        /// <summary>
        /// Load reference list of Language tables
        /// </summary>
        /// <param name="model"></param>
        private void LoadReferenceLists(DBLanguageTransModel model)
        {

            DBLanguageTransLogic dbTransLogic = new DBLanguageTransLogic(this.UserName);

            var tranLangtypes = dbTransLogic.LoadLanguageTables()
             .OrderBy(x => x.SrcTableName)
             .Select(x => new Select2Option
             {
                 id = x.ID.ToString(),
                 text = x.SrcTableName
             })
             .ToList();

            var dbTablelistwithNone = tranLangtypes;
            dbTablelistwithNone.Insert(0, new Select2Option { id = null, text = WebPageResources.SelectOption_None });
            dbTablelistwithNone = dbTablelistwithNone.Where(x => x.text != "RecommendationType").ToList();
            model.lstSrcTableNameOptions = dbTablelistwithNone;

        }

        private List<LanguageDBData> ViewModelToDBModel(List<LanguageResult> model)
        {
            List<LanguageDBData> objLangDBList = new List<LanguageDBData>();

            foreach (var x in model)
            {
                ////German
                if (x.objGedata.edited == true)
                {
                    LanguageDBData target = new LanguageDBData
                    {
                        LCID = x.objGedata.LCID,
                        SourceKey = x.objGedata.SourceKey,
                        Sourcekey1 = x.objGedata.SourceKey1,
                        LanguageName = FormatHelper.HtmlEncode(x.objGedata.LanguageName),
                        RowVersion = ConvertStringtoByte(x.objGedata.RowVersion)
                    };
                    objLangDBList.Add(target);
                }

                //Spanish
                if (x.objSpdata.edited == true)
                {
                    LanguageDBData target = new LanguageDBData
                    {
                        LCID = x.objSpdata.LCID,
                        SourceKey = x.objSpdata.SourceKey,
                        Sourcekey1 = x.objSpdata.SourceKey1,
                        LanguageName = FormatHelper.HtmlEncode(x.objSpdata.LanguageName),
                        RowVersion = ConvertStringtoByte(x.objSpdata.RowVersion)
                    };
                    objLangDBList.Add(target);
                }

                //French
                if (x.objfrdata.edited == true)
                {
                    LanguageDBData target = new LanguageDBData
                    {
                        LCID = x.objfrdata.LCID,
                        SourceKey = x.objfrdata.SourceKey,
                        Sourcekey1 = x.objfrdata.SourceKey1,
                        LanguageName = FormatHelper.HtmlEncode(x.objfrdata.LanguageName),
                        RowVersion = ConvertStringtoByte(x.objfrdata.RowVersion)
                    };
                    objLangDBList.Add(target);
                }

                //Italy
                if (x.objItdata.edited == true)
                {
                    LanguageDBData target = new LanguageDBData
                    {
                        LCID = x.objItdata.LCID,
                        SourceKey = x.objItdata.SourceKey,
                        Sourcekey1 = x.objItdata.SourceKey1,
                        LanguageName = FormatHelper.HtmlEncode(x.objItdata.LanguageName),
                        RowVersion = ConvertStringtoByte(x.objItdata.RowVersion)
                    };
                    objLangDBList.Add(target);
                }

                //Portuguese
                if (x.objPedata.edited == true)
                {
                    LanguageDBData target = new LanguageDBData
                    {
                        LCID = x.objPedata.LCID,
                        SourceKey = x.objPedata.SourceKey,
                        Sourcekey1 = x.objPedata.SourceKey1,
                        LanguageName = FormatHelper.HtmlEncode(x.objPedata.LanguageName),
                        RowVersion = ConvertStringtoByte(x.objPedata.RowVersion)
                    };
                    objLangDBList.Add(target);
                }
            }

            return objLangDBList;
        }

        private string ConvertByteToString(byte[] source)
        {
            var val = source != null ? source.Count() > 0 ? Convert.ToBase64String(source) : "0" : "0";
            return val;
        }

        private byte[] ConvertStringtoByte(string source)
        {
            byte[] val = new byte[0];
            if (source != "0")
            {
                return !string.IsNullOrEmpty(source) ? Convert.FromBase64String(source) : val;
            }
            else
            {
                return val;
            }
        }

        [HttpPost]
        public JsonResult Save(List<LanguageResult> model, int tableVal)
        {
            DBLanguageTransLogic dbTransLogic = new DBLanguageTransLogic(this.UserName);
            try
            {

                var result = ViewModelToDBModel(model);

                LogHelper.Info($"Assigning the values to DBModel Object {result.Count}");

                int upsertid = Constants.LanguageErrorCodes.NoResult;
                bool lockChk = false;

                if (result != null && result.Count > 0)
                {
                    string sKey = string.Empty;

                    var dbTablelist = dbTransLogic.LoadLanguageTables().Where(x => x.ID == tableVal).ToList();


                    if (dbTablelist != null && dbTablelist.Count > 0)
                    {

                        lockChk = dbTransLogic.Upsert(result, dbTablelist[0].SrcTableName, dbTablelist[0].DstTableName, dbTablelist[0].DestKey, dbTablelist[0].EntityColumnName, dbTablelist[0].DstColumnName);
                        if (lockChk)
                        {
                            upsertid = Constants.LanguageErrorCodes.Success;
                            LogHelper.Info($"Language transaction Save Success - ID { upsertid}");
                        }
                        else
                        {
                            upsertid = Constants.LanguageErrorCodes.ConcurrencyError;
                            LogHelper.Info($"Language transaction ConcurrencyError - ID { upsertid}");
                        }
                    }

                    LogHelper.Info($"Upsert IsSuccess {lockChk}");
                }

                return Json(new { id = upsertid });
            }
            catch (Exception ex)
            {
                LogHelper.Error($"Language transaction failed  { ex}");
                LogHelper.Error($"Language transaction failed  { ex.InnerException}");
                LogHelper.Error(RequestHelpers.GetRequestInfo(HttpContext), ex);
                return Json(new { error = ex.Message, JsonRequestBehavior.AllowGet });
            }
        }
    }

}